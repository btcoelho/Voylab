"""Bounded operational G0 comparison for TRONCO-01 (maximum 16 generations)."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

from unsloth import FastLanguageModel

BASE_MODEL = "unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit"
BASE_DIR = Path("/home/bcoelho/voynich-lab")
ADAPTER = BASE_DIR / "experiencias/M16_CURRICULO/runs/m16-l4l5-r1/adapter"
M16_DATA = BASE_DIR / "experiencias/M16_CURRICULO/data/sft/validation.jsonl"
M17 = Path("/mnt/c/Users/Bruno/Documents/Codex/2026-10-17/files-pasted-by-the-user-projeto/work/M17_DESCOBERTA_DIAGNOSTICO")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def hash_tree(path: Path) -> str:
    h = hashlib.sha256()
    for file in sorted(p for p in path.rglob("*") if p.is_file()):
        h.update(file.relative_to(path).as_posix().encode())
        h.update(bytes.fromhex(hash_file(file)))
    return h.hexdigest()


def tasks():
    return [
        {
            "task_id": "small_json",
            "task": "Emit the required JSON response.",
            "state": {"task": "Emit the required JSON response.", "response_schema": {"action": "report", "result": "ready"}},
            "validate": lambda x: x.get("action") == "report" and x.get("result") == "ready",
        },
        {
            "task_id": "choose_query",
            "task": "Choose one available query ID and return it in the required JSON response.",
            "state": {"task": "Choose one available query ID and return it in the required JSON response.", "available_query_ids": ["qA", "qB", "qC"], "response_schema": {"action": "query", "query_id": "one ID from available_query_ids"}},
            "validate": lambda x: x.get("action") == "query" and x.get("query_id") in {"qA", "qB", "qC"},
        },
        {
            "task_id": "cite_conflict",
            "task": "The public records contain a conflict for the same input. Report the contradiction and cite both record IDs.",
            "state": {"task": "The public records contain a conflict for the same input. Report the contradiction and cite both record IDs.", "observations": [{"id": "e1", "input": {"x": "same"}, "output": "red"}, {"id": "e2", "input": {"x": "same"}, "output": "blue"}], "response_schema": {"action": "report", "verdict": "contradiction", "evidence_ids": ["e1", "e2"]}},
            "validate": lambda x: x.get("action") == "report" and x.get("verdict") == "contradiction" and set(x.get("evidence_ids", [])) == {"e1", "e2"},
        },
    ]


def native_examples():
    rows = [json.loads(line) for line in M16_DATA.read_text(encoding="utf-8").splitlines() if line.strip()]
    selected = {}
    for index, row in enumerate(rows):
        try:
            state = json.loads(row["prompt"][-1]["content"])
            answer = json.loads(row["completion"][-1]["content"])
        except (KeyError, IndexError, TypeError, json.JSONDecodeError):
            continue
        action = answer.get("action")
        if action in {"query", "commit"} and action not in selected:
            selected[action] = {"task_id": f"native_m16_{action}", "source": str(M16_DATA), "row_index": index, "state": state}
        if set(selected) == {"query", "commit"}:
            break
    if set(selected) != {"query", "commit"}:
        raise RuntimeError(f"Could not recover query+commit examples from validation data; found {sorted(selected)}")
    return list(selected.values())


def render(tokenizer, state: dict, prompt_mode: str) -> str:
    content = json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    messages = [{"role": "user", "content": content}]
    if prompt_mode == "system":
        messages.insert(0, {"role": "system", "content": "Follow the task and response_schema in the user JSON. Return exactly one valid JSON object, with no prose or markdown."})
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


def parse_first_object(text: str):
    decoder = json.JSONDecoder()
    for index, char in enumerate(text):
        if char == "{":
            try:
                value, _ = decoder.raw_decode(text[index:])
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                return value
    return None


def validate_small(task_id, parsed):
    if parsed is None:
        return False, "No complete JSON object was found in the generated text."
    task = tasks_by_id[task_id]
    if task["validate"](parsed):
        return True, None
    if task_id == "small_json":
        return False, f"Expected action='report' and result='ready'; received {parsed!r}."
    if task_id == "choose_query":
        return False, f"Expected action='query' and query_id in ['qA','qB','qC']; received {parsed!r}."
    return False, f"Expected action='report', verdict='contradiction', evidence_ids=['e1','e2']; received {parsed!r}."


def classify(parsed, task_id):
    if parsed is None:
        return "parse_failure"
    if task_id.startswith("native_m16_"):
        action = parsed.get("action")
        if action not in {"query", "commit", "abstain"}:
            return "unsupported_action"
        if action == "query":
            if parsed.get("x") not in parsed.get("__available_experiments", []):
                return "invalid_query_or_missing_validation_context"
        if action == "commit" and not isinstance(parsed.get("hypothesis_id"), str):
            return "invalid_commit"
        return "action_valid"
    return "action_valid" if tasks_by_id[task_id]["validate"](parsed) else "schema_or_semantic_validation_failure"


tasks_by_id = {t["task_id"]: t for t in tasks()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    examples = native_examples()
    base_ref = (Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/refs/main")
    base_revision = base_ref.read_text().strip() if base_ref.exists() else "unresolved-local-cache-ref"
    manifest = {
        "protocol": "TRONCO01-G0-v0.1",
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "max_generations": 16,
        "models": {"base": {"id": BASE_MODEL, "cached_revision": base_revision}, "m16": {"adapter_path": str(ADAPTER), "adapter_tree_sha256": hash_tree(ADAPTER), "base_cached_revision": base_revision}},
        "m16_validation_data": {"path": str(M16_DATA), "sha256": hash_file(M16_DATA), "selected_examples": [{k: v for k, v in e.items() if k != "state"} for e in examples]},
        "m17_source_hashes_before": {name: hash_file(M17 / name) for name in ["llm_agents.py", "action_utils.py", "generator.py", "environment.py", "evaluate_m17.py"]},
        "generation": {"max_new_tokens": 192, "do_sample": False, "temperature": None, "input_truncation": False, "max_input_tokens": 2048},
        "conditions": ["current_user_only", "direct_system_instruction"],
        "planned_generations": 16,
    }
    (out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    question_registry = []
    for task in tasks():
        state_text = json.dumps(task["state"], ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        question_registry.append({"question_id": task["task_id"], "revision": 1, "state": task["state"], "state_sha256": sha256_bytes(state_text.encode()), "split": "engineering_development", "sealed": True})
    for example in examples:
        state_text = json.dumps(example["state"], ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        question_registry.append({"question_id": example["task_id"], "revision": 1, "state": example["state"], "state_sha256": sha256_bytes(state_text.encode()), "split": "m16_validation_development", "source_row_index": example["row_index"], "sealed": True})
    (out / "question_registry.json").write_text(json.dumps(question_registry, ensure_ascii=False, indent=2), encoding="utf-8")
    ledger_path = out / "event_ledger.jsonl"
    prev = "0" * 64
    seq = 0

    def ledger(event):
        nonlocal prev, seq
        body = {"seq": seq, "previous_hash": prev, **event}
        digest = sha256_bytes(json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())
        body["event_hash"] = digest
        with ledger_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(body, ensure_ascii=False, sort_keys=True) + "\n")
        prev, seq = digest, seq + 1

    for question in question_registry:
        ledger({"type": "question_registered", "question_id": question["question_id"], "revision": question["revision"], "evidence_id": f"ev-{seq:04d}", "state_sha256": question["state_sha256"], "split": question["split"]})

    for model_id in ("base", "m16"):
        path = BASE_MODEL if model_id == "base" else str(ADAPTER)
        model, tokenizer = FastLanguageModel.from_pretrained(model_name=path, max_seq_length=2048, dtype=None, load_in_4bit=True)
        FastLanguageModel.for_inference(model)
        model.eval()
        for task in tasks():
            for mode in ("current_user_only", "direct_system_instruction"):
                # The current M17 contract sends the serialized public state as the only user message.
                actual_mode = "current_user_only" if mode == "current_user_only" else "system"
                prompt = render(tokenizer, task["state"], actual_mode)
                prompt_ids = tokenizer(prompt, return_tensors="pt", truncation=False)["input_ids"]
                input_tokens = int(prompt_ids.shape[1])
                if input_tokens > 2048:
                    raise RuntimeError(f"G0 prompt exceeds context limit: {task['task_id']} {input_tokens}")
                inputs = {k: v.to(model.device) for k, v in tokenizer(prompt, return_tensors="pt", truncation=False).items()}
                generation_error = None
                try:
                    with __import__("torch").inference_mode():
                        generated = model.generate(**inputs, max_new_tokens=192, max_length=None, do_sample=False,
                                                   pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
                                                   return_dict_in_generate=True)
                    output_ids = generated.sequences[0, input_tokens:]
                    raw = tokenizer.decode(output_ids, skip_special_tokens=True)
                    parsed = parse_first_object(raw)
                    valid, validation_error = validate_small(task["task_id"], parsed)
                except Exception as exc:
                    output_ids, raw, parsed = [], "", None
                    valid, validation_error = False, None
                    generation_error = f"{type(exc).__name__}: {exc}"
                if generation_error:
                    result_class = "generation_failure"
                elif parsed is None:
                    result_class = "parse_failure"
                elif valid:
                    result_class = "action_valid"
                else:
                    result_class = "schema_or_semantic_validation_failure"
                eos_id = tokenizer.eos_token_id
                eos_reached = bool(len(output_ids) and eos_id is not None and int(output_ids[-1]) == int(eos_id))
                item = {
                    "generation_id": f"{model_id}:{task['task_id']}:{mode}", "model": model_id,
                    "task_id": task["task_id"], "prompt_condition": mode, "state": task["state"],
                    "rendered_prompt": prompt, "prompt_sha256": sha256_bytes(prompt.encode()),
                    "input_tokens": input_tokens, "raw_output": raw, "output_tokens": int(len(output_ids)),
                    "eos_reached": eos_reached, "hit_generation_limit": len(output_ids) >= 192,
                    "parsed_action": parsed, "validation": result_class, "valid": valid,
                    "validation_error": validation_error, "generation_error": generation_error,
                    "finish_reason": "generation_error" if generation_error else "eos" if eos_reached else "max_new_tokens_or_other_stop",
                }
                with (out / "generations.jsonl").open("a", encoding="utf-8") as f:
                    f.write(json.dumps(item, ensure_ascii=False) + "\n")
                ledger({"type": "generation", "generation_id": item["generation_id"], "evidence_id": f"ev-{seq:04d}", "prompt_sha256": item["prompt_sha256"], "raw_output_sha256": sha256_bytes(raw.encode()), "validation": result_class})
                print(json.dumps({"id": item["generation_id"], "input_tokens": input_tokens, "output_tokens": len(output_ids), "eos": eos_reached, "validation": result_class}, ensure_ascii=False), flush=True)
        del model, tokenizer
        __import__("torch").cuda.empty_cache()

    # Native M16 contract: the same two validation examples are given to each model, without a fabricated translation.
    for model_id in ("base", "m16"):
        path = BASE_MODEL if model_id == "base" else str(ADAPTER)
        model, tokenizer = FastLanguageModel.from_pretrained(model_name=path, max_seq_length=2048, dtype=None, load_in_4bit=True)
        FastLanguageModel.for_inference(model)
        model.eval()
        for example in examples:
            prompt = render(tokenizer, example["state"], "current_user_only")
            prompt_ids = tokenizer(prompt, return_tensors="pt", truncation=False)["input_ids"]
            input_tokens = int(prompt_ids.shape[1])
            if input_tokens > 2048:
                raise RuntimeError(f"Native M16 prompt exceeds context limit: {example['task_id']} {input_tokens}")
            inputs = {k: v.to(model.device) for k, v in tokenizer(prompt, return_tensors="pt", truncation=False).items()}
            generation_error = None
            try:
                with __import__("torch").inference_mode():
                    generated = model.generate(**inputs, max_new_tokens=192, max_length=None, do_sample=False,
                                               pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
                                               return_dict_in_generate=True)
                output_ids = generated.sequences[0, input_tokens:]
                raw = tokenizer.decode(output_ids, skip_special_tokens=True)
                parsed = parse_first_object(raw)
            except Exception as exc:
                output_ids, raw, parsed = [], "", None
                generation_error = f"{type(exc).__name__}: {exc}"
            action = parsed.get("action") if parsed else None
            state = example["state"]
            valid = action in {"query", "commit", "abstain"}
            if action == "query":
                valid = isinstance(parsed.get("x"), int) and parsed["x"] in state.get("available_experiments", [])
            elif action == "commit":
                valid = isinstance(parsed.get("hypothesis_id"), str) and parsed["hypothesis_id"] in {h.get("id") for h in state.get("hypotheses", [])}
            elif action == "abstain":
                valid = True
            validation_error = None
            if parsed is None and not generation_error:
                validation_error = "No complete JSON object was found in the generated text."
            elif parsed and not valid:
                if action not in {"query", "commit", "abstain"}:
                    validation_error = f"Unsupported action {action!r}; allowed actions are query, commit, abstain."
                elif action == "query":
                    validation_error = f"Query x={parsed.get('x')!r} is not in available_experiments."
                elif action == "commit":
                    validation_error = f"hypothesis_id={parsed.get('hypothesis_id')!r} does not identify a listed hypothesis."
            category = "generation_failure" if generation_error else "parse_failure" if parsed is None else "action_valid" if valid else "native_contract_failure"
            item = {"generation_id": f"{model_id}:{example['task_id']}:native", "model": model_id,
                    "task_id": example["task_id"], "source_row_index": example["row_index"], "state": state,
                    "rendered_prompt": prompt, "prompt_sha256": sha256_bytes(prompt.encode()),
                    "input_tokens": input_tokens, "raw_output": raw, "output_tokens": int(len(output_ids)),
                    "eos_reached": bool(len(output_ids) and tokenizer.eos_token_id is not None and int(output_ids[-1]) == int(tokenizer.eos_token_id)),
                    "hit_generation_limit": len(output_ids) >= 192, "parsed_action": parsed,
                    "validation": category, "valid": bool(valid)}
            item["validation_error"] = validation_error
            item["generation_error"] = generation_error
            item["finish_reason"] = "generation_error" if generation_error else "eos" if item["eos_reached"] else "max_new_tokens_or_other_stop"
            with (out / "generations.jsonl").open("a", encoding="utf-8") as f:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")
            ledger({"type": "generation", "generation_id": item["generation_id"], "evidence_id": f"ev-{seq:04d}", "prompt_sha256": item["prompt_sha256"], "raw_output_sha256": sha256_bytes(raw.encode()), "validation": category})
            print(json.dumps({"id": item["generation_id"], "input_tokens": input_tokens, "output_tokens": len(output_ids), "eos": item["eos_reached"], "validation": category}, ensure_ascii=False), flush=True)
        del model, tokenizer
        __import__("torch").cuda.empty_cache()

    manifest["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    manifest["generations_completed"] = sum(1 for line in (out / "generations.jsonl").read_text(encoding="utf-8").splitlines() if line.strip())
    manifest["ledger_final_hash"] = prev
    manifest["m17_source_hashes_after"] = {name: hash_file(M17 / name) for name in manifest["m17_source_hashes_before"]}
    manifest["m17_source_unchanged"] = manifest["m17_source_hashes_before"] == manifest["m17_source_hashes_after"]
    (out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
