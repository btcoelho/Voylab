# Auditoria TRONCO-01/M17/G2 — protocolo operacional v2

Este pacote combina a auditoria de validade v1 preservada com a especificação,
avaliador, testes e reanálise retrospectiva v2. Leia `DECISION_V2.md` e
`SPEC_V2.md` antes de interpretar os resultados. A reanálise v2 usa apenas episódios
G1/G2 já registados e não constitui nova amostra.

## Reprodução v2

Requisitos: Python 3.12; `requirements-audit.txt`; fontes históricas incluídas em
`evidence/original/`. No Linux/WSL, a partir desta pasta:

```bash
python3 -m venv /tmp/tronco01-v2-reproduction
/tmp/tronco01-v2-reproduction/bin/python -m pip install -r requirements-audit.txt
export PYTHONDONTWRITEBYTECODE=1
export AUDIT_SOURCE_ROOT="$PWD/evidence/original"
PY=/tmp/tronco01-v2-reproduction/bin/python
$PY -m pytest tests/test_operational_v2.py -q -p no:cacheprovider
$PY reanalyze_v2.py
```

O runtime de modelo não é necessário. A reprodução da reanálise carrega somente o
ambiente determinístico para refazer respostas de consulta preservadas. Não carrega
pesos e não instancia geradores de reservas.

## Conteúdo e proveniência

- `reference_core_v2.py`: avaliação de ajuste, conjunto compatível, certificado e localização direta.
- `tests/test_operational_v2.py`: nove leis/casos do contrato v2.
- `results/retrospective_v2_*`: saída reproduzível da reanálise G1/G2.
- `evidence/original/`: fontes, protocolos e registos selecionados; sem dados privados, pesos ou reservas M17.
- `DECISION_V2.md`: decisão no gate obrigatório.
- `SHA256SUMS_V2.txt`: hashes do conteúdo deste pacote, exceto o próprio ficheiro de hashes.

Resultados e resultados do pacote v1 permanecem etiquetados pela versão que os produziu.
