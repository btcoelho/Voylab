"""Small operational evaluator v2, derived from SPEC_V2.md, without legacy semantics."""
from __future__ import annotations

from itertools import combinations

FIELDS = ("glyph", "setting", "partner", "phase")
SCOPE = {
    "Output depends only on glyph.": ("glyph",),
    "Output depends only on setting.": ("setting",),
    "Output depends on glyph and phase.": ("glyph", "phase"),
}


def prediction(card, inputs):
    fields = SCOPE.get(card["statement"])
    if fields is None:
        raise ValueError("unsupported candidate statement")
    key = "|".join(inputs[field] for field in fields)
    return card["table"][key]


def compatible_set(cards, observations):
    viable = set()
    for card in cards:
        if all(prediction(card, obs["input"]) == obs["output"] for obs in observations):
            viable.add(card["id"])
    return viable


def expected_status(working, observations):
    if not observations:
        return "undetermined"
    if any(prediction(working, obs["input"]) != obs["output"] for obs in observations):
        return "rejected"
    return "supported"


def diagnosis(viable):
    if not viable:
        return "none_fit"
    if len(viable) == 1:
        return "identified"
    return "ambiguous"


def assess(state, report):
    """Return separate target, diagnosis and certificate checks.

    Structural/schema validation is intentionally a prior layer. This function
    assumes the report has the v2 fields and focuses on scientific support.
    """
    obs = state["observations"]
    cards = state["candidate_models"]
    working = state["working_model"]
    viable = compatible_set(cards, obs)
    status = expected_status(working, obs)
    evidence_list = report.get("evidence_ids", [])
    candidate_list = report.get("candidate_model_codes", [])
    cited = set(evidence_list)
    by_id = {item["id"]: item for item in obs}
    cited_rows = [by_id[item] for item in cited if item in by_id]
    if status == "supported":
        certificate = cited == set(by_id)
    elif status == "rejected":
        certificate = any(prediction(working, row["input"]) != row["output"] for row in cited_rows)
    else:
        certificate = not obs and not cited
    declared = set(report.get("candidate_model_codes", []))
    no_duplicate_evidence = len(evidence_list) == len(cited)
    no_duplicate_candidates = len(candidate_list) == len(declared)
    certificate = certificate and no_duplicate_evidence
    return {
        "expected_status": status,
        "status_correct": report.get("verdict") == status,
        "expected_compatible_models": sorted(viable),
        "declared_compatible_models_correct": declared == viable,
        "no_duplicate_ids": no_duplicate_evidence and no_duplicate_candidates,
        "expected_diagnosis": diagnosis(viable),
        "certificate_sufficient": certificate,
        "science_supported": report.get("verdict") == status and declared == viable and certificate and no_duplicate_candidates,
        "unobserved_evidence_ids": sorted(cited - set(by_id)),
    }


def direct_location_witness(observations, cited_ids, feature, values):
    """Whether cited rows contain the stated direct observational contrast."""
    if feature not in FIELDS:
        return False
    by_id = {row["id"]: row for row in observations}
    if not set(cited_ids).issubset(by_id):
        return False
    cited = [by_id[item] for item in set(cited_ids)]
    asserted = set(values if isinstance(values, list) else [values])
    for left, right in combinations(cited, 2):
        a, b = left["input"], right["input"]
        unchanged = all(a[f] == b[f] for f in FIELDS if f != feature)
        if unchanged and a[feature] != b[feature] and left["output"] != right["output"]:
            if {a[feature], b[feature]} == asserted:
                return True
    return False
