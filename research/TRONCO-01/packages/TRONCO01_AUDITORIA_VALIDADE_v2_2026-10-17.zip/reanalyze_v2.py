"""Retrospective-only replay of saved G1/G2 episodes under SPEC_V2.md."""
from __future__ import annotations

from collections import defaultdict
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("AUDIT_SOURCE_ROOT", str(HERE / "evidence/original"))).resolve()
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / "work/M17_DESCOBERTA_DIAGNOSTICO"))
import environment
import reference_core_v2 as v2


def records(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main():
    stages = [("G1v02", "work/TRONCO01_G1/run_20261017_v02"),
              ("G2", "work/TRONCO01_G2/run_20261017_v01")]
    episode_results = []
    grouped = defaultdict(lambda: defaultdict(int))
    for stage, folder in stages:
        directory = ROOT / folder
        schedule = {item["episode_id"]: item for item in records(directory / "schedule.jsonl")}
        episodes = records(directory / "episodes.jsonl")
        events = records(directory / "actions.jsonl")
        actions_by_episode = defaultdict(list)
        for event in events:
            actions_by_episode[(event["condition"], event["episode_id"])].append(event)
        for item in episodes:
            key = (item["condition"], item["episode_id"])
            episode = environment.Episode(schedule[item["episode_id"]]["world"])
            logs = sorted(actions_by_episode[key], key=lambda event: event["step"])
            for event in logs:
                if event["accepted"] and event["action"].get("action") == "query":
                    replay = episode.apply(event["action"])
                    if replay != event["environment_response"]:
                        raise AssertionError(f"saved query replay mismatch: {key} step {event['step']}")
            report = item["report"]
            result = None if report is None else v2.assess(episode.state(), report)
            row = {"stage": stage, "condition": item["condition"], "episode_id": item["episode_id"],
                   "historical_decision": item["decision_correct"], "explicit_report": report is not None,
                   "retrospective_not_a_new_model_trial": True, "assessment_v2": result}
            episode_results.append(row)
            counts = grouped[(stage, item["condition"])]
            counts["episodes"] += 1
            counts["explicit_reports"] += report is not None
            counts["historic_decisions_correct"] += bool(item["decision_correct"])
            if result is not None:
                counts["v2_status_correct"] += result["status_correct"]
                counts["v2_certificate_sufficient"] += result["certificate_sufficient"]
                counts["v2_model_set_exact"] += result["declared_compatible_models_correct"]
                counts["v2_science_supported_joint"] += result["science_supported"]
                counts["v2_duplicate_free"] += result["no_duplicate_ids"]
    summary = {}
    for (stage, condition), values in sorted(grouped.items()):
        summary.setdefault(stage, {})[condition] = dict(values)
    out = HERE / "results"
    out.mkdir(exist_ok=True)
    (out / "retrospective_v2_episodes.json").write_text(json.dumps(episode_results, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (out / "retrospective_v2_summary.json").write_text(json.dumps({
        "protocol": "SPEC_V2.md", "purpose": "retrospective replay only; not new model evidence",
        "query_replay_errors": 0, "conditions": summary,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"episodes": len(episode_results), "explicit_reports": sum(x["explicit_report"] for x in episode_results),
                      "summary_file": str(out / "retrospective_v2_summary.json")}))


if __name__ == "__main__":
    main()
