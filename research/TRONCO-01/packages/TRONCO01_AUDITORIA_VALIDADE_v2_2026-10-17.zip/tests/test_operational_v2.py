from copy import deepcopy
from hypothesis import given, settings, strategies as st

from fixtures import base_state, row
import reference_core_v2 as v2


def make_report(verdict, evidence, candidates):
    return {"verdict": verdict, "evidence_ids": list(evidence), "candidate_model_codes": list(candidates)}


def test_target_and_diagnosis_are_separate():
    s = base_state()
    s["observations"] = [row("a")]
    result = v2.assess(s, make_report("supported", ["a"], ["A", "C"]))
    assert result["science_supported"]
    assert result["expected_diagnosis"] == "ambiguous"


def test_support_requires_complete_observed_history_certificate():
    s = base_state()
    s["observations"] = [row("a"), row("b", glyph="g1", output="0")]
    result = v2.assess(s, make_report("supported", ["a"], ["A", "C"]))
    assert result["status_correct"]
    assert not result["certificate_sufficient"]
    assert not result["science_supported"]


def test_one_cited_counterexample_suffices_to_reject():
    s = base_state()
    s["observations"] = [row("a"), row("b", glyph="g0", phase="t1", output="1")]
    result = v2.assess(s, make_report("rejected", ["b"], ["C"]))
    assert result["status_correct"]
    assert result["certificate_sufficient"]


def test_candidates_are_checked_against_every_public_row():
    s = base_state()
    s["observations"] = [row("a"), row("b", output="1")]
    result = v2.assess(s, make_report("rejected", ["b"], ["A", "C"]))
    assert result["expected_compatible_models"] == []
    assert not result["declared_compatible_models_correct"]


def test_empty_history_is_undetermined_and_no_candidate_fit_is_distinct():
    s = base_state()
    s["observations"] = []
    assert v2.assess(s, make_report("undetermined", [], ["A", "B", "C"]))["expected_diagnosis"] == "ambiguous"
    s["observations"] = [row("a"), row("b", output="1")]
    assert v2.assess(s, make_report("rejected", ["b"], []))["expected_diagnosis"] == "none_fit"


@given(st.permutations(["a", "b", "c"]))
@settings(max_examples=6, deadline=None, derandomize=True)
def test_observation_order_invariance(order):
    s = base_state()
    original = [row("a"), row("b", glyph="g0", phase="t1", output="1"), row("c", glyph="g1")]
    expected = v2.compatible_set(s["candidate_models"], original)
    for permutation in [list(order)]:
        reordered = [next(x for x in original if x["id"] == uid) for uid in permutation]
        assert v2.compatible_set(s["candidate_models"], reordered) == expected
        assert v2.expected_status(s["working_model"], reordered) == "rejected"


def test_consistent_duplicate_does_not_change_truth():
    s = base_state()
    obs = [row("a"), row("b", glyph="g1")]
    before = v2.compatible_set(s["candidate_models"], obs)
    obs.append({**deepcopy(obs[0]), "id": "duplicate"})
    assert v2.compatible_set(s["candidate_models"], obs) == before


def test_location_value_must_be_the_observed_contrast():
    obs = [row("a"), row("b", phase="t1", output="1")]
    assert v2.direct_location_witness(obs, ["a", "b"], "phase", ["t0", "t1"])
    assert not v2.direct_location_witness(obs, ["a", "b"], "phase", ["invented"])
    confounded = [row("a"), row("b", phase="t1", setting="s1", partner="p1", output="1")]
    assert not v2.direct_location_witness(confounded, ["a", "b"], "phase", ["t0", "t1"])


def test_unknown_cited_id_never_certifies_claim():
    s = base_state()
    result = v2.assess(s, make_report("supported", ["a", "invented"], ["A", "C"]))
    assert result["unobserved_evidence_ids"] == ["invented"]
    assert not result["science_supported"]
