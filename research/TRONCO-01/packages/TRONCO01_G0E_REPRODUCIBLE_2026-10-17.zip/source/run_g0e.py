"""Corrected, bounded 32-generation transport gate. Freezes schedule before inference."""
from __future__ import annotations
import hashlib,itertools,json,time,torch
from pathlib import Path
import sys
import unsloth
from transformers import AutoTokenizer
sys.path.insert(0,'/mnt/c/Users/Bruno/Documents/Codex/2026-10-17/files-pasted-by-the-user-projeto/work/TRONCO01_G0C')
from run_g0c import ROOT,BASE,ADAPTER,BALANCED,MAX_NEW,TrieConstraint,canon,sha,validate,generate

OUT=ROOT/'work/TRONCO01_G0E/run_20261017'

def tree_sha(path):
  h=hashlib.sha256()
  for file in sorted(p for p in path.rglob('*') if p.is_file()):
    h.update(file.relative_to(path).as_posix().encode())
    h.update(bytes.fromhex(hashlib.sha256(file.read_bytes()).hexdigest()))
  return h.hexdigest()

def fixtures():
  specs=[
   ('e_query_a','query','qM',0),('e_query_b','query','qT',1),
   ('e_supported_a','supported',None,0),('e_supported_b','supported',None,1),
   ('e_rejected_a','rejected',None,0),('e_rejected_b','rejected',None,1),
   ('e_undetermined_a','undetermined',None,0),('e_undetermined_b','undetermined',None,1)]
  out=[]
  for name,kind,qid,v in specs:
    stem='A' if v==0 else 'B'; h1='H'+stem+'7'; h2='K'+stem+'4'; e1='r'+stem+'Q'; e2='r'+stem+'S'
    obs=[{'id':e1,'input':{'glyph':'g'+stem+'1','setting':'s'+stem+'1','partner':'p'+stem+'1','phase':'t'+stem+'1'},'output':'o'+stem+'1'},
         {'id':e2,'input':{'glyph':'g'+stem+'1','setting':'s'+stem+'1','partner':'p'+stem+'1','phase':'t'+stem+'2'},'output':'o'+stem+'2'}]
    menu=[{'id':'q'+stem+'M','input':{'glyph':'g'+stem+'2','setting':'s'+stem+'2','partner':'p'+stem+'2','phase':'t'+stem+'3'}},
          {'id':'q'+stem+'T','input':{'glyph':'g'+stem+'3','setting':'s'+stem+'3','partner':'p'+stem+'3','phase':'t'+stem+'4'}}]
    state={'task':f'G0e transport fixture {name}. Follow requested_action exactly; this is a transport check, not scientific inference.',
      'device':'fixture_device','working_model':{'id':h1,'statement':'Fixture hypothesis.','table':{}},
      'candidate_models':[{'id':h1,'statement':'Fixture hypothesis.','table':{}},{'id':h2,'statement':'Alternative fixture.','table':{}}],
      'observations':obs,'query_menu':menu,'remaining_query_budget':2,
      'response_schema':{'query':{'action':'query','query_id':'one ID from query_menu'},
       'report':{'action':'report','verdict':'supported | rejected | undetermined','candidate_model_codes':'listed model IDs',
        'evidence_ids':'observed evidence IDs','location':{'feature':'input field or null','value':'value or null'},
        'confidence':'number from 0 to 1','explanation':'short statement'}}}
    if kind=='query': expected={'action':'query','query_id':qid}
    elif kind=='supported': expected={'action':'report','verdict':'supported','candidate_model_codes':[h1],'evidence_ids':[e1],
       'location':{'feature':None,'value':None},'confidence':0.8,'explanation':f'G0e target {stem}.'}
    elif kind=='rejected': expected={'action':'report','verdict':'rejected','candidate_model_codes':[h2],'evidence_ids':[e1,e2],
       'location':{'feature':'glyph','value':'g'+stem+'1'},'confidence':0.9,'explanation':f'G0e target {stem}.'}
    else: expected={'action':'report','verdict':'undetermined','candidate_model_codes':[h1,h2],'evidence_ids':[e1],
       'location':{'feature':None,'value':None},'confidence':0.5,'explanation':f'G0e target {stem}.'}
    state['requested_action']=expected
    out.append({'task_id':name,'kind':kind,'state':state,'expected':expected,'split':'G0e_new_transport'})
  return out

def choices(state):
  req=state['requested_action']; out=[]
  # Keep both action classes available whenever a query is legally available.
  out.extend({'action':'query','query_id':q['id']} for q in state['query_menu'])
  mids=[m['id'] for m in state['candidate_models']]; eids=[e['id'] for e in state['observations']]
  loc={'feature':None,'value':None}
  for verdict in ('supported','rejected','undetermined'):
    out.append({'action':'report','verdict':verdict,'candidate_model_codes':mids if verdict=='undetermined' else [mids[0]],
      'evidence_ids':eids if verdict=='rejected' else [eids[0]],'location':loc,
      'confidence':0.5 if verdict=='undetermined' else 0.8,'explanation':'short statement'})
  # Add the exact target only after validating its schema and public references.
  out.append(req)
  # Deduplicate canonical objects; ensure exact target is reachable before any model loads.
  unique={canon(x):x for x in out}
  return list(unique.values())

def main():
  OUT.mkdir(parents=True,exist_ok=True)
  if any(OUT.iterdir()): raise RuntimeError(f'Nonempty output directory: {OUT}')
  fs=fixtures(); tok=AutoTokenizer.from_pretrained(str(BASE),local_files_only=True,use_fast=True); schedule=[]
  for model in ('base','m16'):
   for f in fs:
    for mode in ('free','constrained'):
      prompt=tok.apply_chat_template([{'role':'system','content':BALANCED},{'role':'user','content':canon(f['state'])}],tokenize=False,add_generation_prompt=True)
      ids=tok(prompt,truncation=False)['input_ids']
      if len(ids)>2048: raise RuntimeError('Prompt exceeds context')
      candidates=choices(f['state'])
      target_reachable=f['expected'] in candidates
      if not target_reachable: raise RuntimeError(f'Target unreachable: {f["task_id"]}')
      if f['state']['query_menu'] and not any(c.get('action')=='query' for c in candidates): raise RuntimeError('Query action missing')
      if not any(c.get('action')=='report' for c in candidates): raise RuntimeError('Report action missing')
      schedule.append({'model':model,'task_id':f['task_id'],'kind':f['kind'],'mode':mode,'state':f['state'],'expected':f['expected'],
        'prompt':prompt,'prompt_sha256':sha(prompt.encode()),'input_tokens':len(ids),'candidate_count':len(candidates),
        'target_reachable':target_reachable,'action_types_permitted':sorted({c['action'] for c in candidates})})
  prereg={'protocol_id':'TRONCO01-G0e-v0.1','frozen_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
    'planned_generations':32,'max_generations':32,'no_retries':True,'model_revision':BASE.name,
    'adapter_path':str(ADAPTER),'adapter_m16_tree_sha256':tree_sha(ADAPTER),'base_sha256':tree_sha(BASE),'balanced_system_sha256':sha(BALANCED.encode()),
    'generation':{'max_new_tokens':MAX_NEW,'do_sample':False,'greedy':True,'input_truncation':False},
    'gate':{'per_model':{'fixtures':8,'exact_action_target':8,'zero_truncations':True,'zero_generation_failures':True},
      'notes':'For constrained arm, all exact targets are inserted into a validated candidate set; both query and report remain available. Score free and constrained arms separately.'},
    'fixtures':fs,'schedule':schedule}
  prereg['sha256']=sha(json.dumps(prereg,sort_keys=True,ensure_ascii=False).encode())
  (OUT/'preregistration.json').write_text(json.dumps(prereg,ensure_ascii=False,indent=2),encoding='utf8')
  (OUT/'schedule.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in schedule),encoding='utf8')
  rows=[]
  for mid in ('base','m16'):
    model,mtok=unsloth.FastLanguageModel.from_pretrained(model_name=str(BASE if mid=='base' else ADAPTER),max_seq_length=2048,dtype=None,load_in_4bit=True)
    unsloth.FastLanguageModel.for_inference(model); model.eval()
    if mtok.get_vocab()!=tok.get_vocab(): raise RuntimeError('Tokenizer mismatch')
    for t in [x for x in schedule if x['model']==mid]:
      constraint=None
      if t['mode']=='constrained':
        opts=choices(t['state']); seqs=[mtok.encode(canon(a),add_special_tokens=False) for a in opts]
        constraint=TrieConstraint(t['input_tokens'],seqs,mtok.eos_token_id)
      result=generate(model,mtok,t,constraint)
      # Keep direct scoring fields and prompt hash, raw output remains in the record.
      result.update({'kind':t['kind'],'expected':t['expected'],'target_reachable_before_inference':t['target_reachable'],
                     'action_types_permitted':t['action_types_permitted']})
      rows.append(result)
      print(json.dumps({'model':mid,'task':t['task_id'],'mode':t['mode'],'strict':result.get('strict_json'),
        'valid':result.get('valid'),'match':result.get('match'),'eos':result.get('eos')},ensure_ascii=False),flush=True)
    del model,mtok; torch.cuda.empty_cache()
  (OUT/'generations.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf8')
  summary={'protocol_id':prereg['protocol_id'],'planned':32,'completed':len(rows),'per_model_mode':{}}
  for mid in ('base','m16'):
   for mode in ('free','constrained'):
    a=[x for x in rows if x['model']==mid and x['mode']==mode]
    summary['per_model_mode'][mid+'_'+mode]={'n':len(a),'strict_json':sum(x.get('strict_json',False) for x in a),
      'valid':sum(x.get('valid',False) for x in a),'exact':sum(x.get('match',False) for x in a),
      'eos':sum(x.get('eos',False) for x in a),'target_reachable':all(x.get('target_reachable_before_inference',False) for x in a)}
  summary['gate_by_model']={m:{'passed':all(summary['per_model_mode'][m+'_'+mode]['n']==8 and summary['per_model_mode'][m+'_'+mode]['exact']==8 and summary['per_model_mode'][m+'_'+mode]['eos']==8 for mode in ('free','constrained'))} for m in ('base','m16')}
  (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')

if __name__=='__main__': main()
