"""Preflighted transport gate using actual M17 dev worlds and Episode.apply."""
from __future__ import annotations
import copy,hashlib,json,sys,time,torch
from pathlib import Path

ROOT=Path('/mnt/c/Users/Bruno/Documents/Codex/2026-10-17/files-pasted-by-the-user-projeto')
M17=ROOT/'work/M17_DESCOBERTA_DIAGNOSTICO'
OUT=ROOT/'work/TRONCO01_G0F/run_20261017'
sys.path.insert(0,str(M17)); sys.path.insert(0,str(ROOT/'work/TRONCO01_G0C'))
import unsloth
from transformers import AutoTokenizer
from generator import make_world,audit_world
from environment import Episode
from run_g0c import BASE,ADAPTER,BALANCED,MAX_NEW,TrieConstraint,canon,sha,generate

def tree_sha(path):
 h=hashlib.sha256()
 for f in sorted(p for p in path.rglob('*') if p.is_file()):
  h.update(f.relative_to(path).as_posix().encode()); h.update(bytes.fromhex(hashlib.sha256(f.read_bytes()).hexdigest()))
 return h.hexdigest()

def get_fixtures():
 categories=['NORMAL','CONTRADICTION','INSUFFICIENCY','CHANGE','HYPOTHESIS_ABSENT']
 counts={'NORMAL':1,'CONTRADICTION':2,'INSUFFICIENCY':2,'CHANGE':2,'HYPOTHESIS_ABSENT':1}
 worlds=[]
 for ci,cat in enumerate(categories):
  for j in range(counts[cat]):
   index=ci*20+j
   w=make_world(cat,'dev_table',53001,index)
   audit=audit_world(w)
   if not audit['identified']: raise RuntimeError(f'World audit failed: {cat}/{index}')
   worlds.append((cat,index,w))
 specs=[('transport_query_1','query'),('transport_query_2','query'),
        ('transport_supported_1','supported'),('transport_supported_2','supported'),
        ('transport_rejected_1','rejected'),('transport_rejected_2','rejected'),
        ('transport_undetermined_1','undetermined'),('transport_undetermined_2','undetermined')]
 fixtures=[]
 for i,(task_id,kind) in enumerate(specs):
  cat,index,w=worlds[i]; public=copy.deepcopy(w['public']); obs=public['observations']; menu=public['query_menu']
  models=[m['id'] for m in public['candidate_models']]
  if kind=='query': target={'action':'query','query_id':menu[(i//1)%len(menu)]['id']}
  elif kind=='supported': target={'action':'report','verdict':'supported','candidate_model_codes':[public['working_model']['id']],
      'evidence_ids':[obs[0]['id']],'location':{'feature':None,'value':None},'confidence':0.8,'explanation':'G0f transport target.'}
  elif kind=='rejected': target={'action':'report','verdict':'rejected','candidate_model_codes':models[:1],
      'evidence_ids':[r['id'] for r in obs[:2]],'location':{},'confidence':0.9,'explanation':'G0f transport target.'}
  else: target={'action':'report','verdict':'undetermined','candidate_model_codes':models,
      'evidence_ids':[obs[0]['id']],'location':{},'confidence':0.5,'explanation':'G0f transport target.'}
  public['task']=f'G0f transport fixture {task_id}. Follow requested_action exactly. Do not infer a scientific conclusion.'
  public['requested_action']=target
  public['response_schema']={'query':{'action':'query','query_id':'one available query_menu ID'},
      'report':{'action':'report','verdict':'supported, rejected, or undetermined','candidate_model_codes':'listed model IDs',
      'evidence_ids':'observed record IDs','location':'object','confidence':'number in [0,1]','explanation':'string'}}
  fixtures.append({'task_id':task_id,'kind':kind,'category_for_scoring':cat,'seed':53001,'family':'dev_table','world_index':index,
      'world_id':w['world_id'],'world':w,'state':public,'expected':target,'split':'development_transport'})
 return fixtures

def permitted(state,target):
 out=[{'action':'query','query_id':q['id']} for q in state['query_menu']]
 obs=state['observations']; mids=[m['id'] for m in state['candidate_models']]
 alternatives=[
  {'action':'report','verdict':'supported','candidate_model_codes':[mids[0]],'evidence_ids':[obs[0]['id']],
   'location':{'feature':None,'value':None},'confidence':0.8,'explanation':'short statement'},
  {'action':'report','verdict':'rejected','candidate_model_codes':mids[:1],'evidence_ids':[r['id'] for r in obs[:2]],
   'location':{},'confidence':0.9,'explanation':'short statement'},
  {'action':'report','verdict':'undetermined','candidate_model_codes':mids,'evidence_ids':[obs[0]['id']],
   'location':{},'confidence':0.5,'explanation':'short statement'}]
 out.extend(alternatives); out.append(target)
 return list({canon(a):a for a in out}.values())

def apply_valid(world,action):
 ep=Episode(world)
 try: response=ep.apply(action)
 except Exception as e: return False,f'{type(e).__name__}: {e}'
 return bool(response.get('accepted')),response.get('error')

def score_raw(raw,state,target,world):
 try: parsed=json.loads(raw.strip())
 except Exception as e: return {'json':False,'schema':False,'valid':False,'match':False,'error':f'{type(e).__name__}: {e}'}
 if not isinstance(parsed,dict): return {'json':False,'schema':False,'valid':False,'match':False,'error':'top-level value is not an object'}
 action=parsed.get('action')
 if action=='query': schema=set(parsed)=={'action','query_id'} and isinstance(parsed.get('query_id'),str)
 elif action=='report':
  schema=(set(parsed)=={'action','verdict','candidate_model_codes','evidence_ids','location','confidence','explanation'} and
   parsed.get('verdict') in {'supported','rejected','undetermined'} and isinstance(parsed.get('candidate_model_codes'),list) and
   all(isinstance(x,str) for x in parsed['candidate_model_codes']) and isinstance(parsed.get('evidence_ids'),list) and
   all(isinstance(x,str) for x in parsed['evidence_ids']) and isinstance(parsed.get('location'),dict) and
   isinstance(parsed.get('confidence'),(int,float)) and not isinstance(parsed.get('confidence'),bool) and
   0<=parsed['confidence']<=1 and isinstance(parsed.get('explanation'),str))
 else: schema=False
 if not schema: return {'json':True,'schema':False,'valid':False,'match':False,'parsed':parsed,'error':'strict action schema failed'}
 valid,error=apply_valid(world,parsed)
 return {'json':True,'schema':True,'valid':valid,'match':bool(valid and parsed==target),'parsed':parsed,'error':error}

def synthetic_scorer_audit(f):
 world,state,target=f['world'],f['state'],f['expected']; candidates=permitted(state,target)
 if not apply_valid(world,target)[0]: return False,'target rejected by Episode.apply'
 for candidate in candidates:
  accepted,error=apply_valid(world,candidate)
  if not accepted: return False,f'permitted candidate rejected by Episode.apply: {candidate!r}; {error}'
 if target not in candidates: return False,'target omitted from candidate set'
 if not {'query','report'}.issubset({x['action'] for x in candidates}): return False,'both legal action types not available'
 # Negative controls must fail validity; a wrong but legal action must be valid and nonmatching.
 bad=copy.deepcopy(target)
 if bad['action']=='query': bad['query_id']='__not_in_menu__'
 else: bad['evidence_ids']=['__not_observed__']
 if apply_valid(world,bad)[0]: return False,'invalid-reference negative control was accepted'
 wrong=next(x for x in candidates if x['action']!=target['action'])
 if not apply_valid(world,wrong)[0]: return False,'alternative action type was not a legal negative control'
 if wrong==target: return False,'negative control equals target'
 good=score_raw(canon(target),state,target,world)
 if not (good['json'] and good['schema'] and good['valid'] and good['match']): return False,'correct synthetic target did not score as correct'
 bad_raw=score_raw('{"action":',state,target,world)
 if bad_raw['json'] or bad_raw['schema'] or bad_raw['valid']: return False,'malformed/truncated JSON was not rejected'
 missing=copy.deepcopy(target)
 if missing['action']=='query': missing.pop('query_id')
 else: missing.pop('evidence_ids')
 if score_raw(canon(missing),state,target,world)['schema']: return False,'missing required field was accepted'
 wrong_score=score_raw(canon(wrong),state,target,world)
 if not (wrong_score['valid'] and not wrong_score['match']): return False,'legal alternative was not scored as valid and nonmatching'
 return True,{'candidate_count':len(candidates),'target_reachable':True,'target_valid':True,
   'legal_actions':sorted({x['action'] for x in candidates}),'bad_reference_rejected':True,'alternative_action_valid':True,
   'malformed_json_rejected':True,'missing_field_rejected':True,'valid_wrong_action_nonmatch':True}

def main():
 OUT.mkdir(parents=True,exist_ok=True)
 if any(OUT.iterdir()): raise RuntimeError(f'Nonempty output: {OUT}')
 fixtures=get_fixtures(); audit=[]
 for f in fixtures:
  ok,detail=synthetic_scorer_audit(f)
  audit.append({'task_id':f['task_id'],'world_id':f['world_id'],'ok':ok,'detail':detail})
 if not all(x['ok'] for x in audit):
  (OUT/'preflight_failure.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf8')
  raise RuntimeError('Preflight failed; no model was loaded.')
 tok=AutoTokenizer.from_pretrained(str(BASE),local_files_only=True,use_fast=True); schedule=[]
 for model in ('base','m16'):
  for f in fixtures:
   for mode in ('free','constrained'):
    prompt=tok.apply_chat_template([{'role':'system','content':BALANCED},{'role':'user','content':canon(f['state'])}],tokenize=False,add_generation_prompt=True)
    n=len(tok(prompt,truncation=False)['input_ids'])
    if n>2048: raise RuntimeError('Prompt exceeds context; no model was loaded.')
    schedule.append({'model':model,'task_id':f['task_id'],'kind':f['kind'],'mode':mode,'state':f['state'],'expected':f['expected'],
      'prompt':prompt,'prompt_sha256':sha(prompt.encode()),'input_tokens':n,'world_id_for_scoring_only':f['world_id'],
      'legal_action_types':sorted({a['action'] for a in permitted(f['state'],f['expected'])})})
 prereg={'protocol_id':'TRONCO01-G0f-v0.1','frozen_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
  'planned_generations':32,'max_generations':32,'no_retries':True,'base_model_revision':BASE.name,'base_tree_sha256':tree_sha(BASE),
  'adapter_tree_sha256':tree_sha(ADAPTER),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  'm17_sources_sha256':{n:hashlib.sha256((M17/n).read_bytes()).hexdigest() for n in ('llm_agents.py','action_utils.py','generator.py','environment.py','evaluate_m17.py')},
  'generation':{'max_new_tokens':MAX_NEW,'do_sample':False,'temperature':None,'context':2048,'no_truncation':True},
  'gate_evaluated_separately_by_condition':True,'gate_per_condition':{'n':8,'exact_requested_action':8,'zero_invalid_actions':True,'zero_generation_failures':True,'zero_truncations':True},
  'preflight':audit,'fixtures_public_and_targets':[{k:v for k,v in f.items() if k not in ('world',)} for f in fixtures],
  'schedule':schedule}
 prereg['sha256']=sha(json.dumps(prereg,ensure_ascii=False,sort_keys=True).encode())
 (OUT/'preregistration.json').write_text(json.dumps(prereg,ensure_ascii=False,indent=2),encoding='utf8')
 (OUT/'schedule.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in schedule),encoding='utf8')
 (OUT/'preflight.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf8')
 # Model inference begins only after all fixtures, candidate actions and prompts pass preflight.
 rows=[]
 for mid in ('base','m16'):
  model,mtok=unsloth.FastLanguageModel.from_pretrained(model_name=str(BASE if mid=='base' else ADAPTER),max_seq_length=2048,dtype=None,load_in_4bit=True)
  unsloth.FastLanguageModel.for_inference(model); model.eval()
  if mtok.get_vocab()!=tok.get_vocab(): raise RuntimeError('Tokenizer mismatch')
  for t in [x for x in schedule if x['model']==mid]:
   constraint=None
   if t['mode']=='constrained':
    options=permitted(t['state'],t['expected'])
    sequences=[mtok.encode(canon(a),add_special_tokens=False) for a in options]
    constraint=TrieConstraint(t['input_tokens'],sequences,mtok.eos_token_id)
   res=generate(model,mtok,t,constraint)
   parsed=res.get('parsed'); score={'json':False,'schema':False,'valid':False,'match':False,'error':'no parsed object'}
   if isinstance(parsed,dict): score=score_raw(res.get('raw',''),t['state'],t['expected'],next(f['world'] for f in fixtures if f['task_id']==t['task_id']))
   res.update({'kind':t['kind'],'expected':t['expected'],'environment_action_valid':score['valid'],
       'strict_schema':score['schema'],'environment_error':score.get('error')})
   res['match']=score['match']
   rows.append(res)
   print(json.dumps({'model':mid,'task':t['task_id'],'mode':t['mode'],'json':res.get('strict_json'),
     'valid':valid,'match':res['match'],'eos':res.get('eos'),'limit':res.get('hit_limit')},ensure_ascii=False),flush=True)
  del model,mtok; torch.cuda.empty_cache()
 (OUT/'generations.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf8')
 summary={'protocol_id':prereg['protocol_id'],'planned':32,'completed':len(rows),'preflight_passed':True,'conditions':{}}
 for mid in ('base','m16'):
  for mode in ('free','constrained'):
   a=[x for x in rows if x['model']==mid and x['mode']==mode]
   summary['conditions'][mid+'_'+mode]={'n':len(a),'strict_json':sum(x.get('strict_json',False) for x in a),
    'valid_actions':sum(x.get('environment_action_valid',False) for x in a),'exact_valid_targets':sum(x.get('match',False) for x in a),
    'eos':sum(x.get('eos',False) for x in a),'limit_hits':sum(x.get('hit_limit',False) for x in a)}
 summary['gate_by_condition']={k:{'passed':v['n']==8 and v['exact_valid_targets']==8 and v['valid_actions']==8 and v['eos']==8 and v['limit_hits']==0}
   for k,v in summary['conditions'].items()}
 (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')

if __name__=='__main__': main()
