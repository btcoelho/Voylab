# TRONCO-01 G1 archive

The authoritative G1 result is `TRONCO01_G1/run_20261017_v02/`. Its preregistration, 25-world schedule, weight-free preflight, streamed action log, episode outcomes, summaries, and stop status are included. The G1 scripts and the relevant public M17 source files are included for audit.

`TRONCO01_G1/audit_v0_1_invalid_attempt/` preserves the first sentinel attempt. It is excluded from scientific results because its initial schema allowed cross-action fields and incomplete reports. G1 v0.2 used different worlds.

The archive does not include model weights or the M17 private directory. The preregistration records the base snapshot revision and tree hash, M16 adapter tree hash, source hashes, and schedule hash. Exact inference reproduction requires those same local checkpoints, the original full M17 tree, and the recorded Python stack. The source-only M17 copy under `references/` intentionally omits private/reserved material.

The recorded stack for G1 v0.2 was PyTorch 2.14.1+cu132, Transformers 5.17.0, Unsloth 2026.10.6, and `lm-format-enforcer` 0.11.3 on an RTX 4070.

The final report is `TRONCO01_G1_RESULTADO_E_ANALISE_2026-10-17.md`. No reserved split was opened and no fine-tuning was performed.
