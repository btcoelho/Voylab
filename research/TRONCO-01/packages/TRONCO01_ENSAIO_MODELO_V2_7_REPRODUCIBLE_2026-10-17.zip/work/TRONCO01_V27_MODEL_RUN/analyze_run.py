"""Recalculate the saved v2.7 run without importing its scorer or a learned model."""
from pathlib import Path
from collections import Counter, defaultdict
from itertools import combinations
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "work/TRONCO01_TRIAL_v2_7_FROZEN"
RUN = PACKAGE / "run_20261017"
OUT = ROOT / "outputs/TRONCO01_RESULTADO_MODELO_V2_7_2026-10-17.json"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def strict(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    def invalid(value):
        raise ValueError(value)
    value = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    if not isinstance(value, dict):
        raise ValueError("not an object")
    return value


def fits(card, row):
    fields = {"Output depends only on glyph.": ("glyph",),
              "Output depends only on setting.": ("setting",),
              "Output depends on glyph and phase.": ("glyph", "phase")}[card["statement"]]
    key = "|".join(row["input"][name] for name in fields)
    return key in card["table"] and card["table"][key] == row["output"]


def shape_valid(state, action):
    keys = {"action", "verdict", "candidate_model_codes", "diagnosis", "sufficiency", "evidence_ids", "location"}
    if set(action) != keys or action.get("action") != "report":
        return False
    if action["verdict"] not in ("supported", "rejected", "undetermined"):
        return False
    if action["diagnosis"] not in ("none_fit", "identified", "ambiguous"):
        return False
    if action["sufficiency"] not in ("no_observations", "no_candidate_fits", "identity_ambiguous", "identity_resolved"):
        return False
    for field, available in (("candidate_model_codes", [c["id"] for c in state["candidate_models"]]),
                             ("evidence_ids", [r["id"] for r in state["observations"]])):
        values = action[field]
        if not isinstance(values, list) or any(not isinstance(x, str) for x in values):
            return False
        if len(set(values)) != len(values) or len(values) > len(available) or not set(values) <= set(available):
            return False
    loc = action["location"]
    if not isinstance(loc, dict) or set(loc) != {"feature", "values"}:
        return False
    if loc["feature"] not in ("none", "glyph", "setting", "partner", "phase"):
        return False
    values = loc["values"]
    if not isinstance(values, list) or any(not isinstance(x, str) for x in values):
        return False
    pool = {v for row in state["observations"] for v in row["input"].values()}
    return len(set(values)) == len(values) and len(values) <= 2 and set(values) <= pool


def evaluate(state, action, truth):
    rows = state["observations"]
    working = next(c for c in state["candidate_models"] if c["id"] == state["working_model"]["id"])
    cited = [r for r in rows if r["id"] in action["evidence_ids"]]
    if action["verdict"] == "supported":
        signature = lambda r: (tuple(sorted(r["input"].items())), r["output"])
        cert = bool(rows) and {signature(r) for r in rows} <= {signature(r) for r in cited}
    elif action["verdict"] == "rejected":
        cert = any(not fits(working, r) for r in cited)
    else:
        cert = not rows and not action["evidence_ids"]
    loc = action["location"]
    loc_ok = loc == {"feature": "none", "values": []}
    if loc["feature"] != "none" and len(set(loc["values"])) == 2:
        field = loc["feature"]
        for a, b in combinations(cited, 2):
            changing = {key for key in a["input"] if a["input"][key] != b["input"][key]}
            if (changing == {field} and a["output"] != b["output"]
                    and {a["input"][field], b["input"][field]} == set(loc["values"])):
                loc_ok = True
    result = {"legal": True, "expected_verdict": truth["verdict"],
        "expected_candidate_model_codes": truth["candidates"], "expected_diagnosis": truth["diagnosis"],
        "expected_sufficiency": truth["sufficiency"], "verdict_correct": action["verdict"] == truth["verdict"],
        "candidates_correct": sorted(action["candidate_model_codes"]) == truth["candidates"],
        "diagnosis_correct": action["diagnosis"] == truth["diagnosis"],
        "sufficiency_correct": action["sufficiency"] == truth["sufficiency"],
        "evidence_certificate_sufficient": cert, "location_supported": None if loc_ok else False}
    result["joint_success"] = all(result[k] for k in ("legal", "verdict_correct", "candidates_correct",
        "diagnosis_correct", "sufficiency_correct", "evidence_certificate_sufficient")) and loc_ok
    return result


def main():
    manifest = load(PACKAGE / "frozen_manifest.json")
    prereg = load(PACKAGE / "preregistration_draft.json")
    for item in manifest["files"]:
        assert sha((PACKAGE / item["path"]).read_bytes()) == item["sha256"], item["path"]
    record = load(RUN / "execution_record.json")
    assert record["manifest_sha256"] == sha((PACKAGE / "frozen_manifest.json").read_bytes())
    assert record["preregistration_sha256"] == sha((PACKAGE / "preregistration_draft.json").read_bytes())
    assert record["started_at_utc"] > prereg["frozen_at_utc"]
    schedule = [json.loads(line) for line in (PACKAGE / "development_schedule.jsonl").read_text().splitlines()]
    # This reference was written and hashed before loading the checkpoint.
    spec = importlib.util.spec_from_file_location("pre_inference_reference", PACKAGE / "pre_inference_reference.py")
    reference = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reference)
    events = [json.loads(line) for line in (RUN / "events.jsonl").read_text().splitlines()] if (RUN / "events.jsonl").exists() else []
    assert [e["sequence"] for e in events] == list(range(1, len(events) + 1))
    outcomes = load(RUN / "outcomes.json") if (RUN / "outcomes.json").exists() else []
    assert outcomes == [e["outcome"] for e in events if e["kind"] == "episode_outcome"]
    per_ep = defaultdict(list)
    for event in events:
        if "episode_id" in event:
            per_ep[event["episode_id"]].append(event)
    by_id = {x["episode_id"]: x for x in outcomes}
    assert len(by_id) == len(outcomes)
    assert [e["episode_id"] for e in events if e["kind"] == "episode_start"] == [s["episode_id"] for s in schedule[:len(by_id)]]
    components = Counter()
    exploratory = Counter()
    rows = []
    for item in schedule:
        ep = item["episode_id"]; state = item["public_state"]
        truth = reference.reference_labels(state)
        episode = {"episode_id": ep, "stratum": item["stratum"], "expected": truth,
                   "status": by_id.get(ep, {}).get("status", "not_executed")}
        owned = per_ep[ep]
        attempts = [e for e in owned if e["kind"] == "generation_attempt"]
        gens = [e for e in owned if e["kind"] == "generation"]
        raw_events = [e for e in owned if e["kind"] == "raw_action"]
        actions = [e for e in owned if e["kind"] == "action_result"]
        assert len(attempts) <= 1 and len(gens) <= 1 and len(raw_events) == len(gens)
        episode["generation_attempts"] = len(attempts)
        for prompt in (e for e in owned if e["kind"] == "prompt"):
            assert prompt["request_state"] == state
            assert prompt["prompt_sha256"] == sha(prompt["prompt"].encode())
            public_text = prompt["prompt"].split("<|im_start|>user\n", 1)[1].split("<|im_end|>", 1)[0]
            assert json.loads(public_text) == state
            assert (PACKAGE / "SYSTEM_PROMPT.txt").read_text().strip() in prompt["prompt"]
            assert prompt["action_schema_sha256"] == sha(json.dumps(prompt["action_schema"], sort_keys=True, separators=(",", ":")).encode())
        if gens:
            g = gens[0]
            assert g["weights_sha256"] == prereg["experimental_condition"]["weights_sha256"]
            assert g["tokenizer_json_sha256"] == prereg["experimental_condition"]["tokenizer_json_sha256"]
            assert g["generated_token_count"] == len(g["generated_token_ids"]) <= 256
            assert g["settings"] == {"do_sample": False, "max_new_tokens": 256, "max_length": None, "grammar_constrained": True}
            episode.update(eos_terminated=g["eos_terminated"], generated_tokens=g["generated_token_count"],
                           prompt_tokens=g["prompt_token_count"], elapsed_seconds=g["elapsed_seconds"], raw=raw_events[0]["raw"])
            components["eos_terminated"] += bool(g["eos_terminated"])
            components["at_token_limit_without_eos"] += g["generated_token_count"] == 256 and not g["eos_terminated"]
            try:
                action = strict(raw_events[0]["raw"])
            except (ValueError, TypeError) as exc:
                episode.update(json_valid=False, action_shape_valid=False, parse_error=str(exc))
                assert by_id[ep]["status"] == "model_output_failure"
            else:
                episode.update(json_valid=True, action_shape_valid=shape_valid(state, action), action=action)
                components["json_valid"] += 1
                components["action_shape_valid"] += episode["action_shape_valid"]
                # Diagnostic reading of parsed fields, including rejected actions.
                # These counts do not replace the frozen primary endpoint.
                fields = {"verdict_correct": action.get("verdict") == truth["verdict"],
                    "candidates_correct": sorted(action.get("candidate_model_codes", [])) == truth["candidates"],
                    "diagnosis_correct": action.get("diagnosis") == truth["diagnosis"],
                    "sufficiency_correct": action.get("sufficiency") == truth["sufficiency"]}
                fields["all_four_core_fields_correct"] = all(fields.values())
                episode["exploratory_parsed_field_diagnostics"] = fields
                for name, value in fields.items():
                    exploratory[name] += bool(value)
                issues = []
                available_ids = {r["id"] for r in state["observations"]}
                if set(action.get("evidence_ids", [])) - available_ids:
                    issues.append("evidence ID not present in observations")
                loc = action.get("location", {})
                values = loc.get("values", [])
                pool = {v for row in state["observations"] for v in row["input"].values()}
                if set(values) - pool:
                    issues.append("location value not present in observations")
                if len(values) != len(set(values)):
                    issues.append("duplicate location values")
                if loc.get("feature") == "none" and values:
                    issues.append("location none with nonempty values")
                episode["observed_interface_issues"] = issues
                if episode["action_shape_valid"]:
                    assert by_id[ep]["status"] == "reported" and len(actions) == 1
                    assert actions[0]["action"] == action and actions[0]["raw_sequence"] == raw_events[0]["sequence"]
                    calculated = evaluate(state, action, truth)
                    assert calculated == actions[0]["result"]["evaluation"] == by_id[ep]["evaluation"], ep
                    episode["independent_evaluation"] = calculated
                    for name in ("verdict_correct", "candidates_correct", "diagnosis_correct", "sufficiency_correct",
                                 "evidence_certificate_sufficient", "joint_success"):
                        components[name] += bool(calculated[name])
                    components["location_claims"] += action["location"]["feature"] != "none"
                    components["location_claims_supported"] += action["location"]["feature"] != "none" and calculated["location_supported"] is not False
                else:
                    assert by_id[ep]["status"] == "model_output_failure"
        rows.append(episode)
    if (RUN / "summary.json").exists():
        summary = load(RUN / "summary.json")
        assert summary["generation_calls"] == sum(x["generation_attempts"] for x in rows)
        assert summary["joint_successes"] == components["joint_success"]
        assert summary["episodes_attempted"] == len(outcomes)
        assert summary["episodes_planned"] == 10
        assert summary["reported"] == sum(x["status"] == "reported" for x in rows)
        assert summary["model_output_failures"] == sum(x["status"] == "model_output_failure" for x in rows)
    else:
        summary = None
    duplicate = [r for r in rows if r["episode_id"] in ("pilot_01", "pilot_02")]
    result = {"protocol": prereg["protocol"], "execution_record": record, "summary": summary,
        "learned_model_calls_in_trial": sum(x["generation_attempts"] for x in rows),
        "model_weights_loaded_in_trial": bool(any(e["kind"] == "generation" for e in events)),
        "independent_checks_passed": True, "frozen_internal_hashes_verified": len(manifest["files"]),
        "primary_scorer_semantics_imported": False, "private_labels_present_in_saved_prompts": False,
        "calls_made_by_this_analysis": 0, "component_counts": dict(components),
        "exploratory_counts_among_all_parsed_actions": dict(exploratory), "episodes": rows,
        "distinct_public_states": 9, "identical_empty_episodes": ["pilot_01", "pilot_02"],
        "identical_empty_raw_outputs": len(duplicate) == 2 and all("raw" in r for r in duplicate) and duplicate[0]["raw"] == duplicate[1]["raw"],
        "missing_episodes": [r["episode_id"] for r in rows if r["status"] == "not_executed"],
        "historical_v23": {"episodes": 10, "generation_calls": 19, "malformed_outputs": 4, "illegal_decoded_actions": 12, "joint_successes": 0},
        "limits": "Previously exposed development states; one response, no queries; comparison of whole configurations; no generalization or M17 claim."}
    result["artifact_sha256"] = {p.name: sha(p.read_bytes()) for p in RUN.iterdir() if p.is_file()}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in ("execution_record", "episodes", "artifact_sha256")}, indent=2))
    print(str(OUT))


if __name__ == "__main__":
    main()
