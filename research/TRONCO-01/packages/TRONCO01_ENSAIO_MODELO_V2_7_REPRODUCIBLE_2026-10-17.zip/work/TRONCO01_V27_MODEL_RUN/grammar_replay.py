"""Replay saved outputs through real LMFE/tokenizer without loading a learned model."""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "work/TRONCO01_TRIAL_v2_7_FROZEN"
RUN = PACKAGE / "run_20261017"
import torch
import transformers.tokenization_utils as tokenization_utils
from transformers import AutoTokenizer, PreTrainedTokenizerBase
tokenization_utils.PreTrainedTokenizerBase = PreTrainedTokenizerBase
from lmformatenforcer import JsonSchemaParser
from lmformatenforcer.characterlevelparser import UnionParser
from lmformatenforcer.integrations.transformers import build_transformers_prefix_allowed_tokens_fn
sys.path.insert(0, str(PACKAGE))
import harness


def accepts(schema, text):
    parser = JsonSchemaParser(schema)
    for index, character in enumerate(text):
        if character not in parser.get_allowed_characters():
            return {"accepted": False, "rejected_at": index, "character": character}
        parser = parser.add_character(character)
    return {"accepted": parser.can_end()}


def main():
    events = [json.loads(line) for line in (RUN / "events.jsonl").read_text().splitlines()]
    manifest = json.loads((PACKAGE / "frozen_manifest.json").read_text())
    snapshot = next(Path(x["path"]).parent for x in manifest["external_files"] if Path(x["path"]).name == "tokenizer.json")
    tokenizer = AutoTokenizer.from_pretrained(str(snapshot), local_files_only=True)
    rows = []
    for prompt in (e for e in events if e["kind"] == "prompt"):
        ep = prompt["episode_id"]
        generation = next(e for e in events if e["kind"] == "generation" and e["episode_id"] == ep)
        raw = next(e["raw"] for e in events if e["kind"] == "raw_action" and e["episode_id"] == ep)
        parser = UnionParser([JsonSchemaParser(branch) for branch in prompt["action_schema"]["oneOf"]])
        grammar = build_transformers_prefix_allowed_tokens_fn(tokenizer, parser)
        sequence = tokenizer.encode(prompt["prompt"], add_special_tokens=False)
        accepted = True
        for token in generation["generated_token_ids"]:
            if token not in grammar(0, torch.tensor(sequence, dtype=torch.long)):
                accepted = False
                break
            sequence.append(token)
        assert accepted, ep
        assert generation["eos_terminated"] == (generation["generated_token_ids"][-1] == tokenizer.eos_token_id)
        try:
            harness.validate_action_shape(json.loads(raw), prompt["request_state"])
            final_valid = True
        except harness.ModelOutputError:
            final_valid = False
        rows.append({"episode_id": ep, "saved_tokens_all_allowed_by_real_callback": accepted,
                     "final_validator_accepts": final_valid})
    examples = [
        ("empty_array_allowed", {"type": "array", "items": {"type": "string", "enum": ["o1"]}, "maxItems": 0}, "[]", True),
        ("zero_max_items_permits_first_item", {"type": "array", "items": {"type": "string", "enum": ["o1"]}, "maxItems": 0}, '["o1"]', False),
        ("empty_enum_does_not_block_unknown_string", {"type": "string", "enum": []}, '"A"', False),
        ("duplicate_items_not_enforced", {"type": "array", "items": {"type": "string", "enum": ["A", "B"]}, "uniqueItems": True, "maxItems": 3}, '["A","A"]', False),
    ]
    minimal = []
    for name, schema, text, contract in examples:
        actual = accepts(schema, text)
        minimal.append({"name": name, "schema": schema, "text": text,
                        "contract_would_allow": contract, "lmfe_actual": actual,
                        "mismatch": actual["accepted"] != contract})
    source_path = Path(sys.modules["lmformatenforcer.jsonschemaparser"].__file__)
    result = {"analysis": "post-run offline grammar counterexamples", "lm_format_enforcer_version": "0.11.3",
        "learned_model_calls": 0, "model_weights_loaded": False,
        "real_tokenizer_and_callback": True, "source_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest(),
        "saved_output_replay": rows, "minimal_cases": minimal,
        "eos_metadata_independently_verified_against_tokenizer": True,
        "interpretation": "The integration cannot assume empty enum, maxItems zero, or uniqueItems are enforced by this installed parser. The final validator correctly rejected the affected outputs."}
    output = ROOT / "outputs/TRONCO01_DIAGNOSTICO_GRAMATICA_V2_7_2026-10-17.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
