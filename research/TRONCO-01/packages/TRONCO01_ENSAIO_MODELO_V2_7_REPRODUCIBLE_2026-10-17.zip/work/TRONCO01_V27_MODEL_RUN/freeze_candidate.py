"""Create a distinct frozen execution copy of the reviewed v2.7 candidate."""
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "work/TRONCO01_TRIAL_v2_7"
TARGET = ROOT / "work/TRONCO01_TRIAL_v2_7_FROZEN"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    old_manifest = json.loads((SOURCE / "analysis_manifest_draft.json").read_text())
    for item in old_manifest["files"]:
        assert sha(SOURCE / item["path"]) == item["sha256"], item["path"]
    if TARGET.exists():
        raise FileExistsError("frozen execution copy already exists; do not overwrite or refreeze")
    review = ROOT / "outputs/TRONCO01_REVISAO_RESULTADOS_V2_7_2026-10-17.md"
    assert "instrumento apto" in review.read_text(encoding="utf-8").lower()
    shutil.copytree(SOURCE, TARGET, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    shutil.copy2(review, TARGET / "PRE_INFERENCE_REVIEW.md")
    shutil.copy2(ROOT / "work/TRONCO01_V27_RESULT_REVIEW/verify_review.py", TARGET / "pre_inference_reference.py")
    shutil.copy2(Path(__file__).parent / "launch_once.py", TARGET / "launch_once.py")
    now = datetime.now(timezone.utc).isoformat()
    prereg = json.loads((TARGET / "preregistration_draft.json").read_text())
    prereg.update(status="frozen_before_inference", frozen=True, frozen_at_utc=now)
    prereg["analysis_gate"] = "Completed by the attached v2.7 review before freezing; next analysis after this one fixed trial and before any configuration change."
    prereg["execution_authorization"] = {"user_message": "segue", "scope": "one passage over the ten scheduled development episodes; no retries"}
    prereg["pre_inference_review_sha256"] = sha(TARGET / "PRE_INFERENCE_REVIEW.md")
    groups = defaultdict(list)
    schedule = [json.loads(line) for line in (TARGET / "development_schedule.jsonl").read_text().splitlines()]
    for item in schedule:
        groups[json.dumps(item["public_state"], sort_keys=True)].append(item["episode_id"])
    prereg["schedule"]["distinct_public_states"] = len(groups)
    prereg["schedule"]["identical_state_groups"] = [ids for ids in groups.values() if len(ids) > 1]
    assert sha(TARGET / "development_schedule.jsonl") == prereg["schedule"]["schedule_sha256"]
    write(TARGET / "preregistration_draft.json", prereg)
    write(TARGET / "protocol_status.json", {"protocol": prereg["protocol"],
        "snapshot_status": "frozen_before_first_launch", "frozen_at_utc": now,
        "mandatory_pre_inference_analysis_completed": True,
        "preregistration_frozen": True, "manifest_frozen": True,
        "execution_record": "run_20261017/execution_record.json",
        "note": "This file describes the immutable pre-run snapshot; runtime results are stored separately."})
    manifest = dict(old_manifest)
    manifest.update(status="frozen_before_inference", frozen_at_utc=now,
                    preregistration_sha256=sha(TARGET / "preregistration_draft.json"))
    names = [x["path"] for x in old_manifest["files"]]
    names += ["PRE_INFERENCE_REVIEW.md", "pre_inference_reference.py", "launch_once.py", "FREEZE_RECORD.json"]
    write(TARGET / "FREEZE_RECORD.json", {"frozen_at_utc": now,
        "source_candidate_manifest_sha256": sha(SOURCE / "analysis_manifest_draft.json"),
        "review_sha256": sha(review), "original_source_unchanged": True,
        "executable_source_files_unchanged": ["trial_runner.py", "harness.py", "model_backend.py", "replay.py", "runtime_environment.py"],
        "inference_configuration_changed": False, "checkpoints_or_reserves_opened": False})
    manifest["files"] = [{"path": name, "sha256": sha(TARGET / name)} for name in names]
    write(TARGET / "frozen_manifest.json", manifest)
    # Keep the original draft manifest as a historical snapshot; only frozen_manifest is executable.
    print(json.dumps({"frozen_directory": str(TARGET), "frozen_at_utc": now,
                      "manifest_sha256": sha(TARGET / "frozen_manifest.json"),
                      "internal_files": len(names), "external_artifacts": len(manifest["external_files"]),
                      "episodes": len(schedule), "distinct_public_states": len(groups)}, indent=2))


if __name__ == "__main__":
    main()
