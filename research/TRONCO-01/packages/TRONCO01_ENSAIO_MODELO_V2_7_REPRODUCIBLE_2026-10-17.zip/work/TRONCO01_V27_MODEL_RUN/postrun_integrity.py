"""Verify source/checkpoint integrity after the one authorized learned-model run."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
FROZEN = ROOT / "work/TRONCO01_TRIAL_v2_7_FROZEN"
DRAFT = ROOT / "work/TRONCO01_TRIAL_v2_7"
sys.path.insert(0, str(FROZEN))
from harness import FrozenManifestGuard

frozen = FrozenManifestGuard(FROZEN / "frozen_manifest.json").verify()
draft = FrozenManifestGuard(DRAFT / "analysis_manifest_draft.json").verify(allow_draft=True)
source_names = ["trial_runner.py", "harness.py", "model_backend.py", "replay.py", "runtime_environment.py", "SYSTEM_PROMPT.txt", "development_schedule.jsonl"]
for name in source_names:
    assert (FROZEN / name).read_bytes() == (DRAFT / name).read_bytes(), name
result = {"frozen_status": frozen["__manifest_status__"], "frozen_internal_files": sum(not n.startswith("external:") for n in frozen) - 1,
          "checkpoint_artifacts": sum(n.startswith("external:") for n in frozen),
          "draft_source_preserved": True, "source_files_identical_to_reviewed_candidate": source_names,
          "post_run_hash_verification_passed": True, "new_model_calls": 0}
path = ROOT / "outputs/TRONCO01_INTEGRIDADE_POS_ENSAIO_V2_7_2026-10-17.json"
path.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
