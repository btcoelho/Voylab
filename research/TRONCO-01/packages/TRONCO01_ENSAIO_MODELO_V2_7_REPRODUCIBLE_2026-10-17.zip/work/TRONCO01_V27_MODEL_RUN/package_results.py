"""Package immutable trial inputs, raw learned outputs, and offline analysis."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs"
ZIP = OUT / "TRONCO01_ENSAIO_MODELO_V2_7_REPRODUCIBLE_2026-10-17.zip"
inputs = {}
for folder in ("TRONCO01_TRIAL_v2_7_FROZEN", "TRONCO01_TRIAL_v2_7", "TRONCO01_V27_MODEL_RUN"):
    base = ROOT / "work" / folder
    for path in base.rglob("*"):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            assert path.suffix != ".safetensors", "model weights must not be included"
            inputs[path.relative_to(ROOT).as_posix()] = path
for name in ("TRONCO01_RESULTADO_MODELO_V2_7_2026-10-17.md", "TRONCO01_RESULTADO_MODELO_V2_7_2026-10-17.json",
             "TRONCO01_DIAGNOSTICO_GRAMATICA_V2_7_2026-10-17.json", "TRONCO01_INTEGRIDADE_POS_ENSAIO_V2_7_2026-10-17.json"):
    inputs["outputs/" + name] = OUT / name
original = OUT / "TRONCO01_V2_7_PONTO_ANALISE_REPRODUCIBLE_2026-10-17.zip"
inputs["historical/" + original.name] = original
readme = '''# TRONCO-01 v2.7: one real model run, negative development result

Start with outputs/TRONCO01_RESULTADO_MODELO_V2_7_2026-10-17.md.
The real run is work/TRONCO01_TRIAL_v2_7_FROZEN/run_20261017/.
Its executable input manifest is frozen_manifest.json, frozen before loading weights.
The original candidate is work/TRONCO01_TRIAL_v2_7/; it remains a draft.
Draft documents and old results copied into the frozen folder are lineage snapshots;
analysis_manifest_draft.json is NOT the active manifest for the frozen execution copy.
fixtures/v23 contains historical results, separate from the new real run.

To reproduce analysis only, from this extracted root:
python work/TRONCO01_V27_MODEL_RUN/analyze_run.py

The grammar replay and external checkpoint integrity checks require the exact WSL
runtime and local snapshot named in the frozen manifest. They load no learned model.
The launcher is preserved for provenance and has a completed run lock. Do not retry
this experiment. There were ten learned generation calls, no training, no reserve use.
Model weights are excluded. Hashes describe exact files; they are not signatures.
'''
digests = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in inputs.items()}
digests["README.md"] = hashlib.sha256(readme.encode()).hexdigest()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(inputs.items()):
        z.write(path, name)
    z.writestr("README.md", readme)
    z.writestr("PACKAGE_SHA256.json", json.dumps({"files": digests, "contains_model_weights": False,
        "learned_generation_calls": 10, "experiment_result": "0/10 joint successes"}, indent=2) + "\n")
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    for name, digest in digests.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == digest, name
print(json.dumps({"archive": str(ZIP), "bytes": ZIP.stat().st_size, "members_hashed": len(digests),
                  "crc_valid": True, "sha256": hashlib.sha256(ZIP.read_bytes()).hexdigest()}, indent=2))
