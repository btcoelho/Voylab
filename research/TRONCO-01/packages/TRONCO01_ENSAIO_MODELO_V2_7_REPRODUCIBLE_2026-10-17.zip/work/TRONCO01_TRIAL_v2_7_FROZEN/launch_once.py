"""Launch the exact frozen v2.7 trial once; preserve output and never retry."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

PACKAGE = Path(__file__).resolve().parent
RUN = PACKAGE / "run_20261017"


def main():
    sys.path.insert(0, str(PACKAGE))
    from harness import FrozenManifestGuard
    from runtime_environment import verify_runtime
    manifest_path = PACKAGE / "frozen_manifest.json"
    verified = FrozenManifestGuard(manifest_path).verify()
    prereg_path = PACKAGE / "preregistration_draft.json"
    prereg = json.loads(prereg_path.read_text())
    runtime = verify_runtime(prereg["software_environment"])
    assert verified["__manifest_status__"] == "frozen_before_inference"
    condition = prereg["experimental_condition"]
    model_dir = next(Path(x["path"]).parent for x in json.loads(manifest_path.read_text())["external_files"]
                     if Path(x["path"]).name == "model.safetensors")
    RUN.mkdir(exist_ok=False)
    lock = RUN / "attempt_once.lock"
    with lock.open("x") as handle:
        handle.write(datetime.now(timezone.utc).isoformat() + "\n")
    args = [sys.executable, str(PACKAGE / "trial_runner.py"),
        "--schedule", str(PACKAGE / condition["schedule"]),
        "--system-prompt", str(PACKAGE / condition["system_prompt"]),
        "--model-path", str(model_dir), "--manifest", str(manifest_path),
        "--preregistration", str(prereg_path), "--output-dir", str(RUN),
        "--weights-sha256", condition["weights_sha256"],
        "--tokenizer-sha256", condition["tokenizer_json_sha256"],
        "--tokenizer-config-sha256", condition["tokenizer_config_sha256"], "--max-calls", "1"]
    record = {"started_at_utc": datetime.now(timezone.utc).isoformat(), "argv": args,
        "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "preregistration_sha256": hashlib.sha256(prereg_path.read_bytes()).hexdigest(),
        "runtime": runtime, "launch_attempt": 1, "retry_permitted": False,
        "gpu": subprocess.run(["nvidia-smi", "--query-gpu=name,memory.free,driver_version", "--format=csv,noheader"],
                              capture_output=True, text=True).stdout.strip()}
    record_path = RUN / "execution_record.json"
    record_path.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"launching": str(RUN), "manifest_sha256": record["manifest_sha256"]}), flush=True)
    env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", PYTHONUNBUFFERED="1")
    with (RUN / "process.log").open("w", encoding="utf-8") as log:
        proc = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, env=env)
    record.update(finished_at_utc=datetime.now(timezone.utc).isoformat(), exit_code=proc.returncode)
    if (RUN / "summary.json").exists():
        record["summary"] = json.loads((RUN / "summary.json").read_text())
    record["event_journal_exists"] = (RUN / "events.jsonl").exists()
    record_path.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2), flush=True)
    return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main())
