# TRONCO-01 v2.7: one real model run, negative development result

Start with outputs/TRONCO01_RESULTADO_MODELO_V2_7_2026-10-17.md.
The real run is work/TRONCO01_TRIAL_v2_7_FROZEN/run_20261017/.
Its executable input manifest is frozen_manifest.json, frozen before loading weights.
The original candidate is work/TRONCO01_TRIAL_v2_7/; it remains a draft.
Draft documents and old results copied into the frozen folder are lineage snapshots;
analysis_manifest_draft.json is NOT the active manifest for the frozen execution copy.
fixtures/v23 contains historical results, separate from the new real run.

To reproduce analysis only, from this extracted root:
python work/TRONCO01_V27_MODEL_RUN/analyze_run.py

The grammar replay and external checkpoint integrity checks require the exact WSL
runtime and local snapshot named in the frozen manifest. They load no learned model.
The launcher is preserved for provenance and has a completed run lock. Do not retry
this experiment. There were ten learned generation calls, no training, no reserve use.
Model weights are excluded. Hashes describe exact files; they are not signatures.
