"""Verify the candidate manifest and confirm its draft status blocks production entry."""
import json
from pathlib import Path

from harness import FrozenManifestGuard, ResumeIntegrityError

ROOT=Path(__file__).resolve().parent
guard=FrozenManifestGuard(ROOT/"frozen_inputs_draft.json")
manifest=json.loads(guard.manifest_path.read_text(encoding="utf-8"))
assert manifest["status"]=="draft_not_frozen"
verified=guard.verify(allow_draft=True)
try:
    guard.verify()
    blocked=False
except ResumeIntegrityError:
    blocked=True
assert blocked
assert verified.get("preregistration_draft.json")==manifest["preregistration_sha256"]
assert len([k for k in verified if k.startswith("external:")])==3
result={"manifest_status":manifest["status"],"internal_files_verified":len(manifest["files"]),
        "external_model_files_verified":3,"production_verification_blocks_draft":blocked,
        "model_weights_loaded":False,"model_inference":False}
output=ROOT/"results/frozen_manifest_gate_v2_5.json"
output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result,indent=2))
