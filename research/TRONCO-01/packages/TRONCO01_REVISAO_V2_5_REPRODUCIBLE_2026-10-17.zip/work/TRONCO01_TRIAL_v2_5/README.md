# TRONCO-01 v2.4 offline integration precheck

This is a preparation and analysis checkpoint. It includes an executable action/recovery harness, an independent standard-library replay of the historical v2.3 pilot, tests, and a frozen copy of the public schedule and historical records. It does not load a model or make inference calls.

The action schema restricts syntax and IDs visible in the current state. It does not compute the expected verdict, candidate set, diagnosis, sufficiency, evidence certificate, or location. The installed grammar parser does not enforce `uniqueItems`; duplicate list values can pass constrained decoding and are rejected by the final Python validator. Such a generation is recorded as a model-output failure, without automatic retry or silent deduplication. Rejected environment actions receive public legality feedback on the next call; malformed JSON or a shape rejected by the final validator terminates the episode. Calls remain bounded, and interrupted episodes require inspection.

## Reproduce the saved v2.3 analysis

From this directory run: python replay.py

The command uses fixtures/v23 and only the archived public schedule, event journal, and saved outcomes. It makes no model calls. Add --output PATH to save the reconstructed JSON elsewhere.

## Verify this offline harness

Run: python -m unittest discover -s tests -v

Run: python mutation_check.py

The tests use only Python's standard library.

The tokenizer-only gate is saved in results/tokenizer_preflight_v2_5.json. To reproduce it, install requirements-tokenizer.txt in Python 3.12 and point TRONCO_TOKENIZER_PATH at a cached tokenizer directory before running python grammar_preflight.py. The script loads tokenizer files only; it does not load model weights. `python offline_backend_smoke.py` runs a fixed scripted backend through the actual Qwen chat template, tokenizer grammar, frozen manifest and trial harness without loading model weights. This validates wiring and recording, not model generation or scientific performance. `model_backend.py` contains a lazy adapter copied from the frozen v2.3 runner. It requires a frozen manifest covering the preregistration, checkpoint and tokenizer, and checks their hashes before importing Unsloth; it has not been instantiated or called. `python make_frozen_manifest.py --weights PATH_TO_MODEL_SAFETENSORS` hashes these inputs and the model artifacts but deliberately leaves the manifest in `draft_not_frozen` state. Run `python verify_draft_manifest.py` to confirm all hashes and that production mode rejects the draft.

## Status

protocol_status.json and preregistration_draft.json define a development rerun candidate. It reuses the historical 10 public states and the same checkpoint/configuration where the saved hashes can be verified, solely to measure the interface change; it is not confirmatory or an independent generalization set. Run `python make_frozen_manifest.py --weights PATH_TO_MODEL_SAFETENSORS` to hash the external checkpoint bytes and public inputs without loading weights. The manifest remains marked draft. Freeze it and pass the mandatory analysis gate before any inference. Historical v2.3, G1/G2, and M17 are not modified.
