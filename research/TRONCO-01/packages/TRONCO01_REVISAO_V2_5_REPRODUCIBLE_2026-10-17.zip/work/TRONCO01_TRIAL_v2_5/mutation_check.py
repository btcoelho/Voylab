"""Verify the targeted regression tests kill one-source-line mutants."""
from __future__ import annotations
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / "harness.py").read_text(encoding="utf-8")
MUTANTS = {
    "duplicate_candidate_validator_removed": (
        'or len(set(action["candidate_model_codes"])) != len(action["candidate_model_codes"])',
        "or False",
        "test_duplicate_candidate_evidence_and_location_values_are_rejected",
    ),
    "resume_fingerprint_comparison_removed": (
        'elif starts[0].get("trial_fingerprint") != trial_fingerprint:',
        "elif False:",
        "test_changed_in_memory_schedule_is_blocked_by_journal_fingerprint",
    ),
    "entry_manifest_guard_removed": (
        "    verified_inputs = generation_guard()\n    allowed_status =",
        "    verified_inputs = {}\n    allowed_status =",
        "test_complete_resume_runs_guard_even_when_schedule_is_unchanged",
    ),
}


def main():
    results = {}
    for name, (old, new, test_name) in MUTANTS.items():
        if old not in SOURCE:
            raise RuntimeError(f"mutation anchor not found: {name}")
        mutant = SOURCE.replace(old, new, 1)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "harness.py").write_text(mutant, encoding="utf-8")
            shutil.copy2(ROOT / "tests/test_harness.py", root / "test_harness.py")
            process = subprocess.run(
                [sys.executable, "-m", "unittest", f"test_harness.HarnessTests.{test_name}"],
                cwd=root, text=True, capture_output=True,
            )
            killed = process.returncode != 0
            results[name] = {"target_test": test_name, "mutant_killed": killed,
                             "test_exit_code": process.returncode,
                             "diagnostic_tail": (process.stdout + process.stderr)[-1800:]}
            if not killed:
                raise AssertionError(f"regression test did not detect mutant: {name}")
    result = {"method": "three deliberate one-line source mutants in temporary copies; targeted unittest failures kill mutants",
              "production_tree_modified": False, "model_calls": 0, "mutants": results,
              "all_targeted_mutants_killed": all(x["mutant_killed"] for x in results.values())}
    output = ROOT / "results/mutation_check_v2_5.json"
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "mutants"}, indent=2))
    for name, value in results.items():
        print(name, "KILLED" if value["mutant_killed"] else "SURVIVED")


if __name__ == "__main__":
    main()
