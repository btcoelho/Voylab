# Gate de análise pré-modelo — TRONCO-01 v2.5

Estado: a preparação offline e a integração simulada foram concluídas. A pré-registração e o manifesto continuam em rascunho; o adaptador real não foi chamado e o ensaio não começou.

## Resultado da execução offline

- 25 testes unitários cobrem JSON estrito, schema, feedback, diário, retoma, identidade de pré-registração, hashes internos/externos e recusa de carregar um checkpoint divergente.
- Três mutações de uma linha — remoção da rejeição de duplicados, comparação de fingerprint e gate de manifesto na entrada — foram mortas pelos testes direcionados.
- O tokenizer real, sem carregar pesos, permitiu EOS em saídas estruturais válidas, bloqueou sete formas inválidas e confirmou que um relatório cientificamente errado continua admissível. Também confirmou que os três casos de IDs duplicados passam pela gramática e são recusados pelo validador Python.
- O backend simulado percorreu o chat template Qwen, a gramática LMFE, o manifesto, o executor de ensaios e o diário: uma consulta, uma observação adicionada e um relatório terminal em duas chamadas. A saída fixa do teste é deliberadamente não-oracular e não mede o modelo.
- O SHA-256 local dos pesos `model.safetensors`, do `tokenizer.json` e de `tokenizer_config.json` coincide com os valores históricos registados. A verificação leu bytes; nenhum peso foi carregado.
- O replay histórico continua a dar 10 episódios, 19 chamadas, quatro saídas truncadas, 12 ações ilegais, três relatórios legais e 0/10 sucessos conjuntos. Os ficheiros históricos permaneceram intactos.

## Resolução das duas lacunas

**Retoma/proveniência:** cada ensaio começa com um fingerprint que inclui a agenda canónica, o limite de chamadas e o SHA-256 da pré-registração. O guard corre à entrada, inclusive numa retoma integral, verifica ficheiros internos e externos e exige manifesto congelado para qualquer uso de geração real. Uma agenda em memória alterada ou um manifesto alterado bloqueiam sem nova chamada. A classe do backend repete o gate e confere hashes dos pesos e tokenizer antes de importar Unsloth.

**Duplicações:** LM Format Enforcer 0.11.3 aceita os três tipos de duplicação testados. Em vez de apresentar a gramática como garantia de unicidade, a v2.5 torna explícita a política de duas fases: a gramática restringe estrutura, IDs e orçamento; o validador Python rejeita listas repetidas; a saída é registada como falha de formato, sem normalização ou pontuação. A repetição não é automática, conforme a política proposta. Os testes cobrem as duplicações e a divergência está guardada no resultado do tokenizer.

## Pré-registração candidata

O candidato usa o mesmo Qwen2.5-0.5B Instruct quantizado e os mesmos parâmetros de geração recuperados do pré-registo v2.3: amostragem desligada, 256 tokens novos e janela de contexto 2048. Os hashes locais do ficheiro de pesos e do tokenizer foram confirmados. A agenda contém os mesmos dez estados iniciais, agora sem consultas, para examinar resposta direta. Esses estados foram previamente expostos; o ensaio seria somente de desenvolvimento e não estimaria generalização nem serviria como validação confirmatória.

## Decisão neste ponto

**Os defeitos identificados estão corrigidos ou explicitamente delimitados e os controlos offline passaram; a integração real do modelo continua sem teste.** O protocolo não está autorizado tecnicamente a carregar pesos enquanto a pré-registração e o manifesto mantiverem o estado de rascunho. Antes da primeira inferência, ainda é necessário decidir se o desenvolvimento repetido destes dez estados é útil, congelar uma agenda apropriada, marcar a pré-registração como congelada e gerar o manifesto final. O primeiro ensaio resultante terá de ser descrito como exploratório e condicionado a esse gate.

Nenhum modelo foi carregado ou chamado, não houve fine-tuning nem ampliação do modelo, e G1/G2, v2.3 e as reservas M17 não foram alterados.
