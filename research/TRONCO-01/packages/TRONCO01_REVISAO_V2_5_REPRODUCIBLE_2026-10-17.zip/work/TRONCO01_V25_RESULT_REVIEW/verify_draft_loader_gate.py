"""Intercept the loader to check whether a verified draft can reach model loading.

All checkpoint files are tiny dummy bytes. Unsloth is replaced before import.
"""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import types
from functools import partial

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"work/TRONCO01_TRIAL_v2_5"))
from harness import FrozenManifestGuard
from model_backend import Qwen25Generator

class LoaderReached(RuntimeError): pass
calls=[]
class FakeFastLanguageModel:
    @staticmethod
    def from_pretrained(**kwargs):
        calls.append(str(kwargs["model_name"]))
        raise LoaderReached("intercepted before any actual model load")

fake=types.ModuleType("unsloth")
fake.FastLanguageModel=FakeFastLanguageModel
sys.modules["unsloth"]=fake

with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    files={"model.safetensors":b"dummy-weights", "tokenizer.json":b"dummy-tokenizer",
           "tokenizer_config.json":b"dummy-tokenizer-config"}
    for name,data in files.items(): (root/name).write_bytes(data)
    prereg=root/"preregistration_draft.json"
    prereg.write_text('{"status":"draft","frozen":false}',encoding="utf-8")
    ph=hashlib.sha256(prereg.read_bytes()).hexdigest()
    mh={name:hashlib.sha256(data).hexdigest() for name,data in files.items()}
    manifest=root/"manifest.json"
    manifest.write_text(json.dumps({"status":"draft_not_frozen",
        "files":[{"path":prereg.name,"sha256":ph}],
        "external_files":[{"path":str(root/name),"sha256":digest} for name,digest in mh.items()]}),encoding="utf-8")
    guard=FrozenManifestGuard(manifest)
    try:
        Qwen25Generator.from_verified_checkpoint(root,mh["model.safetensors"],mh["tokenizer.json"],
            mh["tokenizer_config.json"],partial(guard.verify,allow_draft=True),ph)
        observed="unexpected normal return"
    except LoaderReached:
        observed="loader reached despite manifest status draft_not_frozen"
    except Exception as exc:
        observed=f"blocked: {type(exc).__name__}: {exc}"

result={"original_adapter":True,"verified_manifest_status":"draft_not_frozen",
        "guard_used":"partial(FrozenManifestGuard.verify, allow_draft=True)",
        "loader_reached":bool(calls),"actual_model_weights_loaded":False,"model_inference":False,
        "observation":observed,
        "scope":"Default guard rejects draft; loader does not independently check status and accepts the explicit offline guard when hashes match. This is an integration precondition gap, not evidence of a historical real model load."}
out=ROOT/"outputs/TRONCO01_GATE_CARREGADOR_v2_5_2026-10-17.json"
out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
print(json.dumps(result,indent=2,ensure_ascii=False))
