from pathlib import Path
import hashlib
import json
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
PACKAGE=ROOT/"work/TRONCO01_TRIAL_v2_5"
REVIEW=Path(__file__).resolve().parent
OUT=ROOT/"outputs"
sys.path.insert(0,str(PACKAGE))
import replay

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

original_archive=OUT/"TRONCO01_TRIAL_V2_5_OFFLINE_REPRODUCIBLE_2026-10-17.zip"
with zipfile.ZipFile(original_archive) as z:
    saved=json.loads(z.read("ARCHIVE_MANIFEST.json"))
    checks={name:hashlib.sha256(z.read(name)).hexdigest()==expected for name,expected in saved["files_sha256"].items()}
    disk={name:(ROOT/name).is_file() and digest(ROOT/name)==expected for name,expected in saved["files_sha256"].items()}
    archive_ok=z.testzip() is None and all(checks.values()) and all(disk.values())
assert archive_ok
old_status=json.loads((OUT/"TRONCO01_STATUS_PREMODELO_v2_5_2026-10-17.json").read_text(encoding="utf-8"))
old_mutations=json.loads((PACKAGE/"results/mutation_check_v2_5.json").read_text(encoding="utf-8"))
corrected=json.loads((OUT/"TRONCO01_VERIFICACAO_MUTACOES_v2_5_CORRIGIDA_2026-10-17.json").read_text(encoding="utf-8"))
adapter=json.loads((OUT/"TRONCO01_ADAPTADOR_v2_5_SIMULADO_REAL_2026-10-17.json").read_text(encoding="utf-8"))
gate=json.loads((OUT/"TRONCO01_GATE_CARREGADOR_v2_5_2026-10-17.json").read_text(encoding="utf-8"))
replayed=replay.replay(PACKAGE/"fixtures/v23")
assert replayed["summary"]==old_status["historical_v23_summary"]
original_invalid=sum("ModuleNotFoundError: No module named 'model_backend'" in case["diagnostic_tail"] for case in old_mutations["mutants"].values())
assert original_invalid==3 and corrected["valid_kills"]==3
result={"new_model_calls":0,"real_model_weights_loaded":False,"original_v25_files_modified":False,
    "archive_integrity":{"checked_members":len(checks),"all_hashes_match":all(checks.values()),"disk_matches_archive":all(disk.values())},
    "unit_test_review":{"tests":25,"exit_code":0,"basis":"Executed original unittest discovery in this review; all 25 passed."},
    "original_mutation_claim":{"valid":False,"invalid_runs_due_to_import_error":original_invalid},
    "corrected_mutation_evidence":{"baseline_tests_pass":corrected["baselines_pass"],"valid_assertion_kills":corrected["valid_kills"]},
    "actual_adapter_fake_model_check":adapter,"draft_loader_gate_check":gate,
    "historical_replay":replayed["summary"],
    "decision":"technical improvements confirmed; patch verification/reporting and loader status check, then finish one frozen production runner before any learned-model inference",
    "experiment_scope":"Ten exposed development cases are acceptable for regression; changed query budget and call limit prevent attributing differences solely to the prompt/grammar.",
    "review_source_sha256":{p.name:digest(p) for p in REVIEW.glob("*.py")}}
summary=OUT/"TRONCO01_CONFERENCIA_v2_5_CORRIGIDA_2026-10-17.json"
summary.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
output_files=[summary,OUT/"TRONCO01_REVISAO_RESULTADOS_v2_5_2026-10-17.md",
    OUT/"TRONCO01_VERIFICACAO_MUTACOES_v2_5_CORRIGIDA_2026-10-17.json",OUT/"TRONCO01_ADAPTADOR_v2_5_SIMULADO_REAL_2026-10-17.json",
    OUT/"TRONCO01_GATE_CARREGADOR_v2_5_2026-10-17.json",original_archive,
    OUT/"TRONCO01_STATUS_PREMODELO_v2_5_2026-10-17.json",
    OUT/"TRONCO01_PONTO_ANALISE_PREMODELO_v2_5_2026-10-17.md"]
files=sorted([p for base in (PACKAGE,REVIEW) for p in base.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix!=".pyc"])+output_files
archive=OUT/"TRONCO01_REVISAO_V2_5_REPRODUCIBLE_2026-10-17.zip"
with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    hashes={}
    for p in files:
        name=str(p.relative_to(ROOT)).replace("\\","/")
        z.write(p,name); hashes[name]=digest(p)
    z.writestr("REVIEW_MANIFEST.json",json.dumps({"files_sha256":hashes,"contains_model_weights":False},indent=2)+"\n")
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(name)).hexdigest()==expected for name,expected in hashes.items())
print(json.dumps({"summary":str(summary),"archive":str(archive),"members":len(hashes)+1,"hashes":"passed","original_unchanged":True,"new_model_calls":0},indent=2))
