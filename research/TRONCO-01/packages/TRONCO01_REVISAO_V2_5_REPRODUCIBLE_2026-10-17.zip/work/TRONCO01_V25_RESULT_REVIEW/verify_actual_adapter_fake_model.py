"""Exercise original Qwen25Generator.__call__ with real tokenizer and scripted CPU tensors.
No checkpoint is loaded; the fake generate method only appends fixed token IDs.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "work/TRONCO01_TRIAL_v2_5"
sys.path.insert(0, str(PACKAGE))
import torch
import transformers.tokenization_utils as tokenization_utils
from transformers import AutoTokenizer, PreTrainedTokenizerBase
tokenization_utils.PreTrainedTokenizerBase = PreTrainedTokenizerBase
from harness import public_action_schema
from model_backend import Qwen25Generator, build_chat_prompt

TOKENIZER = Path(os.environ.get("TRONCO_TOKENIZER_PATH", "/home/bcoelho/.cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"))


class ScriptedModel:
    device = torch.device("cpu")
    calls = 0

    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        self.payload = '{"action":"report","verdict":"undetermined","candidate_model_codes":["A"],"diagnosis":"identified","sufficiency":"no_observations","evidence_ids":[],"location":{"feature":"none","values":[]}}'

    def generate(self, **kwargs):
        self.calls += 1
        assert kwargs["do_sample"] is False and kwargs["max_new_tokens"] == 256 and kwargs["max_length"] is None
        assert "prefix_allowed_tokens_fn" in kwargs
        prefix = kwargs["input_ids"][0].tolist()
        sequence = list(prefix)
        tokens = self.tokenizer.encode(self.payload, add_special_tokens=False) + [self.tokenizer.eos_token_id]
        grammar = kwargs["prefix_allowed_tokens_fn"]
        for token in tokens:
            allowed = grammar(0, torch.tensor(sequence, dtype=torch.long))
            if token not in allowed:
                raise AssertionError(f"actual model adapter's grammar blocks scripted token {token}")
            sequence.append(token)
        return torch.tensor([sequence], dtype=torch.long)


def main():
    tokenizer = AutoTokenizer.from_pretrained(str(TOKENIZER), local_files_only=True)
    fake = ScriptedModel(tokenizer)
    adapter = Qwen25Generator(fake, tokenizer)
    adapter.weights_sha256 = "SIMULATED_NO_WEIGHTS"
    adapter.tokenizer_sha256 = "SIMULATED_BACKEND_WITH_CACHED_TOKENIZER"
    state = {"candidate_models": [{"id": "A"}], "observations": [], "query_menu": [], "remaining_query_budget": 0}
    system = (PACKAGE / "SYSTEM_PROMPT.txt").read_text(encoding="utf-8")
    prompt = build_chat_prompt(tokenizer, system, state)
    raw, metadata = adapter(prompt, public_action_schema(state))
    assert raw == fake.payload and metadata["eos_terminated"] is True
    assert metadata["generated_token_count"] == len(metadata["generated_token_ids"])
    assert metadata["generated_token_ids"][-1] == tokenizer.eos_token_id
    result = {"actual_original_adapter_call_exercised": True, "fake_generate_calls": fake.calls,
              "checkpoint_loaded": False, "model_inference_performed": False,
              "raw_output_matches_script": raw == fake.payload, "eos_recorded": metadata["eos_terminated"],
              "prompt_token_count": metadata["prompt_token_count"], "generated_token_count": metadata["generated_token_count"],
              "scope": "Original __call__, actual Transformers LMFE callback, actual tokenizer/tensors; no learned model or Unsloth loader execution."}
    out = ROOT / "outputs/TRONCO01_ADAPTADOR_v2_5_SIMULADO_REAL_2026-10-17.json"
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
