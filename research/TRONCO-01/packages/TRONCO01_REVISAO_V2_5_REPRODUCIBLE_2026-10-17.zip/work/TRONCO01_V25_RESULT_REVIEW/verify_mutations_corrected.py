"""Check baseline and mutants, counting assertion failures only; preserve original v2.5."""
from __future__ import annotations
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "work/TRONCO01_TRIAL_v2_5"
SOURCE = (PACKAGE / "harness.py").read_text(encoding="utf-8")
RUNNER = '''import io,json,sys,unittest
stream=io.StringIO()
suite=unittest.defaultTestLoader.loadTestsFromName(sys.argv[1])
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
print(json.dumps({"tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),"successful":result.wasSuccessful(),"log":stream.getvalue()}))
'''
MUTANTS = {
    "duplicate_candidate_check_removed": (
        'or len(set(action["candidate_model_codes"])) != len(action["candidate_model_codes"])',
        "or False", "test_duplicate_candidate_evidence_and_location_values_are_rejected"),
    "resume_fingerprint_check_removed": (
        'elif starts[0].get("trial_fingerprint") != trial_fingerprint:',
        "elif False:", "test_changed_in_memory_schedule_is_blocked_by_journal_fingerprint"),
    "entry_manifest_guard_skipped_on_resume": (
        "    verified_inputs = generation_guard()\n",
        '    verified_inputs = (generation_guard() if not Path(event_path).exists() else {"__manifest_status__":"frozen_before_inference", "preregistration_draft.json":preregistration_sha256})\n',
        "test_complete_resume_runs_guard_even_when_schedule_is_unchanged"),
}


def run_source(source, test):
    with tempfile.TemporaryDirectory() as scratch:
        root = Path(scratch)
        (root / "harness.py").write_text(source, encoding="utf-8")
        shutil.copy2(PACKAGE / "model_backend.py", root / "model_backend.py")
        shutil.copy2(PACKAGE / "tests/test_harness.py", root / "test_harness.py")
        proc = subprocess.run([sys.executable, "-c", RUNNER, f"test_harness.HarnessTests.{test}"],
                              cwd=root, capture_output=True, text=True)
        if proc.returncode:
            raise RuntimeError(proc.stdout + proc.stderr)
        return json.loads(proc.stdout)


def main():
    cases = {}
    for name, (old, new, test) in MUTANTS.items():
        if SOURCE.count(old) != 1:
            raise RuntimeError(f"non-unique mutation anchor: {name}")
        baseline = run_source(SOURCE, test)
        if baseline["tests_run"] != 1 or not baseline["successful"] or baseline["errors"]:
            raise AssertionError(f"baseline invalid: {name}: {baseline}")
        mutant = run_source(SOURCE.replace(old, new, 1), test)
        killed = mutant["tests_run"] == 1 and mutant["errors"] == 0 and mutant["failures"] > 0
        cases[name] = {"test": test, "baseline": baseline, "mutant": mutant,
                       "killed_by_assertion": killed}
    result = {"original_v25_result_valid": False,
              "original_error": "All three archived mutation tests failed to import model_backend; test_exit_code != 0 was incorrectly treated as a kill.",
              "method": "Copy all dependencies; run the exact target unmodified first; require one test, zero errors and assertion failures to kill the mutant.",
              "new_model_calls": 0, "model_weights_loaded": False,
              "baselines_pass": all(x["baseline"]["successful"] for x in cases.values()),
              "valid_kills": sum(x["killed_by_assertion"] for x in cases.values()), "cases": cases}
    out = ROOT / "outputs/TRONCO01_VERIFICACAO_MUTACOES_v2_5_CORRIGIDA_2026-10-17.json"
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "cases"}, indent=2, ensure_ascii=False))
    if result["valid_kills"] != len(cases):
        raise AssertionError("a targeted mutant survived or the run was inconclusive")


if __name__ == "__main__":
    main()
