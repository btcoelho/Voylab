"""External review of unchanged v2.6: full runner with fake loader and semantic mutation."""
from pathlib import Path
from unittest.mock import patch
import copy
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / 'work/TRONCO01_TRIAL_v2_6'
OUT = ROOT / 'outputs'
sys.path.insert(0, str(PACKAGE))
import trial_runner
import replay
import harness
import model_backend
import mutation_check

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))

schedule = replay.load_jsonl(PACKAGE / 'development_schedule.jsonl')
reference = {r['episode_id']: r['expected'] for r in replay.load_jsonl(PACKAGE / 'development_reference_private.jsonl')}
reports = []
for item in schedule:
    expected = reference[item['episode_id']]
    reports.append({'action':'report', 'verdict':expected['verdict'],
        'candidate_model_codes':expected['candidates'], 'diagnosis':expected['diagnosis'],
        'sufficiency':expected['sufficiency'],
        'evidence_ids':[r['id'] for r in item['public_state']['observations']],
        'location':{'feature':'none','values':[]}})

class FakeTokenizer:
    def apply_chat_template(self, messages, tokenize, add_generation_prompt):
        assert tokenize is False and add_generation_prompt is True
        return json.dumps(messages, ensure_ascii=False)

class FakeBackend:
    tokenizer = FakeTokenizer()
    def __init__(self, outputs): self.outputs = iter(outputs); self.calls = 0
    def __call__(self, prompt, schema):
        messages = json.loads(prompt)
        state = json.loads(messages[1]['content'])
        assert 'expected' not in state and not state['query_menu'] and state['remaining_query_budget'] == 0
        self.calls += 1
        output = next(self.outputs)
        if isinstance(output, Exception): raise output
        return output if isinstance(output, str) else json.dumps(output), {'backend':'REVIEW_FIXED_OUTPUT', 'eos_terminated':True}

def full_runner(outputs, resume=False):
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        shutil.copy2(PACKAGE/'development_schedule.jsonl', base/'development_schedule.jsonl')
        shutil.copy2(PACKAGE/'SYSTEM_PROMPT.txt', base/'SYSTEM_PROMPT.txt')
        prereg = read(PACKAGE/'preregistration_draft.json')
        prereg.update(status='frozen_before_inference', frozen=True)
        external=[]
        for name,key in [('model.safetensors','weights_sha256'),('tokenizer.json','tokenizer_json_sha256'),('tokenizer_config.json','tokenizer_config_sha256')]:
            path=base/name; path.write_bytes(('DUMMY '+name).encode())
            digest=sha(path); prereg['experimental_condition'][key]=digest
            external.append({'path':str(path),'sha256':digest})
        (base/'preregistration_draft.json').write_text(json.dumps(prereg),encoding='utf-8')
        files=[{'path':name,'sha256':sha(base/name)} for name in ['development_schedule.jsonl','SYSTEM_PROMPT.txt','preregistration_draft.json']]
        (base/'manifest.json').write_text(json.dumps({'status':'frozen_before_inference','files':files,'external_files':external}),encoding='utf-8')
        backend=FakeBackend(outputs)
        c=prereg['experimental_condition']
        args=(base/'development_schedule.jsonl',base/'SYSTEM_PROMPT.txt',base,base/'manifest.json',base/'run',c['weights_sha256'],c['tokenizer_json_sha256'],c['tokenizer_config_sha256'],base/'preregistration_draft.json')
        with patch.object(model_backend.Qwen25Generator,'from_verified_checkpoint',return_value=backend) as loader:
            result=trial_runner.run(*args)
            if resume:
                before=backend.calls
                again=trial_runner.run(*args)
                assert backend.calls==before and again==result
            result['fake_generation_calls']=backend.calls
            result['fake_loader_calls']=loader.call_count
        return result

good=full_runner(reports,resume=True)
wrong=[dict(r,verdict='supported' if r['verdict']!='supported' else 'rejected') for r in reports]
bad=full_runner(wrong)
malformed=full_runner(['{broken']+reports[1:])
technical=full_runner(reports[:2]+[RuntimeError('controlled infrastructure failure')]+reports[3:])
assert good['joint_successes']==10 and bad['joint_successes']==0
assert malformed['model_output_failures']==1 and malformed['episodes_attempted']==10 and malformed['joint_successes']==9
assert technical['technical_failures']==1 and technical['sentinel_stop_events']==1 and technical['fake_generation_calls']==3

rejected_index=next(i for i,r in enumerate(reports) if r['verdict']=='rejected')
state=schedule[rejected_index]['public_state']
unsupported=dict(reports[rejected_index],evidence_ids=[])
original_score=replay.score(state,unsupported)
assert not original_score['joint_success'] and not original_score['evidence_certificate_sufficient']

def manual_semantic_checks(score):
    # Hand-defined public state: glyph model fails at o2; setting model fits both rows.
    cards=[{'id':'A','statement':'Output depends only on glyph.','table':{'g0':'0','g1':'1'}},
           {'id':'B','statement':'Output depends only on setting.','table':{'s0':'0','s1':'1'}}]
    public={'candidate_models':cards,'working_model':cards[0],
            'observations':[{'id':'o1','input':{'glyph':'g0','setting':'s0','partner':'p0','phase':'t0'},'output':'0'},
                            {'id':'o2','input':{'glyph':'g0','setting':'s1','partner':'p0','phase':'t0'},'output':'1'}],
            'query_menu':[],'remaining_query_budget':0}
    correct={'action':'report','verdict':'rejected','candidate_model_codes':['B'],
             'diagnosis':'identified','sufficiency':'identity_resolved','evidence_ids':['o2'],
             'location':{'feature':'none','values':[]}}
    cases=[('refutation_with_counterexample',public,correct,True),
           ('refutation_without_citation',public,dict(correct,evidence_ids=[]),False),
           ('refutation_with_nonrefuting_citation',public,dict(correct,evidence_ids=['o1']),False),
           ('wrong_candidate_set',public,dict(correct,candidate_model_codes=['A']),False),
           ('wrong_diagnosis',public,dict(correct,diagnosis='ambiguous'),False),
           ('wrong_sufficiency',public,dict(correct,sufficiency='identity_ambiguous'),False),
           ('supported_location',public,dict(correct,evidence_ids=['o1','o2'],location={'feature':'setting','values':['s0','s1']}),True),
           ('location_without_cited_pair',public,dict(correct,location={'feature':'setting','values':['s0','s1']}),False)]
    supporting=copy.deepcopy(public); supporting['working_model']=cards[1]
    support=dict(correct,verdict='supported',evidence_ids=['o1','o2'])
    cases += [('support_complete_certificate',supporting,support,True),
              ('support_incomplete_certificate',supporting,dict(support,evidence_ids=['o1']),False)]
    results=[]
    for name, public_state, action, expected in cases:
        harness.validate_action_shape(action,public_state)
        actual=bool(score(public_state,action)['joint_success'])
        results.append({'case':name,'expected_joint_success':expected,'actual_joint_success':actual,'matches':actual==expected})
    return results

manual_original=manual_semantic_checks(replay.score)
assert all(r['matches'] for r in manual_original)

source=(PACKAGE/'replay.py').read_text(encoding='utf-8')
anchor="elif v=='rejected': cert=any(not prediction(working,r) for r in cited)"
assert source.count(anchor)==1
mutated=source.replace(anchor,"elif v=='rejected': cert=True",1)
with tempfile.TemporaryDirectory() as tmp:
    scratch=Path(tmp)/'package'
    shutil.copytree(PACKAGE,scratch,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    (scratch/'replay.py').write_text(mutated,encoding='utf-8')
    proc=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(scratch/'tests'),'-v'],cwd=scratch,capture_output=True,text=True)
    namespace={'__name__':'mutation_reference','__file__':str(scratch/'replay.py')}
    exec(compile(mutated,str(scratch/'replay.py'),'exec'),namespace)
    mutated_score=namespace['score'](state,unsupported)
    assert mutated_score['joint_success']
    semantic_mutation={'change':'Remove rejected-evidence certificate requirement',
        'suite_exit_code':proc.returncode,'survives_all_existing_tests':proc.returncode==0,
        'suite_log':proc.stdout+proc.stderr,
        'counterexample':{'episode_id':schedule[rejected_index]['episode_id'],'public_state':state,'action':unsupported,
            'original_score':original_score,'mutated_score':mutated_score},
        'new_independent_manual_checks':manual_semantic_checks(namespace['score'])}

mutation_rechecks={}
for name,(old,new,test) in mutation_check.MUTANTS.items():
    baseline=mutation_check.run_source(mutation_check.SOURCE,test)
    mutant=mutation_check.run_source(mutation_check.SOURCE.replace(old,new,1),test)
    valid=baseline['successful'] and baseline['tests_run']==1 and mutant['tests_run']==1 and mutant['errors']==0 and mutant['failures']>0
    assert valid
    mutation_rechecks[name]={'baseline_passes':True,'killed_by_assertion':True}

with zipfile.ZipFile(OUT/'TRONCO01_V2_6_PONTO_ANALISE_REPRODUCIBLE_2026-10-17.zip') as z:
    saved=json.loads(z.read('PACKAGE_MANIFEST.json'))['files_sha256']
    archive_ok=z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in saved.items())
    local={n:sha(ROOT/n)==h for n,h in saved.items() if n.startswith('work/TRONCO01_TRIAL_v2_6/')}
assert archive_ok and all(local.values())
prereg=read(PACKAGE/'preregistration_draft.json')
manifest=read(PACKAGE/'analysis_manifest_draft.json')
result={'new_learned_model_calls':0,'model_weights_loaded':False,
    'v26_original_source_unchanged':all(local.values()),'archive_integrity':archive_ok,'archive_hashed_members':len(saved),
    'full_runner_with_fake_loader':{'all_correct':good,'all_wrong':bad,'malformed_continues':malformed,'technical_sentinel':technical,
        'expected_answers_source':'saved development_reference_private.jsonl; not generated from replay.labels during this review',
        'scope':'trial_runner.run plus actual guard, harness and scorer; loader and tokenizer replaced with fakes'},
    'semantic_mutation':semantic_mutation,
    'manual_semantic_checks_on_original':manual_original,
    'existing_three_mutations_reproduced':mutation_rechecks,
    'freeze_scope':{'external_filenames':[Path(x['path']).name for x in manifest['external_files']],
                    'runtime_environment_declared_in_preregistration':'software_environment' in prereg,
                    'preregistration_status':prereg['status']}}
path=OUT/'TRONCO01_V2_6_VERIFICACAO_INDEPENDENTE_2026-10-17.json'
path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'output':str(path),'full_runner_good':good['joint_successes'],'full_runner_wrong':bad['joint_successes'],
    'malformed_continues':malformed['episodes_attempted'],'technical_stop_after':technical['fake_generation_calls'],
    'semantic_mutant_survives':semantic_mutation['survives_all_existing_tests'],
    'archive_integrity':archive_ok,'original_unchanged':all(local.values())},indent=2))
