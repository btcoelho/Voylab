from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
REVIEW=Path(__file__).resolve().parent
OUT=ROOT/'outputs'
files=[*sorted(REVIEW.glob('*.py')),
       OUT/'TRONCO01_REVISAO_RESULTADOS_V2_6_2026-10-17.md',
       OUT/'TRONCO01_V2_6_VERIFICACAO_INDEPENDENTE_2026-10-17.json',
       OUT/'TRONCO01_V2_6_RUNTIME_INSPECIONADO_2026-10-17.json',
       OUT/'TRONCO01_V2_6_PONTO_ANALISE_REPRODUCIBLE_2026-10-17.zip']
archive=OUT/'TRONCO01_REVISAO_V2_6_REPRODUCIBLE_2026-10-17.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    hashes={}
    for path in files:
        name=path.relative_to(ROOT).as_posix()
        data=path.read_bytes(); hashes[name]=hashlib.sha256(data).hexdigest()
        z.writestr(name,data)
    z.writestr('REVIEW_MANIFEST.json',json.dumps({'files_sha256':hashes,'new_model_calls':0,'contains_weights':False},indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(name)).hexdigest()==expected for name,expected in hashes.items())
print(json.dumps({'archive':str(archive),'members':len(hashes)+1,'all_hashes_match':True,'new_model_calls':0},indent=2))
