"""Read local checkpoint metadata and package versions; do not import/load a model."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
PACKAGE=ROOT/'work/TRONCO01_TRIAL_v2_6'
manifest=json.loads((PACKAGE/'analysis_manifest_draft.json').read_text(encoding='utf-8'))
checkpoint=Path(manifest['external_files'][0]['path']).parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
verified={entry['path']:sha(PACKAGE/entry['path'])==entry['sha256'] for entry in manifest['files']}
external={entry['path']:sha(Path(entry['path']))==entry['sha256'] for entry in manifest['external_files']}
assert all(verified.values()) and all(external.values())
covered={Path(entry['path']).name for entry in manifest['external_files']}
metadata=[{'name':p.name,'sha256':sha(p),'covered_by_candidate_manifest':p.name in covered}
          for p in sorted(checkpoint.iterdir()) if p.is_file() and p.suffix in {'.json','.txt'}]
result={'all_20_internal_hashes_match':all(verified.values()),'all_3_external_hashes_match':all(external.values()),
        'checkpoint_metadata_files':metadata,
        'runtime_versions':{'python':sys.version.split()[0],**{name:importlib.metadata.version(name)
            for name in ['transformers','lm-format-enforcer','unsloth','torch','bitsandbytes']}},
        'scope':'Package metadata and bytes only; no torch/Unsloth import and no model load.',
        'new_model_calls':0}
out=ROOT/'outputs/TRONCO01_V2_6_RUNTIME_INSPECIONADO_2026-10-17.json'
out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
