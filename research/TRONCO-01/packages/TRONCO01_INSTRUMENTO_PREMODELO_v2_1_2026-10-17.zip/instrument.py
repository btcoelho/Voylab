"""Integrated deterministic contract v2.1. Does not import legacy scoring code."""
from __future__ import annotations

from copy import deepcopy
from itertools import combinations
import hashlib
import json
import math
import os
from pathlib import Path
from jsonschema import Draft202012Validator

FIELDS = ("glyph", "setting", "partner", "phase")
SCOPES = {
    "Output depends only on glyph.": ("glyph",),
    "Output depends only on setting.": ("setting",),
    "Output depends on glyph and phase.": ("glyph", "phase"),
}
LOCATION_SCHEMA = {"type": "object", "properties": {
    "feature": {"enum": ["none", *FIELDS]},
    "values": {"type": "array", "items": {"type": "string"}, "maxItems": 2, "uniqueItems": True}},
    "required": ["feature", "values"], "additionalProperties": False}
ACTION_SCHEMA = {"$schema": "https://json-schema.org/draft/2020-12/schema", "oneOf": [
    {"type": "object", "properties": {"action": {"const": "query"}, "query_id": {"type": "string", "minLength": 1}},
     "required": ["action", "query_id"], "additionalProperties": False},
    {"type": "object", "properties": {
        "action": {"const": "report"},
        "verdict": {"enum": ["supported", "rejected", "undetermined"]},
        "diagnosis": {"enum": ["none_fit", "identified", "ambiguous"]},
        "sufficiency": {"enum": ["no_observations", "no_candidate_fits", "identity_ambiguous", "identity_resolved"]},
        "candidate_model_codes": {"type": "array", "items": {"type": "string"}, "uniqueItems": True},
        "evidence_ids": {"type": "array", "items": {"type": "string"}, "uniqueItems": True},
        "location": LOCATION_SCHEMA,
        "explanation": {"type": "string"}},
     "required": ["action", "verdict", "diagnosis", "sufficiency", "candidate_model_codes", "evidence_ids", "location"],
     "additionalProperties": False},
]}
Draft202012Validator.check_schema(ACTION_SCHEMA)
VALIDATOR = Draft202012Validator(ACTION_SCHEMA)


def decode_action(raw: str):
    if not isinstance(raw, str):
        raise ValueError("action must be text")
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError(f"duplicate JSON key: {key}")
            result[key] = value
        return result
    def constant(value):
        raise ValueError(f"non-finite JSON constant: {value}")
    def finite_float(value):
        result = float(value)
        if not math.isfinite(result):
            raise ValueError("non-finite JSON number")
        return result
    decoder = json.JSONDecoder(object_pairs_hook=pairs, parse_constant=constant, parse_float=finite_float)
    text = raw.strip()
    value, end = decoder.raw_decode(text)
    if end != len(text) or not isinstance(value, dict):
        raise ValueError("expected exactly one JSON object and no surrounding text")
    return value


def structural_errors(action):
    if not isinstance(action, dict):
        return ["action is not an object"]
    return sorted(error.message for error in VALIDATOR.iter_errors(action))


def state_errors(state):
    errors = []
    observations = state.get("observations", [])
    cards = state.get("candidate_models", [])
    queries = state.get("query_menu", [])
    for label, values in (("observation", [r.get("id") for r in observations]),
                          ("candidate", [c.get("id") for c in cards]),
                          ("query", [q.get("id") for q in queries])):
        if None in values or len(values) != len(set(values)):
            errors.append(f"{label} IDs must be present and unique")
    if not isinstance(state.get("remaining_query_budget"), int) or isinstance(state.get("remaining_query_budget"), bool) or state["remaining_query_budget"] < 0:
        errors.append("remaining query budget must be a nonnegative integer")
    return errors


def prediction(card, inputs):
    scope = SCOPES.get(card.get("statement"))
    if scope is None:
        raise ValueError("unsupported public model statement")
    return card["table"]["|".join(inputs[field] for field in scope)]


def compatible_cards(state):
    return {card["id"] for card in state["candidate_models"]
            if all(prediction(card, row["input"]) == row["output"] for row in state["observations"])}


def expected_verdict(state):
    rows = state["observations"]
    if not rows:
        return "undetermined"
    if any(prediction(state["working_model"], row["input"]) != row["output"] for row in rows):
        return "rejected"
    return "supported"


def expected_diagnosis(compatible):
    if not compatible:
        return "none_fit"
    if len(compatible) == 1:
        return "identified"
    return "ambiguous"


def expected_sufficiency(compatible, has_observations):
    if not has_observations:
        return "no_observations"
    if not compatible:
        return "no_candidate_fits"
    if len(compatible) > 1:
        return "identity_ambiguous"
    return "identity_resolved"


def legal_errors(state, action):
    errors = structural_errors(action) + state_errors(state)
    if errors:
        return errors
    if action["action"] == "query":
        if state["remaining_query_budget"] <= 0:
            errors.append("query budget exhausted")
        if action["query_id"] not in {q["id"] for q in state["query_menu"]}:
            errors.append("query ID not in public menu")
    else:
        known_obs = {r["id"] for r in state["observations"]}
        known_cards = {c["id"] for c in state["candidate_models"]}
        if not set(action["evidence_ids"]).issubset(known_obs):
            errors.append("report cites an unobserved evidence ID")
        if not set(action["candidate_model_codes"]).issubset(known_cards):
            errors.append("report names an unlisted model ID")
    return errors


def _content(row):
    x = row["input"]
    return (tuple(x[field] for field in FIELDS), row["output"])


def evidence_certificate(state, action):
    rows = state["observations"]
    known = {r["id"]: r for r in rows}
    cited_ids = set(action["evidence_ids"])
    cited_rows = [known[rid] for rid in cited_ids if rid in known]
    verdict = action["verdict"]
    if verdict == "supported":
        return {_content(r) for r in cited_rows} == {_content(r) for r in rows} and bool(rows)
    if verdict == "rejected":
        working = state["working_model"]
        return any(prediction(working, r["input"]) != r["output"] for r in cited_rows)
    return not rows and not action["evidence_ids"]


def location_supported(state, action):
    loc = action["location"]
    if loc["feature"] == "none":
        if loc["values"]:
            return False
        return None
    known = {r["id"]: r for r in state["observations"]}
    cited = [known[x] for x in action["evidence_ids"] if x in known]
    feature, values = loc["feature"], set(loc["values"])
    if len(values) != 2:
        return False
    for left, right in combinations(cited, 2):
        a, b = left["input"], right["input"]
        if (all(a[f] == b[f] for f in FIELDS if f != feature)
                and a[feature] != b[feature]
                and left["output"] != right["output"]
                and {a[feature], b[feature]} == values):
            return True
    return False


def evaluate_report(state, action):
    """Keep legality and scientific support separate; joint success gates both."""
    errors = legal_errors(state, action)
    if errors or action.get("action") != "report":
        return {"legal": False, "legal_errors": errors or ["action is not a report"], "joint_success": False}
    viable = compatible_cards(state)
    verdict_ok = action["verdict"] == expected_verdict(state)
    candidates_ok = set(action["candidate_model_codes"]) == viable
    diagnosis_ok = action["diagnosis"] == expected_diagnosis(viable)
    sufficiency_ok = action["sufficiency"] == expected_sufficiency(viable, bool(state["observations"]))
    certificate_ok = evidence_certificate(state, action)
    location = location_supported(state, action)
    location_ok = location is not False
    joint = all((verdict_ok, candidates_ok, diagnosis_ok, sufficiency_ok, certificate_ok, location_ok))
    return {"legal": True, "legal_errors": [], "expected_verdict": expected_verdict(state),
            "expected_candidate_model_codes": sorted(viable), "expected_diagnosis": expected_diagnosis(viable),
            "expected_sufficiency": expected_sufficiency(viable, bool(state["observations"])),
            "verdict_correct": verdict_ok, "candidates_correct": candidates_ok,
            "diagnosis_correct": diagnosis_ok, "sufficiency_correct": sufficiency_ok,
            "evidence_certificate_sufficient": certificate_ok, "location_supported": location,
            "joint_success": joint}


class Episode:
    def __init__(self, state, oracle):
        errors = state_errors(state)
        if errors:
            raise ValueError(errors)
        self.current = deepcopy(state)
        self.oracle = oracle
        self.terminal = False

    def state(self):
        return deepcopy(self.current)

    def apply(self, action):
        if self.terminal:
            raise RuntimeError("episode already terminated")
        errors = legal_errors(self.current, action)
        if errors:
            return {"accepted": False, "legal_errors": errors}
        if action["action"] == "report":
            result = evaluate_report(self.current, action)
            self.terminal = True
            return {"accepted": True, "terminal": True, "evaluation": result}
        query = next(q for q in self.current["query_menu"] if q["id"] == action["query_id"])
        output = self.oracle(deepcopy(query["input"]))
        new_id = f"o{len(self.current['observations']) + 1}"
        while new_id in {row["id"] for row in self.current["observations"]}:
            new_id += "_"
        observation = {"id": new_id, "input": deepcopy(query["input"]), "output": output}
        self.current["observations"].append(observation)
        self.current["query_menu"].remove(query)
        self.current["remaining_query_budget"] -= 1
        return {"accepted": True, "observation": deepcopy(observation)}


class Journal:
    """Append-only JSONL journal; raw model output is durable before parsing."""
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.sequence = 0
        if self.path.exists():
            with self.path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    json.loads(line)
                    self.sequence += 1

    def append(self, event):
        self.sequence += 1
        item = {"sequence": self.sequence, **event}
        with self.path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        return item

    def run_raw_action(self, episode, raw, apply_hook=None):
        raw_event = self.append({"kind": "raw_action", "raw": raw})
        action = decode_action(raw)
        result = (apply_hook or episode.apply)(action)
        self.append({"kind": "action_result", "raw_sequence": raw_event["sequence"], "action": action, "result": result})
        return result


class FrozenRunGuard:
    """Verify frozen code and schedule hashes immediately before generation."""
    def __init__(self, manifest_path):
        self.manifest_path = Path(manifest_path).resolve()
        self.root = self.manifest_path.parent

    def verify(self):
        manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        failures = []
        for entry in manifest["files"]:
            path = (self.root / entry["path"]).resolve()
            if self.root not in path.parents:
                failures.append({"path": entry["path"], "error": "path escapes frozen root"})
                continue
            if not path.is_file():
                failures.append({"path": entry["path"], "error": "missing frozen file"})
                continue
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if actual != entry["sha256"]:
                failures.append({"path": entry["path"], "error": "frozen hash mismatch"})
        if failures:
            raise RuntimeError({"frozen_run_gate_failed": failures})
        return True


class FrozenExecutor:
    """Minimal composition boundary: hash gate -> generator -> durable raw -> action."""
    def __init__(self, generate, guard, journal, episode):
        self.generate = generate
        self.guard = guard
        self.journal = journal
        self.episode = episode

    def step(self, prompt):
        self.guard.verify()
        raw = self.generate(prompt)
        return self.journal.run_raw_action(self.episode, raw)
