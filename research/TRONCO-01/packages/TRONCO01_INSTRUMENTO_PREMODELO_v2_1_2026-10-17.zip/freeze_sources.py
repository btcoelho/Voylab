"""Freeze the specification, executable contract, tests and synthetic schedule."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = [
    "README.md", "SPEC.md", "requirements.txt", "freeze_sources.py", "instrument.py", "grammar_preflight.py", "finite_audit.py",
    "mutation_audit.py", "preflight.py", "preflight_schedule.jsonl", "reanalyze_history.py",
    "tests/conftest.py", "tests/test_instrument.py",
]
FILES.extend(sorted(path.relative_to(ROOT).as_posix()
                    for path in (ROOT / "evidence/original").rglob("*") if path.is_file()))
manifest = {"protocol": "TRONCO-01-v2.1", "files": [
    {"path": name, "sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest()}
    for name in FILES
]}
(ROOT / "frozen_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"frozen": len(FILES), "manifest": str(ROOT / "frozen_manifest.json")}))
