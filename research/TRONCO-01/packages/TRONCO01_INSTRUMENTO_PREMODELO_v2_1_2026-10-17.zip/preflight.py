"""Pre-model gate: hash freeze, finite audit, targeted mutations, tests and tokenizer grammar."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from instrument import FrozenRunGuard


def main():
    guard = FrozenRunGuard(HERE / "frozen_manifest.json")
    guard.verify()
    schedule_hash = hashlib.sha256((HERE / "preflight_schedule.jsonl").read_bytes()).hexdigest()
    finite = subprocess.run([sys.executable, str(HERE / "finite_audit.py")], capture_output=True, text=True)
    mutation = subprocess.run([sys.executable, str(HERE / "mutation_audit.py")], capture_output=True, text=True)
    tests = subprocess.run([sys.executable, "-m", "pytest", "tests", "-q", "-p", "no:cacheprovider"],
                           cwd=HERE, capture_output=True, text=True)
    grammar = subprocess.run([sys.executable, str(HERE / "grammar_preflight.py")], capture_output=True, text=True)
    reanalysis = subprocess.run([sys.executable, str(HERE / "reanalyze_history.py")], capture_output=True, text=True)
    guard.verify()
    for name, result in (("finite", finite), ("mutation", mutation), ("tests", tests), ("grammar", grammar), ("historical_reanalysis", reanalysis)):
        if result.returncode:
            raise SystemExit(json.dumps({"gate": "FAIL", "stage": name, "stdout": result.stdout, "stderr": result.stderr}, indent=2))
    result = {
        "gate": "PASS_FOR_PREMODEL_REVIEW",
        "protocol": "TRONCO-01-v2.1",
        "model_inference": False,
        "frozen_sources_verified_at_start_and_end": True,
        "synthetic_schedule_sha256": schedule_hash,
        "finite": json.loads((HERE / "results/finite_audit_v2_1.json").read_text()),
        "mutations": json.loads((HERE / "results/mutation_audit_v2_1.json").read_text()),
        "grammar": json.loads((HERE / "results/grammar_preflight_v2_1.json").read_text()),
        "pytest_stdout": tests.stdout.strip(),
        "historical_reanalysis": json.loads((HERE / "results/retrospective_v2_1_summary.json").read_text()),
        "review_boundary": "human analysis required before any new model inference",
    }
    out = HERE / "results"
    out.mkdir(exist_ok=True)
    (out / "preflight_gate_v2_1.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in {"grammar", "finite", "mutations"}}, indent=2))


if __name__ == "__main__":
    main()
