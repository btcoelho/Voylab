"""Character-level lm-format-enforcer grammar check; no tokenizer or weights."""
from __future__ import annotations

import json
from pathlib import Path
import sys
from lmformatenforcer import JsonSchemaParser
from lmformatenforcer.characterlevelparser import UnionParser

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import instrument

def sample_state():
    cards = [
        {"id": "A", "statement": "Output depends only on glyph.", "table": {"g0": "0", "g1": "0"}},
        {"id": "B", "statement": "Output depends only on setting.", "table": {"s0": "1", "s1": "1"}},
        {"id": "C", "statement": "Output depends on glyph and phase.",
         "table": {"g0|t0": "0", "g0|t1": "1", "g1|t0": "0", "g1|t1": "1"}},
    ]
    return {"candidate_models": cards, "working_model": dict(cards[0]),
            "observations": [{"id": "a", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"}],
            "query_menu": [{"id": f"q{i}", "input": {"glyph": "g0", "setting": "s0", "partner": f"p{i}", "phase": "t1"}} for i in range(4)],
            "remaining_query_budget": 3}

def report(verdict="supported", diagnosis="ambiguous", sufficiency="identity_ambiguous", location=None):
    return {"action": "report", "verdict": verdict, "diagnosis": diagnosis, "sufficiency": sufficiency,
            "candidate_model_codes": ["A", "C"], "evidence_ids": ["a"],
            "location": location if location is not None else {"feature": "none", "values": []}}

def reachable(text):
    parser = UnionParser([JsonSchemaParser(branch) for branch in instrument.ACTION_SCHEMA["oneOf"]])
    for char in text:
        if char not in parser.get_allowed_characters():
            return {"character_path": False, "can_end": False}
        parser = parser.add_character(char)
    return {"character_path": True, "can_end": parser.can_end()}

def main():
    state = sample_state()
    queries = [json.dumps({"action": "query", "query_id": item["id"]}, separators=(",", ":")) for item in state["query_menu"]]
    good = report()
    wrong_but_structural = report(verdict="rejected")
    with_location = report(location={"feature": "phase", "values": ["t0", "t1"]})
    valid = queries + [json.dumps(item, separators=(",", ":")) for item in (good, wrong_but_structural, with_location)]
    valid_results = {text: reachable(text) for text in valid}
    malformed = {
        "extra_field": '{"action":"query","query_id":"q0","extra":1}',
        "incomplete_report": '{"action":"report","verdict":"supported"}',
        "wrong_type": '{"action":"query","query_id":42}',
    }
    malformed_results = {key: reachable(value) for key, value in malformed.items()}
    incomplete = reachable('{"action":')
    duplicate_json_keys_rejected_by_decoder = False
    try:
        instrument.decode_action('{"action":"query","action":"report"}')
    except ValueError:
        duplicate_json_keys_rejected_by_decoder = True
    result = {
        "parser": "lm-format-enforcer JsonSchemaParser (character-level)",
        "tokenizer_checked": False, "weights_loaded": False,
        "valid_action_paths": len(valid_results),
        "valid_action_probes": valid_results,
        "all_valid_actions_can_end": all(r["character_path"] and r["can_end"] for r in valid_results.values()),
        "wrong_but_well_formed_report_can_end": valid_results[json.dumps(wrong_but_structural, separators=(",", ":"))]["can_end"],
        "malformed_actions_cannot_end": all(not r["can_end"] for r in malformed_results.values()),
        "malformed_probes": malformed_results, "incomplete_prefix": incomplete,
        "incomplete_prefix_cannot_end": incomplete["character_path"] and not incomplete["can_end"],
        "strict_decoder_rejects_duplicate_keys": duplicate_json_keys_rejected_by_decoder,
    }
    if not (result["all_valid_actions_can_end"] and result["wrong_but_well_formed_report_can_end"]
            and result["malformed_actions_cannot_end"] and result["incomplete_prefix_cannot_end"]
            and result["strict_decoder_rejects_duplicate_keys"]):
        raise AssertionError(json.dumps(result, indent=2))
    out = HERE / "results"
    out.mkdir(exist_ok=True)
    (out / "grammar_preflight_v2_1.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
