# TRONCO-01 v2.1 — preflight do instrumento sem inferência

Este diretório contém uma cadeia de avaliação determinística baseada no contrato em SPEC.md. Não carrega pesos nem chama um modelo. Os episódios antigos G1/G2 estão preservados em evidence/original/ e são usados só na reanálise retrospectiva, com os campos v2.1 ausentes assinalados.

## Execução

Requer Python 3.12. A partir deste diretório, criar um ambiente virtual, instalar requirements.txt e executar freeze_sources.py uma vez; em seguida executar preflight.py. Em Linux/WSL, os comandos são:

python -m venv .venv  
.venv/bin/python -m pip install -r requirements.txt  
.venv/bin/python freeze_sources.py  
.venv/bin/python preflight.py

No PowerShell, use .venv\Scripts\python.exe no lugar de .venv/bin/python.

freeze_sources.py cria o hash lock do protocolo, código, testes e agenda sintética. Execute-o uma vez depois de rever esses ficheiros e antes do portão. preflight.py verifica os hashes no início e no fim e bloqueia diferenças. O teste do limite de execução usa uma função de geração simulada e prova que uma divergência de hash impede a chamada.

## Portão

O preflight executa a suíte pytest, a enumeração de 10 368 estados, cinco mutações direcionadas, a gramática JSON em lm-format-enforcer ao nível de caracteres e uma reanálise dos registos guardados. Respostas erradas mas estruturalmente bem formadas continuam representáveis. A gramática testa completude até ao fim do objeto; o parser recusa chaves repetidas e texto exterior; a máquina de estados grava e sincroniza o texto bruto antes de avaliar a ação.

O resultado fica em results/preflight_gate_v2_1.json. PASS_FOR_PREMODEL_REVIEW significa que este pacote passou estes controlos locais e chegou ao ponto de revisão. Não demonstra validade externa nem inicia um ensaio. O tokenizer e pesos Qwen não são necessários. A análise humana é obrigatória antes de qualquer inferência.
