"""Freeze public execution inputs and attach the preregistration hash."""
import hashlib
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--weights", type=Path, required=True,
                    help="Exact model.safetensors file; hashed as bytes without loading model weights")
args = parser.parse_args()
weights = args.weights.expanduser().absolute()
if not weights.is_file():
    raise FileNotFoundError(weights)
weights_hash = hashlib.sha256(weights.read_bytes()).hexdigest()
tokenizer_path = weights.parent / "tokenizer.json"
tokenizer_config_path = weights.parent / "tokenizer_config.json"
tokenizer_hash = hashlib.sha256(tokenizer_path.read_bytes()).hexdigest()
tokenizer_config_hash = hashlib.sha256(tokenizer_config_path.read_bytes()).hexdigest()
PREREG = ROOT / "preregistration_draft.json"
SCHEDULE = ROOT / "development_schedule.jsonl"
PREREG_HASH = hashlib.sha256(PREREG.read_bytes()).hexdigest()
prereg = json.loads(PREREG.read_text(encoding="utf-8"))
prereg["schedule"]["schedule_sha256"] = hashlib.sha256(SCHEDULE.read_bytes()).hexdigest()
prereg["status"] = "DRAFT_AWAITING_MANDATORY_ANALYSIS"
prereg["frozen"] = False
PREREG.write_text(json.dumps(prereg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
# Recompute after writing the hash field, which must itself be covered by the final manifest.
PREREG_HASH = hashlib.sha256(PREREG.read_bytes()).hexdigest()
files = ["preregistration_draft.json", "development_schedule.jsonl", "SYSTEM_PROMPT.txt",
         "harness.py", "replay.py", "grammar_preflight.py", "offline_backend_smoke.py", "model_backend.py",
         "prepare_development_schedule.py", "requirements-tokenizer.txt", "README.md",
         "protocol_status.json", "mutation_check.py", "tests/test_harness.py", "tests/test_replay.py",
         "make_frozen_manifest.py", "verify_draft_manifest.py", "finalize_outputs.py", "package_v25.py", "ANALYSIS_GATE.md", "fixtures/v23/public_schedule.jsonl",
         "development_reference_private.jsonl"]
entries = [{"path": name, "sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest()}
           for name in files]
manifest = {"protocol": prereg["protocol"], "status": "draft_not_frozen",
            "preregistration_sha256": PREREG_HASH, "files": entries,
            "external_files": [{"path": str(weights), "sha256": weights_hash},
                                {"path": str(tokenizer_path), "sha256": tokenizer_hash},
                                {"path": str(tokenizer_config_path), "sha256": tokenizer_config_hash}],
            "private_reference_sha256_not_for_model_prompt": hashlib.sha256((ROOT / "development_reference_private.jsonl").read_bytes()).hexdigest(),
            "weights_sha256_expected": prereg["experimental_condition"]["historical_weights_sha256"],
            "tokenizer_json_sha256_expected": prereg["experimental_condition"]["historical_tokenizer_json_sha256"],
            "tokenizer_config_sha256_expected": prereg["experimental_condition"]["historical_tokenizer_config_sha256"],
            "weight_file_verification": "match" if weights_hash == prereg["experimental_condition"]["historical_weights_sha256"] else "MISMATCH"}
if manifest["weight_file_verification"] != "match":
    raise RuntimeError("local checkpoint bytes do not match the hash recorded in the historical preregistration")
if tokenizer_hash != prereg["experimental_condition"]["historical_tokenizer_json_sha256"]:
    raise RuntimeError("local tokenizer bytes do not match the hash in the v2.5 preregistration draft")
if tokenizer_config_hash != prereg["experimental_condition"]["historical_tokenizer_config_sha256"]:
    raise RuntimeError("local tokenizer config bytes do not match the hash in the v2.5 preregistration draft")
(ROOT / "frozen_inputs_draft.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"preregistration_sha256": PREREG_HASH,
                  "schedule_sha256": prereg["schedule"]["schedule_sha256"],
                  "manifest_entries": len(entries), "inference": False}, indent=2))
