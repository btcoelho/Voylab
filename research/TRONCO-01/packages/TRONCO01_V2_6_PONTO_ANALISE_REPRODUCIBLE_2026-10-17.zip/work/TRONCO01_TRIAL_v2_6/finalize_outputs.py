"""Re-run standard-library checks and render the pre-model analysis artifacts."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
PACKAGE=Path(__file__).resolve().parent
OUT=ROOT/"outputs"
STATUS=OUT/"TRONCO01_STATUS_PREMODELO_v2_5_2026-10-17.json"
REPORT=OUT/"TRONCO01_PONTO_ANALISE_PREMODELO_v2_5_2026-10-17.md"

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    test=subprocess.run([sys.executable,"-m","unittest","discover","-s","tests","-v"],cwd=PACKAGE,text=True,capture_output=True)
    compile_run=subprocess.run([sys.executable,"-m","py_compile","harness.py","replay.py","grammar_preflight.py","offline_backend_smoke.py","model_backend.py","prepare_development_schedule.py","mutation_check.py","make_frozen_manifest.py","verify_draft_manifest.py","package_v25.py","finalize_outputs.py"],cwd=PACKAGE,text=True,capture_output=True)
    if test.returncode or compile_run.returncode: raise RuntimeError(test.stdout+test.stderr+compile_run.stderr)
    testlog=test.stdout+test.stderr
    ran=next((line.strip() for line in testlog.splitlines() if line.startswith("Ran ")),"unknown")
    test_count=ran.split()[1] if ran.startswith("Ran ") else "?"
    elapsed=ran.rsplit(" in ",1)[1].rstrip(".") if " in " in ran else ""
    grammar=json.loads((PACKAGE/"results/tokenizer_preflight_v2_5.json").read_text(encoding="utf-8"))
    smoke=json.loads((PACKAGE/"results/offline_backend_smoke_v2_5.json").read_text(encoding="utf-8"))
    mutations=json.loads((PACKAGE/"results/mutation_check_v2_5.json").read_text(encoding="utf-8"))
    gate=json.loads((PACKAGE/"results/frozen_manifest_gate_v2_5.json").read_text(encoding="utf-8"))
    replay=json.loads((PACKAGE/"results/v23_replay_reconciled_v2_5.json").read_text(encoding="utf-8"))
    prereg=json.loads((PACKAGE/"preregistration_draft.json").read_text(encoding="utf-8"))
    manifest=json.loads((PACKAGE/"frozen_inputs_draft.json").read_text(encoding="utf-8"))
    expected=prereg["experimental_condition"]
    assert smoke["model_weights_loaded"] is False and smoke["model_inference"] is False
    assert grammar["model_weights_loaded"] is False and grammar["model_inference"] is False
    assert mutations["all_targeted_mutants_killed"] and replay["summary"]["joint_successes"]==0
    assert gate["production_verification_blocks_draft"] and gate["external_model_files_verified"]==3
    weights=next(x for x in manifest["external_files"] if x["path"].endswith("model.safetensors"))
    tokenizer=next(x for x in manifest["external_files"] if x["path"].endswith("tokenizer.json"))
    tokenizer_config=next(x for x in manifest["external_files"] if x["path"].endswith("tokenizer_config.json"))
    assert weights["sha256"]==expected["historical_weights_sha256"]
    assert tokenizer["sha256"]==expected["historical_tokenizer_json_sha256"]
    assert tokenizer_config["sha256"]==expected["historical_tokenizer_config_sha256"]
    result={
        "date":"2026-10-17","protocol":"TRONCO-01-v2.5-development-rerun",
        "decision":"offline integration prepared for mandatory human analysis; real model generation remains unverified",
        "analysis_gate":"reached_before_any_model_inference",
        "model_weights_loaded":False,"model_inference_performed":False,"new_model_calls":0,
        "fine_tuning_performed":False,"larger_model_introduced":False,
        "historical_data_modified":False,"preregistration_frozen":False,
        "unit_tests":{"summary":ran,"exit_code":test.returncode},
        "python_compile_exit_code":compile_run.returncode,
        "mutation_testing":{"mutants":len(mutations["mutants"]),"all_killed":mutations["all_targeted_mutants_killed"]},
        "tokenizer_gate":{"transformers":grammar["transformers"],"lm_format_enforcer":grammar["lm_format_enforcer"],
            "case_count":len(grammar["cases"]),"all_valid_paths_eos":grammar["valid_payloads_complete_and_eos_allowed"],
            "invalid_shapes_blocked":grammar["invalid_payloads_blocked"],
            "wrong_semantic_report_still_allowed":grammar["wrong_semantic_report_remains_structurally_allowed"],
            "duplicate_cases_pass_grammar":all(grammar["cases"][x]["all_payload_tokens_allowed"] and grammar["cases"][x]["eos_allowed"] for x in grammar["duplicate_cases_final_validator_rejects"]),
            "duplicate_cases_rejected_by_final_validator":all(grammar["duplicate_cases_final_validator_rejects"].values()),
            "max_sample_report_tokens":grammar["cases"]["largest_bounded_report"]["tokens"]},
        "scripted_backend_smoke":smoke,
        "historical_v23_summary":replay["summary"],
        "candidate_checkpoint_hashes":{"weights":weights["sha256"],"tokenizer":tokenizer["sha256"],"tokenizer_config":tokenizer_config["sha256"],"all_match_preregistration":True},
        "draft_manifest":{"status":manifest["status"],"internal_file_count":len(manifest["files"]),"external_file_count":len(manifest["external_files"])},
        "draft_gate_verification":gate,
        "preregistration":{"episodes":prereg["schedule"]["episode_count"],"strata":prereg["schedule"]["strata"],"queries_enabled":False,"confirmatory":False},
        "limitations":["The real Qwen generation adapter was implemented but never instantiated or called.",
            "The ten public states were exposed in v2.3 and are only a development panel.",
            "The LMFE grammar accepts duplicate IDs; the final Python validator rejects them as model-output failures.",
            "The original initial v2.3 preregistration content remains unavailable; only its hash survives."],
        "source_sha256":{name:sha(PACKAGE/name) for name in ("harness.py","model_backend.py","replay.py","grammar_preflight.py","offline_backend_smoke.py","preregistration_draft.json","development_schedule.jsonl","frozen_inputs_draft.json")}
    }
    STATUS.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    report=f'''# Ponto de análise obrigatório antes do modelo — TRONCO-01 v2.5

## Decisão

**A preparação offline está pronta para análise humana; o ensaio de modelo ainda não começou.** O manifesto e a pré-registração permanecem em rascunho, e o guard impede que o carregador Qwen aceite esse estado. Nenhum peso foi carregado, nenhuma inferência foi executada, e não houve fine-tuning ou mudança para modelo maior.

## O que foi corrigido e demonstrado

- O diário agora grava uma identidade de ensaio que liga a agenda canónica, o limite de chamadas e o hash da pré-registração. O guard é verificado à entrada, mesmo se todos os episódios estiverem concluídos. Retoma com agenda, pré-registração ou ficheiro externo alterado é bloqueada.
- O backend Qwen2.5 foi extraído do executor histórico para um adaptador lazy. Antes de importar Unsloth ou carregar pesos, exige manifesto congelado e confirma hash da pré-registração, pesos, tokenizer e configuração do tokenizer. Testes mostraram que manifesto em rascunho e hash incorreto param antes de qualquer chamada.
- A gramática LMFE 0.11.3 aceita as três formas de listas duplicadas testadas. Isso ficou explicitamente declarado: a validação Python rejeita as duplicações e regista a saída como falha, sem deduplicar nem pontuar. O teste do tokenizer confirmou os dois lados da regra.
- A integração simulada usou tokenizer e template de chat Qwen reais, manifesto de teste, gramática LMFE, executor de ensaios e diário. Uma ação de consulta acrescentou uma observação e o relatório seguinte encerrou o episódio em duas chamadas. A resposta é fixa e não-oracular; não é evidência de capacidade do modelo.
- Passaram {test_count} testes ({elapsed}); três mutações dirigidas foram detetadas; os módulos compilaram. O SHA-256 local de `model.safetensors`, `tokenizer.json` e `tokenizer_config.json` coincide com os valores registados no pré-registo v2.3, verificados lendo ficheiros sem carregar pesos.

## Resultado histórico

O replay independente permanece em **0/10 sucessos conjuntos**: 19 chamadas, quatro saídas truncadas sem EOS, 12 ações ilegais, três relatórios legais e zero consultas. A nova interface teria recusado as 12 ações antigas que citavam IDs inexistentes, mas isso é uma verificação sobre saídas guardadas, não uma previsão de uma nova geração.

## Ensaio candidato e alcance

A pré-registração em rascunho propõe o mesmo checkpoint e os mesmos parâmetros recuperáveis — Qwen2.5-0.5B Instruct quantizado, `do_sample=false`, 256 tokens novos e contexto 2048 — num modo de resposta direta sem consultas. Reusa os dez estados públicos de v2.3. Como já foram expostos, serviria apenas para diagnosticar a alteração de interface; não seria teste cego, confirmatório ou medida de generalização.

## Ponto que requer decisão humana

Antes da primeira inferência, decidir se este painel exposto ainda é útil para desenvolvimento. Se sim, congelar uma agenda identificada como desenvolvimento, mudar o manifesto para `frozen_before_inference`, confirmar os hashes ativos e registar a decisão. O manifesto atual está em `draft_not_frozen` e o carregador bloqueia esse estado. A geração real e o comportamento do adaptador Qwen só poderão ser avaliados depois desse gate; a simulação não os substitui.

G1/G2, os registos v2.3 e as reservas M17 permanecem intactos.
'''
    REPORT.write_text(report,encoding="utf-8")
    print(json.dumps({"status":str(STATUS),"report":str(REPORT),"tests":ran,"inference":False},indent=2))

if __name__=="__main__": main()
