"""Build and verify the v2.5 offline reproducibility archive."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
PACKAGE=ROOT/"work/TRONCO01_TRIAL_v2_5"
OUTPUTS=ROOT/"outputs"
REPORT=OUTPUTS/"TRONCO01_PONTO_ANALISE_PREMODELO_v2_5_2026-10-17.md"
STATUS=OUTPUTS/"TRONCO01_STATUS_PREMODELO_v2_5_2026-10-17.json"
ARCHIVE=OUTPUTS/"TRONCO01_TRIAL_V2_5_OFFLINE_REPRODUCIBLE_2026-10-17.zip"

def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda:f.read(1024*1024),b""):
            h.update(part)
    return h.hexdigest()

def main():
    members=sorted(p for p in PACKAGE.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix!=".pyc")
    if not all((PACKAGE/rel).is_file() for rel in ("results/tokenizer_preflight_v2_5.json","results/mutation_check_v2_5.json","results/offline_backend_smoke_v2_5.json","results/v23_replay_reconciled_v2_5.json","results/frozen_manifest_gate_v2_5.json","frozen_inputs_draft.json")):
        raise RuntimeError("Required offline results or draft manifest are missing")
    report_hash=digest(REPORT); status_hash=digest(STATUS)
    entries=members+[REPORT,STATUS]
    with zipfile.ZipFile(ARCHIVE,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for path in entries:
            zf.write(path,str(path.relative_to(ROOT)).replace("\\","/"))
        zf.writestr("ARCHIVE_MANIFEST.json",json.dumps({
            "files_sha256":{str(path.relative_to(ROOT)).replace("\\","/"):digest(path) for path in entries},
            "contains_private_M17_oracle":False,"contains_model_weights":False,
            "preregistration_status":"draft_not_frozen"},indent=2)+"\n")
    with zipfile.ZipFile(ARCHIVE) as zf:
        if zf.testzip() is not None: raise RuntimeError("Archive CRC validation failed")
        manifest=json.loads(zf.read("ARCHIVE_MANIFEST.json"))
        checks={name:hashlib.sha256(zf.read(name)).hexdigest()==sha for name,sha in manifest["files_sha256"].items()}
        if not all(checks.values()): raise RuntimeError("Archive hash validation failed")
        if any("private_oracle.jsonl" in name for name in zf.namelist()): raise RuntimeError("Private oracle leaked")
    print(json.dumps({"archive":str(ARCHIVE),"members":len(entries)+1,"crc":"passed",
                      "member_hashes":"passed","report_sha256":report_hash,
                      "status_sha256":status_hash,"weights_included":False},indent=2))

if __name__=="__main__": main()
