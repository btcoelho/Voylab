# TRONCO-01 v2.6 — ponto obrigatório de análise pré-modelo

Estado do pacote: **pronto para revisão; pré-registo e manifesto ainda em rascunho**.

## O que foi integrado

- `trial_runner.py` executa a agenda pública v2.6 através do harness e pontua relatórios com `replay.score`, o scorer independente usado para reconciliar os episódios históricos v2.3.
- O protocolo é de resposta directa: dez estados sintéticos já expostos, uma chamada por episódio e zero consultas. É apenas desenvolvimento; não estima generalização nem isola causalmente prompt, gramática e limites de chamadas.
- O runner verifica o hash integral da agenda, o prompt, os três hashes do checkpoint, o número de chamadas e a condição sem consultas contra o pré-registo antes de carregar o modelo.
- O adaptador exige por conta própria `__manifest_status__ == frozen_before_inference`; a proteção não depende de quem fornece o callback do guard. A chamada `__call__` também foi exercitada com o tokenizer real, LMFE real e modelo de geração simulado em CPU.
- O verificador de mutações está integrado e só conta falhas de asserção com baseline válido e zero erros.

## Verificações concluídas

- 32 testes offline passaram, incluindo relatórios correctos e incorrectos nos dez estados públicos, registo de EOS, falha técnica com sentinel, retoma sem uma segunda geração e verificação dos bytes do prompt.
- Três mutações dirigidas foram mortas por asserções; os três testes de baseline passaram.
- O teste do gate confirmou que um manifesto `draft_not_frozen` é recusado pelo carregador antes da importação do loader de modelos.
- Os hashes locais de pesos, tokenizer e configuração do tokenizer coincidiram com os valores do protocolo. Foram lidos como bytes; os pesos não foram carregados.
- Nenhuma inferência foi executada.

## Decisão a tomar nesta análise

Avaliar se este ensaio exploratório com os dez estados repetidos responde a uma pergunta útil após corrigir a ligação ao scorer. Verificar se a especificação do scorer `replay.score`, os critérios de sucesso conjunto e a classificação das falhas estão adequados. Se aprovado, congelar pré-registo e manifesto, verificar o ambiente efectivo e só então considerar uma execução única dos dez episódios.

O checkpoint obrigatório termina aqui. A pré-registração em `preregistration_draft.json` permanece `DRAFT_AWAITING_MANDATORY_ANALYSIS`, e `analysis_manifest_draft.json` permanece `draft_not_frozen`. O runner bloqueia ambos os estados antes de qualquer carregamento ou inferência.
