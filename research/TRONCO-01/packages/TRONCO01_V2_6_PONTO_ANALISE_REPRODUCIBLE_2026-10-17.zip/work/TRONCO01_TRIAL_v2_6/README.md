# TRONCO-01 v2.6 — preparação para ensaio exploratório

Este pacote prepara o runner completo e pára no ponto de análise pré-modelo. Não carrega pesos nem executa inferência.

## Reproduzir as verificações offline

Na raiz do pacote:

```powershell
python -m unittest discover -s tests -v
python mutation_check.py
python replay.py --trial-dir fixtures/v23
```

O `trial_runner.py` liga a agenda ao `harness.py`, constrói o chat prompt pelo adaptador Qwen e aplica `replay.score` ao relatório terminal. O avaliador não recebe o rótulo privado: pontua a partir do estado público e da definição explícita dos modelos candidatos.

## Estado do ensaio

`preregistration_draft.json` descreve dez estados sintéticos já expostos, zero consultas e uma chamada por episódio. O objectivo é exploratório e não fornece uma estimativa de generalização. `analysis_manifest_draft.json` verifica os hashes internos e os três ficheiros externos do checkpoint, permanecendo em `draft_not_frozen`.

Depois da análise obrigatória, o protocolo ainda requer congelar formalmente os documentos, confirmar o ambiente de execução e rever o comando de execução. O runner exige estado congelado, os hashes exactos, a agenda prevista e a configuração registada antes de carregar o checkpoint.

Para preparar/verificar o manifesto candidato, sem carregar pesos:

```powershell
python prepare_analysis_gate.py --weights PATH_TO_MODEL_SAFETENSORS
```

O pacote mantém os registos históricos de v2.3 e a cópia v2.5. Não altera G1/G2 ou as reservas M17; não inclui pesos do modelo.
