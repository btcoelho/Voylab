import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import harness
import model_backend
import replay
import trial_runner


class TrialRunnerTests(unittest.TestCase):
    def state(self):
        return {"candidate_models": [
            {"id": "A", "statement": "Output depends only on glyph.", "table": {"g0": "0", "g1": "1"}},
            {"id": "B", "statement": "Output depends only on setting.", "table": {"s0": "0", "s1": "1"}},
            {"id": "C", "statement": "Output depends on glyph and phase.",
             "table": {"g0|t0": "0", "g0|t1": "1", "g1|t0": "1", "g1|t1": "0"}}],
            "observations": [], "query_menu": [], "remaining_query_budget": 0,
            "working_model": {"id": "A", "statement": "Output depends only on glyph.",
                              "table": {"g0": "0", "g1": "1"}}}

    def correct_empty_report(self):
        return {"action": "report", "verdict": "undetermined", "candidate_model_codes": ["A", "B", "C"],
                "diagnosis": "ambiguous", "sufficiency": "no_observations", "evidence_ids": [],
                "location": {"feature": "none", "values": []}}

    def test_runner_scorer_distinguishes_fixed_correct_and_incorrect_answers(self):
        state = self.state()
        good = trial_runner.apply_scientific_action(state, self.correct_empty_report())
        wrong = dict(self.correct_empty_report(), verdict="supported")
        bad = trial_runner.apply_scientific_action(state, wrong)
        self.assertTrue(good["accepted"] and good["evaluation"]["joint_success"])
        self.assertTrue(bad["accepted"])
        self.assertFalse(bad["evaluation"]["joint_success"])
        self.assertFalse(trial_runner.apply_scientific_action(
            state, {"action": "query", "query_id": "q0"})["accepted"])

    def test_independent_scorer_accepts_expected_reports_for_all_ten_public_cases(self):
        schedule = trial_runner.load_schedule(Path(__file__).resolve().parents[1] / "development_schedule.jsonl")
        for item in schedule:
            state = item["public_state"]
            labels = replay.labels(state)
            rows = state["observations"]
            if labels["verdict"] == "supported":
                evidence = [row["id"] for row in rows]
            elif labels["verdict"] == "rejected":
                working = next(c for c in state["candidate_models"] if c["id"] == state["working_model"]["id"])
                evidence = [next(row["id"] for row in rows if not replay.prediction(working, row))]
            else:
                evidence = []
            action = {"action": "report", "verdict": labels["verdict"],
                      "candidate_model_codes": labels["candidates"], "diagnosis": labels["diagnosis"],
                      "sufficiency": labels["sufficiency"], "evidence_ids": evidence,
                      "location": {"feature": "none", "values": []}}
            with self.subTest(episode=item["episode_id"]):
                result = trial_runner.apply_scientific_action(state, action)
                self.assertTrue(result["accepted"])
                self.assertTrue(result["evaluation"]["joint_success"])
                corrupted = dict(action, verdict="supported" if action["verdict"] != "supported" else "rejected")
                self.assertFalse(trial_runner.apply_scientific_action(state, corrupted)["evaluation"]["joint_success"])

    def test_same_harness_runner_records_eos_and_resumes_without_extra_call(self):
        root = Path(tempfile.mkdtemp())
        state = self.state()
        schedule = [{"episode_id": "fixed_01", "public_state": state}]
        prereg_hash = "b" * 64
        guard = lambda: {"__manifest_status__": "frozen_before_inference",
                         "preregistration_draft.json": prereg_hash}
        calls = []
        def generate(prompt, schema):
            calls.append(prompt)
            return json.dumps(self.correct_empty_report()), {"eos_terminated": True, "backend": "fixed-test-output"}
        args = dict(schedule=schedule, generate=generate, apply=trial_runner.apply_scientific_action,
                    prompt_for=lambda s: json.dumps(s, sort_keys=True),
                    event_path=root / "events.jsonl", outcomes_path=root / "outcomes.json",
                    summary_path=root / "summary.json", generation_guard=guard,
                    max_calls=1, preregistration_sha256=prereg_hash)
        first = harness.execute_trial(**args)
        second = harness.execute_trial(**args)
        events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
        generation = next(e for e in events if e["kind"] == "generation")
        self.assertEqual(first["joint_successes"], 1)
        self.assertEqual(second["joint_successes"], 1)
        self.assertEqual(len(calls), 1)
        self.assertTrue(generation["eos_terminated"])

    def test_backend_failure_is_recorded_as_technical_sentinel(self):
        root = Path(tempfile.mkdtemp())
        prereg_hash = "c" * 64
        schedule = [{"episode_id": "fixed_technical", "public_state": self.state()}]
        summary = harness.execute_trial(
            schedule, lambda prompt, schema: (_ for _ in ()).throw(RuntimeError("backend unavailable")),
            trial_runner.apply_scientific_action, lambda state: json.dumps(state),
            root / "events.jsonl", root / "outcomes.json", root / "summary.json",
            generation_guard=lambda: {"__manifest_status__": "frozen_before_inference",
                                      "preregistration_draft.json": prereg_hash},
            max_calls=1, preregistration_sha256=prereg_hash)
        events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
        self.assertEqual(summary["technical_failures"], 1)
        self.assertEqual(summary["sentinel_stop_events"], 1)
        self.assertTrue(any(event["kind"] == "generation_error" for event in events))

    def test_draft_status_is_rejected_before_loader_import(self):
        root = Path(tempfile.mkdtemp())
        for name, content in (("model.safetensors", b"weights"), ("tokenizer.json", b"tokenizer"),
                              ("tokenizer_config.json", b"config")):
            (root / name).write_bytes(content)
        prereg_hash = hashlib.sha256(b"draft").hexdigest()
        guard = lambda: {"__manifest_status__": "draft_not_frozen",
                         "preregistration_draft.json": prereg_hash}
        with self.assertRaisesRegex(RuntimeError, "requires a verified frozen_before_inference manifest"):
            model_backend.Qwen25Generator.from_verified_checkpoint(
                root, "0" * 64, "0" * 64, "0" * 64, guard, prereg_hash)

    def test_schedule_loader_keeps_only_the_frozen_public_payload(self):
        root = Path(tempfile.mkdtemp())
        path = root / "schedule.jsonl"
        path.write_text(json.dumps({"episode_id": "e1", "public_state": self.state(), "stratum": "empty"}) + "\n")
        result = trial_runner.load_schedule(path)
        self.assertEqual(set(result[0]), {"episode_id", "public_state"})

    def test_runner_prompt_must_match_manifest_bytes(self):
        root = Path(tempfile.mkdtemp())
        path = root / "SYSTEM_PROMPT.txt"
        path.write_text("frozen prompt")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        prereg = {"experimental_condition": {"system_prompt": "SYSTEM_PROMPT.txt"}}
        self.assertEqual(trial_runner.load_verified_system_prompt(path, prereg, {"SYSTEM_PROMPT.txt": digest}),
                         "frozen prompt")
        path.write_text("changed prompt")
        with self.assertRaises(harness.ResumeIntegrityError):
            trial_runner.load_verified_system_prompt(path, prereg, {"SYSTEM_PROMPT.txt": digest})


if __name__ == "__main__":
    unittest.main()
