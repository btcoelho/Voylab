"""Pre-registered, bounded G0b interface evaluation; maximum 20 generations."""
from __future__ import annotations

import hashlib
import json
import time
from collections import Counter
from pathlib import Path

import torch
from unsloth import FastLanguageModel
from transformers import AutoTokenizer

BASE_MODEL = "unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit"
ROOT = Path("/mnt/c/Users/Bruno/Documents/Codex/2026-10-17/files-pasted-by-the-user-projeto")
WORK = ROOT / "work/TRONCO01_G0B"
OUT = WORK / "run_20261017"
PROTO = ROOT / "outputs/TRONCO01_G0B_PROTOCOLO_2026-10-17.md"
M17 = ROOT / "work/M17_DESCOBERTA_DIAGNOSTICO"
M16_ROOT = Path("/home/bcoelho/voynich-lab/experiencias/M16_CURRICULO")
M16_DATA = M16_ROOT / "data/sft/validation.jsonl"
M16_MANIFEST = M16_ROOT / "data/sft/manifest.json"
M16_ADAPTER = M16_ROOT / "runs/m16-l4l5-r1/adapter"
MAX_INPUT = 2048
MAX_NEW = 192

SYSTEM_EXAMPLES = '''You are performing an interface transport check, not scientific reasoning. Read the user JSON. Emit exactly one JSON object, with no markdown or surrounding text. Follow response_schema. Copy the requested_action values exactly; use only IDs present in the public state. Do not add or infer fields. Examples of the complete output shapes:
{"action":"query","query_id":"q-demo"}
{"action":"report","verdict":"supported","candidate_model_codes":["H-demo"],"evidence_ids":["r-demo"],"location":{"feature":null,"value":null},"confidence":0.8,"explanation":"short statement"}
{"action":"report","verdict":"rejected","candidate_model_codes":["H-demo"],"evidence_ids":["r-demo"],"location":{"feature":"input","value":{"glyph":"g-demo"}},"confidence":0.8,"explanation":"short statement"}
{"action":"report","verdict":"undetermined","candidate_model_codes":["H-demo","K-demo"],"evidence_ids":["r-demo"],"location":{"feature":null,"value":null},"confidence":0.5,"explanation":"short statement"}'''


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha_tree(path: Path) -> str:
    h = hashlib.sha256()
    for file in sorted(p for p in path.rglob("*") if p.is_file()):
        h.update(file.relative_to(path).as_posix().encode())
        h.update(bytes.fromhex(sha_file(file)))
    return h.hexdigest()


def canon(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def build_fixtures():
    schema = {
        "query": {"action": "query", "query_id": "one ID from query_menu"},
        "report": {"action": "report", "verdict": "supported | rejected | undetermined",
                   "candidate_model_codes": [], "evidence_ids": [],
                   "location": {"feature": "input field or null", "value": "value or null"},
                   "confidence": "number from 0 to 1", "explanation": "short statement"},
    }
    common = {
        "device": "unknown_system",
        "working_model": {"id": "H3", "statement": "Fixture hypothesis.", "table": {"gA": "o1"}},
        "candidate_models": [
            {"id": "H3", "statement": "Fixture hypothesis.", "table": {"gA": "o1"}},
            {"id": "K2", "statement": "Alternative fixture hypothesis.", "table": {"gA": "o2"}},
        ],
        "observations": [
            {"id": "rA", "input": {"glyph": "gA", "setting": "sA", "partner": "pA", "phase": "tA"}, "output": "o1"},
            {"id": "rB", "input": {"glyph": "gA", "setting": "sA", "partner": "pA", "phase": "tB"}, "output": "o2"},
        ],
        "query_menu": [
            {"id": "qA", "input": {"glyph": "gA", "setting": "sA", "partner": "pA", "phase": "tA"}},
            {"id": "qB", "input": {"glyph": "gB", "setting": "sB", "partner": "pB", "phase": "tB"}},
        ],
        "remaining_query_budget": 2,
        "response_schema": schema,
    }
    specs = [
        ("transport_query", "query", {"action": "query", "query_id": "qB"}),
        ("transport_supported", "report", {"action": "report", "verdict": "supported", "candidate_model_codes": ["H3"], "evidence_ids": ["rA"], "location": {"feature": None, "value": None}, "confidence": 0.8, "explanation": "Transport fixture."}),
        ("transport_rejected", "report", {"action": "report", "verdict": "rejected", "candidate_model_codes": ["H3"], "evidence_ids": ["rA", "rB"], "location": {"feature": "input", "value": {"glyph": "gA"}}, "confidence": 0.9, "explanation": "Transport fixture."}),
        ("transport_undetermined", "report", {"action": "report", "verdict": "undetermined", "candidate_model_codes": ["H3", "K2"], "evidence_ids": ["rA"], "location": {"feature": None, "value": None}, "confidence": 0.5, "explanation": "Transport fixture."}),
    ]
    result = []
    for task_id, kind, requested in specs:
        state = dict(common)
        state["task"] = f"G0b interface fixture for {kind}: emit the requested action exactly; do not perform scientific inference."
        state["requested_action"] = requested
        result.append({"task_id": task_id, "state": state, "expected": requested, "split": "G0b_development_transport"})
    return result


def native_examples():
    rows = [json.loads(line) for line in M16_DATA.read_text(encoding="utf-8").splitlines() if line.strip()]
    manifest = json.loads(M16_MANIFEST.read_text(encoding="utf-8"))
    # Row 3 is a query in validation world 1 (L4); row 66 is a commit in world 21 (L5).
    # These worlds are independent and neither state was used in G0.
    selections = [(3, 1, "L4", "query"), (66, 21, "L5", "commit")]
    result = []
    for row_index, world_index, level, action in selections:
        row = rows[row_index]
        state = json.loads(row["prompt"][-1]["content"])
        target = json.loads(row["completion"][-1]["content"])
        world = manifest["validation_worlds"][world_index]
        if state.get("level") != level or target.get("action") != action or world.get("level") != level:
            raise RuntimeError(f"M16 selection mismatch at row {row_index}")
        result.append({"task_id": f"native_m16_{level}_{action}", "row_index": row_index,
                       "world_index": world_index, "world_id": world["world_id"], "state": state,
                       "teacher_action": target, "split": "m16_validation_development"})
    if result[0]["world_id"] == result[1]["world_id"]:
        raise RuntimeError("Native M16 controls must use distinct worlds")
    return result


def render(tokenizer, state, system=False, system_content=None):
    messages = [{"role": "user", "content": canon(state)}]
    if system:
        messages.insert(0, {"role": "system", "content": system_content or SYSTEM_EXAMPLES})
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


def strict_parse(raw):
    try:
        value = json.loads(raw.strip())
    except json.JSONDecodeError as exc:
        return None, f"JSONDecodeError at char {exc.pos}: {exc.msg}"
    if not isinstance(value, dict):
        return None, f"Top-level JSON value must be an object; got {type(value).__name__}."
    return value, None


def validate_transport(state, action):
    if not isinstance(action, dict):
        return False, False, "No JSON action object."
    requested = state["requested_action"]
    observed = {row["id"] for row in state["observations"]}
    models = {card["id"] for card in state["candidate_models"]}
    if requested["action"] == "query":
        menu_ids = {row["id"] for row in state["query_menu"]}
        valid = action.get("action") == "query" and action.get("query_id") in menu_ids
        matches = valid and action == requested
        error = None if valid else "Expected query action with query_id from query_menu."
        if valid and not matches:
            error = f"Valid query schema but did not echo requested query_id {requested['query_id']!r}."
        return valid, matches, error
    allowed_verdicts = {"supported", "rejected", "undetermined"}
    valid = (
        action.get("action") == "report"
        and action.get("verdict") in allowed_verdicts
        and isinstance(action.get("confidence"), (int, float)) and not isinstance(action.get("confidence"), bool)
        and 0 <= action.get("confidence", -1) <= 1
        and isinstance(action.get("candidate_model_codes"), list)
        and all(isinstance(x, str) and x in models for x in action.get("candidate_model_codes", []))
        and isinstance(action.get("evidence_ids"), list)
        and all(isinstance(x, str) and x in observed for x in action.get("evidence_ids", []))
        and isinstance(action.get("location"), dict)
        and isinstance(action.get("explanation"), str)
    )
    if not valid:
        return False, False, "Report action failed required fields, types, allowed values, or public-ID checks."
    matches = action == requested
    error = None if matches else "Schema-valid report did not match requested action fields."
    return True, matches, error


def validate_native(state, action):
    if not isinstance(action, dict):
        return False, "No JSON action object."
    kind = action.get("action")
    allowed = set(state.get("allowed_actions", []))
    if kind not in allowed:
        return False, f"Action {kind!r} is not in allowed_actions."
    if kind == "query":
        if not isinstance(action.get("x"), int) or action["x"] not in state.get("available_experiments", []):
            return False, f"Query x={action.get('x')!r} is not an available experiment."
    elif kind == "commit":
        ids = {h.get("id") for h in state.get("hypotheses", [])}
        if action.get("hypothesis_id") not in ids:
            return False, f"hypothesis_id={action.get('hypothesis_id')!r} is not a listed hypothesis."
    elif kind == "search_alternatives":
        if not state.get("can_search_alternatives", False):
            return False, "Alternative search is not available in this state."
    return True, None


def write_line(path, item):
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if any(OUT.iterdir()):
        raise RuntimeError(f"Output directory is not empty: {OUT}")
    fixtures = build_fixtures()
    native = native_examples()
    tasks = fixtures + [
        {"task_id": "canonical_user_only", "state": {"task": "Reply with exactly this JSON object and no other text: {\"status\":\"ok\",\"n\":7}"}, "expected": {"status": "ok", "n": 7}, "split": "base_transport_control", "system": False},
        {"task_id": "canonical_system", "state": {"task": "Return the exact JSON object requested.", "requested_object": {"status": "ready", "n": 3}}, "expected": {"status": "ready", "n": 3}, "split": "base_transport_control", "system": True, "system_prompt": "Return exactly one JSON object with the fields and values in requested_object. Do not include prose or markdown."},
    ]
    local_ref = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/refs/main"
    base_revision = local_ref.read_text().strip() if local_ref.exists() else "unresolved"
    frozen_sources = ["llm_agents.py", "action_utils.py", "generator.py", "environment.py", "evaluate_m17.py"]
    snapshot_path = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots" / base_revision
    base_tokenizer = AutoTokenizer.from_pretrained(str(snapshot_path), local_files_only=True, use_fast=True)
    m16_tokenizer = AutoTokenizer.from_pretrained(str(M16_ADAPTER), local_files_only=True, use_fast=True)
    if base_tokenizer.get_vocab() != m16_tokenizer.get_vocab():
        raise RuntimeError("Base and adapter tokenizers have different vocabularies; stop before inference.")
    if base_tokenizer.chat_template != m16_tokenizer.chat_template:
        raise RuntimeError("Base and adapter chat templates differ; stop before inference.")

    model_plan = {"base": {"path": BASE_MODEL, "tests": []}, "m16": {"path": str(M16_ADAPTER), "tests": []}}
    for model_id in ("base", "m16"):
        for fixture in fixtures:
            for system in (False, True):
                model_plan[model_id]["tests"].append({
                    "task": fixture, "system": system,
                    "system_prompt": SYSTEM_EXAMPLES if system else None,
                    "condition": "explicit_system_with_complete_action_examples" if system else "M17_current_user_only",
                })
    model_plan["base"]["tests"].extend(
        {"task": t, "system": t["system"], "system_prompt": t.get("system_prompt"), "condition": t["task_id"]}
        for t in tasks if t["task_id"].startswith("canonical_")
    )
    model_plan["m16"]["tests"].extend(
        {"task": e, "system": False, "system_prompt": None, "condition": "native_m16"}
        for e in native
    )

    # Render and persist every exact prompt before any model inference.
    tokenizer_metadata = {
        "base_tokenizer_source": str(snapshot_path), "adapter_tokenizer_source": str(M16_ADAPTER),
        "vocabulary_size": len(base_tokenizer), "vocabulary_sha256": sha_bytes(canon(base_tokenizer.get_vocab()).encode()),
        "chat_template_sha256": sha_bytes((base_tokenizer.chat_template or "").encode()),
    }
    schedule = []
    for model_id in ("base", "m16"):
        for test in model_plan[model_id]["tests"]:
            task = test["task"]
            prompt = render(base_tokenizer, task["state"], system=test["system"], system_content=test["system_prompt"])
            input_tokens = len(base_tokenizer(prompt, truncation=False)["input_ids"])
            if input_tokens > MAX_INPUT:
                raise RuntimeError(f"Pre-registered prompt {task['task_id']} exceeds {MAX_INPUT} tokens.")
            record = {
                "generation_id": f"{model_id}:{task['task_id']}:{test['condition']}",
                "model": model_id, "task_id": task["task_id"], "condition": test["condition"],
                "system_message_used": test["system"], "system_message": test["system_prompt"],
                "state": task["state"], "expected_action": task.get("expected"),
                "teacher_action_scoring_only": task.get("teacher_action"),
                "rendered_prompt": prompt, "prompt_sha256": sha_bytes(prompt.encode()),
                "input_tokens": input_tokens,
            }
            schedule.append(record)
    schedule_path = OUT / "schedule.jsonl"
    for record in schedule:
        write_line(schedule_path, record)

    prereg = {
        "protocol_id": "TRONCO01-G0b-v0.1",
        "frozen_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "max_generations": 20,
        "planned_generations": 20,
        "base_model": BASE_MODEL,
        "cached_model_revision": base_revision,
        "adapter_path": str(M16_ADAPTER),
        "adapter_tree_sha256": sha_tree(M16_ADAPTER),
        "m16_examples": [{k: e[k] for k in ("row_index", "world_index", "world_id", "task_id", "split")} for e in native],
        "m16_validation_examples_sha256": sha_file(M16_DATA),
        "prompt_conditions": ["M17_current_user_only", "explicit_system_with_complete_action_examples"],
        "generation_parameters": {"max_input_tokens": MAX_INPUT, "max_new_tokens": MAX_NEW, "do_sample": False, "temperature": None, "truncation": False},
        "fixtures": [{"task_id": t["task_id"], "state": t["state"], "expected": t["expected"], "split": t["split"]} for t in fixtures],
        "canonical_controls": [{"task_id": t["task_id"], "state": t["state"], "expected": t["expected"], "system": t["system"]} for t in tasks if t["task_id"].startswith("canonical_")],
        "m17_sources_before": {name: sha_file(M17 / name) for name in frozen_sources},
        "protocol_document_sha256": sha_file(PROTO),
        "runner_sha256": sha_file(WORK / "run_g0b.py"),
        "tokenizer_metadata": tokenizer_metadata,
        "schedule_sha256": sha_file(schedule_path),
        "strict_single_json_required": True,
        "no_retries": True,
    }
    prereg_bytes = json.dumps(prereg, ensure_ascii=False, sort_keys=True, indent=2).encode()
    prereg["preregistration_sha256"] = sha_bytes(prereg_bytes)
    prereg_path = OUT / "preregistration.json"
    prereg_path.write_text(json.dumps(prereg, ensure_ascii=False, indent=2), encoding="utf-8")

    ledger_path = OUT / "event_ledger.jsonl"
    previous = "0" * 64
    seq = 0
    def ledger(event):
        nonlocal previous, seq
        body = {"seq": seq, "previous_hash": previous, **event}
        digest = sha_bytes(canon(body).encode())
        body["event_hash"] = digest
        write_line(ledger_path, body)
        previous, seq = digest, seq + 1

    questions = []
    for fixture in fixtures:
        questions.append({"question_id": fixture["task_id"], "revision": 1, "state": fixture["state"], "split": fixture["split"]})
    for t in tasks:
        if t["task_id"].startswith("canonical_"):
            questions.append({"question_id": t["task_id"], "revision": 1, "state": t["state"], "split": t["split"]})
    for e in native:
        questions.append({"question_id": e["task_id"], "revision": 1, "state": e["state"], "split": e["split"], "world_id": e["world_id"]})
    for q in questions:
        q["state_sha256"] = sha_bytes(canon(q["state"]).encode())
        ledger({"type": "question_registered", "question_id": q["question_id"], "revision": q["revision"], "state_sha256": q["state_sha256"], "split": q["split"]})
    (OUT / "question_registry.json").write_text(json.dumps(questions, ensure_ascii=False, indent=2), encoding="utf-8")

    task_lookup = {task["task_id"]: task for task in fixtures + tasks + native}
    for model_id in ("base", "m16"):
        model, tokenizer = FastLanguageModel.from_pretrained(model_name=model_plan[model_id]["path"], max_seq_length=MAX_INPUT, dtype=None, load_in_4bit=True)
        FastLanguageModel.for_inference(model)
        model.eval()
        prepared_tests = [record for record in schedule if record["model"] == model_id]
        for index, test in enumerate(prepared_tests):
            task = task_lookup[test["task_id"]]
            system = test["system_message_used"]
            prompt = test["rendered_prompt"]
            tokenized = tokenizer(prompt, return_tensors="pt", truncation=False)
            input_tokens = int(tokenized["input_ids"].shape[1])
            generation_error = None
            if input_tokens != test["input_tokens"]:
                output_ids, raw = [], ""
                parsed, parse_error = None, f"Runtime tokenizer produced {input_tokens} tokens; preregistered prompt has {test['input_tokens']}."
                validation, target_match, validation_error = False, False, parse_error
                generation_error = "tokenizer_schedule_mismatch"
            elif input_tokens > MAX_INPUT:
                output_ids, raw = [], ""
                parsed, parse_error = None, f"Prompt has {input_tokens} tokens, above limit {MAX_INPUT}."
                validation, target_match, validation_error = False, False, parse_error
                generation_error = "prompt_overflow"
            else:
                inputs = {key: value.to(model.device) for key, value in tokenized.items()}
                try:
                    with torch.inference_mode():
                        generated = model.generate(**inputs, max_new_tokens=MAX_NEW, max_length=None, do_sample=False,
                                                   pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
                                                   return_dict_in_generate=True)
                    output_ids = generated.sequences[0, input_tokens:]
                    raw = tokenizer.decode(output_ids, skip_special_tokens=True)
                    parsed, parse_error = strict_parse(raw)
                    validation_error = None
                    target_match = False
                    if task["task_id"].startswith("transport_"):
                        validation, target_match, validation_error = validate_transport(task["state"], parsed)
                    elif task["task_id"].startswith("canonical_"):
                        validation = isinstance(parsed, dict) and set(parsed) == set(task["expected"]) and parsed == task["expected"]
                        target_match = validation
                        if not validation:
                            validation_error = f"Expected exact JSON object {task['expected']!r}; received {parsed!r}."
                    else:
                        validation, validation_error = validate_native(task["state"], parsed)
                        target_match = validation and parsed == task["teacher_action"]
                        if validation and not target_match:
                            validation_error = "Action is valid for the native state but differs from the teacher action."
                    if parsed is None and validation_error is None:
                        validation_error = parse_error
                except Exception as exc:
                    output_ids, raw, parsed = [], "", None
                    parse_error = None
                    validation, target_match = False, False
                    validation_error = None
                    generation_error = f"{type(exc).__name__}: {exc}"
            eos_id = tokenizer.eos_token_id
            eos = bool(len(output_ids) and eos_id is not None and int(output_ids[-1]) == int(eos_id))
            result_class = "generation_failure" if generation_error else "parse_failure" if parsed is None else "action_valid" if validation else "schema_or_reference_failure"
            generation_id = f"{model_id}:{task['task_id']}:{test['condition']}"
            item = {
                "generation_id": generation_id, "model": model_id, "task_id": task["task_id"],
                "condition": test["condition"], "system_message_used": system,
                "state": task["state"], "rendered_prompt": prompt,
                "prompt_sha256": sha_bytes(prompt.encode()), "input_tokens": input_tokens,
                "raw_output": raw, "output_tokens": int(len(output_ids)), "eos_reached": eos,
                "hit_generation_limit": len(output_ids) >= MAX_NEW,
                "parsed_object": parsed, "strict_json_object": parsed is not None,
                "action_valid": bool(validation), "target_match": bool(target_match),
                "result_class": result_class, "parse_error": parse_error,
                "validation_error": validation_error, "generation_error": generation_error,
            }
            if "teacher_action" in task:
                item["teacher_action_for_scoring_only"] = task["teacher_action"]
                item["teacher_match"] = bool(target_match)
            write_line(OUT / "generations.jsonl", item)
            ledger({"type": "generation", "generation_id": generation_id,
                    "question_id": task["task_id"], "evidence_id": f"ev-{seq:04d}",
                    "prompt_sha256": item["prompt_sha256"], "raw_output_sha256": sha_bytes(raw.encode()),
                    "result_class": result_class, "action_valid": bool(validation), "target_match": bool(target_match)})
            print(json.dumps({"id": generation_id, "input_tokens": input_tokens, "output_tokens": int(len(output_ids)), "eos": eos, "class": result_class, "valid": bool(validation), "target_match": bool(target_match)}, ensure_ascii=False), flush=True)
        del model, tokenizer
        torch.cuda.empty_cache()

    rows = [json.loads(line) for line in (OUT / "generations.jsonl").read_text(encoding="utf-8").splitlines() if line]
    m17_after = {name: sha_file(M17 / name) for name in frozen_sources}
    classes = Counter(r["result_class"] for r in rows)
    by_group = {}
    for key, predicate in {
        "base_transport_current": lambda r: r["model"] == "base" and r["task_id"].startswith("transport_") and not r["system_message_used"],
        "base_transport_system": lambda r: r["model"] == "base" and r["task_id"].startswith("transport_") and r["system_message_used"],
        "m16_transport_current": lambda r: r["model"] == "m16" and r["task_id"].startswith("transport_") and not r["system_message_used"],
        "m16_transport_system": lambda r: r["model"] == "m16" and r["task_id"].startswith("transport_") and r["system_message_used"],
        "base_canonical": lambda r: r["model"] == "base" and r["task_id"].startswith("canonical_"),
        "m16_native": lambda r: r["model"] == "m16" and r["task_id"].startswith("native_m16_"),
    }.items():
        subset = [r for r in rows if predicate(r)]
        by_group[key] = {"n": len(subset), "strict_json": sum(r["strict_json_object"] for r in subset),
                         "valid": sum(r["action_valid"] for r in subset), "target_match": sum(r["target_match"] for r in subset),
                         "classes": dict(Counter(r["result_class"] for r in subset))}
    summary = {
        "protocol_id": prereg["protocol_id"], "generations_completed": len(rows), "max_generations": 20,
        "by_group": by_group, "all_eos": all(r["eos_reached"] for r in rows),
        "generation_limit_hits": sum(r["hit_generation_limit"] for r in rows),
        "result_classes": dict(classes), "m17_sources_unchanged": prereg["m17_sources_before"] == m17_after,
        "m17_sources_after": m17_after, "registered_questions": len(questions),
        "events": seq, "ledger_final_hash": previous,
        "finished_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    for model_id in ("base", "m16"):
        gate_rows = [r for r in rows if r["model"] == model_id and r["task_id"].startswith("transport_") and r["system_message_used"]]
        summary.setdefault("transport_gate_by_model", {})[model_id] = {
            "n": len(gate_rows), "strict_json": sum(r["strict_json_object"] for r in gate_rows),
            "action_valid": sum(r["action_valid"] for r in gate_rows),
            "target_match": sum(r["target_match"] for r in gate_rows),
            "passed": len(gate_rows) == 4 and all(r["strict_json_object"] and r["action_valid"] and r["target_match"] and not r["hit_generation_limit"] for r in gate_rows),
        }
    (OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    run_manifest = {"protocol_sha256": prereg["preregistration_sha256"], "schedule_sha256": sha_file(schedule_path),
                    "generations_completed": len(rows), "summary": summary}
    (OUT / "run_manifest.json").write_text(json.dumps(run_manifest, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
