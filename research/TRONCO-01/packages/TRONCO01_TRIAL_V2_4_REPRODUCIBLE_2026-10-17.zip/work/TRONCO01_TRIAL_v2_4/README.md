# TRONCO-01 v2.4 offline integration precheck

This is a preparation and analysis checkpoint. It includes an executable action/recovery harness, an independent standard-library replay of the historical v2.3 pilot, tests, and a frozen copy of the public schedule and historical records. It does not load a model or make inference calls.

The action schema restricts only syntax and IDs visible in the current state. It does not compute the expected verdict, candidate set, diagnosis, sufficiency, evidence certificate, or location. Rejected actions receive a public legality message on the next call; that message contains no expected scientific conclusion. Calls remain bounded, malformed model output terminates the episode as a model-output failure, and an interrupted unfinished episode requires inspection instead of automatic replay.

## Reproduce the saved v2.3 analysis

From this directory run: python replay.py

The command uses fixtures/v23 and only the archived public schedule, event journal, and saved outcomes. It makes no model calls. Add --output PATH to save the reconstructed JSON elsewhere.

## Verify this offline harness

Run: python -m unittest discover -s tests -v

The tests use only Python's standard library.

The tokenizer-only gate passed for the recorded cases and is saved in results/tokenizer_preflight_v2_4.json. To reproduce it, install requirements-tokenizer.txt in Python 3.12 and point TRONCO_TOKENIZER_PATH at the cached tokenizer directory before running python grammar_preflight.py. The script loads tokenizer files only; it does not load model weights. The model generation adapter remains untested.

## Status

protocol_status.json deliberately leaves model, weights, generation settings, and a future episode schedule unset. The v2.4 prompt and state-scoped IDs change the interface, so any later inference requires a distinct pre-registration and a new mandatory analysis point. Historical v2.3, G1/G2, and M17 are not modified.
