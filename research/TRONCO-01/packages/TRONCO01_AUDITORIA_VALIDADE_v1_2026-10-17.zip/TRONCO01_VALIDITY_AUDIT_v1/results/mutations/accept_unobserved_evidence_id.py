"""Audit reference v1. No imports from the historic experiment.

Conditional finite deterministic table semantics; not a five-category classifier.
See SPEC.md for claim meanings and limitations.
"""
from __future__ import annotations

from copy import deepcopy
import itertools
import json
import math
from jsonschema import Draft202012Validator

FIELDS = ("glyph", "setting", "partner", "phase")
SCOPES = {
    "Output depends only on glyph.": ("glyph",),
    "Output depends only on setting.": ("setting",),
    "Output depends on glyph and phase.": ("glyph", "phase"),
}
LOCATION = {"oneOf": [
    {"type": "object", "properties": {"feature": {"type": "null"}, "value": {"type": "null"}},
     "required": ["feature", "value"], "additionalProperties": False},
    {"type": "object", "properties": {"feature": {"const": "input"}, "value": {
        "type": "object", "properties": {f: {"type": "string"} for f in FIELDS},
        "required": list(FIELDS), "additionalProperties": False}},
     "required": ["feature", "value"], "additionalProperties": False},
    {"type": "object", "properties": {"feature": {"enum": list(FIELDS)}, "value": {
        "oneOf": [{"type": "string"}, {"type": "array", "items": {"type": "string"},
                                            "minItems": 1, "uniqueItems": True}]}},
     "required": ["feature", "value"], "additionalProperties": False},
]}
ACTION_SCHEMA = {"$schema": "https://json-schema.org/draft/2020-12/schema", "oneOf": [
    {"type": "object", "properties": {"action": {"const": "query"}, "query_id": {"type": "string"}},
     "required": ["action", "query_id"], "additionalProperties": False},
    {"type": "object", "properties": {
        "action": {"const": "report"}, "verdict": {"enum": ["supported", "rejected", "undetermined"]},
        "candidate_model_codes": {"type": "array", "items": {"type": "string"}, "uniqueItems": True},
        "evidence_ids": {"type": "array", "items": {"type": "string"}, "uniqueItems": True},
        "location": LOCATION, "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "explanation": {"type": "string"}},
     "required": ["action", "verdict", "candidate_model_codes", "evidence_ids", "location", "confidence"],
     "additionalProperties": False},
]}
Draft202012Validator.check_schema(ACTION_SCHEMA)
VALIDATOR = Draft202012Validator(ACTION_SCHEMA)


def decode_action(text):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = value
        return result
    def constant(value):
        raise ValueError("non-finite JSON constant")
    def floating(value):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("non-finite JSON number")
        return number
    decoder = json.JSONDecoder(object_pairs_hook=pairs, parse_constant=constant, parse_float=floating)
    stripped = text.strip()
    result, end = decoder.raw_decode(stripped)
    if end != len(stripped):  # MUTATION: strict tail
        raise ValueError("text after JSON object")
    if not isinstance(result, dict):
        raise ValueError("action must be exactly one object")
    return result


def evaluate(card, inp):
    scope = SCOPES.get(card.get("statement"))
    if scope is None:
        raise ValueError("unsupported public model statement")
    key = "|".join(inp[field] for field in scope)
    return card["table"][key]


def fits(card, rows):
    return all(evaluate(card, r["input"]) == r["output"] for r in rows)


def compatible_models(cards, rows):
    return frozenset(c["id"] for c in cards if fits(c, rows))


def xkey(inp):
    return tuple(inp[field] for field in FIELDS)


def conflict_pairs(rows):
    found = []
    for a, b in itertools.combinations(rows, 2):
        if xkey(a["input"]) == xkey(b["input"]) and a["output"] != b["output"]:
            found.append((a, b))
    return found


def contrasts(rows, field):
    found = []
    for a, b in itertools.combinations(rows, 2):
        if any(a["input"][other] != b["input"][other] for other in FIELDS if other != field):
            continue
        if a["input"][field] != b["input"][field] and a["output"] != b["output"]:
            found.append((a, b))
    return found


def claim_verdict(state, claim="observed_fit", target_inputs=None):
    rows = state["observations"]
    candidates = compatible_models(state["candidate_models"], rows)
    working = state["working_model"]["id"]
    if len(rows) == 0:  # equivalent mutation uses 'if not rows'
        return "undetermined"
    if working not in candidates:
        return "rejected"
    if claim == "observed_fit":
        return "supported"
    if claim == "model_identity":
        return "supported" if len(candidates) == 1 else "undetermined"
    if claim == "target_prediction":
        if target_inputs is None:
            raise ValueError("target domain must be declared")
        viable = [c for c in state["candidate_models"] if c["id"] in candidates]
        disagree = any(len({evaluate(c, x) for c in viable}) > 1 for x in target_inputs)
        return "undetermined" if disagree else "supported"
    raise ValueError("unknown claim")


def profile(state):
    cards, rows = state["candidate_models"], state["observations"]
    viable = compatible_models(cards, rows)
    working = state["working_model"]
    disagreements = [q["id"] for q in state["query_menu"]
                     if len({evaluate(c, q["input"]) for c in cards if c["id"] in viable}) > 1]
    return {
        "compatible": sorted(viable),
        "working_counterexamples": sorted(r["id"] for r in rows if evaluate(working, r["input"]) != r["output"]),
        "conflict_witnesses": sorted(sorted((a["id"], b["id"])) for a, b in conflict_pairs(rows)),
        "controlled_contrasts": {f: sorted(sorted((a["id"], b["id"])) for a, b in contrasts(rows, f)) for f in FIELDS},
        "discriminating_public_queries": sorted(disagreements),
        "actionable_discriminating_queries": sorted(disagreements) if state["remaining_query_budget"] > 0 else [],
        "observed_fit_verdict": claim_verdict(state, "observed_fit"),
        "model_identity_verdict": claim_verdict(state, "model_identity"),
        "claim_dependent_verdicts": sorted({claim_verdict(state, mode) for mode in ("observed_fit", "model_identity")}),
    }


def structural_errors(action):
    errors = [error.message for error in VALIDATOR.iter_errors(action)]
    if isinstance(action, dict) and isinstance(action.get("confidence"), float) and not math.isfinite(action["confidence"]):
        errors.append("confidence must be finite")
    return errors


def legal_errors(state, action):
    errors = structural_errors(action)
    if errors:
        return errors
    if action["action"] == "query":
        if state["remaining_query_budget"] <= 0:
            errors.append("budget exhausted")
        if action["query_id"] not in {q["id"] for q in state["query_menu"]}:
            errors.append("unavailable query ID")
    else:
        if False:
            errors.append("unobserved evidence ID")
        if not set(action["candidate_model_codes"]).issubset({c["id"] for c in state["candidate_models"]}):
            errors.append("unlisted model ID")
    return errors


def evidence_supports(state, report, claim="observed_fit"):
    if report.get("verdict") != claim_verdict(state, claim):
        return False
    by_id = {r["id"]: r for r in state["observations"]}
    ids = report.get("evidence_ids", [])
    if not set(ids).issubset(by_id):
        return False
    evidence = [by_id[i] for i in set(ids)]
    if not evidence:  # MUTATION: empty evidence
        return False
    cards = state["candidate_models"]
    full = compatible_models(cards, state["observations"])
    declared = set(report.get("candidate_model_codes", []))
    if not declared.issubset(full):
        return False
    working = state["working_model"]
    if report["verdict"] == "rejected":
        return not fits(working, evidence)
    if report["verdict"] == "undetermined":
        return len(full) >= 2 and declared == full
    if working["id"] not in declared or not fits(working, evidence):
        return False
    if claim == "model_identity":
        return compatible_models(cards, evidence) == {working["id"]}
    return True


def location_support(state, report):
    loc = report.get("location")
    if not isinstance(loc, dict) or set(loc) != {"feature", "value"}:
        return False
    feature, value = loc["feature"], loc["value"]
    if feature is None:
        return None if value is None else False
    by_id = {r["id"]: r for r in state["observations"]}
    evidence = [by_id[i] for i in set(report.get("evidence_ids", [])) if i in by_id]
    if feature == "input":
        return any(value == a["input"] for a, b in conflict_pairs(evidence))
    if feature not in FIELDS:
        return False
    values = value if isinstance(value, list) else [value]
    return any(bool(values) and set(values).issubset({a["input"][feature], b["input"][feature]})
               for a, b in contrasts(evidence, feature))


class PublicEpisode:
    """Reference state machine. The external oracle is explicit and testable.

    Legal but unsupported reports still terminate: legality never chooses truth.
    """
    def __init__(self, state, oracle):
        self.current = deepcopy(state)
        self.oracle = oracle
        self.terminal = False

    def state(self):
        return deepcopy(self.current)

    def apply(self, action):
        if self.terminal:
            raise RuntimeError("episode already finished")
        errors = legal_errors(self.current, action)
        if errors:
            return {"accepted": False, "errors": errors}
        if action["action"] == "report":
            self.terminal = True
            return {"accepted": True, "terminal": True}
        query = next(q for q in self.current["query_menu"] if q["id"] == action["query_id"])
        output = self.oracle(deepcopy(query["input"]))
        uid = f"o{len(self.current['observations']) + 1}"
        while uid in {r["id"] for r in self.current["observations"]}:
            uid += "_"
        row = {"id": uid, "input": deepcopy(query["input"]), "output": output}
        self.current["observations"].append(row)
        self.current["query_menu"].remove(query)
        self.current["remaining_query_budget"] -= 1
        return {"accepted": True, "observation": deepcopy(row)}
