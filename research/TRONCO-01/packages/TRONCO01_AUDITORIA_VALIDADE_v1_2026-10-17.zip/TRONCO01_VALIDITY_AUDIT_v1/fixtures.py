"""Hand-written development fixtures; no production generator/oracle imports."""
from copy import deepcopy


def row(uid, glyph="g0", setting="s0", partner="p0", phase="t0", output="0"):
    return {"id": uid, "input": {"glyph": glyph, "setting": setting, "partner": partner, "phase": phase}, "output": output}


def base_state():
    cards = [
        {"id": "A", "statement": "Output depends only on glyph.", "table": {"g0": "0", "g1": "0"}},
        {"id": "B", "statement": "Output depends only on setting.", "table": {"s0": "1", "s1": "1"}},
        {"id": "C", "statement": "Output depends on glyph and phase.",
         "table": {"g0|t0": "0", "g0|t1": "1", "g1|t0": "0", "g1|t1": "1"}},
    ]
    return {"candidate_models": cards, "working_model": deepcopy(cards[0]),
            "observations": [row("a")],
            "query_menu": [{"id": f"q{i}", "input": row("unused", partner=f"p{i}", phase="t1" if i == 4 else "t0")["input"]} for i in range(5)],
            "remaining_query_budget": 3}


def report(verdict="supported", evidence=("a",), candidates=("A",), feature=None, value=None):
    return {"action": "report", "verdict": verdict, "candidate_model_codes": list(candidates),
            "evidence_ids": list(evidence), "location": {"feature": feature, "value": value},
            "confidence": 0.5}


def legacy_world(state, category="NORMAL", actual="A"):
    # Explicit toy oracle is one of the published tables; never a reserved world.
    kinds = {"A": "glyph", "B": "setting", "C": "glyph_phase"}
    cards = [{**deepcopy(c), "kind": kinds[c["id"]]} for c in state["candidate_models"]]
    return {"category": category, "family": "dev_table", "world_id": "audit-manual",
            "cards": cards, "working_model_id": state["working_model"]["id"],
            "hidden": {"kind": "card", "card": next(c for c in cards if c["id"] == actual)},
            "public": deepcopy(state)}
