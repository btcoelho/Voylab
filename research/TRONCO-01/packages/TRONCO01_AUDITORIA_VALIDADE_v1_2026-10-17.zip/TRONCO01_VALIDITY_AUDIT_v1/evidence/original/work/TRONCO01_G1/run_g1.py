from __future__ import annotations

import gc
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
M17 = ROOT / "work" / "M17_DESCOBERTA_DIAGNOSTICO"
RUN = ROOT / "work" / "TRONCO01_G1" / "run_20261017_v02"
sys.path.insert(0, str(M17))

from agents import (FixedQueryControl, RandomQueryControl, StatisticalAnomalyDetector,
                    SymbolicActiveControl)
from environment import Episode, score_report
from evaluate_m17 import CATEGORIES, summarize
from preflight_g1 import SYSTEM, state_parser

BASE_PATH = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"
ADAPTER_PATH = Path.home() / "voynich-lab/experiencias/M16_CURRICULO/runs/m16-l4l5-r1/adapter"
MAX_CONTEXT = 2048
MAX_NEW = 192
MAX_ACTIONS = 4


def sha(text: bytes) -> str:
    return hashlib.sha256(text).hexdigest()


def canon(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def prompt_for(tokenizer, state: dict, schema_condition: bool) -> str:
    messages = []
    if schema_condition:
        messages.append({"role": "system", "content": SYSTEM})
    messages.append({"role": "user", "content": canon(state)})
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


class ModelDriver:
    def __init__(self, model_id: str, model, tokenizer):
        self.model_id = model_id
        self.model = model
        self.tokenizer = tokenizer
        import transformers
        import transformers.tokenization_utils as tokenization_utils
        tokenization_utils.PreTrainedTokenizerBase = transformers.PreTrainedTokenizerBase
        from lmformatenforcer.integrations.transformers import (
            build_transformers_prefix_allowed_tokens_fn,
            build_token_enforcer_tokenizer_data,
        )
        self.build_prefix = build_transformers_prefix_allowed_tokens_fn
        self.token_data = build_token_enforcer_tokenizer_data(tokenizer)

    @classmethod
    def load(cls, model_id: str):
        import unsloth
        model_path = BASE_PATH if model_id == "base" else ADAPTER_PATH
        model, tokenizer = unsloth.FastLanguageModel.from_pretrained(
            model_name=str(model_path), max_seq_length=MAX_CONTEXT, dtype=None, load_in_4bit=True
        )
        unsloth.FastLanguageModel.for_inference(model)
        model.eval()
        return cls(model_id, model, tokenizer)

    def act(self, state: dict, condition: str) -> dict:
        schema_condition = condition.endswith("_schema")
        prompt = prompt_for(self.tokenizer, state, schema_condition)
        encoded = self.tokenizer(prompt, return_tensors="pt", truncation=False)
        input_len = int(encoded["input_ids"].shape[1])
        if input_len + MAX_NEW > MAX_CONTEXT:
            return {
                "action": {"action": "invalid_model_output"}, "raw": "",
                "prompt_sha256": sha(prompt.encode()), "input_tokens": input_len,
                "output_tokens": 0, "eos": False, "hit_limit": False,
                "strict_json": False, "parse_success": False, "generation_failure": True,
                "error": f"context budget exceeded: {input_len}+{MAX_NEW}>{MAX_CONTEXT}",
            }
        input_ids = encoded["input_ids"].to(self.model.device)
        kwargs = {
            "max_new_tokens": MAX_NEW,
            "max_length": None,
            "do_sample": False,
            "pad_token_id": self.tokenizer.pad_token_id or self.tokenizer.eos_token_id,
            "return_dict_in_generate": True,
        }
        if schema_condition:
            parser = state_parser(state)
            kwargs["prefix_allowed_tokens_fn"] = self.build_prefix(self.token_data, parser)
        try:
            with torch.inference_mode():
                result = self.model.generate(input_ids=input_ids, **kwargs)
            generated = result.sequences[0, input_len:]
            raw = self.tokenizer.decode(generated, skip_special_tokens=True)
            eos = bool(len(generated) and int(generated[-1].item()) == self.tokenizer.eos_token_id)
            try:
                parsed = json.loads(raw.strip())
                strict = isinstance(parsed, dict)
                parse_success = isinstance(parsed, dict)
                parse_error = None
            except Exception as error:
                parsed = None
                strict = False
                parse_success = False
                parse_error = f"{type(error).__name__}: {error}"
            if not schema_condition and not isinstance(parsed, dict):
                from action_utils import first_json_object
                parsed = first_json_object(raw)
                parse_success = isinstance(parsed, dict)
            return {
                "action": parsed if isinstance(parsed, dict) else {"action": "invalid_model_output"},
                "raw": raw,
                "prompt_sha256": sha(prompt.encode()),
                "input_tokens": input_len,
                "output_tokens": int(len(generated)),
                "eos": eos,
                "hit_limit": int(len(generated)) >= MAX_NEW,
                "strict_json": strict,
                "parse_success": parse_success,
                "parse_error": parse_error,
                "generation_failure": False,
                "error": None,
            }
        except Exception as error:
            return {
                "action": {"action": "invalid_model_output"}, "raw": "",
                "prompt_sha256": sha(prompt.encode()), "input_tokens": input_len,
                "output_tokens": 0, "eos": False, "hit_limit": False,
                "strict_json": False, "parse_success": False, "generation_failure": True,
                "error": f"{type(error).__name__}: {error}",
            }


def append_jsonl(path: Path, row: dict) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def contract_error(state: dict, action: dict) -> str | None:
    if not isinstance(action, dict):
        return "action is not an object"
    if action.get("action") == "query":
        if set(action) != {"action", "query_id"}:
            return "query action has missing or extra fields"
        if action.get("query_id") not in {q["id"] for q in state["query_menu"]}:
            return "query_id is not currently public and available"
        if state["remaining_query_budget"] <= 0:
            return "query budget is exhausted"
        return None
    if action.get("action") != "report":
        return "action must be query or report"
    required = {"action", "verdict", "candidate_model_codes", "evidence_ids",
                "location", "confidence", "explanation"}
    if set(action) != required:
        return "report has missing or extra fields"
    if action["verdict"] not in {"supported", "rejected", "undetermined"}:
        return "invalid report verdict"
    if not isinstance(action["candidate_model_codes"], list) or any(
            not isinstance(x, str) or x not in {m["id"] for m in state["candidate_models"]}
            for x in action["candidate_model_codes"]):
        return "candidate_model_codes contains a non-public model ID"
    if not isinstance(action["evidence_ids"], list) or any(
            not isinstance(x, str) or x not in {r["id"] for r in state["observations"]}
            for x in action["evidence_ids"]):
        return "evidence_ids contains a non-public observation ID"
    if not isinstance(action["location"], dict):
        return "location must be an object"
    if not isinstance(action["confidence"], (int, float)) or isinstance(action["confidence"], bool) or not 0 <= action["confidence"] <= 1:
        return "confidence must be numeric in [0,1]"
    if not isinstance(action["explanation"], str):
        return "explanation must be a string"
    return None


def run_episode(episode_data: dict, condition: str, action_fn, model_id: str,
                event_path: Path) -> dict:
    world = episode_data["world"]
    ep = Episode(world)
    generation_failures = 0
    parser_failures = 0
    truncations = 0
    output_tokens = 0
    attempts = 0
    failed = False
    explicit_report = False
    for step in range(1, MAX_ACTIONS + 1):
        if ep.terminal:
            break
        state = ep.state()
        meta = action_fn(state)
        action = meta.get("action")
        attempts += 1
        generation_failures += int(bool(meta.get("generation_failure")))
        parser_failures += int(not bool(meta.get("parse_success", meta.get("strict_json"))))
        truncations += int(bool(meta.get("hit_limit")))
        output_tokens += int(meta.get("output_tokens", 0))
        schema_error = contract_error(state, action)
        try:
            if schema_error:
                response = {"accepted": False, "error": f"G1 contract: {schema_error}"}
            else:
                response = ep.apply(action)
            accepted = bool(response.get("accepted"))
        except Exception as error:
            response = {"accepted": False, "error": f"{type(error).__name__}: {error}"}
            accepted = False
        event = {
            "model": model_id, "condition": condition,
            "episode_id": episode_data["episode_id"],
            "cohort": episode_data["cohort"], "step": step,
            "world_id": world["world_id"], "category_for_scoring_only": world["category"],
            "prompt_sha256": meta.get("prompt_sha256"),
            "input_tokens": meta.get("input_tokens"), "output_tokens": meta.get("output_tokens"),
            "eos": meta.get("eos"), "hit_limit": meta.get("hit_limit"),
            "strict_json": meta.get("strict_json"), "parse_error": meta.get("parse_error"),
            "generation_failure": meta.get("generation_failure"), "generation_error": meta.get("error"),
            "raw": meta.get("raw"), "action": action,
            "environment_response": response, "accepted": accepted,
        }
        append_jsonl(event_path, event)
        if not accepted:
            failed = True
            ep.invalid_actions += 1
            break
        if ep.terminal:
            explicit_report = True
            break

    forced = not ep.terminal
    report_for_scoring = ep.report
    if forced:
        report_for_scoring = {"verdict": "undetermined", "confidence": 0.0,
                              "candidate_model_codes": [], "evidence_ids": [],
                              "location": {}, "explanation": "forced termination"}
    scored = score_report(world, ep.observations, report_for_scoring)
    if forced:
        scored = {"decision_correct": False, "diagnosis_correct": False, "localized_correct": False}
    return {
        "category": world["category"], "family": world["family"],
        "world_id": world["world_id"], "model": model_id, "condition": condition,
        "episode_id": episode_data["episode_id"], "cohort": episode_data["cohort"],
        "verdict": report_for_scoring["verdict"],
        "confidence": report_for_scoring["confidence"],
        "query_count": len(ep.query_records), "invalid_actions": ep.invalid_actions,
        "action_count": attempts, "forced_termination": forced,
        "explicit_report": explicit_report,
        "operational_failure": bool(failed or forced or generation_failures or parser_failures or truncations),
        "generation_failures": generation_failures, "parser_failures": parser_failures,
        "truncations": truncations, "output_tokens": output_tokens,
        "redundant_queries": ep.redundant_queries,
        "expected_information_gain": [x["expected"] for x in ep.query_ig],
        "actual_information_gain": [x["actual"] for x in ep.query_ig],
        "decision_correct": scored["decision_correct"],
        "diagnosis_correct": scored["diagnosis_correct"],
        "localized_correct": scored["localized_correct"],
        "candidate_set_size": len(ep.compatible_ids()),
        "query_history": ep.query_records, "report": ep.report,
    }


def control_agents(seed: int, world: dict) -> dict:
    return {
        "statistical_detector": StatisticalAnomalyDetector(),
        "random_query": RandomQueryControl(seed ^ int(world["world_id"][:8], 16)),
        "fixed_query": FixedQueryControl(seed),
        "symbolic_active": SymbolicActiveControl(),
    }


def write_episode(path: Path, row: dict) -> None:
    append_jsonl(path, row)


def main() -> None:
    prereg = json.loads((RUN / "preregistration.json").read_text(encoding="utf-8"))
    preflight = json.loads((RUN / "preflight.json").read_text(encoding="utf-8"))
    if preflight.get("status") != "PASS" or preflight.get("weights_loaded") is not False:
        raise RuntimeError("Pre-inference technical gate did not pass")
    if prereg.get("status") != "frozen_pre_inference":
        raise RuntimeError("Protocol is not in frozen pre-inference state")
    schedule = [json.loads(line) for line in (RUN / "schedule.jsonl").read_text(encoding="utf-8").splitlines()]
    sentinel = [x for x in schedule if x["cohort"] == "sentinel"]
    extension = [x for x in schedule if x["cohort"] == "extension"]
    events_path = RUN / "actions.jsonl"
    episodes_path = RUN / "episodes.jsonl"
    if any(path.exists() for path in (events_path, episodes_path, RUN / "summary.json")):
        raise RuntimeError("Run outputs already exist; refusing to repeat inference")
    events_path.write_text("", encoding="utf-8")
    episodes_path.write_text("", encoding="utf-8")
    episode_rows: list[dict] = []
    model_rows: dict[str, list[dict]] = {key: [] for key in
        ("base_native", "base_schema", "m16_native", "m16_schema")}

    def run_model_condition(driver, episode_data, condition):
        row = run_episode(episode_data, condition,
                          lambda state: driver.act(state, condition), driver.model_id, events_path)
        write_episode(episodes_path, row)
        episode_rows.append(row)
        model_rows[condition].append(row)
        print(json.dumps({"condition": condition, "episode": episode_data["episode_id"],
                          "cohort": episode_data["cohort"], "verdict": row["verdict"],
                          "explicit_report": row["explicit_report"], "operational_failure": row["operational_failure"],
                          "queries": row["query_count"]}), flush=True)

    def load_and_run(model_id, episodes):
        driver = ModelDriver.load(model_id)
        conditions = (f"{model_id}_native", f"{model_id}_schema")
        for episode_data in episodes:
            for condition in conditions:
                run_model_condition(driver, episode_data, condition)
        del driver
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    # The five-world operational sentinel is the only model evaluation before its gate.
    load_and_run("base", sentinel)
    load_and_run("m16", sentinel)

    controls_done = set()

    def run_controls(episodes):
        for episode_data in episodes:
            world = episode_data["world"]
            seed = int(episode_data["seed"])
            for name, agent in control_agents(seed, world).items():
                condition = f"control_{name}"
                def control_action(state, a=agent):
                    action = a.act(state)
                    return {"action": action, "raw": canon(action), "strict_json": True,
                            "parse_success": True, "generation_failure": False,
                            "hit_limit": False, "output_tokens": 0,
                            "input_tokens": 0, "eos": True}
                row = run_episode(episode_data, condition, control_action,
                                  "control", events_path)
                write_episode(episodes_path, row)
                episode_rows.append(row)
                model_rows.setdefault(condition, []).append(row)
                controls_done.add(episode_data["episode_id"])
        print(json.dumps({"controls_completed_worlds": len(controls_done)}), flush=True)

    run_controls(sentinel)
    gate = {}
    for condition in ("base_schema", "m16_schema"):
        rows = [r for r in model_rows[condition] if r["cohort"] == "sentinel"]
        gate[condition] = {
            "n": len(rows), "explicit_reports": sum(r["explicit_report"] for r in rows),
            "generation_failures": sum(r["generation_failures"] for r in rows),
            "parser_failures": sum(r["parser_failures"] for r in rows),
            "truncations": sum(r["truncations"] for r in rows),
            "invalid_actions": sum(r["invalid_actions"] for r in rows),
            "passed": (len(rows) == 5 and all(r["explicit_report"] for r in rows)
                       and sum(r["generation_failures"] for r in rows) == 0
                       and sum(r["parser_failures"] for r in rows) == 0
                       and sum(r["truncations"] for r in rows) == 0
                       and sum(r["invalid_actions"] for r in rows) == 0),
        }
    sentinel_summary = {"protocol": prereg["protocol"], "sentinel_completed": True,
                        "mandatory_analysis_gate": gate,
                        "extension_authorized_by_rule": any(x["passed"] for x in gate.values()),
                        "conditions": {k: summarize(v) for k, v in model_rows.items() if v}}
    (RUN / "sentinel_summary.json").write_text(json.dumps(sentinel_summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if not sentinel_summary["extension_authorized_by_rule"]:
        status = {"status": "stopped_after_sentinel", "reason": "Neither schema-constrained model condition passed the operational gate.",
                  "gate": gate, "diagnostic_and_confirmation_opened": False, "fine_tuning": False}
        (RUN / "status.json").write_text(json.dumps(status, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(json.dumps(status, indent=2, ensure_ascii=False), flush=True)
        return

    # The frozen rule advances all conditions and controls together on the remaining 20 worlds.
    load_and_run("base", extension)
    load_and_run("m16", extension)
    run_controls(extension)
    summaries = {}
    for condition, rows in model_rows.items():
        summaries[condition] = {
            "episodes": len(rows),
            "sentinel": summarize([r for r in rows if r["cohort"] == "sentinel"]),
            "all_25": summarize(rows),
            "by_category": {
                category: summarize([r for r in rows if r["category"] == category])
                for category in CATEGORIES if any(r["category"] == category for r in rows)
            },
            "operational_failures": sum(r["operational_failure"] for r in rows),
            "generation_failures": sum(r["generation_failures"] for r in rows),
            "parser_failures": sum(r["parser_failures"] for r in rows),
            "truncations": sum(r["truncations"] for r in rows),
        }
    summary = {
        "protocol": prereg["protocol"], "status": "development_exploration_complete",
        "sentinel_gate": gate, "episodes_total": len(schedule),
        "all_worlds_excluded_from_prior_pilot_and_g0g": True,
        "reserved_splits_opened": False, "fine_tuning": False,
        "conditions": summaries,
        "limitations": ["25 balanced development worlds are exploratory.",
                        "No transfer approval or population-level error claim.",
                        "The constrained condition combines the G1 instruction and schema decoding."],
    }
    (RUN / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    status = {"status": "development_exploration_complete", "mandatory_analysis": True,
              "diagnostic_and_confirmation_opened": False, "fine_tuning": False}
    (RUN / "status.json").write_text(json.dumps(status, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": status["status"], "sentinel_gate": gate,
                      "episodes_total": len(schedule), "conditions": list(summaries)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
