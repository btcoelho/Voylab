from __future__ import annotations

import copy
import gc
import hashlib
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
M17 = ROOT / "work" / "M17_DESCOBERTA_DIAGNOSTICO"
RUN = ROOT / "work" / "TRONCO01_G2" / "run_20261017_v01"
G1DIR = ROOT / "work" / "TRONCO01_G1"
sys.path[:0] = [str(M17), str(G1DIR)]

from agents import (FixedQueryControl, RandomQueryControl, StatisticalAnomalyDetector,
                    SymbolicActiveControl)
from environment import Episode, score_report
from evaluate_m17 import CATEGORIES, summarize
from preflight_g1 import SYSTEM as G1_SYSTEM, state_parser

BASE_PATH = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"
MAX_CONTEXT = 2048
MAX_NEW = 192
MAX_ACTIONS = 4

G2_SYSTEM = (
    "You are an investigator. Use only the public state in the user message. "
    "Choose a useful allowed query when more evidence is needed, or report a conclusion. "
    "Return exactly one JSON action matching response_schema. Do not invent IDs or evidence. "
    "For a report, treat descriptive text in response_schema as instructions, not values to copy. "
    "In location.feature, give the literal field name. To locate conflicting outputs for the same "
    "complete input, set feature to 'input' and value to the complete input object. To localize an "
    "effect, use its literal field name: glyph, setting, partner, or phase, and cite the observations "
    "that show it. Use null only when the evidence does not justify a location. Include enough evidence "
    "IDs to establish every reported contrast. If more than one candidate account remains compatible, "
    "report undetermined and list those public candidate IDs."
)

G2_RESPONSE_SCHEMA = {
    "query": {"action": "query", "query_id": "one ID from query_menu"},
    "report": {
        "action": "report",
        "candidate_model_codes": "list of public candidate IDs supported or still compatible",
        "confidence": "number from 0 to 1",
        "evidence_ids": "public observation IDs needed to establish the conclusion",
        "explanation": "short statement",
        "location": {
            "feature": "literal field name: input, glyph, setting, partner, phase, or null",
            "value": "complete input object for feature=input; relevant observed value(s) for a field; otherwise null",
        },
        "verdict": "supported | rejected | undetermined",
    },
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canon(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def condition_state(state: dict, condition: str) -> dict:
    result = copy.deepcopy(state)
    if condition.startswith("base_g2_"):
        result["response_schema"] = copy.deepcopy(G2_RESPONSE_SCHEMA)
    return result


def prompt_for(tokenizer, state: dict, condition: str) -> str:
    system = G1_SYSTEM if condition == "base_g1_bridge" else G2_SYSTEM
    messages = [{"role": "system", "content": system},
                {"role": "user", "content": canon(condition_state(state, condition))}]
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


class ModelDriver:
    def __init__(self, model, tokenizer):
        self.model = model
        self.tokenizer = tokenizer
        import transformers
        import transformers.tokenization_utils as tokenization_utils
        tokenization_utils.PreTrainedTokenizerBase = transformers.PreTrainedTokenizerBase
        from lmformatenforcer.integrations.transformers import (
            build_transformers_prefix_allowed_tokens_fn,
            build_token_enforcer_tokenizer_data,
        )
        self.build_prefix = build_transformers_prefix_allowed_tokens_fn
        self.token_data = build_token_enforcer_tokenizer_data(tokenizer)

    @classmethod
    def load(cls):
        import unsloth
        model, tokenizer = unsloth.FastLanguageModel.from_pretrained(
            model_name=str(BASE_PATH), max_seq_length=MAX_CONTEXT, dtype=None, load_in_4bit=True
        )
        unsloth.FastLanguageModel.for_inference(model)
        model.eval()
        return cls(model, tokenizer)

    def act(self, state: dict, condition: str) -> dict:
        is_constrained = condition != "base_g2_free"
        prompt = prompt_for(self.tokenizer, state, condition)
        encoded = self.tokenizer(prompt, return_tensors="pt", truncation=False)
        input_len = int(encoded["input_ids"].shape[1])
        if input_len + MAX_NEW > MAX_CONTEXT:
            return {
                "action": {"action": "invalid_model_output"}, "raw": "",
                "prompt_sha256": sha(prompt.encode()), "input_tokens": input_len,
                "output_tokens": 0, "eos": False, "hit_limit": False,
                "strict_json": False, "parse_success": False, "generation_failure": True,
                "error": f"context budget exceeded: {input_len}+{MAX_NEW}>{MAX_CONTEXT}",
            }
        input_ids = encoded["input_ids"].to(self.model.device)
        kwargs = {
            "max_new_tokens": MAX_NEW, "max_length": None, "do_sample": False,
            "pad_token_id": self.tokenizer.pad_token_id or self.tokenizer.eos_token_id,
            "return_dict_in_generate": True,
        }
        if is_constrained:
            kwargs["prefix_allowed_tokens_fn"] = self.build_prefix(
                self.token_data, state_parser(condition_state(state, condition)))
        try:
            with torch.inference_mode():
                result = self.model.generate(input_ids=input_ids, **kwargs)
            generated = result.sequences[0, input_len:]
            raw = self.tokenizer.decode(generated, skip_special_tokens=True)
            eos = bool(len(generated) and int(generated[-1].item()) == self.tokenizer.eos_token_id)
            strict = False
            try:
                parsed = json.loads(raw.strip())
                strict = isinstance(parsed, dict)
                parse_success = isinstance(parsed, dict)
                parse_error = None
            except Exception as error:
                parsed = None
                parse_success = False
                parse_error = f"{type(error).__name__}: {error}"
            if not isinstance(parsed, dict):
                from action_utils import first_json_object
                parsed = first_json_object(raw)
                parse_success = isinstance(parsed, dict)
            return {
                "action": parsed if isinstance(parsed, dict) else {"action": "invalid_model_output"},
                "raw": raw, "prompt_sha256": sha(prompt.encode()),
                "input_tokens": input_len, "output_tokens": int(len(generated)),
                "eos": eos, "hit_limit": int(len(generated)) >= MAX_NEW,
                "strict_json": strict, "parse_success": parse_success,
                "parse_error": parse_error, "generation_failure": False, "error": None,
            }
        except Exception as error:
            return {
                "action": {"action": "invalid_model_output"}, "raw": "",
                "prompt_sha256": sha(prompt.encode()), "input_tokens": input_len,
                "output_tokens": 0, "eos": False, "hit_limit": False,
                "strict_json": False, "parse_success": False, "generation_failure": True,
                "error": f"{type(error).__name__}: {error}",
            }


def contract_error(state: dict, action: dict) -> str | None:
    if not isinstance(action, dict):
        return "action is not an object"
    if action.get("action") == "query":
        if set(action) != {"action", "query_id"}:
            return "query action has missing or extra fields"
        if action.get("query_id") not in {q["id"] for q in state["query_menu"]}:
            return "query_id is not currently public and available"
        if state["remaining_query_budget"] <= 0:
            return "query budget is exhausted"
        return None
    if action.get("action") != "report":
        return "action must be query or report"
    required = {"action", "verdict", "candidate_model_codes", "evidence_ids",
                "location", "confidence", "explanation"}
    if set(action) != required:
        return "report has missing or extra fields"
    if action["verdict"] not in {"supported", "rejected", "undetermined"}:
        return "invalid report verdict"
    if not isinstance(action["candidate_model_codes"], list) or any(
            not isinstance(x, str) or x not in {m["id"] for m in state["candidate_models"]}
            for x in action["candidate_model_codes"]):
        return "candidate_model_codes contains a non-public model ID"
    if not isinstance(action["evidence_ids"], list) or any(
            not isinstance(x, str) or x not in {r["id"] for r in state["observations"]}
            for x in action["evidence_ids"]):
        return "evidence_ids contains a non-public observation ID"
    if not isinstance(action["location"], dict):
        return "location must be an object"
    if not isinstance(action["confidence"], (int, float)) or isinstance(action["confidence"], bool) or not 0 <= action["confidence"] <= 1:
        return "confidence must be numeric in [0,1]"
    if not isinstance(action["explanation"], str):
        return "explanation must be a string"
    return None


def append_jsonl(path: Path, row: dict) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush()


def run_episode(item: dict, condition: str, action_fn, event_path: Path) -> dict:
    world = item["world"]
    ep = Episode(world)
    generation_failures = parser_failures = truncations = output_tokens = attempts = 0
    failed = explicit = False
    for step in range(1, MAX_ACTIONS + 1):
        if ep.terminal:
            break
        state = condition_state(ep.state(), condition)
        meta = action_fn(state)
        action = meta.get("action")
        attempts += 1
        generation_failures += int(bool(meta.get("generation_failure")))
        parser_failures += int(not bool(meta.get("parse_success", meta.get("strict_json"))))
        truncations += int(bool(meta.get("hit_limit")))
        output_tokens += int(meta.get("output_tokens", 0))
        error = contract_error(state, action)
        try:
            response = {"accepted": False, "error": f"G2 contract: {error}"} if error else ep.apply(action)
            accepted = bool(response.get("accepted"))
        except Exception as exc:
            response = {"accepted": False, "error": f"{type(exc).__name__}: {exc}"}
            accepted = False
        append_jsonl(event_path, {
            "model": "base" if condition.startswith("base_") else "control",
            "condition": condition, "episode_id": item["episode_id"],
            "cohort": item["cohort"], "step": step, "world_id": world["world_id"],
            "category_for_scoring_only": world["category"],
            "prompt_sha256": meta.get("prompt_sha256"),
            "input_tokens": meta.get("input_tokens"), "output_tokens": meta.get("output_tokens"),
            "eos": meta.get("eos"), "hit_limit": meta.get("hit_limit"),
            "strict_json": meta.get("strict_json"), "parse_error": meta.get("parse_error"),
            "generation_failure": meta.get("generation_failure"), "generation_error": meta.get("error"),
            "raw": meta.get("raw"), "action": action, "environment_response": response, "accepted": accepted,
        })
        if not accepted:
            failed = True
            ep.invalid_actions += 1
            break
        if ep.terminal:
            explicit = True
            break
    forced = not ep.terminal
    report = ep.report or {"verdict": "undetermined", "confidence": 0.0,
                           "candidate_model_codes": [], "evidence_ids": [],
                           "location": {}, "explanation": "forced termination"}
    scored = score_report(world, ep.observations, report)
    if forced:
        scored = {"decision_correct": False, "diagnosis_correct": False, "localized_correct": False}
    return {
        "category": world["category"], "family": world["family"], "world_id": world["world_id"],
        "model": "base" if condition.startswith("base_") else "control",
        "condition": condition, "episode_id": item["episode_id"], "cohort": item["cohort"],
        "verdict": report["verdict"], "confidence": report["confidence"],
        "query_count": len(ep.query_records), "invalid_actions": ep.invalid_actions,
        "action_count": attempts, "forced_termination": forced, "explicit_report": explicit,
        "operational_failure": bool(failed or forced or generation_failures or parser_failures or truncations),
        "generation_failures": generation_failures, "parser_failures": parser_failures,
        "truncations": truncations, "output_tokens": output_tokens,
        "redundant_queries": ep.redundant_queries,
        "expected_information_gain": [x["expected"] for x in ep.query_ig],
        "actual_information_gain": [x["actual"] for x in ep.query_ig],
        "decision_correct": scored["decision_correct"], "diagnosis_correct": scored["diagnosis_correct"],
        "localized_correct": scored["localized_correct"], "candidate_set_size": len(ep.compatible_ids()),
        "query_history": ep.query_records, "report": report if explicit else None,
    }


def controls_for(item: dict) -> dict:
    world = item["world"]
    seed = int(item["seed"])
    return {
        "control_statistical_detector": StatisticalAnomalyDetector(),
        "control_random_query": RandomQueryControl(seed ^ int(world["world_id"][:8], 16)),
        "control_fixed_query": FixedQueryControl(seed),
        "control_symbolic_active": SymbolicActiveControl(),
    }


def summarize_explicit(rows: list[dict]) -> dict:
    result = summarize(rows)
    explicit = [r for r in rows if r["explicit_report"]]
    result["calibration"] = summarize(explicit)["calibration"] if explicit else {"brier": None, "ece10": None}
    result["calibration_denominator"] = len(explicit)
    return result


def main() -> None:
    prereg = json.loads((RUN / "preregistration.json").read_text(encoding="utf-8"))
    preflight = json.loads((RUN / "preflight.json").read_text(encoding="utf-8"))
    if prereg.get("status") != "frozen_pre_inference" or preflight.get("status") != "PASS" or preflight.get("weights_loaded"):
        raise RuntimeError("Frozen preregistration or weight-free preflight gate failed")
    if any((RUN / name).exists() for name in ("actions.jsonl", "episodes.jsonl", "summary.json")):
        raise RuntimeError("Refusing to repeat G2 inference")
    schedule = [json.loads(x) for x in (RUN / "schedule.jsonl").read_text(encoding="utf-8").splitlines()]
    sentinel = [x for x in schedule if x["cohort"] == "sentinel"]
    extension = [x for x in schedule if x["cohort"] == "extension"]
    actions_path = RUN / "actions.jsonl"
    episodes_path = RUN / "episodes.jsonl"
    actions_path.write_text("", encoding="utf-8")
    episodes_path.write_text("", encoding="utf-8")
    by_condition: dict[str, list[dict]] = {}

    def run_models(items: list[dict]) -> None:
        driver = ModelDriver.load()
        try:
            for item in items:
                for condition in ("base_g1_bridge", "base_g2_schema", "base_g2_free"):
                    row = run_episode(item, condition, lambda state, c=condition: driver.act(state, c), actions_path)
                    by_condition.setdefault(condition, []).append(row)
                    append_jsonl(episodes_path, row)
                    print(json.dumps({"condition": condition, "episode": item["episode_id"],
                                      "cohort": item["cohort"], "verdict": row["verdict"],
                                      "explicit": row["explicit_report"], "operational_failure": row["operational_failure"],
                                      "queries": row["query_count"]}), flush=True)
        finally:
            del driver
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    def run_controls(items: list[dict]) -> None:
        for item in items:
            for condition, agent in controls_for(item).items():
                def act(state, a=agent):
                    action = a.act(state)
                    return {"action": action, "raw": canon(action), "strict_json": True,
                            "parse_success": True, "generation_failure": False,
                            "hit_limit": False, "output_tokens": 0,
                            "input_tokens": 0, "eos": True}
                row = run_episode(item, condition, act, actions_path)
                by_condition.setdefault(condition, []).append(row)
                append_jsonl(episodes_path, row)
        print(json.dumps({"control_worlds_completed": len(items)}), flush=True)

    run_models(sentinel)
    run_controls(sentinel)
    gate_rows = by_condition["base_g2_schema"]
    gate = {
        "n": len(gate_rows), "explicit_reports": sum(r["explicit_report"] for r in gate_rows),
        "generation_failures": sum(r["generation_failures"] for r in gate_rows),
        "parser_failures": sum(r["parser_failures"] for r in gate_rows),
        "truncations": sum(r["truncations"] for r in gate_rows),
        "invalid_actions": sum(r["invalid_actions"] for r in gate_rows),
        "passed": (len(gate_rows) == 5 and all(r["explicit_report"] for r in gate_rows)
                   and not any(sum(r[k] for r in gate_rows) for k in
                               ("generation_failures", "parser_failures", "truncations", "invalid_actions"))),
    }
    extension_authorized = gate["passed"]
    (RUN / "sentinel_summary.json").write_text(json.dumps({
        "protocol": prereg["protocol"], "gate": gate,
        "extension_authorized_by_rule": extension_authorized,
        "conditions": {k: summarize_explicit(v) for k, v in by_condition.items()},
        "reserved_splits_opened": False, "fine_tuning": False,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if not extension_authorized:
        status = {"status": "stopped_after_sentinel", "mandatory_analysis": True,
                  "reason": "base_g2_schema did not pass the frozen operational gate.",
                  "diagnostic_and_confirmation_opened": False, "fine_tuning": False}
        (RUN / "status.json").write_text(json.dumps(status, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(json.dumps(status, indent=2), flush=True)
        return

    run_models(extension)
    run_controls(extension)
    summary = {
        "protocol": prereg["protocol"], "status": "development_exploration_complete",
        "sentinel_gate": gate, "episodes_per_condition": {k: len(v) for k, v in by_condition.items()},
        "conditions": {k: {
            "all_25": summarize_explicit(v),
            "sentinel": summarize_explicit([r for r in v if r["cohort"] == "sentinel"]),
            "by_category": {c: summarize_explicit([r for r in v if r["category"] == c]) for c in CATEGORIES},
            "operational_failures": sum(r["operational_failure"] for r in v),
            "correct_decisions_without_localization": sum(r["decision_correct"] and not r["localized_correct"] for r in v),
            "invalid_actions": sum(r["invalid_actions"] for r in v),
        } for k, v in by_condition.items()},
        "reserved_splits_opened": False, "fine_tuning": False,
        "limitations": ["25 balanced development episodes are exploratory.",
                        "No transfer approval or population-level error claim.",
                        "The constrained and free G2 arms share the same G2 system instruction and public response_schema."],
    }
    (RUN / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    status = {"status": "development_exploration_complete", "mandatory_analysis": True,
              "diagnostic_and_confirmation_opened": False, "fine_tuning": False}
    (RUN / "status.json").write_text(json.dumps(status, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": status["status"], "gate": gate,
                      "episodes_per_condition": {k: len(v) for k, v in by_condition.items()}}, indent=2), flush=True)


if __name__ == "__main__":
    main()
