from __future__ import annotations

import hashlib
import json
import sys
import copy
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
M17 = ROOT / "work" / "M17_DESCOBERTA_DIAGNOSTICO"
RUN = ROOT / "work" / "TRONCO01_G1" / "run_20261017_v02"
sys.path.insert(0, str(M17))

from environment import Episode
from generator import QUERY_BUDGET


SYSTEM = (
    "You are an investigator. Use only the public state in the user message. "
    "Choose a useful allowed query when more evidence is needed, or report a conclusion. "
    "Return exactly one JSON action matching response_schema. Do not invent IDs or evidence."
)
FORBIDDEN_KEYS = {"category", "family", "hidden", "truth", "seed", "index", "world_id",
                  "requested_action", "expected", "target"}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_digest(path: Path) -> str:
    h = hashlib.sha256()
    for item in sorted(p for p in path.rglob("*") if p.is_file() and "__pycache__" not in p.parts):
        h.update(item.relative_to(path).as_posix().encode())
        h.update(bytes.fromhex(digest(item)))
    return h.hexdigest()


def state_schemas(state: dict) -> list[dict]:
    model_ids = [x["id"] for x in state["candidate_models"]]
    evidence_ids = [x["id"] for x in state["observations"]]
    schemas = []
    if state["remaining_query_budget"] > 0 and state["query_menu"]:
        schemas.append({
            "type": "object",
            "properties": {
                "action": {"enum": ["query"]},
                "query_id": {"enum": [q["id"] for q in state["query_menu"]]},
            },
            "required": ["action", "query_id"],
            "additionalProperties": False,
        })
    schemas.append({
        "type": "object",
        "properties": {
            "action": {"enum": ["report"]},
            "verdict": {"enum": ["supported", "rejected", "undetermined"]},
            "candidate_model_codes": {"type": "array", "items": {"enum": model_ids}},
            "evidence_ids": {"type": "array", "items": {"enum": evidence_ids}},
            "location": {"type": "object"},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
            "explanation": {"type": "string"},
        },
        "required": ["action", "verdict", "candidate_model_codes", "evidence_ids", "location", "confidence", "explanation"],
        "additionalProperties": False,
    })
    return schemas


def state_parser(state: dict):
    from lmformatenforcer import JsonSchemaParser
    from lmformatenforcer.characterlevelparser import UnionParser
    return UnionParser([JsonSchemaParser(schema) for schema in state_schemas(state)])


def prompt_for(state: dict, schema_condition: bool, tokenizer) -> str:
    messages = []
    if schema_condition:
        messages.append({"role": "system", "content": SYSTEM})
    messages.append({
        "role": "user",
        "content": json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
    })
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)


def no_leak(value):
    if isinstance(value, dict):
        if FORBIDDEN_KEYS.intersection(value):
            raise AssertionError(f"hidden metadata key in public state: {FORBIDDEN_KEYS.intersection(value)}")
        for item in value.values():
            no_leak(item)
    elif isinstance(value, list):
        for item in value:
            no_leak(item)


def check_constrained_json(callback, tokenizer, prompt_ids: list[int], text: str) -> None:
    generated = tokenizer.encode(text, add_special_tokens=False)
    prefix = []
    for i, token in enumerate(generated):
        allowed = callback(0, torch.tensor(prompt_ids + prefix, dtype=torch.long))
        if token not in allowed:
            allowed_text = [tokenizer.decode([x]) for x in allowed[:25]]
            raise AssertionError(
                f"schema grammar blocked token {i}={tokenizer.decode([token])!r}; "
                f"prefix={tokenizer.decode(prefix)!r}; candidate={text!r}; "
                f"allowed={allowed_text!r}"
            )
        prefix.append(token)


def check_constrained_rejects(callback, tokenizer, prompt_ids: list[int], text: str) -> None:
    generated = tokenizer.encode(text, add_special_tokens=False)
    prefix = []
    for token in generated:
        allowed = callback(0, torch.tensor(prompt_ids + prefix, dtype=torch.long))
        if token not in allowed:
            return
        prefix.append(token)
    raise AssertionError(f"schema grammar accepted invalid JSON action: {text!r}")


def accepted(world, action):
    response = Episode(world).apply(action)
    return bool(response.get("accepted")), response


def main() -> None:
    # Keep the preflight weight-free: only the base tokenizer is loaded.
    import transformers
    import transformers.tokenization_utils as tokenization_utils
    tokenization_utils.PreTrainedTokenizerBase = transformers.PreTrainedTokenizerBase
    from lmformatenforcer import JsonSchemaParser
    from lmformatenforcer.characterlevelparser import UnionParser
    from lmformatenforcer.integrations.transformers import (
        build_transformers_prefix_allowed_tokens_fn,
        build_token_enforcer_tokenizer_data,
    )
    from transformers import AutoTokenizer

    prereg = json.loads((RUN / "preregistration.json").read_text(encoding="utf-8"))
    schedule = [json.loads(x) for x in (RUN / "schedule.jsonl").read_text(encoding="utf-8").splitlines()]
    if digest(RUN / "schedule.jsonl") != prereg["schedule_sha256"]:
        raise AssertionError("schedule hash mismatch")
    if tree_digest(M17) != prereg["m17_tree_sha256"]:
        raise AssertionError("M17 source/data tree changed after preregistration")
    for relative, expected in prereg["source_sha256"].items():
        path = ROOT / relative
        if digest(path) != expected:
            raise AssertionError(f"preregistered source changed: {relative}")

    base_path = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"
    adapter_path = Path.home() / "voynich-lab/experiencias/M16_CURRICULO/runs/m16-l4l5-r1/adapter"
    base_sha = tree_digest(base_path)
    adapter_sha = tree_digest(adapter_path)
    if base_sha != "397dbcc558e4ac54485a796835a20cfd3c9364f55558bcc5ba583b8fa6e199c5":
        raise AssertionError(f"base checkpoint differs from G0g lock: {base_sha}")
    if adapter_sha != "b5d6ab418b2c683e759c373d2d20e19e2deaed237e4e29dd9b33c4ef112c548f":
        raise AssertionError(f"M16 adapter differs from G0g lock: {adapter_sha}")

    tokenizer = AutoTokenizer.from_pretrained(str(base_path), local_files_only=True)
    token_data = build_token_enforcer_tokenizer_data(tokenizer)
    checks = {
        "scheduled_episodes": len(schedule), "states_checked": 0,
        "schema_query_ids_checked": 0, "legal_query_actions_checked": 0,
        "query_and_report_paths_reachable": 0, "invalid_references_rejected": 0,
        "invalid_schema_paths_rejected": 0,
        "prompt_context_checks": 0,
    }
    max_context = prereg["model_policy"]["max_context_tokens"]
    for episode in schedule:
        world = episode["world"]
        ep = Episode(world)
        for state_i in range(QUERY_BUDGET + 1):
            state = ep.state()
            no_leak(state)
            schemas = state_schemas(state)
            prompt = prompt_for(state, True, tokenizer)
            prompt_ids = tokenizer.encode(prompt, add_special_tokens=False)
            if len(prompt_ids) + prereg["model_policy"]["max_new_tokens"] > max_context:
                raise AssertionError(f"context budget exceeded: {episode['episode_id']} state {state_i}: {len(prompt_ids)}+192>{max_context}")
            checks["prompt_context_checks"] += 1
            checks["states_checked"] += 1

            query_ids = ([q["id"] for q in state["query_menu"]]
                         if state["remaining_query_budget"] > 0 else [])
            for qid in query_ids:
                action = {"action": "query", "query_id": qid}
                trial = copy.deepcopy(ep)
                response = trial.apply(action)
                ok = bool(response.get("accepted"))
                if not ok:
                    raise AssertionError(f"Episode rejected public query: {episode['episode_id']} {qid}")
                checks["legal_query_actions_checked"] += 1
                if {"action", "query_id"} == set(action):
                    callback = build_transformers_prefix_allowed_tokens_fn(
                        token_data, UnionParser([JsonSchemaParser(branch) for branch in schemas]))
                    check_constrained_json(callback, tokenizer, prompt_ids,
                                           json.dumps(action, separators=(",", ":")))
                    checks["schema_query_ids_checked"] += 1

            if query_ids:
                sample = {"action": "query", "query_id": query_ids[0]}
                callback = build_transformers_prefix_allowed_tokens_fn(
                    token_data, UnionParser([JsonSchemaParser(branch) for branch in schemas]))
                check_constrained_json(callback, tokenizer, prompt_ids, json.dumps(sample, separators=(",", ":")))
                checks["query_and_report_paths_reachable"] += 1
                callback = build_transformers_prefix_allowed_tokens_fn(
                    token_data, UnionParser([JsonSchemaParser(branch) for branch in schemas]))
                invalid_query = {"action": "query", "query_id": query_ids[0], "verdict": "supported"}
                check_constrained_rejects(callback, tokenizer, prompt_ids,
                                          json.dumps(invalid_query, separators=(",", ":")))
                checks["invalid_schema_paths_rejected"] += 1
            report = {"action": "report", "verdict": "undetermined", "candidate_model_codes": [],
                      "evidence_ids": [], "location": {}, "confidence": 0.5, "explanation": "uncertain"}
            trial = copy.deepcopy(ep)
            response = trial.apply(report)
            ok = bool(response.get("accepted"))
            if not ok:
                raise AssertionError(f"synthetic legal report rejected: {response}")
            callback = build_transformers_prefix_allowed_tokens_fn(
                token_data, UnionParser([JsonSchemaParser(branch) for branch in schemas]))
            check_constrained_json(callback, tokenizer, prompt_ids, json.dumps(report, separators=(",", ":")))
            callback = build_transformers_prefix_allowed_tokens_fn(
                token_data, UnionParser([JsonSchemaParser(branch) for branch in schemas]))
            check_constrained_rejects(callback, tokenizer, prompt_ids,
                                      json.dumps({"action": "report", "verdict": "undetermined"}, separators=(",", ":")))
            checks["invalid_schema_paths_rejected"] += 1
            callback = build_transformers_prefix_allowed_tokens_fn(
                token_data, UnionParser([JsonSchemaParser(branch) for branch in schemas]))
            invalid_report = dict(report, evidence_ids=["__not_public__"])
            check_constrained_rejects(callback, tokenizer, prompt_ids,
                                      json.dumps(invalid_report, separators=(",", ":")))
            checks["invalid_schema_paths_rejected"] += 1
            if not query_ids:
                checks["query_and_report_paths_reachable"] += 1

            invalid_query = {"action": "query", "query_id": "__not_public__"}
            if copy.deepcopy(ep).apply(invalid_query).get("accepted"):
                raise AssertionError("unknown query ID was accepted")
            invalid_report = dict(report, evidence_ids=["__not_public__"])
            if copy.deepcopy(ep).apply(invalid_report).get("accepted"):
                raise AssertionError("unknown evidence ID was accepted")
            checks["invalid_references_rejected"] += 2

            if state_i < QUERY_BUDGET:
                if not query_ids:
                    raise AssertionError("query menu exhausted before query budget")
                response = ep.apply({"action": "query", "query_id": query_ids[0]})
                if not response.get("accepted"):
                    raise AssertionError(f"state transition query failed: {response}")
        exhausted = ep.state()
        if exhausted["remaining_query_budget"] != 0:
            raise AssertionError("query budget did not exhaust after three legal queries")
        exhausted_schemas = state_schemas(exhausted)
        if len(exhausted_schemas) != 1 or exhausted_schemas[0]["properties"]["action"].get("enum") != ["report"]:
            raise AssertionError("query branch remains reachable after budget exhaustion")
        no_leak(exhausted)
        # Reset semantics are checked by constructing a fresh Episode: observations and budget restore.
        fresh = Episode(world)
        if fresh.state() != world["public"] or fresh.remaining != QUERY_BUDGET:
            raise AssertionError("episode reset failed")

    result = {
        "status": "PASS",
        "weights_loaded": False,
        "checks": checks,
        "base_checkpoint_sha256": base_sha,
        "m16_adapter_sha256": adapter_sha,
        "tokenizer_revision": "216d96b52c97a3c8294776df8477592f6828981c",
        "transformers_version": transformers.__version__,
        "lm_format_enforcer_version": "0.11.3",
        "schedule_sha256": digest(RUN / "schedule.jsonl"),
        "m17_tree_sha256": tree_digest(M17),
    }
    (RUN / "preflight.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
