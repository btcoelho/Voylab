"""Stricter independent audit of query-based localization on dev/diagnostic only."""
import argparse
import itertools
import json
from pathlib import Path

from environment import _has_phase_effect
from evaluate_m17 import CATEGORIES, DEV, DIAGNOSTIC, PER_CATEGORY
from generator import _compatible, _hidden_predict, _predict, audit_world, make_world


def run(split):
    seeds = DEV if split == "dev" else DIAGNOSTIC
    output = {"split": split, "worlds": 0, "base_identifiability_pass": 0,
              "change_query_localizes_and_identifies": 0, "change_worlds": 0}
    for seed, family in seeds:
        for ci, category in enumerate(CATEGORIES):
            for i in range(PER_CATEGORY):
                index = ci * PER_CATEGORY + i
                world = make_world(category, family, seed, index)
                output["worlds"] += 1
                output["base_identifiability_pass"] += int(audit_world(world)["identified"])
                if category != "CHANGE":
                    continue
                output["change_worlds"] += 1
                rows = world["public"]["observations"]
                phase_card = next(c for c in world["cards"] if c["kind"] == "glyph_phase")
                found = False
                menu = world["public"]["query_menu"]
                for n in range(1, min(3, len(menu)) + 1):
                    for queries in itertools.combinations(menu, n):
                        additions = [
                            {"id": f"audit_query_{j}", "input": query["input"],
                             "output": _hidden_predict(world["hidden"], query["input"])}
                            for j, query in enumerate(queries)
                        ]
                        trial = rows + additions
                        if (_has_phase_effect(trial)[0]
                                and _compatible(world["cards"], trial) == [phase_card["id"]]):
                            found = True
                            break
                    if found:
                        break
                output["change_query_localizes_and_identifies"] += int(found)
    output["all_pass"] = (
        output["base_identifiability_pass"] == output["worlds"]
        and output["change_query_localizes_and_identifies"] == output["change_worlds"]
    )
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--split", choices=("dev", "diagnostic"), required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.split)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
