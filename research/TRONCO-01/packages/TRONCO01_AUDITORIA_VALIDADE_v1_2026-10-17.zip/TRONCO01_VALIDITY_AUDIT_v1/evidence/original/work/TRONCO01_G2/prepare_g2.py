from __future__ import annotations

import hashlib
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
M17 = ROOT / "work" / "M17_DESCOBERTA_DIAGNOSTICO"
RUN = ROOT / "work" / "TRONCO01_G2" / "run_20261017_v01"
G1 = ROOT / "work" / "TRONCO01_G1"
sys.path.insert(0, str(M17))

from evaluate_m17 import CATEGORIES, build_worlds
from generator import audit_world, make_world


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_sha(path: Path) -> str:
    h = hashlib.sha256()
    for item in sorted(p for p in path.rglob("*") if p.is_file() and "__pycache__" not in p.parts):
        h.update(item.relative_to(path).as_posix().encode())
        h.update(bytes.fromhex(sha(item)))
    return h.hexdigest()


def main() -> None:
    if any(RUN.iterdir()):
        raise RuntimeError(f"G2 run directory is not empty: {RUN}")

    used: set[str] = set()
    pilot = build_worlds("dev", pilot_per_category=10)
    for _, worlds in pilot.values():
        used.update(w["world_id"] for w in worlds)
    for path in (
        ROOT / "work" / "TRONCO01_G0G" / "run_20261017" / "preflight.json",
        G1 / "run_20261017" / "schedule.jsonl",
        G1 / "run_20261017_v02" / "schedule.jsonl",
    ):
        if path.suffix == ".jsonl":
            used.update(json.loads(line)["world"]["world_id"]
                        for line in path.read_text(encoding="utf-8").splitlines())
        else:
            used.update(row["world_id"] for row in json.loads(path.read_text(encoding="utf-8")))

    candidates = {category: [] for category in CATEGORIES}
    for seed, family in ((53001, "dev_table"), (53003, "dev_table"), (53009, "dev_table")):
        for ci, category in enumerate(CATEGORIES):
            for replicate in range(20):
                index = ci * 20 + replicate
                world = make_world(category, family, seed, index)
                audit = audit_world(world)
                if not audit["identified"]:
                    raise RuntimeError(f"Identifiability audit failed for {seed}/{category}/{index}: {audit}")
                if world["world_id"] not in used:
                    candidates[category].append({
                        "world": world, "category": category, "seed": seed,
                        "family": family, "index": index,
                    })

    rng = random.Random(20261018)
    episodes = []
    for category in CATEGORIES:
        options = sorted(candidates[category], key=lambda x: x["world"]["world_id"])
        if len(options) < 5:
            raise RuntimeError(f"Only {len(options)} unused development worlds for {category}")
        for replicate, selected in enumerate(rng.sample(options, 5)):
            episodes.append({
                "episode_id": f"g2_{category.lower()}_{replicate + 1}",
                "category": category,
                "cohort": "sentinel" if replicate == 0 else "extension",
                **selected,
            })
    schedule_path = RUN / "schedule.jsonl"
    schedule_path.write_text("".join(
        json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        for row in episodes), encoding="utf-8")

    base_path = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"
    prior_lock = json.loads((G1 / "run_20261017_v02" / "preregistration.json").read_text(encoding="utf-8"))
    if tree_sha(base_path) != prior_lock["model_policy"]["base_tree_sha256"]:
        raise RuntimeError("Base checkpoint does not match the completed G1 lock")
    sources = [
        M17 / "environment.py", M17 / "generator.py", M17 / "agents.py",
        M17 / "evaluate_m17.py", M17 / "llm_agents.py", M17 / "PROTOCOL.md",
        G1 / "preflight_g1.py", G1 / "run_g1.py",
        Path(__file__), Path(__file__).with_name("preflight_g2.py"),
        Path(__file__).with_name("run_g2.py"),
    ]
    prereg = {
        "protocol": "TRONCO-01 G2 contract and decoding ablation v0.1",
        "created_local": "2026-10-17 Europe/Lisbon",
        "status": "frozen_pre_inference",
        "purpose": "Estimate the effect of clarifying the public localization contract and isolate constrained decoding from the revised prompt, using paired development worlds.",
        "split": "development_only",
        "fine_tuning": False,
        "reserved_splits_opened": False,
        "episode_count": 25,
        "balanced_categories": {c: 5 for c in CATEGORIES},
        "sentinel_count": 5,
        "sentinel_included_in_25": True,
        "world_selection_seed": 20261018,
        "prior_world_ids_excluded": len(used),
        "world_overlap_with_prior_pilot_g0g_g1": 0,
        "conditions": [
            {"id": "base_g1_bridge", "description": "Base model; unchanged G1 system instruction, G1 public response_schema, strict grammar."},
            {"id": "base_g2_schema", "description": "Same base; G2 clarification in system instruction and public response_schema; same structural/ID grammar."},
            {"id": "base_g2_free", "description": "Identical G2 prompt and public state to base_g2_schema; unconstrained generation, same post-generation parser and action validator."},
            {"id": "controls", "description": "Statistical, random-query, fixed-query, and symbolic-active controls on the same worlds."},
        ],
        "g2_contract": {
            "location_feature": "Use the literal field name. For a conflict at an identical complete input, use feature 'input' and value equal to the complete input object. For a feature effect, use that field name (glyph, setting, partner, or phase) and a relevant observed value. Use null only when no localization is justified. Descriptive text in response_schema is guidance, never a literal report value.",
            "evidence": "Only cite public observation IDs that support the report; include all records needed to establish a claimed contrast.",
            "undetermined": "Use when the observations leave multiple candidate accounts compatible or do not identify the claim; list the compatible public model IDs and cite supporting observations.",
            "candidate_models": "Only listed public IDs; do not invent a code. An empty list is allowed when no listed account is compatible.",
        },
        "system_prompt_g1": "You are an investigator. Use only the public state in the user message. Choose a useful allowed query when more evidence is needed, or report a conclusion. Return exactly one JSON action matching response_schema. Do not invent IDs or evidence.",
        "system_prompt_g2": "You are an investigator. Use only the public state in the user message. Choose a useful allowed query when more evidence is needed, or report a conclusion. Return exactly one JSON action matching response_schema. Do not invent IDs or evidence. For a report, treat descriptive text in response_schema as instructions, not values to copy. In location.feature, give the literal field name. To locate conflicting outputs for the same complete input, set feature to 'input' and value to the complete input object. To localize an effect, use its literal field name: glyph, setting, partner, or phase, and cite the observations that show it. Use null only when the evidence does not justify a location. Include enough evidence IDs to establish every reported contrast. If more than one candidate account remains compatible, report undetermined and list those public candidate IDs.",
        "model": {
            "id": "unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit",
            "revision": prior_lock["model_policy"]["base_revision"],
            "tree_sha256": prior_lock["model_policy"]["base_tree_sha256"],
            "max_context_tokens": 2048,
            "max_new_tokens": 192,
            "sampling": "greedy",
            "max_actions_per_episode": 4,
            "query_budget": 3,
            "generation_retries": 0,
            "invalid_action_policy": "Record first invalid action and stop the episode; no retry or semantic correction.",
        },
        "schema_library": "lm-format-enforcer==0.11.3",
        "operational_gate": {
            "gated_condition": "base_g2_schema",
            "pass": "5/5 explicit reports, zero generation/parser failures, zero truncations, zero invalid actions across the sentinel worlds.",
            "extension": "If base_g2_schema passes, run all remaining 20 worlds for every model condition and every control. Otherwise stop after sentinel analysis.",
        },
        "scoring": [
            "Use the unchanged M17 score_report; do not rescore G1 retrospectively.",
            "Keep operational failures in the episode denominator; distinguish forced termination from chosen undetermined.",
            "Report decision, diagnosis, localization, correct decision without localization, insufficiency, sensitivity, specificity, explicit reports, invalid actions, redundant/expected/actual query information gain, query cost, and confidence calibration over explicit reports only.",
            "Episodes are the units; actions and queries are not independent observations. n=25 is exploratory only.",
        ],
        "stop_rules": [
            "Stop after sentinel analysis if base_g2_schema fails its operational gate.",
            "Stop before inference on hash, integrity, overlap, context, grammar, or model mismatch.",
            "No diagnostic/confirmation split and no fine-tuning in G2.",
        ],
        "source_sha256": {str(p.relative_to(ROOT)): sha(p) for p in sources},
        "m17_tree_sha256": tree_sha(M17),
        "schedule_sha256": sha(schedule_path),
        "world_ids_sha256": hashlib.sha256("\n".join(sorted(x["world"]["world_id"] for x in episodes)).encode()).hexdigest(),
        "episode_ids": [x["episode_id"] for x in episodes],
    }
    (RUN / "preregistration.json").write_text(json.dumps(prereg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": prereg["status"], "episodes": len(episodes), "sentinel": 5,
        "categories": prereg["balanced_categories"], "excluded_prior_ids": len(used),
        "unused_candidates_by_category": {c: len(v) for c, v in candidates.items()},
        "schedule_sha256": prereg["schedule_sha256"], "m17_tree_sha256": prereg["m17_tree_sha256"],
        "base_tree_sha256": prereg["model"]["tree_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
