# M17-A/B — descoberta e diagnóstico de problemas

Benchmark interativo textual independente do M16. O M17 apresenta sistemas simbólicos desconhecidos e mede se o agente distingue normalidade, contradição, informação insuficiente, mudança de regra e hipótese ausente. O Voynich não aparece no treino nem na avaliação.

## Execução no WSL

```bash
cd ~/voynich-lab/experiencias/M17_DESCOBERTA_DIAGNOSTICO
../../.venv/bin/python -m unittest discover -s tests -v
../../.venv/bin/python generate_dev.py
../../.venv/bin/python evaluate_m17.py --split dev --agent controls --out results/dev_controls.json
../../.venv/bin/python evaluate_m17.py --split diagnostic --agent controls --out results/diagnostic_controls.json
../../.venv/bin/python evaluate_m17.py --split diagnostic --agent base_model --out results/diagnostic_base.json
../../.venv/bin/python evaluate_m17.py --split diagnostic --agent m16_adapter --out results/diagnostic_m16.json
```

O protocolo congelado, metas, partições, limites e decisões de treino estão em `PROTOCOL.md`. `results/frozen_sha256.txt` identifica a versão congelada. O diretório `private/` contém apenas os gabaritos do desenvolvimento, não apresentados ao agente. Os resultados de avaliação são agregados; o avaliador não exporta rótulos nem IDs de mundos individuais.

Não execute confirmação até existir uma decisão escrita sobre a intervenção e os critérios não mudarem. Não faça fine-tuning antes de terminar as medições de base e M16. Se M16 passar, preserve o adaptador e planeie uma dificuldade maior. Se falhar, qualquer treino deve ser um LoRA separado, com dados apenas de desenvolvimento e comparação cega na confirmação.

O modelo base usado é Qwen2.5-0.5B-Instruct em 4-bit através de Unsloth. O M17-A/B não avalia imagens ou manuscritos históricos. Uma passagem neste protocolo não demonstra compreensão do Voynich.
