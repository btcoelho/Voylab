from __future__ import annotations

import hashlib
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
M17 = ROOT / "work" / "M17_DESCOBERTA_DIAGNOSTICO"
OUT = ROOT / "work" / "TRONCO01_G1" / "run_20261017_v02"
sys.path.insert(0, str(M17))

from evaluate_m17 import CATEGORIES, build_worlds
from generator import audit_world, make_world


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_sha(path: Path) -> str:
    h = hashlib.sha256()
    for item in sorted(p for p in path.rglob("*") if p.is_file() and "__pycache__" not in p.parts):
        h.update(item.relative_to(path).as_posix().encode())
        h.update(bytes.fromhex(sha(item)))
    return h.hexdigest()


def main() -> None:
    if OUT.exists():
        existing = {p.name for p in OUT.iterdir()}
        if existing - {"schedule.jsonl", "preregistration.json"}:
            raise RuntimeError(f"Refusing to overwrite run data: {sorted(existing)}")
    OUT.mkdir(parents=True, exist_ok=True)

    # Reconstruct the prior 50-world M17 pilot and G0g transport worlds so G1
    # does not reuse model-evaluated cases or transport fixtures.
    used = set()
    prior_pilot = build_worlds("dev", pilot_per_category=10)
    for _, worlds in prior_pilot.values():
        used.update(w["world_id"] for w in worlds)
    g0g_path = ROOT / "work" / "TRONCO01_G0G" / "run_20261017" / "preflight.json"
    for row in json.loads(g0g_path.read_text(encoding="utf-8")):
        used.add(row["world_id"])
    prior_g1_path = ROOT / "work" / "TRONCO01_G1" / "run_20261017" / "schedule.jsonl"
    for line in prior_g1_path.read_text(encoding="utf-8").splitlines():
        used.add(json.loads(line)["world"]["world_id"])

    candidates: dict[str, list[dict]] = {category: [] for category in CATEGORIES}
    for seed, family in ((53001, "dev_table"), (53003, "dev_table"), (53009, "dev_table")):
        for category_index, category in enumerate(CATEGORIES):
            for replicate in range(20):
                index = category_index * 20 + replicate
                world = make_world(category, family, seed, index)
                audit = audit_world(world)
                if not audit["identified"]:
                    raise RuntimeError(f"Identifiability audit failed: {seed}/{category}/{index}: {audit}")
                if world["world_id"] not in used:
                    candidates[category].append({
                        "world": world,
                        "category": category,
                        "seed": seed,
                        "family": family,
                        "index": index,
                    })

    rng = random.Random(20261017)
    selected: dict[str, list[dict]] = {}
    for category in CATEGORIES:
        if len(candidates[category]) < 5:
            raise RuntimeError(f"Only {len(candidates[category])} unused worlds for {category}")
        options = sorted(candidates[category], key=lambda x: x["world"]["world_id"])
        selected[category] = rng.sample(options, 5)

    episodes = []
    for category in CATEGORIES:
        for replicate, selected_world in enumerate(selected[category]):
            episodes.append({
                "episode_id": f"g1_{category.lower()}_{replicate + 1}",
                "cohort": "sentinel" if replicate == 0 else "extension",
                **selected_world,
            })

    with (OUT / "schedule.jsonl").open("w", encoding="utf-8", newline="\n") as f:
        for episode in episodes:
            f.write(json.dumps(episode, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")

    source_files = [
        M17 / "environment.py", M17 / "generator.py", M17 / "agents.py",
        M17 / "evaluate_m17.py", M17 / "llm_agents.py", M17 / "PROTOCOL.md",
        ROOT / "outputs" / "TRONCO01_REVISAO_G0G_E_PROXIMO_BLOCO_2026-10-17.md",
        Path(__file__), Path(__file__).with_name("preflight_g1.py"),
        Path(__file__).with_name("run_g1.py"),
    ]
    base_path = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"
    adapter_path = Path.home() / "voynich-lab/experiencias/M16_CURRICULO/runs/m16-l4l5-r1/adapter"
    g0g_lock = json.loads((ROOT / "work" / "TRONCO01_G0G" / "run_20261017" / "preregistration.json").read_text(encoding="utf-8"))
    if tree_sha(base_path) != g0g_lock["base_tree_sha256"] or tree_sha(adapter_path) != g0g_lock["adapter_tree_sha256"]:
        raise RuntimeError("Model checkpoint or adapter does not match the completed G0g lock")
    prereg = {
        "protocol": "TRONCO-01 G1 development decision benchmark v0.2",
        "created_utc_local": "2026-10-17 Europe/Lisbon",
        "status": "frozen_pre_inference",
        "purpose": "Compare the native M17 wrapper to schema-constrained JSON generation on unseen development worlds; measure autonomous action selection and scientific outcomes.",
        "split": "development_only",
        "reserved_splits_opened": False,
        "fine_tuning": False,
        "episode_count": 25,
        "balanced_categories": {category: 5 for category in CATEGORIES},
        "sentinel_count": 5,
        "sentinel_worlds_included_in_25": True,
        "world_selection_seed": 20261017,
        "world_id_overlap_with_prior_50_world_model_pilot": 0,
        "world_id_overlap_with_g0g_transport": 0,
        "world_id_overlap_with_invalid_g1_v0_1_sentinel": 0,
        "prior_worlds_excluded": len(used),
        "cohort_rule": "One sentinel episode per category; the other four per category run only if at least one constrained model condition passes the operational gate.",
        "conditions": [
            {"id": "base_native", "description": "Existing base M17 wrapper, unconstrained generation."},
            {"id": "m16_native", "description": "Existing M16 M17 wrapper, unconstrained generation."},
            {"id": "base_schema", "description": "Base model with G1 system instruction and JSON schema constraints over public IDs and field types."},
            {"id": "m16_schema", "description": "M16 adapter with the same G1 system instruction and JSON schema constraints."},
            {"id": "controls", "description": "Existing statistical, random-query, fixed-query, and symbolic-active controls."},
        ],
        "model_policy": {
            "base": "unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit",
            "base_revision": g0g_lock["base_model_revision"],
            "base_tree_sha256": g0g_lock["base_tree_sha256"],
            "m16_adapter": str(Path.home() / "voynich-lab/experiencias/M16_CURRICULO/runs/m16-l4l5-r1/adapter"),
            "m16_adapter_tree_sha256": g0g_lock["adapter_tree_sha256"],
            "m16_base_revision": g0g_lock["base_model_revision"],
            "max_context_tokens": 2048,
            "max_new_tokens": 192,
            "do_sample": False,
            "max_actions_per_episode": 4,
            "invalid_action_policy": "Stop the episode on its first invalid action; no retry or semantic correction.",
            "generation_retries": 0,
            "sampling": "greedy",
        },
        "schema_intervention": {
            "library": "lm-format-enforcer==0.11.3",
            "schema_scope": "Only public query IDs, public model IDs, public observation IDs, action types, enumerated verdicts, field types, and JSON structure. No target answer or complete candidate report is supplied.",
            "selector": "The model chooses query/report, query ID, verdict, evidence, model codes, localization, confidence, and explanation.",
            "invalid_or_unparseable": "Recorded as an operational failure and stops the episode.",
        },
        "operational_gate": {
            "per_condition": "A constrained model condition passes only with 5/5 explicit reports, zero parser/generation failures, zero truncations, and zero invalid actions across sentinel worlds.",
            "extension_rule": "If at least one constrained model condition passes, run all 20 extension episodes for every condition and control on the same 25 worlds. Otherwise stop after the sentinel analysis.",
        },
        "scoring": [
            "Keep operational failures in the denominator and separate them from chosen undetermined reports.",
            "Report sensitivity, specificity, insufficiency recognition, evidence diagnosis, localization, explicit-report rate, redundant queries, expected/actual information gain, invalid actions, and query cost by category and overall.",
            "Use the existing M17 score_report and summarize definitions; report episode counts and Wilson intervals. Do not treat action steps as independent observations.",
            "Twenty-five balanced development episodes are exploratory and cannot approve transfer or open reserved splits.",
        ],
        "stop_rules": [
            "No extension if neither constrained model condition passes sentinel.",
            "Stop the entire run before inference on any source/hash/world-selection integrity mismatch.",
            "No reserved diagnostic/confirmation evaluation or fine-tuning in G1.",
        ],
        "source_sha256": {str(p.relative_to(ROOT)): sha(p) for p in source_files},
        "m17_tree_sha256": tree_sha(M17),
        "schedule_sha256": sha(OUT / "schedule.jsonl"),
        "episode_ids": [x["episode_id"] for x in episodes],
        "world_ids_sha256": hashlib.sha256("\n".join(sorted(x["world"]["world_id"] for x in episodes)).encode()).hexdigest(),
    }
    (OUT / "preregistration.json").write_text(json.dumps(prereg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "episodes": len(episodes),
        "sentinel": sum(x["cohort"] == "sentinel" for x in episodes),
        "categories": {c: sum(x["category"] == c for x in episodes) for c in CATEGORIES},
        "unused_prior_exclusion_count": len(used),
        "world_ids_disjoint_from_prior_pilot_and_g0g": True,
        "schedule_sha256": prereg["schedule_sha256"],
        "m17_tree_sha256": prereg["m17_tree_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
