# Auditoria M16 para M17

## Artefactos preservados

Adaptador original: `~/voynich-lab/experiencias/M16_CURRICULO/runs/m16-l4l5-r1/adapter`. O M17 não modifica este diretório, os checkpoints, os resultados M16 nem as reservas do M16.

## Separação e contaminação

O manifesto M16 regista 160 mundos/480 ações de treino (semente 5101) e 40 mundos/121 ações de validação (semente 8207). `audit_dataset.py` foi executado durante esta auditoria e reportou `PASS`, 160/40 mundos e os totais de exemplos esperados. A avaliação final usa sementes 17021, 29027 e 43019, 40 mundos de cada nível por semente; são diferentes das sementes de treino/validação. Os prompts/datasets M16 excluem regra oculta, IDs de verdade e estado do gerador, conforme o protocolo M16. O auditor dos resultados confirma apenas métricas agregadas, sem exportação de respostas por mundo.

## Resultado que foi reproduzido/auditado

`audit_results.py` confirma os gates congelados para as três sementes. L4 e L5 ficaram em 100% em cada semente; não houve ações inválidas nem tentativas de compromisso contradito. O M16 usou em média duas consultas no L4 e 1,01 no L5. Os controlos M16 alcançaram 55–70% em L4 para consulta aleatória e 77,5–82,5% em L5. O teacher determinístico também teve 100%.

## Interpretação e limites

O M16 executa interações em vários passos dentro do protocolo que aprendeu. O protocolo M16 especifica que L4 consulta um catálogo de mecanismos publicado e L5 introduz uma contradição deliberada, com catálogo alternativo expandido. O treino imita um professor determinístico de ganho de informação. A avaliação troca sementes, mas mantém as famílias de regras e o formato do gerador. Portanto, os 100% sustentam competência de execução/imitação nessa tarefa sintética estreita; não demonstram descoberta espontânea de que há um problema, investigação científica independente, transferência para geradores novos, visão ou decifração Voynich.

## Decisão M17

O M16 é carregado como controlo congelado. Só se considera um novo LoRA depois de medir o adaptador M16 e o modelo base no protocolo M17 congelado. Qualquer intervenção posterior usa apenas desenvolvimento e um diretório de saída separado.
