# M17 — piloto técnico e ponto de análise obrigatória

Data: 17/10/2026. Execução na cópia de trabalho. O pacote original foi preservado.

## Decisão

O piloto terminou no conjunto de desenvolvimento e não passou o gate técnico para os modelos base e M16. Não há métricas válidas de competência diagnóstica destes modelos. O diagnóstico reservado não foi iniciado, a confirmação permaneceu fechada e não houve fine-tuning. A próxima decisão necessária é analisar a falha de interface/inferência antes de qualquer avaliação científica.

## Correção do registo anterior

O relatório de retoma inicial sugeriu que faltavam a tarefa e o esquema de ações no prompt M17. Essa afirmação estava errada: o estado público inclui os campos `task` e `response_schema`, e o agente serializa o estado inteiro para o modelo. A causa das respostas inválidas continua por identificar. O piloto guardou resultados agregados, não as causas detalhadas de cada ação inválida.

## Alterações feitas na versão 0.1.2

- Uma terminação automática após o limite de ações já não conta como abstenção correta. O episódio fica marcado como falha operacional e conta como decisão e diagnóstico incorretos; a métrica de insuficiência só conta `undetermined` emitido explicitamente.
- O estado de feedback do agente é limpo no início de cada episódio.
- Relatórios validam tipos e referências dos IDs de evidência e dos códigos de hipótese, bem como localização e explicação.
- Foram adicionados contadores de ações, taxa de ações inválidas, relatórios explícitos e terminações forçadas.
- Foi acrescentado um controlo simbólico ativo que só recebe observações, hipóteses e medições públicas. O agente conhece as formas das tabelas candidatas, pelo que é uma verificação de integridade/limite superior, não uma comparação de aprendizagem.
- A amostra do piloto foi fixada por semente e partilhada pelos dois modelos: 10 mundos de cada uma das cinco categorias, 50 no total. A seleção vem das três sementes de desenvolvimento. Contagens efetivas por semente: 19, 13 e 18; os modelos receberam os mesmos 50 mundos.

Os 14 testes unitários passaram depois das alterações. Incluem casos para a falsa abstenção automática, reset de estado entre episódios, IDs inventados, equilíbrio do piloto e um caso resolvido pelo controlo simbólico em cada categoria.

## Resultados agregados do piloto

| Agente | Ações inválidas | Taxa inválida | Relatórios explícitos | Consultas médias | Diagnóstico sustentado |
|---|---:|---:|---:|---:|---:|
| Qwen2.5 0.5B base | 500/500 | 100% | 0/50 | 0 | 0/50 |
| Adaptador M16 | 500/500 | 100% | 0/50 | 0 | 0/50 |
| Detetor estatístico | 0 | 0% | 50/50 | 0 | 24/50 |
| Consulta aleatória | 0 | 0% | 50/50 | 3 | 22/50 |
| Consulta fixa | 0 | 0% | 50/50 | 3 | 23/50 |
| Controlo simbólico ativo | 0 | 0% | 50/50 | 0,4 | 50/50 |

O controlo simbólico obteve 10/10 em cada categoria neste piloto. Como conhece as formas de tabela usadas para construir os mundos, este resultado confirma que o avaliador e o canal público permitem uma estratégia verificável; não mede aprendizagem ou descoberta autónoma. Os controlos simples mostram dificuldades em insuficiência e mudança de regra.

Em ambos os modelos, os 50 episódios terminaram após dez ações inválidas, sem consultas nem relatório explícito. Após a correção do avaliador, o reconhecimento de insuficiência foi 0/10 em cada modelo. A taxa de validade falhou o critério de ≤1%; a terminação explícita falhou o critério de ≥98%. Estes dados mostram incompatibilidade operacional neste contrato de inferência, mas não permitem atribuir a causa ao raciocínio, ao prompt, ao parsing ou ao adaptador. A avaliação apenas guardou métricas agregadas.

## Próximo trabalho autorizado pelo protocolo

Parar aqui para análise obrigatória. Na próxima retoma de desenvolvimento, acrescentar contagens agregadas das classes de erro de ação e amostras curtas de saída bruta apenas para depuração no conjunto de desenvolvimento. Comparar uma mensagem de sistema direta que mande seguir o esquema JSON com o estado público atual, mantendo mundo, modelo, parser e orçamento fixos. Fazer um piloto pequeno primeiro; só repetir a amostra de 50 se as respostas puderem tornar-se ações válidas.

Se base e M16 passarem o gate técnico após essa intervenção, congelar nova versão e planear a avaliação diagnóstica com os controlos obrigatórios. Continuam sem autorização científica neste ponto o fine-tuning e a abertura da confirmação.

## Referências úteis para reduzir implementação futura

- BoxingGym (preprint de 2025, revisto em outubro de 2025) oferece ambientes para desenho experimental e descoberta de modelos, com implementação e métricas reutilizáveis: https://arxiv.org/abs/2501.01540 e https://github.com/kanishkg/boxing-gym .
- DiscoveryWorld (NeurIPS Datasets and Benchmarks 2024) oferece ambientes interativos, agentes de referência e registos de trajetórias: https://github.com/allenai/discoveryworld .
