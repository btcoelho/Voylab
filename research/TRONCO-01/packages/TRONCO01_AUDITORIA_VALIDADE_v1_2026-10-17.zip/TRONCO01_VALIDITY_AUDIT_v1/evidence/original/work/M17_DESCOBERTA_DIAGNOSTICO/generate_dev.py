"""Generate public M17 development worlds and a separate evaluator-only truth file."""
import hashlib
import json
from pathlib import Path

from generator import audit_world, make_world, public_world

CATEGORIES = ("NORMAL", "CONTRADICTION", "INSUFFICIENCY", "CHANGE", "HYPOTHESIS_ABSENT")
DEV_SEEDS = (53001, 53003, 53009)
PER_CATEGORY_PER_SEED = 20


def canonical(row):
    return json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def main():
    root = Path(__file__).resolve().parent
    out = root / "data/dev"
    private = root / "private"
    out.mkdir(parents=True, exist_ok=True)
    private.mkdir(parents=True, exist_ok=True)
    public_rows, truth_rows = [], []
    audit = {"worlds": 0, "identifiable": 0, "category_counts": {c: 0 for c in CATEGORIES}}
    for seed in DEV_SEEDS:
        for ci, category in enumerate(CATEGORIES):
            for i in range(PER_CATEGORY_PER_SEED):
                index = ci * PER_CATEGORY_PER_SEED + i
                world = make_world(category, "dev_table", seed, index)
                check = audit_world(world)
                if not check["identified"]:
                    raise SystemExit(f"world failed identifiability audit: {world['world_id']} {check}")
                pub = public_world(world)
                forbidden = {"category", "family", "hidden", "truth", "seed", "index"}
                if forbidden.intersection(pub):
                    raise SystemExit(f"private key in public state: {forbidden.intersection(pub)}")
                public_rows.append({"world_id": world["world_id"], "initial_state": pub})
                truth_rows.append({"world_id": world["world_id"], "category": category,
                                   "family": world["family"], "working_model_id": world["working_model_id"],
                                   "hidden_kind": world["hidden"]["kind"], "identifiability": check})
                audit["worlds"] += 1
                audit["identifiable"] += int(check["identified"])
                audit["category_counts"][category] += 1
    (out / "public_worlds.jsonl").write_text("".join(canonical(x) + "\n" for x in public_rows), encoding="utf-8")
    truth_path = private / "dev_truth.jsonl"
    truth_path.write_text("".join(canonical(x) + "\n" for x in truth_rows), encoding="utf-8")
    manifest = {
        "purpose": "development-only generator validation and control calibration; not model training",
        "family": "dev_table", "seeds": list(DEV_SEEDS),
        "worlds_per_category_per_seed": PER_CATEGORY_PER_SEED,
        "public_worlds": len(public_rows), "all_worlds_pass_identifiability_audit": audit["identifiable"] == audit["worlds"],
        "hidden_labels_separated": True,
        "sha256_public": hashlib.sha256((out / "public_worlds.jsonl").read_bytes()).hexdigest(),
        "sha256_private_truth": hashlib.sha256(truth_path.read_bytes()).hexdigest(),
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    (out / "identifiability_audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"manifest": manifest, "audit": audit}, indent=2))


if __name__ == "__main__":
    main()
