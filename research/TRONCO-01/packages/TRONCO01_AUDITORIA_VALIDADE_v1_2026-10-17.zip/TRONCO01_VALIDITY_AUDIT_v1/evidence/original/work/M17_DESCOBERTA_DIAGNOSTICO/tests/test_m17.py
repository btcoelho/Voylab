import itertools
import unittest

from environment import Episode, score_report
from generator import (
    QUERY_BUDGET, _compatible, _hidden_predict, _predict, audit_world, make_world,
)
from action_utils import first_json_object
from evaluate_m17 import CATEGORIES, build_worlds, summarize
from agents import SymbolicActiveControl


class M17WorldTests(unittest.TestCase):
    def test_identifiability_across_categories_and_families(self):
        categories = ("NORMAL", "CONTRADICTION", "INSUFFICIENCY", "CHANGE", "HYPOTHESIS_ABSENT")
        families = ("dev_table", "relational", "multiphase", "compositional")
        for i, (category, family) in enumerate(itertools.product(categories, families)):
            with self.subTest(category=category, family=family):
                world = make_world(category, family, 90101, i)
                self.assertTrue(audit_world(world)["identified"])
                state = world["public"]
                self.assertFalse(any(k in state for k in ("category", "family", "hidden", "truth", "seed", "index")))
                public_text = repr(state).lower()
                for hidden_name in categories:
                    self.assertNotIn(hidden_name.lower(), public_text)

    def test_normal_world_is_consistent_even_if_candidates_are_ambiguous(self):
        world = make_world("NORMAL", "relational", 90103, 0)
        rows = world["public"]["observations"]
        card = next(c for c in world["cards"] if c["id"] == world["working_model_id"])
        self.assertTrue(all(_predict(card, r["input"]) == r["output"] for r in rows))

    def test_insufficiency_words_without_supporting_evidence_do_not_score(self):
        world = make_world("INSUFFICIENCY", "dev_table", 90105, 0)
        report = {"verdict": "undetermined", "candidate_model_codes": [c["id"] for c in world["cards"]],
                  "evidence_ids": [], "location": {}}
        scored = score_report(world, world["public"]["observations"], report)
        self.assertFalse(scored["diagnosis_correct"])
        self.assertFalse(scored["localized_correct"])

    def test_contradiction_has_repeated_input_with_conflicting_outputs(self):
        world = make_world("CONTRADICTION", "multiphase", 90107, 0)
        groups = {}
        for row in world["public"]["observations"]:
            key = tuple(row["input"][k] for k in ("glyph", "setting", "partner", "phase"))
            groups.setdefault(key, set()).add(row["output"])
        self.assertTrue(any(len(values) > 1 for values in groups.values()))

    def test_insufficiency_is_indistinguishable_on_available_queries(self):
        world = make_world("INSUFFICIENCY", "compositional", 90109, 0)
        fitted = [c for c in world["cards"] if c["id"] in _compatible(world["cards"], world["public"]["observations"])]
        self.assertGreaterEqual(len(fitted), 2)
        for q in world["public"]["query_menu"]:
            self.assertEqual(len({_predict(c, q["input"]) for c in fitted}), 1)

    def test_change_has_a_discriminating_query(self):
        world = make_world("CHANGE", "relational", 90111, 0)
        fitted = [c for c in world["cards"] if c["id"] in _compatible(world["cards"], world["public"]["observations"])]
        self.assertGreaterEqual(len(fitted), 2)
        self.assertTrue(any(len({_predict(c, q["input"]) for c in fitted}) > 1
                            for q in world["public"]["query_menu"]))

    def test_hypothesis_absent_has_no_fitting_card_and_pair_evidence(self):
        world = make_world("HYPOTHESIS_ABSENT", "multiphase", 90113, 0)
        self.assertEqual(_compatible(world["cards"], world["public"]["observations"]), [])

    def test_query_consumes_budget_and_cannot_be_repeated(self):
        world = make_world("NORMAL", "dev_table", 90115, 0)
        episode = Episode(world)
        qid = episode.state()["query_menu"][0]["id"]
        self.assertTrue(episode.apply({"action": "query", "query_id": qid})["accepted"])
        self.assertEqual(episode.remaining, QUERY_BUDGET - 1)
        self.assertFalse(episode.apply({"action": "query", "query_id": qid})["accepted"])
        self.assertEqual(episode.remaining, QUERY_BUDGET - 1)

    def test_nested_json_report_is_parsed_as_one_action(self):
        text = 'Here is my result: {"action":"report","verdict":"rejected","location":{"feature":"phase","value":"s1"},"confidence":0.8}'
        action = first_json_object(text)
        self.assertEqual(action["location"], {"feature": "phase", "value": "s1"})
        self.assertEqual(action["confidence"], 0.8)

    def test_forced_undetermined_report_does_not_count_as_abstention(self):
        class InvalidAgent:
            def __init__(self):
                self.last_feedback = None
            def reset_episode(self):
                self.last_feedback = None
            def act(self, state):
                return {"action": "invalid_model_output"}
            def feedback(self, value):
                self.last_feedback = value

        world = make_world("INSUFFICIENCY", "dev_table", 90117, 0)
        row = Episode(world).run(InvalidAgent())
        metrics = summarize([row])
        self.assertEqual(row["invalid_actions"], 10)
        self.assertTrue(row["forced_termination"])
        self.assertFalse(row["decision_correct"])
        self.assertEqual(metrics["insufficiency_recognition"]["estimate"], 0.0)
        self.assertEqual(metrics["explicit_report_rate"]["estimate"], 0.0)

    def test_episode_resets_agent_feedback(self):
        class AgentWithStaleFeedback:
            def __init__(self):
                self.last_feedback = {"previous_world_error": True}
                self.saw_stale_feedback = None
            def reset_episode(self):
                self.last_feedback = None
            def act(self, state):
                self.saw_stale_feedback = self.last_feedback is not None
                return {"action": "report", "verdict": "undetermined", "confidence": 0.5}
            def feedback(self, value):
                self.last_feedback = value

        world = make_world("NORMAL", "dev_table", 90119, 0)
        agent = AgentWithStaleFeedback()
        Episode(world).run(agent)
        self.assertFalse(agent.saw_stale_feedback)

    def test_report_rejects_unknown_evidence_ids(self):
        world = make_world("NORMAL", "dev_table", 90121, 0)
        episode = Episode(world)
        response = episode.apply({"action": "report", "verdict": "supported", "confidence": 0.8,
                                  "evidence_ids": ["invented-id"]})
        self.assertFalse(response["accepted"])

    def test_development_pilot_is_balanced_across_categories(self):
        worlds_by_seed = build_worlds("dev", pilot_per_category=10)
        rows = [world for _, worlds in worlds_by_seed.values() for world in worlds]
        self.assertEqual(len(rows), 50)
        self.assertEqual({category: sum(w["category"] == category for w in rows)
                          for category in CATEGORIES}, {category: 10 for category in CATEGORIES})

    def test_symbolic_public_data_control_can_solve_development_cases(self):
        for index, category in enumerate(CATEGORIES):
            with self.subTest(category=category):
                world = make_world(category, "dev_table", 90123, index)
                result = Episode(world).run(SymbolicActiveControl())
                self.assertEqual(result["invalid_actions"], 0)
                self.assertFalse(result["forced_termination"])
                self.assertTrue(result["diagnosis_correct"])


if __name__ == "__main__":
    unittest.main()
