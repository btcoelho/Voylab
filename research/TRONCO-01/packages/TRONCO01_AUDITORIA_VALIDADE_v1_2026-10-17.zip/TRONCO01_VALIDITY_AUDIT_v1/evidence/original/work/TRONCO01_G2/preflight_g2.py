from __future__ import annotations

import copy
import hashlib
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[2]
M17 = ROOT / "work" / "M17_DESCOBERTA_DIAGNOSTICO"
RUN = ROOT / "work" / "TRONCO01_G2" / "run_20261017_v01"
G1DIR = ROOT / "work" / "TRONCO01_G1"
sys.path[:0] = [str(M17), str(G1DIR)]

from environment import Episode
from generator import QUERY_BUDGET
from preflight_g1 import FORBIDDEN_KEYS, check_constrained_json, check_constrained_rejects, no_leak, state_parser
from run_g2 import G2_RESPONSE_SCHEMA, G2_SYSTEM, contract_error, prompt_for


def main() -> None:
    prereg = json.loads((RUN / "preregistration.json").read_text(encoding="utf-8"))
    if prereg.get("status") != "frozen_pre_inference":
        raise RuntimeError("G2 preregistration is not frozen")
    schedule = [json.loads(x) for x in (RUN / "schedule.jsonl").read_text(encoding="utf-8").splitlines()]
    if len(schedule) != 25 or sum(x["cohort"] == "sentinel" for x in schedule) != 5:
        raise RuntimeError("G2 schedule must contain 25 worlds and five sentinel worlds")
    if {x["category"] for x in schedule} != {"NORMAL", "CONTRADICTION", "INSUFFICIENCY", "CHANGE", "HYPOTHESIS_ABSENT"}:
        raise RuntimeError("Missing category")
    if any(sum(x["category"] == c for x in schedule) != 5 for c in {x["category"] for x in schedule}):
        raise RuntimeError("Schedule is not balanced")
    world_ids = sorted(x["world"]["world_id"] for x in schedule)
    digest = hashlib.sha256("\n".join(world_ids).encode()).hexdigest()
    if digest != prereg["world_ids_sha256"]:
        raise RuntimeError("World list differs from preregistration")
    if hashlib.sha256((RUN / "schedule.jsonl").read_bytes()).hexdigest() != prereg["schedule_sha256"]:
        raise RuntimeError("Schedule hash differs from preregistration")

    # The tokenizer is loaded for grammar/context checks; model weights are not loaded.
    import transformers
    import transformers.tokenization_utils as tokenization_utils
    tokenization_utils.PreTrainedTokenizerBase = transformers.PreTrainedTokenizerBase
    from lmformatenforcer import JsonSchemaParser
    from lmformatenforcer.integrations.transformers import (
        build_transformers_prefix_allowed_tokens_fn,
        build_token_enforcer_tokenizer_data,
    )
    from transformers import AutoTokenizer

    base_path = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"
    tokenizer = AutoTokenizer.from_pretrained(str(base_path), local_files_only=True)
    token_data = build_token_enforcer_tokenizer_data(tokenizer)

    counts = {"scheduled_worlds": len(schedule), "states_checked": 0,
              "query_ids_checked": 0, "invalid_references_rejected": 0,
              "canonical_location_contracts_checked": 0, "prompt_context_checks": 0,
              "query_and_report_grammar_paths_checked": 0}
    for item in schedule:
        episode = Episode(item["world"])
        state = episode.state()
        no_leak(state)
        if FORBIDDEN_KEYS.intersection(state):
            raise AssertionError("forbidden metadata is present in public state")
        state_g2 = copy.deepcopy(state)
        state_g2["response_schema"] = copy.deepcopy(G2_RESPONSE_SCHEMA)
        for g2 in (False, True):
            prompt = prompt_for(tokenizer, state_g2 if g2 else state,
                                "base_g2_schema" if g2 else "base_g1_bridge")
            ids = tokenizer.encode(prompt, add_special_tokens=False)
            if len(ids) + 192 > 2048:
                raise RuntimeError(f"Prompt exceeds context budget in {item['episode_id']}: {len(ids)}")
            counts["prompt_context_checks"] += 1
        parser = state_parser(state)
        prompt_ids = tokenizer.encode(prompt_for(tokenizer, state_g2, "base_g2_schema"), add_special_tokens=False)
        callback = build_transformers_prefix_allowed_tokens_fn(token_data, parser)
        legal_query = {"action": "query", "query_id": state["query_menu"][0]["id"]}
        legal_report = {
            "action": "report", "verdict": "rejected", "candidate_model_codes": [],
            "evidence_ids": [state["observations"][0]["id"]], "location": {},
            "confidence": 0.5, "explanation": "A generic report based on a public observation.",
        }
        for action in (legal_query, legal_report):
            text = json.dumps(action, ensure_ascii=False, separators=(",", ":"))
            check_constrained_json(callback, tokenizer, prompt_ids, text)
            counts["query_and_report_grammar_paths_checked"] += 1
        bad = copy.deepcopy(legal_report)
        bad["evidence_ids"] = ["not-a-public-observation"]
        check_constrained_rejects(callback, tokenizer, prompt_ids,
                                  json.dumps(bad, ensure_ascii=False, separators=(",", ":")))
        counts["invalid_references_rejected"] += 1
        for q in state["query_menu"]:
            if q["id"] not in {x["id"] for x in state["query_menu"]}:
                raise AssertionError("A listed query ID is unreachable")
            counts["query_ids_checked"] += 1

        # Check canonical location shapes against the same action contract used by the run.
        canonical = [
            {"feature": "input", "value": {"glyph": "g", "setting": "s", "partner": "p", "phase": "t"}},
            {"feature": "phase", "value": "t"},
            {"feature": "partner", "value": "p"},
            {},
        ]
        for location in canonical:
            sample = copy.deepcopy(legal_report)
            sample["location"] = location
            if contract_error(state_g2, sample):
                raise AssertionError(f"Canonical location rejected: {location}")
            counts["canonical_location_contracts_checked"] += 1
        counts["states_checked"] += 1

    result = {
        "status": "PASS", "weights_loaded": False, "checks": counts,
        "base_checkpoint_sha256": prereg["model"]["tree_sha256"],
        "m17_tree_sha256": prereg["m17_tree_sha256"],
        "schedule_sha256": prereg["schedule_sha256"],
    }
    (RUN / "preflight.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
