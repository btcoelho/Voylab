# M17 — fecho provisório a pedido do utilizador

**Data:** 2026-10-17  
**Estado:** trabalho interrompido antes da avaliação dos modelos, por decisão do utilizador. Este documento fecha o estado conhecido; não declara aprovação do M17.

## O que ficou feito

- Gerador independente do M16 com cinco categorias ocultas: normal, contradição, insuficiência, mudança contextual e hipótese ausente.
- Ambiente interativo com orçamento de três consultas, hipóteses permutadas, observações de comprimento fixo e estado público sem rótulos ou sementes.
- Avaliador agregado, com intervalos Wilson de 95%, resultados por semente/categoria, sensibilidade, especificidade, insuficiência, localização, diagnóstico com evidência, calibração, consultas e ações inválidas.
- 9 testes técnicos PASS.
- Auditoria de identificabilidade: 300/300 mundos de desenvolvimento e 300/300 de diagnóstico passaram; todos os 60 mundos de mudança em cada partição podem ser identificados e localizados dentro do orçamento de três consultas.
- Controlos completos no desenvolvimento e nas três sementes diagnósticas.
- Auditoria M16 reproduzida: `audit_dataset.py` e `audit_results.py` PASS.
- Protocolo e hashes congelados antes da avaliação diagnóstica dos modelos.

## Resultados dos controlos M17

Estimativas médias nas três sementes de desenvolvimento (`dev_table`):

| Controlo | Sensibilidade | Especificidade | Reconhece insuficiência | Localiza problemas | Diagnóstico sustentado de 5 vias |
|---|---:|---:|---:|---:|---:|
| Detetor estatístico | 66,7% | 100% | 0% | 40,6% | 44,3% |
| Consulta aleatória | 91,1% | 100% | 0% | 37,2% | 42,3% |
| Consulta fixa | 92,2% | 100% | 0% | 36,7% | 42,0% |

Nas três sementes diagnósticas (`relational`, `multiphase`, `compositional`), a consulta fixa teve sensibilidade de 91,7%, 96,7% e 95,0%; a aleatória, 88,3%, 95,0% e 90,0%; ambas tiveram especificidade de 100% e reconhecimento de insuficiência de 0%. O detetor estatístico teve 66,7% de sensibilidade, 100% de especificidade e 0% de reconhecimento de insuficiência em cada semente. Os ficheiros de resultados contêm intervalos de confiança e resultados por categoria.

Interpretação: sensibilidade elevada, por si só, não basta. Os controlos deixam de distinguir insuficiência e localização, pelo que não satisfazem o protocolo M17.

## Auditoria M16

O M16 preservado passou os gates originais L4/L5 em três sementes, com 100% em cada nível/seed, zero ações inválidas, duas consultas médias em L4 e 1,01 em L5. A auditoria de dados confirmou 160 mundos de treino e 40 de validação, com os totais esperados de exemplos. Os resultados são agregados.

O protocolo M16 avalia sementes novas dentro das mesmas famílias de regras e imita um professor determinístico com catálogo publicado. Portanto, os resultados sustentam execução multi-passo nessa tarefa sintética estreita, mas não provam descoberta espontânea, investigação independente ou transferência para um gerador novo. O M16 não foi alterado.

## O que não foi medido

A avaliação do modelo base foi iniciada no diagnóstico e interrompida a pedido do utilizador após 709 gerações registadas. Não foi escrito qualquer resultado agregado; não há métricas válidas do modelo base. A execução M16 no diagnóstico M17 não foi iniciada. A confirmação M17 permaneceu fechada. Não foi feito novo fine-tuning.

Assim, não existe resultado M17 que permita aprovar ou rejeitar o modelo base/M16 no novo benchmark, decidir que capacidade falta ou justificar um novo LoRA. O M17 atual é um protótipo técnico com controlos medidos, não um agente validado nem pronto para promoção científica.

## Progresso ao encerrar

- Implementação técnica M17-A/B: ~50%.
- Validação científica M17-A/B: ~15% (controlos e identificabilidade; modelos principais não medidos).
- M17 global: ~35%.

O pacote não inclui um novo adaptador. A confirmação continua intacta e não foi usada.
