# Retoma técnica do M17 — 17/10/2026

## Âmbito e preservação

A execução foi feita numa cópia de trabalho em work/M17_DESCOBERTA_DIAGNOSTICO. O pacote original e a confirmação permaneceram intactos. Esta retoma parou no gate de análise obrigatória: não foi lançada avaliação diagnóstica, não houve fine-tuning e a partição de confirmação não foi aberta.

## Ajustes técnicos na versão 0.1.1

- A auditoria de 1.500 estados representativos de desenvolvimento encontrou prompts até 1.200 tokens. A medição não cobre todas as permutações possíveis.
- O limite de entrada foi elevado de 1.024 para 2.048 tokens, a truncagem silenciosa foi desativada e prompts acima do limite agora geram erro explícito.
- A chamada de geração com max_new_tokens passou a definir max_length=None, evitando o aviso de conflito herdado da configuração de geração.
- Os nove testes unitários existentes passaram após as alterações (unittest discover -s tests -q, saída 0). Estes testes verificam o protótipo, não a competência do modelo.

## Resultado do smoke test de desenvolvimento

O smoke test falhou o gate de prontidão para avaliação:

- Num smoke test do modelo base com cinco mundos, ocorreram 50 ações inválidas e zero consultas.
- Numa geração isolada do modelo base, com prompt de 1.102 tokens, a resposta foi texto genérico em linguagem natural e não pôde ser interpretada como ação JSON.
- Numa geração isolada do adaptador M16, também com 1.102 tokens, a ação foi review, que não pertence ao contrato de ações do M17.

Estes são resultados de compatibilidade da interface e do harness, não métricas de desempenho ou evidência válida sobre a capacidade diagnóstica. O prompt M17 não fornece instruções explícitas de tarefa e ações permitidas que estavam presentes nos exemplos de treino M16. Além disso, o esquema de ações antigo do M16 não corresponde ao esquema M17. A incompatibilidade é a explicação operacional mais provável; estes smoke tests não isolam causalmente cada fator.

## Decisão no gate

Não foram produzidas métricas diagnósticas do modelo base ou do adaptador M16. Com o smoke test a falhar, avançar para episódios completos mediria sobretudo o desajuste de formato e de contrato.

Próximo passo proposto para retoma: definir e versionar explicitamente a interface de agente M17 — instruções, ações válidas, formato de resposta e tratamento de ações desconhecidas — e, se for usado o adaptador M16, especificar uma tradução compatível entre os esquemas. Depois, executar apenas novos smoke tests no conjunto de desenvolvimento. A avaliação diagnóstica só deverá começar após aprovação desse gate. Fine-tuning e confirmação continuam fora do âmbito até à análise obrigatória.

## Adenda de correção — 17/10/2026

A interpretação acima de que o estado M17 não fornecia tarefa e esquema de ações estava incorreta. O estado público já contém `task` e `response_schema`, e o wrapper envia o estado completo ao modelo. O piloto de 50 mundos, relatado em `M17_PILOTO_E_ANALISE_GATE_2026-10-17.md`, mostrou falhas operacionais de ambos os modelos, mas não isolou a respetiva causa.
