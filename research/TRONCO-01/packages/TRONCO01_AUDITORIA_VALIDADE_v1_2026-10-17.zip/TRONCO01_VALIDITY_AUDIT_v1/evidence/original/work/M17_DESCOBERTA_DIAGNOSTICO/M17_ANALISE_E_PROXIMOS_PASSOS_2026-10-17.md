# M17 — análise crítica e próximos passos

Data: 17/10/2026. Âmbito desta revisão: leitura do código e protocolo, verificação determinística em memória num mundo de desenvolvimento e consulta de fontes externas. Não foram executadas novas inferências dos modelos, avaliação diagnóstica, confirmação ou treino. O código experimental não foi alterado nesta revisão.

## 1. Conclusão

O M17 ainda não permite decidir se o modelo base ou M16 possuem a competência procurada. As falhas de ação observadas são reais, mas a sua causa não está isolada. Antes de investir em treino, é necessário corrigir a contabilização das falhas no avaliador, garantir isolamento entre episódios e executar um piloto comparável com instruções e critérios de decisão inequívocos.

Mesmo um resultado positivo neste M17 demonstraria apenas revisão de modelos e escolha entre medições num ambiente sintético delimitado. A tarefa, as hipóteses e as consultas são fornecidas. A identificação espontânea de problemas e a formulação livre de perguntas continuam por testar.

## 2. Correção factual do relatório anterior

O estado público criado por generator.py já contém os campos task e response_schema, incluindo as ações query e report. llm_agents.py serializa esse estado no prompt. Por isso, a afirmação anterior de que faltavam instruções de tarefa e esquema de ações estava incorreta. Esta análise substitui essa interpretação causal do relatório M17_RETOMA_TECNICA_2026-10-17.md; não altera as observações históricas aí registadas.

As instruções estão embebidas num objeto JSON; a suficiência dessa apresentação para os modelos não foi testada por comparação controlada. Clareza das instruções, semântica das decisões, capacidade do modelo, adaptação M16 e eventual truncagem da resposta são hipóteses a distinguir. A ação review produzida numa única amostra M16 não permite concluir, por si só, qual destas causas domina.

## 3. Achados confirmados no código

### 3.1 Falhas podem contar como reconhecimento de insuficiência

Ao esgotar dez ações sem relatório válido, Episode.run cria automaticamente um relatório undetermined. summarize contabiliza esse veredicto na métrica insufficiency_recognition e score_report pode considerá-lo uma decisão correta na categoria INSUFFICIENCY.

Uma verificação determinística, sem LLM, num mundo de desenvolvimento confirmou: dez ações inválidas, zero diagnóstico sustentado e, ainda assim, insufficiency_recognition = 1.0. É um contraexemplo ao avaliador, não uma estimativa de desempenho. O gate de diagnóstico sustentado continua a reprovar esse caso; o erro afeta a interpretação das métricas de reconhecimento e decisão.

### 3.2 Feedback pode passar de um episódio para o seguinte

run_llm reutiliza a mesma instância do agente. Se a última ação for inválida, Episode.run chama feedback e termina por limite; llm_agents.py mantém last_feedback até à chamada seguinte de act. Sem reset no início do episódio, o próximo mundo recebe um erro do mundo anterior. A verificação determinística confirmou que o feedback fica pendente após o limite.

### 3.3 Critérios de apoio e insuficiência precisam de definição operacional

O protocolo aceita apoio ao modelo de trabalho num NORMAL ainda ambíguo entre hipóteses, mas exige undetermined em INSUFFICIENCY com hipóteses compatíveis. O gerador distingue estes casos pela possibilidade de consultas discriminantes; isto não equivale a uma definição explícita de quando a evidência já recolhida justifica cada veredicto. A instrução pública e a pontuação precisam de uma regra coerente sobre apoio provisório, identificação e ambiguidade, fixada antes de observar novos resultados de modelos.

### 3.4 Limites da validação e da replicação

Os nove testes existentes não cobrem os dois erros operacionais acima nem a integração real do modelo. O diagnóstico tem três sementes no total, uma por família; não existem três repetições por família. Semente e família ficam confundidas nesse desenho. Os intervalos por categoria devem ser apresentados, e as três avaliações não devem ser descritas como três réplicas de cada mecanismo.

## 4. Plano até ao próximo ponto de análise obrigatória

### Passo 1 — corrigir o avaliador e versionar o protocolo

Preparar uma versão 0.1.2, com alterações documentadas antes de novos resultados:

- Representar limites, falhas de geração e ausência de relatório como estados operacionais explícitos. A falha não recebe crédito de abstenção escolhida pelo agente; os episódios falhados permanecem no denominador das métricas principais.
- Reiniciar feedback e qualquer memória do agente no início de cada mundo.
- Validar integralmente o esquema, os tipos e as referências a observações, hipóteses e consultas existentes.
- Definir os veredictos em função da evidência disponível e esclarecer o tratamento de hipóteses ainda compatíveis.
- Reservar espaço para a resposta dentro do contexto total e registar se a geração terminou por limite de tokens.
- Adicionar testes de regressão dirigidos: agente sempre inválido, abstenção explícita e sustentada, isolamento entre episódios, referências inventadas e resposta truncada.
- Atualizar hashes e identificar os controlos anteriores como pertencentes à versão anterior quando forem afetados pela correção das métricas.

As correções devem ser orientadas por estes contraexemplos de código e desenvolvimento. Os resultados diagnósticos não devem orientar ajustes ao avaliador.

### Passo 2 — estabelecer um contrato comum de comunicação

Usar instruções explícitas de operação, ações, significado dos veredictos e obrigação de devolver um objeto JSON. Os dois modelos recebem o mesmo contrato e os mesmos dados públicos. O prompt não revela categorias ocultas, proporções, soluções ou regras de diagnóstico específicas do gerador.

Fixar uma única revisão inicial do prompt. Qualquer variante posterior deve ser registada como novo ensaio de desenvolvimento. Uma tradução especial de ações M16, um descodificador restrito ou um verificador que ajude a escolher respostas constituem condições experimentais adicionais e devem ser identificados separadamente.

### Passo 3 — validar os controlos no desenvolvimento

Executar testes e controlos no desenvolvimento. Incluir um controlo determinístico competente que use apenas o canal público para verificar tabelas e compatibilidade e escolher medições. Este controlo verifica a integridade da tarefa; não serve como demonstração de descoberta autónoma. Preservar também os controlos simples e uma referência sem consultas para a avaliação posterior do valor da investigação.

### Passo 4 — piloto limitado dos modelos

Executar modelo base e M16 nos mesmos 50 mundos de desenvolvimento, dez por categoria, com ordem aleatória comum, repartidos pelas sementes disponíveis. A estratificação é informação do avaliador e não aparece no prompt.

Registar separadamente validade das ações, terminação voluntária, falhas por limite, consultas, diagnóstico sustentado e reconhecimento de insuficiência explicitamente escolhido. Guardar os erros de formato e a saída bruta necessários à depuração sem exportar metadados ocultos ou rótulos individuais. Não converter saídas sem relatório em respostas certas.

Critérios propostos de prontidão técnica, a fixar antes do piloto: no máximo 1% de ações inválidas, pelo menos 98% de episódios terminados com relatório explícito e zero truncagens silenciosas ou passagem de estado entre mundos. Estes são critérios de engenharia; 50 mundos não demonstram capacidade científica nem precisão suficiente sobre taxas raras de falha.

### Paragem obrigatória após o piloto

Produzir relatório comparável dos dois modelos, controlos, custos, tipos de erro e alterações efetuadas. Terminar a execução aqui, antes do diagnóstico reservado, confirmação ou treino.

Decisões a tomar nessa análise:

| Resultado | Decisão seguinte |
|---|---|
| Formato ou terminação continuam a falhar | Isolar o problema de interface, geração ou modelo num teste mínimo de desenvolvimento. |
| Ambos comunicam corretamente, mas falham a evidência | Avaliar uma referência de maior capacidade em inferência antes de investir em LoRA. |
| Base supera M16 de forma consistente | Investigar perda de transferência causada pela adaptação; preservar o base como referência. |
| M16 melhora de forma consistente e os gates técnicos passam | Congelar o protocolo e planear o diagnóstico comparável com todos os controlos. |
| Controlo simbólico resolve a tarefa e os modelos também | Aumentar posteriormente a variedade de mecanismos e a abertura das perguntas para testar competências além das tabelas fornecidas. |

## 5. Reaproveitamento de investigação existente

Estas são duas opções concretas verificadas nesta revisão, não uma pesquisa exaustiva de 2026:

- **BoxingGym (preprint de 2025, revisão de outubro de 2025):** código de ambientes probabilísticos, desenho de experiências e métricas de informação esperada e previsão. Pode poupar trabalho na avaliação posterior da escolha de experiências e da transferência entre mecanismos. O artigo também relata que acrescentar um modelo estatístico explícito não melhora os resultados de forma consistente; uma arquitetura híbrida deve ser testada. Artigo: https://arxiv.org/abs/2501.01540 . Código: https://github.com/kanishkg/boxing-gym .
- **DiscoveryWorld (NeurIPS Datasets and Benchmarks 2024):** ambientes, agentes de referência, API e registos de trajetórias para investigação interativa. Pode servir de teste externo numa fase posterior. A minha recomendação é aproveitar primeiro os padrões de interação, registo e avaliação e medir o esforço de integração antes de substituir o M17. Código e referência da publicação: https://github.com/allenai/discoveryworld .

Nenhum destes recursos, por si só, cobre a definição completa do tronco pretendido. A escolha deve basear-se na competência que permite medir e no código que efetivamente evita reconstruir.
