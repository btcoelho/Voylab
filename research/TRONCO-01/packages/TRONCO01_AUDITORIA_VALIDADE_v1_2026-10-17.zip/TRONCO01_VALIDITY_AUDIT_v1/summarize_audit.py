from collections import Counter
import ast
import json
from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
R = HERE / "results"


def load(name):
    return json.loads((R / name).read_text())


def junit(name):
    root = ET.parse(R / name).getroot()
    suites = list(root) if root.tag == "testsuites" else [root]
    return {k: sum(int(x.get(k, 0)) for x in suites) for k in ("tests", "failures", "errors", "skipped")}


def main():
    eps = load("retrospective_episode_profiles.json")
    retrospective = load("retrospective_summary.json")
    imports = []
    for node in ast.walk(ast.parse((HERE / "reference_core.py").read_text())):
        if isinstance(node, ast.Import):
            imports += [x.name for x in node.names]
        elif isinstance(node, ast.ImportFrom) and node.module != "__future__":
            imports.append(node.module)
    out = {"executed_episode_condition_units": len(eps), "distinct_development_worlds": len({e["world_id"] for e in eps}),
           "explicit_reports": sum(e["report"] is not None for e in eps),
           "legacy_scores_exactly_replayed": sum(v.get("legacy_score_replayed_exact", 0) for s in retrospective.values() for v in s["conditions"].values()),
           "actual_order_sensitive_reports": [{"stage": e["stage"], "condition": e["condition"], "episode_id": e["episode_id"],
               "category": e["category_for_legacy_comparison_only"], "historic_diagnosis": e["historic_diagnosis"]} for e in eps if e.get("legacy_score_order_sensitive_on_two_probes")],
           "accepted_raw_decode_failures": [x for x in load("raw_decode_findings.json") if x["accepted_historically"]],
           "reference_and_integration_tests": junit("reference_junit.xml"), "known_legacy_laws_expected_red": junit("legacy_failures_junit.xml"),
           "reference_semantic_imports": sorted(imports), "independence": "No legacy imports in reference; same author, not external human replication.",
           "finite_domain": load("finite_enumeration.json"), "mutation_panel": {k: v for k, v in load("mutation_summary.json").items() if k != "mutants"},
           "grammar": {k: v for k, v in load("grammar_audit.json").items() if k in {"weights_loaded", "all_prompt_hashes_match", "all_input_counts_match", "query_checks"}},
           "source_preservation": load("source_preservation.json")["all_unchanged"]}
    (R / "final_audit_metrics.json").write_text(json.dumps(out, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
