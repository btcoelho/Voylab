import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ARCHIVE = ROOT / "outputs/TRONCO01_AUDITORIA_VALIDADE_v1_2026-10-17.zip"


def main():
    prefix = "TRONCO01_VALIDITY_AUDIT_v1/"
    with zipfile.ZipFile(ARCHIVE) as z:
        entries = z.namelist()
        manifest = z.read(prefix + "SHA256SUMS.txt").decode()
        checked = []
        for line in manifest.splitlines():
            expected, name = line.split("  ", 1)
            assert hashlib.sha256(z.read(prefix + name)).hexdigest() == expected, name
            checked.append(prefix + name)
        assert set(checked) | {prefix + "SHA256SUMS.txt"} == set(entries)
        assert len(entries) == len(set(entries))
        assert z.testzip() is None
        assert not any("/private/" in n or "/.venv/" in n or n.endswith((".safetensors", ".gguf")) for n in entries)
    inventory = json.loads((HERE / "results/inventory.json").read_text())
    unchanged = all(hashlib.sha256((ROOT / x["path"]).read_bytes()).hexdigest() == x["sha256"]
                    for x in inventory["entries"] if x["path"] != "original_user_attachment")
    assert unchanged
    result = {"archive": ARCHIVE.name, "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
              "manifest_files_verified": len(checked), "zip_files": len(entries), "historical_sources_unchanged": unchanged,
              "zip_crc_and_sha256_pass": True, "private_reserve_files_or_model_weights_included": False}
    target = ROOT / "outputs/TRONCO01_AUDITORIA_VERIFICACAO_v1_2026-10-17.json"
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
