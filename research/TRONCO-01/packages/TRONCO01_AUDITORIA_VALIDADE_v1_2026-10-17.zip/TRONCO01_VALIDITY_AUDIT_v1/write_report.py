from __future__ import annotations

from datetime import date
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / "outputs"
R = HERE / "results"


def load(name):
    return json.loads((R / name).read_text(encoding="utf-8"))


FINDINGS = [
    {"id": "F01", "class": "defeito demonstrado", "rule": "um par contraditório suficiente não exige duplicatas redundantes",
     "observed": "CONTRADICTION exige todos os IDs do primeiro grupo de conflito", "counterexample": "counterexamples.json/F01_minimal_conflict_certificate",
     "impact": "falso negativo reproduzido; não demonstrado que explique os diagnósticos 0/5 do modelo G2", "minimal_fix": "procurar qualquer par contraditório efetivamente citado", "source": "environment.py:227-236"},
    {"id": "F02", "class": "defeito demonstrado", "rule": "a ordem de observações não altera validade do mesmo testemunho",
     "observed": "primeiro conflito/par de phase/partner encontrado condiciona a pontuação", "counterexample": "counterexamples.json/F02_conflict_order e F05_phase_pair_order",
     "impact": "8 relatórios simbólicos G1 e 2 G2 mudam pontuação sob reversão/ordenação das mesmas linhas", "minimal_fix": "avaliar existência de testemunho entre as evidências citadas, não exigir o primeiro testemunho interno", "source": "environment.py:168-196,227-267"},
    {"id": "F03", "class": "defeito demonstrado", "rule": "o valor de localização afirmado deve corresponder a evidência observada",
     "observed": "CHANGE/HYPOTHESIS_ABSENT verificam feature mas ignoram location.value", "counterexample": "counterexamples.json/F03_location_value_unchecked",
     "impact": "localização inventada recebe crédito no exemplo mínimo; nenhuma ocorrência com crédito e valor ausente foi encontrada nos relatórios históricos examinados", "minimal_fix": "validar o valor contra o testemunho citado e declarar que tipo de localização se avalia", "source": "environment.py:246-267"},
    {"id": "F04", "class": "defeito demonstrado", "rule": "hipóteses declaradas compatíveis não podem estar refutadas pelo histórico disponível",
     "observed": "INSUFFICIENCY aceita candidatos extras se acertam apenas o subconjunto de linhas citado", "counterexample": "counterexamples.json/F06_eliminated_candidate_in_accepted_diagnosis",
     "impact": "falso diagnóstico positivo reproduzido; frequência histórica deste defeito não estimada", "minimal_fix": "conferir a declaração contra todo H e os candidatos que continuam compatíveis", "source": "environment.py:237-245"},
    {"id": "F05", "class": "divergência de contrato demonstrada", "rule": "a localização anunciada usa feature/value com significado verificável",
     "observed": "gramática e validador permitem qualquer objeto em location", "counterexample": "grammar_audit.json/contract_probes; counterexamples.json/F07_contract_location_shape",
     "impact": "as quatro localizações explícitas do base G2 falham a forma anunciada; não basta transportar JSON", "minimal_fix": "schema canónico apenas para estrutura/proveniência e validação semântica separada; permitir respostas erradas para medir erros", "source": "preflight_g1.py:62; run_g2.py:165-203"},
    {"id": "F06", "class": "comportamento demonstrado, impacto parcialmente observado", "rule": "uma saída tem interpretação única e o executor respeita o contrato de objeto único",
     "observed": "fallback extrai objeto de texto extra; json.loads conserva última ocorrência de uma chave repetida", "counterexample": "tests/test_legacy_interfaces.py; raw_decode_findings.json; grammar_audit.json/duplicate_nested_keys",
     "impact": "um relatório real G2 aceitou site repetido; rejeitar chaves duplicadas é política explícita de interpretação, não alegação de que todo parser JSON as proíbe. Nenhuma ação historicamente aceite dependia de extração de prosa exterior", "minimal_fix": "decodificador que recuse duplicatas/números não finitos/texto exterior, preservando o original; regra nova versionada", "source": "run_g2.py:133-146; action_utils.py:first_json_object"},
    {"id": "F07", "class": "defeito de verificação demonstrado", "rule": "cada consulta legal deve ser testada na gramática antes da inferência",
     "observed": "preflight testa apenas primeiro query_id e incrementa contador para todos com condição tautológica", "counterexample": "preflight_g2.py:91-96 no snapshot",
     "impact": "contagem 300 não comprova 300 caminhos antes da execução; auditoria posterior foi documentada. A presente auditoria verifica 165 caminhos/EOS nos estados de cinco mundos executados", "minimal_fix": "exercer cada caminho e terminar no EOS; testar proibições e estados após consultas", "source": "preflight_g2.py:75-96"},
    {"id": "F08", "class": "lacuna processual demonstrada; alteração histórica não demonstrada", "rule": "o gate deve verificar os hashes que afirma garantir",
     "observed": "main G2 confere flags do pré-teste; preflight compara agenda, mas não valida todos os hashes de fontes/pesos antes de carregar", "counterexample": "run_g2.py:main e preflight_g2.py:main nos snapshots",
     "impact": "11/11 hashes de fontes atuais coincidem com o pré-registo e a agenda coincide; não há evidência independente do momento do freeze nem dos pesos efetivamente executados", "minimal_fix": "verificação de hashes na fronteira de execução e diário de proveniência; não inferir cronologia só de status textual", "source": "run_g2.py:main; preregistration.json/source_sha256"},
    {"id": "F09", "class": "risco reproduzido por injeção de falha", "rule": "saída devolvida deve ser preservada antes de interpretação/efeitos seguintes",
     "observed": "evento bruto é anexado só depois de aplicar a ação; uma saída não tratada pode preceder a gravação", "counterexample": "tests/test_legacy_interfaces.py/test_logging_order_can_lose_already_returned_raw_on_unhandled_exit",
     "impact": "perda demonstrada com SystemExit simulado, não perda alegada no G2 preservado; replay histórico não mostrou lacunas nas consultas", "minimal_fix": "evento bruto independente antes de parsing/aplicação, depois eventos derivados com sequência", "source": "run_g2.py:run_episode"},
    {"id": "F10", "class": "defeito demonstrado na agregação M17; G2 já tem mitigação", "rule": "ausência de previsão explícita não mede calibração perfeita",
     "observed": "summarize M17 inclui terminações forçadas com confidence=0 e acerto falso no Brier", "counterexample": "calibration_counterexample.json",
     "impact": "Brier/ECE zero podem coexistir com zero previsões; G2 summarize_explicit já exclui tais casos. O significado de confidence continua por definir", "minimal_fix": "calibrar apenas previsões explícitas com evento-alvo declarado e reportar cobertura", "source": "evaluate_m17.py:_calibration e summarize; run_g2.py:summarize_explicit"},
    {"id": "S11", "class": "especificação incompatível entre camadas", "rule": "o alvo epistémico deve ser único e público",
     "observed": "NORMAL aceita suporte ambíguo; prompt G2 exige undetermined se múltiplos candidatos; CHANGE é refutado pelo rótulo mesmo antes de evidência discriminante",
     "counterexample": "SPEC.md; counterexamples.json/S08_public_identical_hidden_expected_differs",
     "impact": "mesmo estado admite suporte por ajuste observacional e indeterminação por identidade; rótulo oculto mistura aquisição, verdade geradora e conclusão justificada", "minimal_fix": "declarar a afirmação julgada e separar compatibilidade de W, alternativas, previsões em D e qualidade das consultas", "source": "PROTOCOL.md/Âmbito; generator.py:_select_rows; run_g2.py:G2_SYSTEM; environment.py:199-224"},
    {"id": "S12", "class": "especificação discutível, não atribuição causal demonstrada", "rule": "distinguir contraste direto, inferência sob hipóteses e mudança causal",
     "observed": "helper de phase permite partner/setting diferentes; phase não é eixo temporal; lista vazia não identifica uma causa única",
     "counterexample": "counterexamples.json/S04_phase_association_is_not_controlled_effect",
     "impact": "certifica uma associação ou seleção dentro da classe, não necessariamente contraste controlado, ruído versus erro ou mudança real de mecanismo", "minimal_fix": "nomear o que se demonstra, explicitar pressupostos e não avaliar causalidade que o desenho não identifica", "source": "environment.py:_has_phase_effect; generator.py:CHANGE/HYPOTHESIS_ABSENT"},
]


def main():
    m = load("final_audit_metrics.json")
    retrospective = load("retrospective_summary.json")
    inv = load("inventory.json")
    g = load("grammar_audit.json")
    portable = load("portable_replay.json")
    (R / "findings.json").write_text(json.dumps(FINDINGS, indent=2, ensure_ascii=False) + "\n")
    table = []
    for label, stage, cond in [("G1 base schema", "G1v02", "base_schema"), ("G1 M16 schema", "G1v02", "m16_schema"),
                               ("G2 base schema", "G2", "base_g2_schema"), ("G2 ponte G1", "G2", "base_g1_bridge"),
                               ("G1 detetor estatístico", "G1v02", "control_statistical_detector"), ("G1 simbólico", "G1v02", "control_symbolic_active")]:
        x = retrospective[stage]["conditions"][cond]
        table.append(f"| {label} | {x['episodes']} | {x['explicit']} | {x['historic_decisions']} | {x.get('observed_fit_verdict_match_explicit', 0)} | {x.get('model_identity_verdict_match_explicit', 0)} |")
    defects = "\n".join(f"| {f['id']} | {f['class']} | {f['observed']} | {f['minimal_fix']} |" for f in FINDINGS)
    report = f"""**TRONCO-01/M17/G2 — auditoria delimitada da validade, v1**

Data: 17/10/2026. Decisão: **a tarefa precisa de redefinição operacional; o instrumento atual permanece inapto para iniciar outro ensaio de modelo.**

A pergunta central não recebe um sim geral: o sistema verifica referências e algumas
relações observacionais, mas não separa de forma fiável sustentação científica,
legalidade, identificação e rótulo gerador. Há falsos negativos, falsos positivos e
dependência da ordem das linhas no pontuador. Um núcleo independente e limitado foi
construído para tornar esses problemas verificáveis; não foi integrado na produção.

**1. Base empírica e preservação**

Foram inventariados {len(inv['entries'])} artefactos selecionados: pedido original,
fontes, protocolos, pré-registos, agendas e registos G1 v0.2/G2, além de resultados
agregados de desenvolvimento M17. Os 11 hashes de fonte enumerados no pré-registo G2
coincidem com os ficheiros atuais; a agenda coincide com o hash declarado. Os ficheiros
históricos monitorizados permanecem inalterados.

Foram reconstruídas {m['executed_episode_condition_units']} execuções por condição em
{m['distinct_development_worlds']} mundos de desenvolvimento, não 235 amostras independentes.
As pontuações dos {m['explicit_reports']} relatórios explícitos foram reproduzidas
exatamente. As respostas de consultas registadas coincidiram com o replay. Isso confirma
consistência entre fontes preservadas, registos e agregação; não valida a regra científica.

Os 30 hashes de prompt de ações de modelo G2 e as contagens de entrada coincidiram com
reconstruções usando o tokenizer fixado. São reconstruções verificadas por hash, não
ficheiros originais de prompts/tokens. `raw` já foi descodificado com remoção de tokens
especiais. Não existem streams completos de tokens nem prova independente do momento
do freeze/da identidade binária dos pesos executados. O pré-registo não substitui essa
proveniência. Os resultados agregados M17 não permitem reconstruir saídas do modelo que
não foram guardadas. A ausência de summary.json G2 completo é coerente com a paragem
no sentinela; sentinel_summary.json e os registos estão preservados.

Não se leram datasets/gabaritos M17 de diagnóstico ou confirmação, não se instanciaram
geradores dessas partições e não se carregaram pesos. As chamadas de geração presentes
nos testes são doubles em memória, com tensores artificiais e texto fixo. Foram usados
apenas mundos de desenvolvimento já executados, fixtures manuais e interpretações
contrafactuais explicitamente identificadas. As três sementes por mecanismo referidas
no protocolo não correspondem ao desenho listado: há uma semente por família reservada;
esta observação usa apenas o texto do protocolo, sem abrir essas famílias.

**2. O alvo que falta definir**

`SPEC.md` distingue três perguntas: (a) W é compatível com o histórico? (b) W foi
identificado entre candidatos? (c) os candidatos sobreviventes concordam nas previsões
num domínio D explicitamente declarado? As três podem produzir respostas diferentes.
Compatibilidade não prova verdade universal; ambiguidade entre modelos não implica
ambiguidade preditiva no menu; refutar W não exige identificar uma alternativa única.

No próprio gerador, NORMAL começa ambíguo e admite uma consulta discriminante. CHANGE
também começa com W e o modelo de phase compatíveis. O pontuador espera supported para
NORMAL e rejected para CHANGE; o prompt G2 manda undetermined com vários candidatos.
A instrução e o critério não são a mesma pergunta.

Foi construído um gémeo contrafactual de um CHANGE G2 já executado, mantendo todos os
dados públicos e usando W como interpretação normal alternativa. Ambos passam as
verificações estruturais de identificabilidade do gerador. Três consultas com respostas
comuns esgotam o orçamento e deixam os estados públicos idênticos, mas o pontuador exige
veredictos diferentes. O par não é uma colisão observada entre duas sementes sorteadas;
é um contraexemplo explícito entre duas interpretações permitidas pelas tabelas e pelo
auditor. Inicialmente existiam consultas discriminantes. Portanto, não demonstra que
uma política ótima nunca poderia resolver os mundos. Demonstra que julgamento final
justificado e qualidade de aquisição de informação precisam de medidas separadas.

Sem especificar a afirmação, não existe um único avaliador correto para todos estes
sentidos de supported/undetermined. A referência devolve os sentidos separadamente e
o conjunto de veredictos defensáveis sob cada interpretação. Não usa categoria oculta.

**3. Defeitos e escolhas de especificação**

| ID | Classificação | Comportamento observado | Correção mínima proposta |
|---|---|---|---|
{defects}

`results/findings.json` contém, para cada entrada, regra pretendida, comportamento,
contraexemplo, impacto histórico demonstrado ou desconhecido, proposta e âncora de fonte.
`results/counterexamples.json` guarda fixtures e resultados completos.

O impacto mais direto no material publicado é F02: **oito dos 25 relatórios do controlo
simbólico G1 e dois dos cinco do G2 mudam de pontuação quando se invertem/ordenam as
mesmas observações**. O relatório, IDs e valores não mudam. Não é incerteza amostral nem
uma nova execução do agente. Os 100% históricos desse controlo dependem de uma escolha
de testemunho pelo pontuador, em vez de uma regra invariante de validade da evidência.

Um exemplo M17 de terminação forçada produz Brier=0/ECE=0 sem uma previsão explícita.
Essa é uma falha de agregação M17; G2 já filtra calibração por relatórios explícitos.
Mesmo aí, confidence precisa de um evento-alvo definido para se interpretar calibração.

**4. Gramática, parsing e pré-teste**

Foram verificados {g['query_checks']['legal_query_paths']} caminhos completos de consulta,
incluindo EOS, em {g['query_checks']['states']} estados reconstruídos dos cinco mundos
G2 executados; os cinco estados sem orçamento recusaram o ramo query. Identificadores
inventados e campos exteriores extra foram recusados. Este é um resultado saudável.

Em contraste, a gramática e o validador aceitaram location vazio ou com campos
arbitrários, apesar da forma feature/value anunciada. O parser histórico também pode
recuperar um objeto de texto exterior. A injeção com um gerador simulado reproduz essa
aceitação; não foi encontrada ação aceite nos registos que dependesse de extração de
prosa. Há um caso real diferente: g2_insufficiency_1 repete a chave site dentro de
location. Foi marcado strict_json=true e aceite; a referência recusa essa interpretação
ambígua. Rejeição de chaves repetidas é uma política explícita de leitura inequívoca.

O pré-teste G2 verificou um ID de consulta por mundo e depois contou todos através de
uma condição que só confirma que um elemento da lista está na própria lista. O relatório
G2 já reconhecia a auditoria posterior dos 300 IDs. Essa correção posterior não torna a
verificação original pré-inferência. Um prefixo incompleto também pode ser alcançável
sem permitir EOS: a auditoria distingue agora essas duas propriedades.

Não se deve resolver isso obrigando o descodificador a produzir a conclusão correta.
O teste novo mantém respostas erradas/evidência vazia como ações potencialmente legais
e mede sustentação numa camada diferente. A localização proposta e a unicidade de IDs
são regras de representação/proveniência, sem seleção automática do diagnóstico.

**5. Referência e testes dos testes**

A referência importa apenas {', '.join(m['reference_semantic_imports'])}. Não reutiliza
preditores, conjuntos compatíveis, testemunhos ou pontuadores de produção. As três
formas públicas de tabela são interpretadas por um contrato literal explícito.
A enumeração compara os resultados com vetores de verdade indexados diretamente,
não com a mesma função sob outro nome.

- {m['finite_domain']['public_states']} estados públicos finitos e {m['finite_domain']['claim_checks']} verificações de afirmações, sem divergências.
- {m['reference_and_integration_tests']['tests']} testes de referência/integração passaram; incluem propriedades Hypothesis, sequências de consultas, reset, orçamento, terminação, ordem, renomeação de IDs, duplicatas, evidência e parsing.
- Quatro leis desejáveis falham por asserção no código histórico preservado, sem erro de infraestrutura; os seus logs vermelhos estão incluídos.
- Onze mutações não equivalentes foram detetadas por falhas de asserção. O controlo equivalente `len(rows)==0` versus `not rows` sobre listas sobreviveu. Nenhum sobrevivente relevante ficou por explicar neste painel.
- Reprodução numa diretoria temporária com fontes copiadas: {'passou os quatro comandos esperados' if portable['all_expected'] else 'falhou; consultar portable_replay.json'}. Essa reprodução elimina dependências dos caminhos das fontes vivas, mas continua na mesma máquina e com o mesmo operador.

O painel de mutações é direcionado e transparente, não uma campanha automática sobre
todo o projeto. As mutações foram feitas em cópias do núcleo de referência. O pontuador
histórico já falha quatro leis de base; não se atribui uma taxa de mutações válida a
uma bateria de aceitação cujo baseline está vermelho. A suíte unitária M17 original
foi lida e incluída como evidência; os seus testes geradores não foram reexecutados e
os antigos totais de testes PASS não são certificados por esta auditoria. Z3 não
acrescentava poder necessário aos contraexemplos e ao domínio
finito escolhido, pelo que não foi usado. A enumeração não cobre ruído, causalidade,
modelos abertos, linguagem natural ou todos os estados/bugs possíveis.

**6. Reanálise retrospectiva — não substitui os resultados históricos**

As colunas seguintes distinguem o rótulo histórico de dois alvos explícitos.
As comparações alternativas só usam relatórios realmente emitidos; as falhas continuam
identificadas no denominador total. A correspondência de um veredicto não exige, nesta
tabela, que o seu testemunho seja suficiente.

| Condição | Episódios | Relatórios explícitos | Acertos categóricos históricos | Veredicto compatível com ajuste observado | Veredicto compatível com identidade de W |
|---|---:|---:|---:|---:|---:|
{chr(10).join(table)}

Por exemplo, o detetor estatístico G1 acerta as 25 decisões de ajuste observacional,
mas só 15 rótulos históricos. O controlo simbólico acerta as 25 decisões de identidade,
mas dá undetermined em cinco estados onde W continua observacionalmente compatível.
Isto não elege um comparador vencedor: mostra que as métricas julgam afirmações diferentes.

Para o base G2, dois dos quatro veredictos explícitos coincidem com compatibilidade
observacional; **nenhum dos quatro tem sustentação por evidência citada**. As localizações
também violam a forma anunciada. A truncagem e a falha do braço livre continuam reais.
Esta auditoria não converte o G2 num sucesso nem demonstra incapacidade geral do modelo.
O gate histórico falhou e a paragem foi adequada.

Os novos contadores de localização tratam apenas contraste observacional direto.
Não são substitutos das pontuações históricas de localização por seleção de modelo.
Contagens, XMLs e perfis por episódio estão disponíveis; nenhuma reanálise é uma nova
confirmação, comparação causal entre prompts ou estimativa populacional.

**7. Decisão e ponto de análise obrigatório**

**A tarefa precisa de redefinição operacional.** O instrumento atual fica inapto para
nova inferência. A razão central é o alvo de conclusão não ser estável entre protocolo,
prompt e pontuador; reparar apenas location ou mudar de modelo não resolve esse problema.

A redefinição mínima é explicitar o objeto da conclusão: compatibilidade de W,
identificação entre hipóteses ou previsão em D. Diagnóstico deve conter testemunhos
verificáveis, sem confundir phase contextual com mudança causal. Qualidade de consultas
e sustentação do relatório final precisam de avaliação separada. As correções F01–F10
podem então ser derivadas dessa especificação e integradas numa versão nova, sem alterar
os resultados históricos. Não é necessária uma arquitetura maior para fazer isso.

O núcleo de referência é um instrumento de auditoria finito, não um agente aprovado.
Para autorizar um pequeno ensaio posterior, é preciso fechar a semântica pública,
integrar uma versão nova e reproduzir a aceitação/verificação de testemunhos, incluindo
os testes negativos. A presente execução termina aqui, antes de qualquer inferência.

O pacote permite a outra pessoa conferir exemplos, resultados e versões. Não houve
revisão por pessoa/equipa externa nem prova universal. Independência de implementação
não elimina pressupostos partilhados pelo autor. As conclusões sobre o benchmark
sintético não são conclusões sobre o manuscrito Voynich.

**Entregáveis e reprodução**

SPEC.md contém a especificação, reference_core.py a referência, results/inventory.json
o inventário/proveniência, results/findings.json os achados, results/counterexamples.json
os testemunhos e README.md os comandos de reprodução. SHA256SUMS.txt permite conferir o
conteúdo do pacote. Dependências diretas e runtime opcional estão fixados em ficheiros
separados. O relatório e a especificação também foram entregues separadamente em outputs.
"""
    (HERE / "REPORT.md").write_text(report, encoding="utf-8")
    OUT.mkdir(exist_ok=True)
    report_path = OUT / "TRONCO01_AUDITORIA_VALIDADE_v1_2026-10-17.md"
    report_path.write_text(report, encoding="utf-8")
    shutil.copyfile(HERE / "SPEC.md", OUT / "TRONCO01_ESPECIFICACAO_MINIMA_AUDITORIA_v1_2026-10-17.md")
    archive = OUT / "TRONCO01_AUDITORIA_VALIDADE_v1_2026-10-17.zip"
    selected = []
    for p in HERE.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(HERE)
        if any(part in {".venv", "__pycache__", ".hypothesis", ".pytest_cache"} for part in rel.parts):
            continue
        if p.name in {"SHA256SUMS.txt", "reference_junit.xml"} and rel.parent == Path("."):
            continue
        selected.append(p)
    manifest = "".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(HERE).as_posix()}\n" for p in sorted(selected))
    (HERE / "SHA256SUMS.txt").write_text(manifest, encoding="utf-8")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(selected) + [HERE / "SHA256SUMS.txt"]:
            z.write(p, f"TRONCO01_VALIDITY_AUDIT_v1/{p.relative_to(HERE).as_posix()}")
    print(json.dumps({"report": str(report_path), "archive": str(archive), "files": len(selected) + 1,
                      "bytes": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
