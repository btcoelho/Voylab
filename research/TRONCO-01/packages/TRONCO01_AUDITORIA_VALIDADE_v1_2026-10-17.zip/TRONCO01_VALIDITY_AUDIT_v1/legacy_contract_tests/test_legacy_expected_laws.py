"""These desired laws intentionally fail against preserved historic source.

Run separately. Nonzero exit here documents defects, not audit infrastructure failure.
"""
from pathlib import Path
from copy import deepcopy
import sys
import os

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
SOURCE_ROOT = Path(os.environ.get("AUDIT_SOURCE_ROOT", str(HERE.parents[1])))
sys.path.insert(0, str(SOURCE_ROOT / "work/M17_DESCOBERTA_DIAGNOSTICO"))
from fixtures import base_state, row, report, legacy_world
from environment import score_report


def test_minimal_contradictory_pair_should_suffice():
    s = base_state()
    s["observations"] += [row("b", output="1"), row("c")]
    r = report("rejected", ("a", "b"), (), "input", s["observations"][0]["input"])
    assert score_report(legacy_world(s, "CONTRADICTION"), s["observations"], r)["diagnosis_correct"]


def test_permutation_should_not_change_evidence_validity():
    s = base_state()
    rows = [row("a"), row("b", output="1"), row("c", glyph="g1"), row("d", glyph="g1", output="1")]
    r = report("rejected", ("c", "d"), (), "input", rows[2]["input"])
    w = legacy_world(s, "CONTRADICTION")
    assert score_report(w, rows, r) == score_report(w, rows[2:] + rows[:2], r)


def test_unobserved_location_value_should_not_be_correct():
    s = base_state()
    s["observations"] += [row("b", phase="t1", output="1")]
    r = report("rejected", ("a", "b"), ("C",), "phase", "impossible")
    assert not score_report(legacy_world(s, "CHANGE", "C"), s["observations"], r)["localized_correct"]


def test_an_eliminated_candidate_should_not_be_accepted_as_compatible():
    s = base_state()
    s["candidate_models"][1]["table"] = {"s0": "0", "s1": "1"}
    s["candidate_models"][2]["table"] = dict.fromkeys(s["candidate_models"][2]["table"], "0")
    s["observations"] = [row("a"), row("b", partner="p1"), row("c", setting="s1")]
    r = report("undetermined", ("a", "b"), ("A", "B", "C"))
    assert not score_report(legacy_world(s, "INSUFFICIENCY"), s["observations"], r)["diagnosis_correct"]
