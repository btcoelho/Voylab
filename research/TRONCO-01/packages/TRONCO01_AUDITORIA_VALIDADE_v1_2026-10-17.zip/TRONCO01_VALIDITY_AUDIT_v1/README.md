# Auditoria delimitada TRONCO-01/M17/G2

Leia SPEC.md antes de interpretar as contagens. A decisão está no relatório entregue
em outputs e no ficheiro REPORT.md deste pacote. Não houve inferência de modelos,
fine-tuning ou acesso a dados de diagnóstico/confirmação M17. Chamadas `generate`
nos testes usam apenas um objeto simulado em memória, sem pesos.

## Componentes

- reference_core.py: referência pequena, sem imports semânticos históricos.
- fixtures.py: exemplos manuais sem gerador histórico.
- tests/test_reference.py: propriedades e máquina de estados da referência.
- tests/test_legacy_interfaces.py: transições comparadas, parser simulado e falha de gravação.
- legacy_contract_tests/: quatro leis que devem FALHAR contra o pontuador preservado.
- offline_audit.py: inventário, hashes, enumeração, contraexemplos e reanálise retrospectiva.
- grammar_audit.py: tokenizer local, sem pesos, sobre estados G2 já executados.
- mutation_audit.py: 11 mutações relevantes e um controlo equivalente, sobre cópias.
- evidence/original/: fontes, protocolos e registos preservados de desenvolvimento.
- results/: resultados JSON, XML JUnit e logs, incluindo os testes deliberadamente vermelhos.

Os schedules G1/G2 são apenas desenvolvimento, já agendado/exposto. O schedule G2
tem 25 mundos, dos quais só cinco foram executados. Os 20 não executados não são
usados como nova amostra. Não se inclui qualquer dataset M17 de reserva.

## Reprodução por outra pessoa (Python 3.12, Linux/WSL)

Descompacte o pacote numa pasta própria. Execute a partir da pasta da auditoria:

```bash
python3 -m venv /tmp/tronco01-audit-reproduction
/tmp/tronco01-audit-reproduction/bin/python -m pip install -r requirements-audit.txt
export PYTHONDONTWRITEBYTECODE=1
export AUDIT_SOURCE_ROOT="$PWD/evidence/original"
PY=/tmp/tronco01-audit-reproduction/bin/python
$PY -m pytest tests/test_reference.py -q -p no:cacheprovider
$PY -c 'from offline_audit import exhaustive; exhaustive()'
$PY mutation_audit.py
$PY -m pytest legacy_contract_tests -q -p no:cacheprovider
```

O último comando DEVE devolver exit code 1, com quatro falhas de asserção conhecidas;
erro de importação ou erro de infraestrutura não é confirmação dessas falhas.
Para a integração completa com os módulos históricos, instale também o runtime:

```bash
$PY -m pip install -r requirements-legacy-runtime.txt
$PY offline_audit.py
$PY -m pytest tests -q -p no:cacheprovider --junitxml=results/reference_junit.xml
```

O script `offline_audit.py` confere as fontes selecionadas e refaz os estados a partir
das observações registadas. Pode voltar a escrever resultados derivados da auditoria;
não altera as fontes históricas. Preserve uma cópia do pacote original para comparar.

Para `grammar_audit.py`, é necessário APENAS o tokenizer do snapshot
`unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit` revisão
`216d96b52c97a3c8294776df8477592f6828981c`, disponível no cache local padrão de Hugging Face.
O script usa `local_files_only=True`, não descarrega nem carrega pesos. Pode ser omitido
na reprodução mínima; essa omissão não equivale a confirmar o resultado de gramática.

```bash
$PY grammar_audit.py
```

## Expectativas

Todos os testes da referência devem passar; a enumeração verifica 10 368 estados e
62 208 afirmações; os quatro testes históricos indicados devem falhar. As 11 mutações
não equivalentes devem produzir falhas de asserção e o controlo equivalente deve
sobreviver. Os logs distingem falhas de asserção de erros de infraestrutura.

As métricas históricas continuam históricas. `retrospective_*` são avaliações
condicionais a afirmações explícitas, não novas taxas de aprovação nem novos ensaios.
A execução original não preservou todos os tokens/prompts brutos; estes limites constam
do inventário. Não foi alegada confirmação por pessoa ou equipa externa.
