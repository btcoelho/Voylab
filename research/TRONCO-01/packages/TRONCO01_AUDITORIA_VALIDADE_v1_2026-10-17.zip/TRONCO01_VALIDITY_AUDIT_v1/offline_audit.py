"""Read-only historical audit; NEVER calls model loading or reserved generators."""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import importlib.metadata
import itertools
import json
import os
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("AUDIT_SOURCE_ROOT", str(HERE.parents[1]))).resolve()
RESULTS = HERE / "results"
EVIDENCE = HERE / "evidence"
import reference_core as ref
from fixtures import base_state, row, report, legacy_world


def dump(name, obj):
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def records(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def legacy():
    sys.path[:0] = [str(ROOT / "work/M17_DESCOBERTA_DIAGNOSTICO"), str(ROOT / "work/TRONCO01_G1"), str(ROOT / "work/TRONCO01_G2")]
    import environment, generator, run_g2
    return environment, generator, run_g2


def inventory():
    selected = []
    for folder in ["work/M17_DESCOBERTA_DIAGNOSTICO", "work/TRONCO01_G1", "work/TRONCO01_G2"]:
        base = ROOT / folder
        selected.extend(base.glob("*.py"))
        selected.extend(base.glob("*.md"))
    for folder in ["work/TRONCO01_G1/run_20261017_v02", "work/TRONCO01_G2/run_20261017_v01"]:
        selected.extend(p for p in (ROOT / folder).glob("*") if p.suffix in {".json", ".jsonl"})
    selected.extend((ROOT / "work/M17_DESCOBERTA_DIAGNOSTICO/results").glob("pilot*_v012.json"))
    selected.extend((ROOT / "work/M17_DESCOBERTA_DIAGNOSTICO/tests").glob("test_*.py"))
    for rel in ["work/M17_DESCOBERTA_DIAGNOSTICO/results/dev_controls.json", "work/M17_DESCOBERTA_DIAGNOSTICO/data/dev/manifest.json"]:
        if (ROOT / rel).exists():
            selected.append(ROOT / rel)
    # No diagnostic/confirmation dataset or truth file is read/copied.
    entries = []
    for p in sorted(set(selected)):
        rel = p.relative_to(ROOT).as_posix()
        payload = p.read_bytes()
        entries.append({"path": rel, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest(),
                        "kind": "preserved source/protocol/record; pre-inference timing not independently attested"})
        out = EVIDENCE / "original" / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists() and out.read_bytes() != payload:
            raise RuntimeError(f"refusing to overwrite evidence: {rel}")
        out.write_bytes(payload)
    request = ROOT / "TRONCO01_ORIGINAL_REQUEST.txt"
    if not request.exists():
        request = Path("/mnt/c/Users/Bruno/.codex/attachments/66bc4dae-782b-440b-9001-533f0070ff65/Texto colado.txt")
    if request.exists():
        data = request.read_bytes()
        target = EVIDENCE / "original/TRONCO01_ORIGINAL_REQUEST.txt"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        entries.append({"path": "original_user_attachment", "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
    prereg = json.loads((ROOT / "work/TRONCO01_G2/run_20261017_v01/preregistration.json").read_text())
    hashes = {e["path"]: e["sha256"] for e in entries}
    comparisons = {path: hashes.get(path) == expected for path, expected in prereg["source_sha256"].items()}
    dump("inventory.json", {"entries": entries, "g2_frozen_source_matches_now": comparisons,
        "g2_schedule_hash_matches_now": hashes["work/TRONCO01_G2/run_20261017_v01/schedule.jsonl"] == prereg["schedule_sha256"],
        "excluded": ["private/", "all M17 diagnostic/confirmation data and generators instantiated for these partitions", "model weights"],
        "missing": ["original full token ID streams", "original complete prompt text per event", "process-level immutable/timestamped evidence of the freeze", "complete software dependency lock for historic run", "explicit claim whose probability confidence denotes"],
        "derived_not_original": ["audit fixture worlds", "replayed public states", "reconstructed prompts", "independent semantic profiles", "retrospective evidence assessments"]})


def check_unchanged():
    saved = json.loads((RESULTS / "inventory.json").read_text())
    checks = {e["path"]: hashlib.sha256((ROOT / e["path"]).read_bytes()).hexdigest() == e["sha256"]
              for e in saved["entries"] if e["path"] != "original_user_attachment"}
    dump("source_preservation.json", {"all_unchanged": all(checks.values()), "checks": checks})


def exhaustive():
    # 128 public table triples x 81 partial binary histories. Expected truth is
    # indexed directly from four-entry vectors, not from reference prediction helpers.
    states = comparisons = 0
    xs = [row("x", glyph=g, phase=t)["input"] for g in ("g0", "g1") for t in ("t0", "t1")]
    for ga in itertools.product("01", repeat=2):
        for sb in "01":
            for pc in itertools.product("01", repeat=4):
                vectors = {"A": (ga[0], ga[0], ga[1], ga[1]), "B": (sb,) * 4, "C": pc}
                s = base_state()
                s["candidate_models"][0]["table"] = dict(zip(("g0", "g1"), ga))
                s["candidate_models"][1]["table"] = {"s0": sb, "s1": sb}
                s["candidate_models"][2]["table"] = dict(zip(("g0|t0", "g0|t1", "g1|t0", "g1|t1"), pc))
                for history in itertools.product((None, "0", "1"), repeat=4):
                    s["observations"] = [{"id": f"r{i}", "input": xs[i], "output": y} for i, y in enumerate(history) if y is not None]
                    want = {mid for mid, vec in vectors.items() if all(y is None or vec[i] == y for i, y in enumerate(history))}
                    assert ref.compatible_models(s["candidate_models"], s["observations"]) == want
                    states += 1
                    for card in s["candidate_models"]:
                        s["working_model"] = card
                        expected_fit = "undetermined" if not s["observations"] else ("supported" if card["id"] in want else "rejected")
                        expected_id = "undetermined" if not s["observations"] or (card["id"] in want and len(want) > 1) else expected_fit
                        assert ref.claim_verdict(s) == expected_fit
                        assert ref.claim_verdict(s, "model_identity") == expected_id
                        comparisons += 2
    dump("finite_enumeration.json", {"public_states": states, "claim_checks": comparisons, "failures": 0,
        "scope": "2 glyphs x 2 phases, binary outputs, one setting observed, 3 fixed table forms, all partial consistent histories",
        "not_proven": "arbitrary natural language hypotheses, noisy data, causal changes, unbounded domains"})


def counterexamples():
    env, gen, runner = legacy()
    found = {}
    s = base_state()
    s["observations"] += [row("b", output="1"), row("c")]
    r = report("rejected", ("a", "b"), (), "input", s["observations"][0]["input"])
    w = legacy_world(s, "CONTRADICTION")
    found["F01_minimal_conflict_certificate"] = {"state": s, "report": r, "legacy": env.score_report(w, s["observations"], r),
        "same_claim_with_redundant_id": env.score_report(w, s["observations"], {**r, "evidence_ids": ["a", "b", "c"]}), "reference_location": ref.location_support(s, r)}
    s = base_state()
    s["observations"] = [row("a"), row("b", output="1"), row("c", glyph="g1"), row("d", glyph="g1", output="1")]
    r = report("rejected", ("c", "d"), (), "input", s["observations"][2]["input"])
    w = legacy_world(s, "CONTRADICTION")
    found["F02_conflict_order"] = {"state": s, "report": r, "legacy_first_group_A": env.score_report(w, s["observations"], r),
        "legacy_first_group_B": env.score_report(w, s["observations"][2:] + s["observations"][:2], r), "reference_location": ref.location_support(s, r)}
    s = base_state()
    s["observations"] = [row("a"), row("b", phase="t1", output="1")]
    r = report("rejected", ("a", "b"), ("C",), "phase", "not-an-observed-value")
    found["F03_location_value_unchecked"] = {"state": s, "report": r,
        "legacy": env.score_report(legacy_world(s, "CHANGE", "C"), s["observations"], r), "reference_location": ref.location_support(s, r)}
    confounded = [row("a"), row("b", setting="s1", partner="p1", phase="t1", output="1")]
    found["S04_phase_association_is_not_controlled_effect"] = {"rows": confounded,
        "legacy_helper_accepts": env._has_phase_effect(confounded)[0] is not None, "controlled_witness_count": len(ref.contrasts(confounded, "phase")),
        "scope": "does not rule out model-based phase inference under an exhaustive candidate-class assumption"}
    s = base_state()
    s["observations"] = [row("a"), row("b", phase="t1", output="1"), row("c", glyph="g1"), row("d", glyph="g1", phase="t1", output="1")]
    r = report("rejected", ("c", "d"), ("C",), "phase", ["t0", "t1"])
    w = legacy_world(s, "CHANGE", "C")
    found["F05_phase_pair_order"] = {"state": s, "report": r, "legacy_first_pair_A": env.score_report(w, s["observations"], r),
        "legacy_first_pair_B": env.score_report(w, s["observations"][2:] + s["observations"][:2], r), "reference_location": ref.location_support(s, r)}
    s = base_state()
    s["candidate_models"][1]["table"] = {"s0": "0", "s1": "1"}
    s["candidate_models"][2]["table"] = dict.fromkeys(s["candidate_models"][2]["table"], "0")
    s["observations"] = [row("a"), row("b", partner="p1"), row("c", setting="s1")]
    r = report("undetermined", ("a", "b"), ("A", "B", "C"))
    found["F06_eliminated_candidate_in_accepted_diagnosis"] = {"state": s, "report": r,
        "legacy": env.score_report(legacy_world(s, "INSUFFICIENCY"), s["observations"], r),
        "reference_evidence": ref.evidence_supports(s, r, "model_identity"), "compatible": sorted(ref.compatible_models(s["candidate_models"], s["observations"]))}
    s = base_state()
    r = report()
    bad = {**r, "location": {"arbitrary": [True]}}
    found["F07_contract_location_shape"] = {"report": bad, "legacy_error": runner.contract_error(s, bad | {"explanation": "x"}),
        "reference_structural_errors": ref.structural_errors(bad)}
    # Trace-specific counterfactual twins using a previously executed development world.
    run = ROOT / "work/TRONCO01_G2/run_20261017_v01"
    item = next(x for x in records(run / "schedule.jsonl") if x["cohort"] == "sentinel" and x["category"] == "CHANGE")
    change = deepcopy(item["world"])
    normal = deepcopy(change)
    stable = next(c for c in normal["cards"] if c["id"] == normal["working_model_id"])
    normal["category"] = "NORMAL"
    normal["hidden"] = {"kind": "card", "card": deepcopy(stable)}
    assert change["public"] == normal["public"]
    assert gen.audit_world(change)["identified"] and gen.audit_world(normal)["identified"]
    # Select three queries where both explicit deterministic interpretations agree.
    common = [q for q in change["public"]["query_menu"] if gen._hidden_predict(change["hidden"], q["input"]) == gen._hidden_predict(normal["hidden"], q["input"])]
    one, two = env.Episode(change), env.Episode(normal)
    for q in common[:3]:
        action = {"action": "query", "query_id": q["id"]}
        assert one.apply(action) == two.apply(action)
    assert one.remaining == two.remaining == 0 and one.state() == two.state()
    state = one.state()
    r = report("supported", [x["id"] for x in state["observations"]], (stable["id"],))
    found["S08_public_identical_hidden_expected_differs"] = {
        "origin": "counterfactual twin of a recorded G2 CHANGE sentinel; not a separately sampled generator seed pair",
        "both_initial_world_audits_pass": True, "public_states_equal_after_budget_exhaustion": True,
        "shared_query_ids": [q["id"] for q in common[:3]], "state": state,
        "legacy_expected_normal": env.score_report(normal, two.observations, r),
        "legacy_expected_change": env.score_report(change, one.observations, r), "public_reference": ref.profile(state),
        "distinction": "initially there were discriminating queries; these particular actions left the truth unresolved. Acquisition quality and warranted final judgment must be scored separately."}
    dump("counterexamples.json", found)
    dump("calibration_counterexample.json", {"forced_failure_without_explicit_report": runner.summarize([{
        "category": "NORMAL", "confidence": 0.0, "decision_correct": False, "diagnosis_correct": False,
        "localized_correct": False, "verdict": "undetermined", "forced_termination": True,
        "query_count": 0, "redundant_queries": 0, "expected_information_gain": [], "actual_information_gain": [],
        "invalid_actions": 1, "action_count": 1}])["calibration"],
        "interpretation": "M17 unfiltered summary gives zero error despite no forecast. G2 summarize_explicit already filters these; confidence target remains unspecified."})


def historical_reanalysis():
    env, _, runner = legacy()
    from action_utils import first_json_object
    results = []
    raw_failures = []
    summaries = {}
    for stage, folder in [("G1v02", "work/TRONCO01_G1/run_20261017_v02"), ("G2", "work/TRONCO01_G2/run_20261017_v01")]:
        directory = ROOT / folder
        schedule = {x["episode_id"]: x for x in records(directory / "schedule.jsonl")}
        episodes = records(directory / "episodes.jsonl")
        events = records(directory / "actions.jsonl")
        actions_by_episode = defaultdict(list)
        for a in events:
            actions_by_episode[(a["condition"], a["episode_id"])].append(a)
        grouped = defaultdict(Counter)
        replay_errors = []
        for e in episodes:
            w = schedule[e["episode_id"]]["world"]
            ep = env.Episode(w)
            logs = sorted(actions_by_episode[e["condition"], e["episode_id"]], key=lambda x: x["step"])
            for a in logs:
                if a["accepted"] and a["action"].get("action") == "query":
                    response = ep.apply(a["action"])
                    if response != a["environment_response"]:
                        replay_errors.append([e["condition"], e["episode_id"], a["step"]])
            state = ep.state()
            fact = ref.profile(state)
            r = e["report"]
            c = grouped[e["condition"]]
            c["episodes"] += 1
            c["explicit"] += bool(e["explicit_report"])
            c["operational_failures_historical"] += bool(e["operational_failure"])
            c["historic_decisions"] += bool(e["decision_correct"])
            c["historic_diagnoses"] += bool(e["diagnosis_correct"])
            for a in logs:
                c["actions"] += 1
                if isinstance(a.get("raw"), str):
                    try:
                        parsed = ref.decode_action(a["raw"])
                        raw_ok = True
                    except (ValueError, json.JSONDecodeError) as exc:
                        raw_ok = False
                        raw_failures.append({"stage": stage, "condition": a["condition"], "episode_id": a["episode_id"],
                            "step": a["step"], "accepted_historically": a["accepted"], "reason": str(exc),
                            "original_strict_json_flag": a["strict_json"], "raw_sha256": hashlib.sha256(a["raw"].encode()).hexdigest()})
                    c["strict_raw_json"] += raw_ok
                    c["accepted_despite_strict_raw_failure"] += a["accepted"] and not raw_ok
                    c["parser_fallback_salvaged_object"] += not a["strict_json"] and first_json_object(a["raw"]) is not None
            entry = {"stage": stage, "episode_id": e["episode_id"], "condition": e["condition"], "world_id": e["world_id"],
                "category_for_legacy_comparison_only": e["category"], "historic_decision": e["decision_correct"],
                "historic_diagnosis": e["diagnosis_correct"], "public_profile": fact, "report": r,
                "retrospective_not_a_new_model_trial": True}
            if r is not None:
                old = env.score_report(w, ep.observations, r)
                c["legacy_score_replayed_exact"] += all(old[k] == e[k] for k in old)
                entry["legacy_score_replayed"] = old
                permutations = [list(reversed(ep.observations)), sorted(ep.observations, key=lambda x: x["id"])]
                sensitive = any(env.score_report(w, perm, r) != old for perm in permutations)
                entry["legacy_score_order_sensitive_on_two_probes"] = sensitive
                c["legacy_score_order_sensitive_on_two_probes"] += sensitive
                c["legacy_localized_with_value_not_observed"] += bool(old["localized_correct"] and r.get("location", {}).get("feature") in ref.FIELDS and
                    not any(v == o["input"][r["location"]["feature"]] for o in ep.observations for v in
                        (r["location"].get("value") if isinstance(r["location"].get("value"), list) else [r["location"].get("value")])))
                entry["reference_structural_legal_errors"] = ref.legal_errors(state, {"action": "report", **r})
                for mode in ("observed_fit", "model_identity"):
                    match = r["verdict"] == ref.claim_verdict(state, mode)
                    grounded = ref.evidence_supports(state, r, mode)
                    c[f"{mode}_verdict_match_explicit"] += match
                    c[f"{mode}_evidence_supported_explicit"] += grounded
                    entry[mode] = {"verdict_match": match, "evidence_supported": grounded}
                loc = ref.location_support(state, r)
                entry["reference_direct_location"] = loc
                c["direct_location_not_valid_under_reference"] += loc is False
                c["location_omitted_or_null"] += not r.get("location") or r.get("location", {}).get("feature", "missing") is None
            results.append(entry)
        summaries[stage] = {"conditions": {k: dict(v) for k, v in grouped.items()}, "recorded_query_replay_errors": replay_errors,
            "interpretation": "sensitivity to declared claim; these counts are retrospective, not replacements for historic scores or approval rates"}
    dump("retrospective_episode_profiles.json", results)
    dump("retrospective_summary.json", summaries)
    dump("raw_decode_findings.json", raw_failures)


def main():
    inventory()
    exhaustive()
    counterexamples()
    historical_reanalysis()
    check_unchanged()
    versions = {}
    for p in ("pytest", "hypothesis", "jsonschema", "lm-format-enforcer", "transformers", "torch"):
        try:
            versions[p] = importlib.metadata.version(p)
        except importlib.metadata.PackageNotFoundError:
            versions[p] = None
    dump("environment.json", {"python": sys.version, "packages": versions, "model_weights_loaded": False,
        "historical_interpreter_not_claimed_identical": True})
    print(json.dumps({"status": "offline_audit_complete", "results": str(RESULTS)}))


if __name__ == "__main__":
    main()
