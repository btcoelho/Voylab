"""Verify reproduction from copied evidence, without live workspace sources."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent


def main():
    results = []
    with tempfile.TemporaryDirectory(prefix="tronco01-audit-replay-") as tmp:
        target = Path(tmp)
        for p in HERE.glob("*.py"):
            shutil.copy2(p, target / p.name)
        for folder in ("tests", "legacy_contract_tests", "evidence"):
            shutil.copytree(HERE / folder, target / folder, ignore=shutil.ignore_patterns("__pycache__"))
        env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "AUDIT_SOURCE_ROOT": str(target / "evidence/original")}
        commands = [
            ([sys.executable, "offline_audit.py"], 0),
            ([sys.executable, "-m", "pytest", "tests", "-q", "-p", "no:cacheprovider"], 0),
            ([sys.executable, "-m", "pytest", "legacy_contract_tests", "-q", "-p", "no:cacheprovider"], 1),
            ([sys.executable, "grammar_audit.py"], 0),
        ]
        for args, expected in commands:
            p = subprocess.run(args, cwd=target, env=env, text=True, capture_output=True)
            results.append({"command": args[1:], "returncode": p.returncode, "expected_returncode": expected,
                            "stdout": p.stdout, "stderr": p.stderr})
            if p.returncode != expected:
                break
    out = {"all_expected": len(results) == len(commands) and all(x["returncode"] == x["expected_returncode"] for x in results),
           "meaning": "fresh directory with copied evidence; same machine/operator, not independent external replication", "runs": results}
    (HERE / "results/portable_replay.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({"all_expected": out["all_expected"], "runs": len(results)}))


if __name__ == "__main__":
    main()
