"""Tokenizer-only grammar and prompt replay of executed G2 development traces."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("AUDIT_SOURCE_ROOT", str(HERE.parents[1]))).resolve()
sys.path[:0] = [str(ROOT / "work/M17_DESCOBERTA_DIAGNOSTICO"), str(ROOT / "work/TRONCO01_G1"), str(ROOT / "work/TRONCO01_G2")]
import reference_core as ref
import run_g2
from preflight_g1 import state_parser
import torch
import transformers
import transformers.tokenization_utils as tokenization_utils
tokenization_utils.PreTrainedTokenizerBase = transformers.PreTrainedTokenizerBase
from lmformatenforcer.integrations.transformers import build_transformers_prefix_allowed_tokens_fn, build_token_enforcer_tokenizer_data
from transformers import AutoTokenizer


def jsonl(path):
    return [json.loads(x) for x in path.read_text().splitlines() if x]


def main():
    model_path = Path.home() / ".cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"
    tokenizer = AutoTokenizer.from_pretrained(str(model_path), local_files_only=True)
    token_data = build_token_enforcer_tokenizer_data(tokenizer)
    directory = ROOT / "work/TRONCO01_G2/run_20261017_v01"
    events = jsonl(directory / "actions.jsonl")
    schedule = {x["episode_id"]: x for x in jsonl(directory / "schedule.jsonl") if x["cohort"] == "sentinel"}
    states = {}
    prompt_replays = []
    bridge_states = []
    for event in events:
        condition, eid = event["condition"], event["episode_id"]
        if not condition.startswith("base_"):
            continue
        key = (condition, eid)
        if key not in states:
            states[key] = deepcopy(schedule[eid]["world"]["public"])
        state = states[key]
        prompt = run_g2.prompt_for(tokenizer, state, condition)
        prompt_replays.append({"condition": condition, "episode_id": eid, "step": event["step"],
            "hash_match": hashlib.sha256(prompt.encode()).hexdigest() == event["prompt_sha256"],
            "input_count_match": len(tokenizer(prompt)["input_ids"]) == event["input_tokens"],
            "reconstructed_not_original_prompt": True})
        if condition == "base_g1_bridge":
            bridge_states.append((eid, deepcopy(state)))
        if event["accepted"] and event["action"]["action"] == "query":
            state["observations"].append(deepcopy(event["environment_response"]["observation"]))
            state["query_menu"] = [q for q in state["query_menu"] if q["id"] != event["action"]["query_id"]]
            state["remaining_query_budget"] -= 1

    def reachable(state, text):
        prompt_ids = tokenizer.encode(run_g2.prompt_for(tokenizer, state, "base_g2_schema"), add_special_tokens=False)
        callback = build_transformers_prefix_allowed_tokens_fn(token_data, state_parser(state))
        prefix = []
        for token in tokenizer.encode(text, add_special_tokens=False):
            if token not in callback(0, torch.tensor(prompt_ids + prefix, dtype=torch.long)):
                return {"path": False, "eos": False}
            prefix.append(token)
        return {"path": True, "eos": tokenizer.eos_token_id in callback(0, torch.tensor(prompt_ids + prefix, dtype=torch.long))}

    counts = {"states": len(bridge_states), "legal_query_paths": 0, "legal_query_eos": 0, "blocked_query_after_budget": 0}
    for eid, state in bridge_states:
        if state["remaining_query_budget"]:
            for query in state["query_menu"]:
                result = reachable(state, json.dumps({"action": "query", "query_id": query["id"]}, separators=(",", ":")))
                counts["legal_query_paths"] += result["path"]
                counts["legal_query_eos"] += result["eos"]
                assert result["path"] and result["eos"]
        else:
            result = reachable(state, json.dumps({"action": "query", "query_id": state["query_menu"][0]["id"]}, separators=(",", ":")))
            counts["blocked_query_after_budget"] += not result["path"]
            assert not result["path"]
    state = bridge_states[0][1]
    base = {"action": "report", "verdict": "supported", "candidate_model_codes": [], "evidence_ids": [],
            "location": {"feature": None, "value": None}, "confidence": 0.5, "explanation": "audit fixture"}
    cases = {
        "canonical_shape_wrong_answer_still_legal": base,
        "location_missing_required_fields": {**base, "location": {}},
        "location_arbitrary_extra_fields": {**base, "location": {"feature": "input", "unrelated": [1, 2]}},
        "invented_evidence": {**base, "evidence_ids": ["invented"]},
        "extra_outer_field": {**base, "outer_extra": True},
        "unknown_query": {"action": "query", "query_id": "invented"},
    }
    probes = []
    for name, action in cases.items():
        text = json.dumps(action, separators=(",", ":"))
        probes.append({"case": name, "grammar": reachable(state, text), "legacy_contract_error": run_g2.contract_error(state, action),
                       "reference_structural_legal_errors": ref.legal_errors(state, action)})
    duplicate = json.dumps(base, separators=(",", ":")).replace('"location":{"feature":null,"value":null}', '"location":{"site":"a","site":"b"}')
    rejected = False
    try:
        ref.decode_action(duplicate)
    except ValueError:
        rejected = True
    probes.append({"case": "duplicate_nested_keys", "grammar": reachable(state, duplicate),
                   "legacy_json_loads_accepts": isinstance(json.loads(duplicate), dict), "reference_rejects": rejected})
    # Historical preflight was path-only: a prefix can be reachable without EOS.
    prefix = reachable(state, '{"action":')
    result = {"weights_loaded": False, "tokenizer_snapshot": model_path.name,
              "prompt_replays": prompt_replays, "all_prompt_hashes_match": all(x["hash_match"] for x in prompt_replays),
              "all_input_counts_match": all(x["input_count_match"] for x in prompt_replays),
              "query_checks": counts, "contract_probes": probes,
              "reachable_incomplete_prefix": prefix,
              "interpretation": "Tokenizer-only reconstruction; validates current pinned tokenizer and preserved traces, not historical execution timing."}
    (HERE / "results/grammar_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k not in {"prompt_replays", "contract_probes"}}))


if __name__ == "__main__":
    main()
