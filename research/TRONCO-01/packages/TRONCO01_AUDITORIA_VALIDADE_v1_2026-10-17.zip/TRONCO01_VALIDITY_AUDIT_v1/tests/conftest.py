import importlib.util
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
path = Path(os.environ.get("AUDIT_REFERENCE_PATH", str(ROOT / "reference_core.py")))
spec = importlib.util.spec_from_file_location("audit_reference", path)
ref = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ref)


def pytest_configure(config):
    config.audit_reference = ref
