from copy import deepcopy
import itertools
import json
import pytest
from hypothesis import given, settings, strategies as st
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant
from conftest import ref
from fixtures import base_state, row, report


def test_hand_calculated_claims_and_target_domain():
    s = base_state()
    assert ref.compatible_models(s["candidate_models"], s["observations"]) == {"A", "C"}
    assert ref.claim_verdict(s, "observed_fit") == "supported"
    assert ref.claim_verdict(s, "model_identity") == "undetermined"
    assert ref.claim_verdict(s, "target_prediction", [s["observations"][0]["input"]]) == "supported"
    assert ref.claim_verdict(s, "target_prediction", [s["query_menu"][-1]["input"]]) == "undetermined"
    with pytest.raises(ValueError):
        ref.claim_verdict(s, "target_prediction")
    s["observations"].append(row("b", phase="t1", output="1"))
    assert ref.compatible_models(s["candidate_models"], s["observations"]) == {"C"}
    assert ref.claim_verdict(s) == "rejected"


def test_all_rows_not_only_first_are_used():
    s = base_state()
    s["observations"].append(row("b", output="1"))
    assert ref.compatible_models(s["candidate_models"], s["observations"]) == set()


def test_any_sufficient_contradictory_pair_with_redundancy():
    s = base_state()
    s["observations"] += [row("b", output="1"), row("c")]
    r = report("rejected", ("a", "b"), (), "input", s["observations"][0]["input"])
    assert ref.location_support(s, r) is True
    assert ref.evidence_supports(s, r)
    assert {frozenset((a["id"], b["id"])) for a, b in ref.conflict_pairs(s["observations"])} == {frozenset(("a", "b")), frozenset(("b", "c"))}


def test_duplicate_consistent_rows_are_not_conflicts():
    assert ref.conflict_pairs([row("a"), row("b")]) == []


def test_controlled_contrast_not_confounded():
    a = row("a")
    b = row("b", phase="t1", output="1")
    c = row("c", phase="t1", setting="s1", partner="p1", output="1")
    assert len(ref.contrasts([a, b], "phase")) == 1
    assert ref.contrasts([a, c], "phase") == []
    s = base_state()
    s["observations"] = [a, b]
    assert ref.location_support(s, report("rejected", ("a", "b"), ("C",), "phase", "invented")) is False
    assert ref.location_support(s, report("rejected", ("a", "b"), ("C",), "phase", ["t0", "t1"])) is True


def test_empty_or_false_evidence_and_unsupported_declarations():
    s = base_state()
    assert ref.legal_errors(s, report(evidence=())) == []  # legal error is not scientific error
    assert not ref.evidence_supports(s, report(evidence=()))
    assert not ref.evidence_supports(s, report(candidates=("B",)))
    assert ref.evidence_supports(s, report("undetermined", candidates=("A", "C")), "model_identity")
    assert not ref.evidence_supports(s, report("undetermined", candidates=("A",)), "model_identity")


@pytest.mark.parametrize("raw", ["{} tail", "prefix {}", "{}{}", '{"action":"query","action":"report"}', '{"confidence":NaN}', '{"confidence":Infinity}', '{"confidence":1e999}', '[]', '{"action":'])
def test_strict_parser_rejects(raw):
    with pytest.raises((ValueError, json.JSONDecodeError)):
        ref.decode_action(raw)


def test_parser_valid_and_schema_legal_semantic_false():
    s = base_state()
    a = report("rejected", evidence=(), candidates=())
    assert ref.decode_action(" \n" + json.dumps(a) + "\n ") == a
    assert ref.legal_errors(s, a) == []
    assert not ref.evidence_supports(s, a)
    assert ref.structural_errors({**a, "extra": True})
    assert ref.legal_errors(s, report(evidence=("invented",)))
    assert ref.legal_errors(s, report(candidates=("invented",)))
    assert ref.structural_errors(report(evidence=("a", "a")))
    assert ref.structural_errors({**a, "confidence": True})
    assert ref.structural_errors({**a, "confidence": float("nan")})
    assert ref.structural_errors({**a, "confidence": float("inf")})


@given(st.permutations([0, 1, 2, 3]))
@settings(max_examples=24, deadline=None, derandomize=True)
def test_observation_order_invariance(order):
    s = base_state()
    s["observations"] = [row("a"), row("b", output="1"), row("c", glyph="g1"), row("d", glyph="g1", output="1")]
    r = report("rejected", ("c", "d"), (), "input", s["observations"][2]["input"])
    expected = ref.profile(s)
    s["observations"] = [s["observations"][i] for i in order]
    assert ref.profile(s) == expected
    assert ref.location_support(s, r) is True


@given(st.lists(st.integers(0, 1), min_size=1, max_size=12))
@settings(max_examples=80, deadline=None, derandomize=True)
def test_duplicate_record_does_not_change_inference(outputs):
    s = base_state()
    s["observations"] = [row(f"r{i}", output=str(v)) for i, v in enumerate(outputs)]
    before = ref.compatible_models(s["candidate_models"], s["observations"])
    s["observations"].append({**deepcopy(s["observations"][0]), "id": "duplicate"})
    assert ref.compatible_models(s["candidate_models"], s["observations"]) == before


@given(st.integers(0, 100000))
@settings(max_examples=40, deadline=None, derandomize=True)
def test_id_renaming(seed):
    s = base_state()
    old = ref.claim_verdict(s, "model_identity")
    idmap = {c["id"]: f"x{seed}_{i}" for i, c in enumerate(s["candidate_models"])}
    for c in s["candidate_models"]:
        c["id"] = idmap[c["id"]]
    s["working_model"]["id"] = idmap[s["working_model"]["id"]]
    assert ref.claim_verdict(s, "model_identity") == old


def test_every_model_and_evidence_row_id_can_be_permuted():
    s = base_state()
    for cards in itertools.permutations(s["candidate_models"]):
        trial = {**s, "candidate_models": list(cards)}
        assert ref.claim_verdict(trial, "model_identity") == "undetermined"


def test_query_budget_repeat_invalid_and_terminal_deterministically():
    p = ref.PublicEpisode(base_state(), lambda x: "0")
    for i in range(3):
        assert p.apply({"action": "query", "query_id": f"q{i}"})["accepted"]
        snap = p.state()
        assert not p.apply({"action": "query", "query_id": f"q{i}"})["accepted"]
        assert p.state() == snap
    assert p.state()["remaining_query_budget"] == 0
    assert not p.apply({"action": "query", "query_id": "q4"})["accepted"]
    assert p.apply(report(evidence=()))["accepted"]
    with pytest.raises(RuntimeError):
        p.apply(report())


def test_hidden_labels_cannot_affect_reference_claims():
    s = base_state()
    expected = ref.profile(s)
    for label in ("NORMAL", "CHANGE", "INSUFFICIENCY", "CONTRADICTION"):
        assert ref.profile({**s, "category": label}) == expected


@given(st.integers(1, 100000))
@settings(max_examples=40, deadline=None, derandomize=True)
def test_bijective_renaming_of_observation_and_query_ids(salt):
    s = base_state()
    r = report("undetermined", candidates=("A", "C"))
    before = ref.evidence_supports(s, r, "model_identity")
    s["observations"][0]["id"] = f"observation_{salt}"
    r["evidence_ids"] = [s["observations"][0]["id"]]
    for index, q in enumerate(s["query_menu"]):
        q["id"] = f"measurement_{salt}_{index}"
    assert ref.evidence_supports(s, r, "model_identity") == before
    assert not ref.legal_errors(s, {"action": "query", "query_id": s["query_menu"][0]["id"]})


class PortMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.port = ref.PublicEpisode(base_state(), lambda x: "0")
        self.original_budget = 3
        self.used = set()

    @rule(index=st.integers(0, 8))
    def query(self, index):
        if self.port.terminal:
            with pytest.raises(RuntimeError):
                self.port.apply({"action": "query", "query_id": f"q{index}"})
            return
        before = self.port.state()
        qid = f"q{index}"
        available = qid in {q["id"] for q in before["query_menu"]}
        expected = before["remaining_query_budget"] > 0 and available
        result = self.port.apply({"action": "query", "query_id": qid})
        assert result["accepted"] is expected
        if expected:
            self.used.add(qid)
        else:
            assert self.port.state() == before

    @rule()
    def finish(self):
        if not self.port.terminal:
            assert self.port.apply(report(evidence=()))["accepted"]
            assert self.port.terminal

    @invariant()
    def budgets_and_ids(self):
        state = self.port.state()
        assert state["remaining_query_budget"] == self.original_budget - len(self.used)
        assert state["remaining_query_budget"] >= 0
        assert not self.used.intersection(q["id"] for q in state["query_menu"])
        ids = [r["id"] for r in state["observations"]]
        assert len(ids) == len(set(ids))


TestPortMachine = PortMachine.TestCase
TestPortMachine.settings = settings(max_examples=50, stateful_step_count=20, deadline=None, derandomize=True)
