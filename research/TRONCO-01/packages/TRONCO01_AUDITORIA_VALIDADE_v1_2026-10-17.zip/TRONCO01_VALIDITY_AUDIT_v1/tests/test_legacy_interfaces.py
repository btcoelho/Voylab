"""Integrations use preserved modules as the implementation under observation.

The independent oracle does not import these modules. No model loader is called.
"""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import sys
import os
import pytest
from hypothesis import given, settings, strategies as st
from conftest import ref
from fixtures import base_state, legacy_world, report

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parents[1]
SOURCE_ROOT = Path(os.environ.get("AUDIT_SOURCE_ROOT", str(HERE.parents[1])))
sys.path[:0] = [str(SOURCE_ROOT / f"work/{p}") for p in ("M17_DESCOBERTA_DIAGNOSTICO", "TRONCO01_G1", "TRONCO01_G2")]
import environment as old
import run_g2 as g2


@given(st.lists(st.integers(0, 6), min_size=1, max_size=15))
@settings(max_examples=80, deadline=None, derandomize=True)
def test_healthy_legacy_query_transitions_against_reference(indices):
    s = base_state()
    a = old.Episode(legacy_world(s))
    b = ref.PublicEpisode(s, lambda inp: "0")
    for index in indices:
        action = {"action": "query", "query_id": f"q{index}"}
        assert a.apply(action)["accepted"] == b.apply(action)["accepted"]
        assert a.state() == b.state()
    payload = report(evidence=())
    assert a.apply(payload)["accepted"] == b.apply(payload)["accepted"]
    with pytest.raises(RuntimeError):
        a.apply(payload)
    with pytest.raises(RuntimeError):
        b.apply(payload)
    assert old.Episode(legacy_world(s)).remaining == 3


def test_actual_driver_fallback_accepts_trailing_prose_without_weights():
    import torch
    raw = '{"action":"query","query_id":"q0"} trailing prose'
    class Tokenizer:
        eos_token_id = 0
        pad_token_id = 0
        def apply_chat_template(self, *args, **kwargs):
            return "stub prompt"
        def __call__(self, *args, **kwargs):
            return {"input_ids": torch.tensor([[8]])}
        def decode(self, *args, **kwargs):
            return raw
    class FakeModel:
        device = "cpu"
        def generate(self, **kwargs):
            return SimpleNamespace(sequences=torch.tensor([[8, 9, 0]]))
    driver = g2.ModelDriver.__new__(g2.ModelDriver)
    driver.model, driver.tokenizer = FakeModel(), Tokenizer()
    result = driver.act(base_state(), "base_g2_free")
    assert result["parse_success"] and not result["strict_json"]
    assert g2.contract_error(base_state(), result["action"]) is None
    with pytest.raises(ValueError):
        ref.decode_action(raw)


def test_logging_order_can_lose_already_returned_raw_on_unhandled_exit(monkeypatch, tmp_path):
    s = base_state()
    payload = {**report(), "explanation": "audit fixture"}
    def crash(self, action):
        raise SystemExit("controlled exit at environment boundary")
    monkeypatch.setattr(g2.Episode, "apply", crash)
    event_file = tmp_path / "events.jsonl"
    meta = {"action": payload, "raw": "already returned raw text", "parse_success": True,
            "strict_json": True, "hit_limit": False}
    item = {"world": legacy_world(s), "episode_id": "toy", "cohort": "audit"}
    with pytest.raises(SystemExit):
        g2.run_episode(item, "base_g2_schema", lambda state: meta, event_file)
    assert not event_file.exists()
