"""Targeted, explicit mutation experiment on audit reference copies only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
DEST = HERE / "results/mutations"
SOURCE = (HERE / "reference_core.py").read_text(encoding="utf-8")
MUTANTS = [
    ("all_rows_to_any", 'return all(evaluate(card, r["input"]) == r["output"] for r in rows)',
     'return any(evaluate(card, r["input"]) == r["output"] for r in rows)', False),
    ("inverted_conflict", 'if xkey(a["input"]) == xkey(b["input"]) and a["output"] != b["output"]:',
     'if xkey(a["input"]) == xkey(b["input"]) and a["output"] == b["output"]:', False),
    ("confounded_contrast", 'if any(a["input"][other] != b["input"][other] for other in FIELDS if other != field):', 'if False:', False),
    ("accept_trailing_json_text", 'if end != len(stripped):', 'if False:', False),
    ("accept_unobserved_evidence_id", 'if not set(action["evidence_ids"]).issubset({r["id"] for r in state["observations"]}):', 'if False:', False),
    ("accept_empty_support", 'if not evidence:  # MUTATION: empty evidence', 'if False:  # intentionally invalid empty-evidence mutant', False),
    ("do_not_eliminate_models", 'for c in cards if fits(c, rows)', 'for c in cards if True', False),
    ("identify_ambiguous_model", 'return "supported" if len(candidates) == 1 else "undetermined"', 'return "supported" if len(candidates) >= 1 else "undetermined"', False),
    ("allow_fourth_query", 'if state["remaining_query_budget"] <= 0:', 'if state["remaining_query_budget"] < 0:', False),
    ("allow_query_reuse", 'self.current["query_menu"].remove(query)', 'pass  # keep query illegally available', False),
    ("ignore_location_value", 'bool(values) and set(values).issubset({a["input"][feature], b["input"][feature]})', 'bool(values)', False),
    ("equivalent_list_empty_check", 'if len(rows) == 0:  # equivalent mutation uses \'if not rows\'', 'if not rows:  # equivalent for the specified list domain', True),
]


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    output = []
    for name, old, new, equivalent in MUTANTS:
        if SOURCE.count(old) != 1:
            raise AssertionError(f"mutation must have exactly one target: {name}, found {SOURCE.count(old)}")
        code = SOURCE.replace(old, new, 1)
        candidate = DEST / f"{name}.py"
        candidate.write_text(code, encoding="utf-8")
        xml = DEST / f"{name}.xml"
        env = {**os.environ, "AUDIT_REFERENCE_PATH": str(candidate), "PYTHONDONTWRITEBYTECODE": "1"}
        process = subprocess.run([sys.executable, "-m", "pytest", "tests/test_reference.py", "-q", "-p", "no:cacheprovider", f"--junitxml={xml}"],
                                 cwd=HERE, env=env, capture_output=True, text=True)
        (DEST / f"{name}.log").write_text(process.stdout + process.stderr, encoding="utf-8")
        tree = ET.parse(xml).getroot()
        suites = list(tree) if tree.tag == "testsuites" else [tree]
        failures = sum(int(x.get("failures", 0)) for x in suites)
        errors = sum(int(x.get("errors", 0)) for x in suites)
        result = "killed_by_assertion" if failures and not errors else ("survived" if process.returncode == 0 else "invalid_or_infrastructure_error")
        output.append({"name": name, "old": old, "new": new, "equivalent_control": equivalent,
                       "source_sha256": hashlib.sha256(code.encode()).hexdigest(), "result": result,
                       "failures": failures, "errors": errors, "returncode": process.returncode})
    result = {"method": "12 transparent targeted mutations, not an exhaustive automatic mutation campaign",
              "non_equivalent_killed": sum(x["result"] == "killed_by_assertion" and not x["equivalent_control"] for x in output),
              "non_equivalent_count": sum(not x["equivalent_control"] for x in output),
              "mutants": output,
              "interpretation": "Equivalent survivor is expected: lists satisfy len(rows)==0 iff not rows. Passing this panel is not universal correctness."}
    (HERE / "results/mutation_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "mutants"}))


if __name__ == "__main__":
    main()
