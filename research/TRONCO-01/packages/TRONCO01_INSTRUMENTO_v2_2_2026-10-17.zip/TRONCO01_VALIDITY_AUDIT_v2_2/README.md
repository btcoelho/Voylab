# TRONCO-01 v2.2 — preflight sem inferência

Esta versão corrige dois defeitos operacionais encontrados na revisão de v2.1: um gate com falha já não deixa um PASS antigo como estado atual, e um episódio terminado é rejeitado antes de verificar o congelamento ou chamar o gerador.

## Execução

Requer Python 3.12 e as dependências em `requirements.txt`. Execute `freeze_sources.py` uma vez após rever os ficheiros; depois execute `preflight.py`. O gate grava RUNNING no início e publica atomicamente PASS ou FAIL no mesmo JSON. A identidade de cada execução fica em `run_id`.

O gate executa pytest, enumeração finita, mutações direcionadas, verificação do tokenizer local, reanálise histórica e valida hashes no início e no fim. O teste de gramática usa o tokenizer Qwen2.5 local já em cache e LM Format Enforcer, sem carregar pesos. Verifica tokens das ações válidas, EOS depois da ação completa e bloqueio de ações malformadas.

`PASS_FOR_PREMODEL_REVIEW` indica que estes controlos locais passaram. A análise humana continua obrigatória antes de qualquer nova inferência. G1/G2 permanecem resultados históricos e a sua reanálise usa os critérios v2.2 retrospectivamente.
