"""Exercise the frozen action grammar against the locally cached Qwen tokenizer; no weights."""
from __future__ import annotations
import json
import os
from pathlib import Path
import sys
from transformers import AutoTokenizer, PreTrainedTokenizerBase
import transformers.tokenization_utils as tokenization_utils
import torch

# Compatibility bridge for the installed Transformers/LM Format Enforcer versions.
tokenization_utils.PreTrainedTokenizerBase = PreTrainedTokenizerBase
from lmformatenforcer import JsonSchemaParser
from lmformatenforcer.characterlevelparser import UnionParser
from lmformatenforcer.integrations.transformers import build_transformers_prefix_allowed_tokens_fn

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import instrument

TOKENIZER_PATH = Path(os.environ.get("TRONCO_TOKENIZER_PATH", "/home/bcoelho/.cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"))
PROMPT = "Escolhe uma ação JSON.\n"

def sample_state():
    return {"candidate_models": [], "working_model": None, "observations": [], "query_menu": [], "remaining_query_budget": 0}

def main():
    if not TOKENIZER_PATH.is_dir():
        raise FileNotFoundError(f"Tokenizer local não encontrado: {TOKENIZER_PATH}")
    tokenizer = AutoTokenizer.from_pretrained(str(TOKENIZER_PATH), local_files_only=True)
    parser = UnionParser([JsonSchemaParser(branch) for branch in instrument.ACTION_SCHEMA["oneOf"]])
    allowed = build_transformers_prefix_allowed_tokens_fn(tokenizer, parser)
    prompt_ids = tokenizer(PROMPT, add_special_tokens=False)["input_ids"]
    state = sample_state()
    query = json.dumps({"action": "query", "query_id": "q0"}, separators=(",", ":"))
    report = {"action": "report", "verdict": "rejected", "diagnosis": "none_fit", "sufficiency": "no_candidate_fits",
              "candidate_model_codes": [], "evidence_ids": [], "location": {"feature": "none", "values": []}}
    valid = {"query": query, "wrong_but_structural_report": json.dumps(report, separators=(",", ":"))}
    malformed = {
        "extra_field": '{"action":"query","query_id":"q0","extra":1}',
        "wrong_type": '{"action":"query","query_id":42}',
        "incomplete": '{"action":"query"}',
    }
    traces = {}
    for name, text in {**valid, **malformed}.items():
        generated = tokenizer(text, add_special_tokens=False)["input_ids"]
        ids = list(prompt_ids)
        steps = []
        for token_id in generated:
            choices = allowed(0, torch.tensor(ids, dtype=torch.long))
            steps.append(token_id in choices)
            if token_id not in choices:
                break
            ids.append(token_id)
        eos = tokenizer.eos_token_id
        eos_allowed = eos is not None and eos in allowed(0, torch.tensor(ids, dtype=torch.long))
        traces[name] = {"token_count": len(generated), "all_tokens_allowed": len(steps) == len(generated) and all(steps),
                        "eos_token_id": eos, "eos_allowed_after_complete_action": eos_allowed,
                        "expected_valid": name in valid}
    result = {"parser": "LMFE Transformer prefix callback + local cached tokenizer",
              "tokenizer_path": str(TOKENIZER_PATH), "tokenizer_name_or_path": tokenizer.name_or_path,
              "tokenizer_vocab_size": len(tokenizer), "weights_loaded": False, "model_inference": False,
              "cases": traces,
              "all_valid_paths_reach_eos": all(traces[name]["all_tokens_allowed"] and traces[name]["eos_allowed_after_complete_action"] for name in valid),
              "all_malformed_paths_blocked": all(not traces[name]["all_tokens_allowed"] or not traces[name]["eos_allowed_after_complete_action"] for name in malformed)}
    if not (result["all_valid_paths_reach_eos"] and result["all_malformed_paths_blocked"]):
        raise AssertionError(json.dumps(result, indent=2))
    out = HERE / "results"
    out.mkdir(exist_ok=True)
    (out / "grammar_preflight_v2_2.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
