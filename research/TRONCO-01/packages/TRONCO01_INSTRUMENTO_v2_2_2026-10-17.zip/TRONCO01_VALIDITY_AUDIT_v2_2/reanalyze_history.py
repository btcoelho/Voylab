"""Retrospective, component-wise replay of G1/G2 under the v2.1 contract."""
from __future__ import annotations
from collections import defaultdict
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SOURCE_ROOT = Path(os.environ.get("AUDIT_SOURCE_ROOT", str(HERE / "evidence/original"))).resolve()
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(SOURCE_ROOT / "work/M17_DESCOBERTA_DIAGNOSTICO"))
import environment
import instrument

def records(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]

def main():
    stages = [("G1v02", "work/TRONCO01_G1/run_20261017_v02"),
              ("G2", "work/TRONCO01_G2/run_20261017_v01")]
    episodes_out = []
    grouped = defaultdict(lambda: defaultdict(int))
    for stage, folder in stages:
        directory = SOURCE_ROOT / folder
        schedule = {row["episode_id"]: row for row in records(directory / "schedule.jsonl")}
        events = records(directory / "actions.jsonl")
        event_map = defaultdict(list)
        for event in events:
            event_map[(event["condition"], event["episode_id"])].append(event)
        for historic in records(directory / "episodes.jsonl"):
            key = (historic["condition"], historic["episode_id"])
            episode = environment.Episode(schedule[historic["episode_id"]]["world"])
            for event in sorted(event_map[key], key=lambda item: item["step"]):
                if event["accepted"] and event["action"].get("action") == "query":
                    observed = episode.apply(event["action"])
                    if observed != event["environment_response"]:
                        raise AssertionError(f"query replay mismatch {key} at step {event['step']}")
            state = episode.state()
            report = historic["report"]
            profile = None
            if report is not None:
                viable = instrument.compatible_cards(state)
                evidence_ids = report.get("evidence_ids", [])
                model_ids = report.get("candidate_model_codes", [])
                known_obs = {row["id"] for row in state["observations"]}
                known_models = {card["id"] for card in state["candidate_models"]}
                certificate = instrument.evidence_certificate(state, report)
                profile = {
                    "v21_target_verdict_correct": report.get("verdict") == instrument.expected_verdict(state),
                    "v21_candidate_set_exact": set(model_ids) == viable and len(model_ids) == len(set(model_ids)),
                    "v21_certificate_sufficient": certificate,
                    "all_evidence_ids_known": set(evidence_ids).issubset(known_obs),
                    "all_candidate_ids_known": set(model_ids).issubset(known_models),
                    "evidence_ids_unique": len(evidence_ids) == len(set(evidence_ids)),
                    "candidate_ids_unique": len(model_ids) == len(set(model_ids)),
                    "missing_v21_fields": [field for field in ("diagnosis", "sufficiency") if field not in report],
                    "full_v21_structure_valid": not instrument.structural_errors({"action": "report", **report}),
                    "retrospective_only": True,
                }
            entry = {"stage": stage, "condition": historic["condition"], "episode_id": historic["episode_id"],
                     "historical_explicit_report": report is not None, "historical_decision_correct": historic["decision_correct"],
                     "assessment": profile}
            episodes_out.append(entry)
            bucket = grouped[(stage, historic["condition"])]
            bucket["episodes"] += 1
            bucket["explicit_reports"] += report is not None
            bucket["historical_decisions_correct"] += bool(historic["decision_correct"])
            if profile:
                for field, keyname in [
                    ("v21_target_verdict_correct", "target_verdict_correct"),
                    ("v21_candidate_set_exact", "candidate_set_exact"),
                    ("v21_certificate_sufficient", "certificate_sufficient"),
                    ("all_evidence_ids_known", "all_evidence_ids_known"),
                    ("all_candidate_ids_known", "all_candidate_ids_known"),
                    ("full_v21_structure_valid", "full_v21_structure_valid"),
                ]:
                    bucket[keyname] += profile[field]
    summary = {}
    for (stage, condition), counts in sorted(grouped.items()):
        summary.setdefault(stage, {})[condition] = dict(counts)
    out = HERE / "results"
    out.mkdir(exist_ok=True)
    (out / "retrospective_v2_1_episodes.json").write_text(json.dumps(episodes_out, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (out / "retrospective_v2_1_summary.json").write_text(json.dumps({
        "contract": "SPEC.md", "episodes": len(episodes_out), "explicit_reports": sum(e["historical_explicit_report"] for e in episodes_out),
        "query_replay_errors": 0, "interpretation": "component-wise retrospective; reports predate v2.1 fields and schema",
        "conditions": summary,
    }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"episodes": len(episodes_out), "explicit_reports": sum(e["historical_explicit_report"] for e in episodes_out),
                      "query_replay_errors": 0}))

if __name__ == "__main__":
    main()
