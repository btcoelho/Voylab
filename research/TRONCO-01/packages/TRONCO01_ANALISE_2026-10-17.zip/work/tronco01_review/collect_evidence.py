"""Read persisted M17 pilot evidence; never import or run the experimental agent."""
import ast
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "work" / "M17_DESCOBERTA_DIAGNOSTICO"
OUTPUT = ROOT / "outputs" / "TRONCO01_AUDITORIA_EVIDENCIA_2026-10-17.json"


def fingerprint(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def summarize_metrics(items):
    episodes = sum(item["episodes"] for item in items)
    actions = sum(item["action_count"] for item in items)
    invalid = sum(item["invalid_actions"] for item in items)
    forced = sum(item["forced_terminations"] for item in items)
    diagnosis = sum(round(item["five_way_evidence_diagnosis"]["estimate"] *
                          item["five_way_evidence_diagnosis"]["n"]) for item in items)
    return {"episodes": episodes, "action_count": actions, "invalid_actions": invalid,
            "invalid_action_rate": invalid / actions if actions else None,
            "forced_terminations": forced, "explicit_reports": episodes - forced,
            "query_count": round(sum(item["mean_queries"] * item["episodes"] for item in items)),
            "evidence_diagnosis_successes": diagnosis,
            "calibration_by_seed_as_stored": [item["calibration"] for item in items]}


def main():
    paths = sorted(SOURCE.glob("*.py")) + sorted((SOURCE / "tests").glob("*.py"))
    paths += [SOURCE / "PROTOCOL.md", SOURCE / "M16_AUDIT.md"]
    paths += [SOURCE / "results" / name for name in
              ("pilot_base_v012.json", "pilot_m16_v012.json", "pilot_controls_v012.json")]
    manifest = {"review_date": "2026-10-17", "new_model_inference_executed": False,
                "new_training_executed": False, "m17_modified_by_review": False,
                "experimental_inputs": [fingerprint(path) for path in paths], "models": {},
                "controls": {}}
    for filename, agent in (("pilot_base_v012.json", "base_model"),
                            ("pilot_m16_v012.json", "m16_adapter")):
        data = json.loads((SOURCE / "results" / filename).read_text(encoding="utf-8"))
        manifest["models"][agent] = summarize_metrics([v["metrics"] for v in data[agent].values()])
    controls = json.loads((SOURCE / "results/pilot_controls_v012.json").read_text(encoding="utf-8"))["controls"]
    names = next(iter(controls.values()))["agents"]
    for name in names:
        manifest["controls"][name] = summarize_metrics([v["agents"][name] for v in controls.values()])
    test_tree = ast.parse((SOURCE / "tests/test_m17.py").read_text(encoding="utf-8"))
    manifest["unit_test_definitions_in_source"] = sum(
        isinstance(node, ast.FunctionDef) and node.name.startswith("test_") for node in ast.walk(test_tree))
    manifest["unit_test_status"] = "14 passed in the prior execution; no tests rerun by this review"
    OUTPUT.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"models": manifest["models"], "output": str(OUTPUT)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
