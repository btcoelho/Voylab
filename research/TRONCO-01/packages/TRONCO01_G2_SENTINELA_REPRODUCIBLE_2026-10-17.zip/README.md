# TRONCO-01 G2 sentinel package

This archive contains the frozen G2 v0.1 preregistration, G2 scripts, required M17 and G1 source files, preflight record, post-run audit of all 300 query IDs, 25-world schedule, raw sentinel actions and episodes, and the mandatory analysis report.

The model checkpoint and Python environment remain external. The checkpoint revision and checksum are recorded in `work/TRONCO01_G2/run_20261017_v01/preregistration.json`. Only source files needed by this run are bundled; private diagnostic and confirmation datasets are excluded.

G2 stopped after the five sentinel worlds because `base_g2_schema` did not meet its preregistered operational gate. The 20 extension worlds were not evaluated. No reserved split was opened and no fine-tuning was done.
