"""Pre-model gate with a fresh, atomic result for every invocation."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid

HERE = Path(__file__).resolve().parent
RESULT = HERE / "results" / "preflight_gate_v2_3.json"
sys.path.insert(0, str(HERE))


def publish(data):
    RESULT.parent.mkdir(exist_ok=True)
    temp = RESULT.with_suffix(".json.tmp")
    temp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, RESULT)


def main():
    run_id = str(uuid.uuid4())
    result = {"run_id": run_id, "protocol": "TRONCO-01-v2.3", "model_inference": False}
    publish({**result, "gate": "RUNNING"})
    try:
        # Keep project imports inside the protected region so even import-time
        # failures replace any prior PASS with this invocation's FAIL.
        from instrument import FrozenRunGuard
        guard = FrozenRunGuard(HERE / "frozen_manifest.json")
        guard.verify()
        schedule_hash = hashlib.sha256((HERE / "preflight_schedule.jsonl").read_bytes()).hexdigest()
        commands = {
            "finite": [sys.executable, str(HERE / "finite_audit.py")],
            "mutation": [sys.executable, str(HERE / "mutation_audit.py")],
            "tests": [sys.executable, "-m", "pytest", "tests", "-q", "-p", "no:cacheprovider"],
            "grammar": [sys.executable, str(HERE / "grammar_preflight.py")],
            "historical_reanalysis": [sys.executable, str(HERE / "reanalyze_history.py")],
        }
        outputs = {}
        for name, command in commands.items():
            completed = subprocess.run(command, cwd=HERE, capture_output=True, text=True)
            outputs[name] = {"returncode": completed.returncode, "stdout": completed.stdout.strip(), "stderr": completed.stderr.strip()}
            if completed.returncode:
                raise RuntimeError({"stage": name, **outputs[name]})
        guard.verify()
        result.update({
            "gate": "PASS_FOR_PREMODEL_REVIEW",
            "frozen_sources_verified_at_start_and_end": True,
            "synthetic_schedule_sha256": schedule_hash,
            "stages": outputs,
            "review_boundary": "human analysis required before any new model inference",
        })
        publish(result)
        print(json.dumps(result, indent=2))
    except Exception as error:
        result.update({"gate": "FAIL", "error": repr(error)})
        publish(result)
        print(json.dumps(result, indent=2))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
