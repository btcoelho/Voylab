# TRONCO-01 v2.3 — gate e protocolo para revisão

Esta versão corrige a falha de inicialização encontrada em v2.2. O estado RUNNING é publicado antes da importação do instrumento; falhas de importação ficam registadas como FAIL com um run_id novo. O executor continua a bloquear geração depois da terminação.

## Reprodução

Requer Python 3.12, as dependências exatas em requirements.txt e o tokenizer Qwen local indicado por TRONCO_TOKENIZER_PATH. O teste exercita o TokenEnforcer diretamente com o tokenizer, sem PyTorch nem pesos. O resultado grava os hashes dos ficheiros efetivamente usados. Uma instalação limpa destas dependências e o gate completo passaram em 17-10-2026.

Criar ambiente virtual, instalar requirements.txt, definir TRONCO_TOKENIZER_PATH para o snapshot do tokenizer e executar freeze_sources.py uma vez depois da revisão. Depois executar preflight.py. Cada chamada publica RUNNING e termina com PASS ou FAIL no JSON v2.3.

PASS_FOR_PREMODEL_REVIEW autoriza apenas a revisão do protocolo. G1/G2 continuam dados históricos e a reanálise usa os critérios v2.3 retrospectivamente.
