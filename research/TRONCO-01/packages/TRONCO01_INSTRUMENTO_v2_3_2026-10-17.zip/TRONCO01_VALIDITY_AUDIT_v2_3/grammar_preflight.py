"""Exercise the frozen action grammar against the locally cached Qwen tokenizer; no weights."""
from __future__ import annotations
import json
import os
import hashlib
from pathlib import Path
import sys
from transformers import AutoTokenizer, PreTrainedTokenizerBase
import transformers.tokenization_utils as tokenization_utils

# Compatibility bridge for the installed Transformers/LM Format Enforcer versions.
tokenization_utils.PreTrainedTokenizerBase = PreTrainedTokenizerBase
from lmformatenforcer import JsonSchemaParser
from lmformatenforcer.characterlevelparser import UnionParser
from lmformatenforcer.tokenenforcer import TokenEnforcer, TokenEnforcerTokenizerData

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import instrument

TOKENIZER_PATH = Path(os.environ.get("TRONCO_TOKENIZER_PATH", "/home/bcoelho/.cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c"))
PROMPT = "Escolhe uma ação JSON.\n"

def sample_state():
    return {"candidate_models": [], "working_model": None, "observations": [], "query_menu": [], "remaining_query_budget": 0}

def main():
    if not TOKENIZER_PATH.is_dir():
        raise FileNotFoundError(f"Tokenizer local não encontrado: {TOKENIZER_PATH}")
    tokenizer = AutoTokenizer.from_pretrained(str(TOKENIZER_PATH), local_files_only=True)
    token_0 = tokenizer.encode("0")[-1]
    regular_tokens = []
    for token_id in range(len(tokenizer)):
        if token_id in tokenizer.all_special_ids:
            continue
        decoded_after_0 = tokenizer.decode([token_0, token_id])[1:]
        decoded_regular = tokenizer.decode([token_id])
        regular_tokens.append((token_id, decoded_after_0, len(decoded_after_0) > len(decoded_regular)))
    tokenizer_data = TokenEnforcerTokenizerData(
        regular_tokens, lambda ids: tokenizer.decode(ids).rstrip("�"), tokenizer.eos_token_id,
        use_bitmask=False, vocab_size=len(tokenizer))
    tokenizer_files = {}
    for name in ("tokenizer.json", "tokenizer_config.json", "vocab.json", "merges.txt", "special_tokens_map.json", "added_tokens.json"):
        path = TOKENIZER_PATH / name
        if path.is_file():
            tokenizer_files[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    parser = UnionParser([JsonSchemaParser(branch) for branch in instrument.ACTION_SCHEMA["oneOf"]])
    enforcer = TokenEnforcer(tokenizer_data, parser)
    prompt_ids = tokenizer(PROMPT, add_special_tokens=False)["input_ids"]
    state = sample_state()
    query = json.dumps({"action": "query", "query_id": "q0"}, separators=(",", ":"))
    report = {"action": "report", "verdict": "rejected", "diagnosis": "none_fit", "sufficiency": "no_candidate_fits",
              "candidate_model_codes": [], "evidence_ids": [], "location": {"feature": "none", "values": []}}
    valid = {"query": query, "wrong_but_structural_report": json.dumps(report, separators=(",", ":"))}
    malformed = {
        "extra_field": '{"action":"query","query_id":"q0","extra":1}',
        "wrong_type": '{"action":"query","query_id":42}',
        "incomplete": '{"action":"query"}',
    }
    traces = {}
    for name, text in {**valid, **malformed}.items():
        generated = tokenizer(text, add_special_tokens=False)["input_ids"]
        ids = list(prompt_ids)
        steps = []
        for token_id in generated:
            choices = enforcer.get_allowed_tokens(ids).allowed_tokens
            steps.append(token_id in choices)
            if token_id not in choices:
                break
            ids.append(token_id)
        eos = tokenizer.eos_token_id
        eos_allowed = eos is not None and eos in enforcer.get_allowed_tokens(ids).allowed_tokens
        traces[name] = {"token_count": len(generated), "all_tokens_allowed": len(steps) == len(generated) and all(steps),
                        "eos_token_id": eos, "eos_allowed_after_complete_action": eos_allowed,
                        "expected_valid": name in valid}
    result = {"parser": "LM Format Enforcer TokenEnforcer + local cached tokenizer",
              "tokenizer_path": str(TOKENIZER_PATH), "tokenizer_name_or_path": tokenizer.name_or_path,
              "tokenizer_files_sha256": tokenizer_files,
              "tokenizer_vocab_size": len(tokenizer), "weights_loaded": False, "model_inference": False,
              "cases": traces,
              "all_valid_paths_reach_eos": all(traces[name]["all_tokens_allowed"] and traces[name]["eos_allowed_after_complete_action"] for name in valid),
              "all_malformed_paths_blocked": all(not traces[name]["all_tokens_allowed"] or not traces[name]["eos_allowed_after_complete_action"] for name in malformed)}
    if not (result["all_valid_paths_reach_eos"] and result["all_malformed_paths_blocked"]):
        raise AssertionError(json.dumps(result, indent=2))
    out = HERE / "results"
    out.mkdir(exist_ok=True)
    (out / "grammar_preflight_v2_3.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
