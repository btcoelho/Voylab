import pytest


@pytest.fixture
def state_factory():
    def make():
        cards = [
            {"id": "A", "statement": "Output depends only on glyph.", "table": {"g0": "0", "g1": "0"}},
            {"id": "B", "statement": "Output depends only on setting.", "table": {"s0": "1", "s1": "1"}},
            {"id": "C", "statement": "Output depends on glyph and phase.",
             "table": {"g0|t0": "0", "g0|t1": "1", "g1|t0": "0", "g1|t1": "1"}},
        ]
        return {"candidate_models": cards, "working_model": dict(cards[0]),
                "observations": [{"id": "a", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"}],
                "query_menu": [{"id": f"q{i}", "input": {"glyph": "g0", "setting": "s0", "partner": f"p{i}", "phase": "t1" if i == 2 else "t0"}} for i in range(4)],
                "remaining_query_budget": 3}
    return make


@pytest.fixture
def report_factory():
    def make(verdict="supported", diagnosis="ambiguous", sufficiency="identity_ambiguous",
             candidates=("A", "C"), evidence=("a",), location=None):
        return {"action": "report", "verdict": verdict, "diagnosis": diagnosis,
                "sufficiency": sufficiency, "candidate_model_codes": list(candidates),
                "evidence_ids": list(evidence), "location": location if location is not None else {"feature": "none", "values": []}}
    return make
