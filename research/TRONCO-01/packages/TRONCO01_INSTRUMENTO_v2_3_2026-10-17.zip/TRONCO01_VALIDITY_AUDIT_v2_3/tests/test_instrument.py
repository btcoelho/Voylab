from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import pytest
from hypothesis import given, settings, strategies as st

import instrument as v


def build_state():
    cards = [
        {"id": "A", "statement": "Output depends only on glyph.", "table": {"g0": "0", "g1": "0"}},
        {"id": "B", "statement": "Output depends only on setting.", "table": {"s0": "1", "s1": "1"}},
        {"id": "C", "statement": "Output depends on glyph and phase.",
         "table": {"g0|t0": "0", "g0|t1": "1", "g1|t0": "0", "g1|t1": "1"}},
    ]
    return {"candidate_models": cards, "working_model": dict(cards[0]),
            "observations": [{"id": "a", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"}],
            "query_menu": [{"id": f"q{i}", "input": {"glyph": "g0", "setting": "s0", "partner": f"p{i}", "phase": "t1" if i == 2 else "t0"}} for i in range(4)],
            "remaining_query_budget": 3}


def test_report_separates_working_fit_from_identification(state_factory, report_factory):
    state = state_factory()
    result = v.evaluate_report(state, report_factory())
    assert result["legal"] and result["joint_success"]
    assert result["expected_verdict"] == "supported"
    assert result["expected_diagnosis"] == "ambiguous"
    assert result["expected_sufficiency"] == "identity_ambiguous"


@pytest.mark.parametrize("raw", [
    '{"action":"report"} trailing', 'prefix {}', '{}{}',
    '{"action":"query","action":"report"}', '{"action":"query","query_id":NaN}',
    '{"action":',
])
def test_decoder_and_schema_reject_ambiguous_or_malformed(raw):
    with pytest.raises((ValueError, json.JSONDecodeError)):
        action = v.decode_action(raw)
        assert not v.structural_errors(action)


def test_schema_rejects_extra_fields():
    assert v.structural_errors({"action": "query", "query_id": "q0", "extra": 1})


def test_wrong_but_legal_report_stays_observable(state_factory, report_factory):
    state = state_factory()
    wrong = report_factory(verdict="rejected", diagnosis="ambiguous", sufficiency="identity_ambiguous")
    result = v.evaluate_report(state, wrong)
    assert result["legal"]
    assert not result["verdict_correct"]
    assert not result["joint_success"]


def test_unobserved_citation_blocks_joint_success(state_factory, report_factory):
    state = state_factory()
    report = report_factory(evidence=("a", "invented"))
    result = v.evaluate_report(state, report)
    assert not result["legal"]
    assert "report cites an unobserved evidence ID" in result["legal_errors"]
    assert not result["joint_success"]


def test_duplicate_observation_content_does_not_change_support_certificate(state_factory, report_factory):
    state = state_factory()
    report = report_factory()
    before = v.evaluate_report(state, report)
    duplicate = deepcopy(state["observations"][0])
    duplicate["id"] = "same_content_new_id"
    state["observations"].append(duplicate)
    state["query_menu"] = []
    after = v.evaluate_report(state, report)
    assert before["joint_success"]
    assert after["joint_success"]


def test_evidence_duplicate_ids_are_structural_error(state_factory, report_factory):
    action = report_factory(evidence=("a", "a"))
    action["action"] = "report"
    assert v.structural_errors(action)


def test_candidate_set_checks_every_observation(state_factory, report_factory):
    state = state_factory()
    state["observations"].append({"id": "b", "input": deepcopy(state["observations"][0]["input"]), "output": "1"})
    action = report_factory(verdict="rejected", diagnosis="none_fit", sufficiency="no_candidate_fits",
                            candidates=("A", "C"), evidence=("b",))
    result = v.evaluate_report(state, action)
    assert result["legal"]
    assert result["expected_candidate_model_codes"] == []
    assert not result["candidates_correct"]
    assert not result["joint_success"]


def test_location_checks_values_and_controlled_design(state_factory, report_factory):
    state = state_factory()
    state["observations"].append({"id": "b", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t1"}, "output": "1"})
    report = report_factory(evidence=("a", "b"), location={"feature": "phase", "values": ["t0", "t1"]})
    assert v.evaluate_report(state, report)["location_supported"] is True
    report["location"] = {"feature": "phase", "values": ["invented", "t1"]}
    assert v.evaluate_report(state, report)["location_supported"] is False
    state["observations"][1]["input"]["setting"] = "s1"
    assert v.evaluate_report(state, report)["location_supported"] is False


def test_unknown_label_has_no_effect(state_factory, report_factory):
    state = state_factory()
    action = report_factory()
    first = v.evaluate_report(state, action)
    state["hidden_category"] = "CHANGE"
    second = v.evaluate_report(state, action)
    assert first == second


def test_queries_budget_rejection_and_termination(state_factory, report_factory):
    episode = v.Episode(state_factory(), lambda inputs: "0")
    before = episode.state()
    assert not episode.apply({"action": "query", "query_id": "not-listed"})["accepted"]
    assert episode.state() == before
    for i in range(3):
        assert episode.apply({"action": "query", "query_id": f"q{i}"})["accepted"]
    assert episode.state()["remaining_query_budget"] == 0
    assert not episode.apply({"action": "query", "query_id": "q3"})["accepted"]
    result = episode.apply(report_factory())
    assert result["terminal"] and result["evaluation"]["legal"]
    with pytest.raises(RuntimeError):
        episode.apply(report_factory())


@given(st.lists(st.integers(min_value=0, max_value=7), min_size=0, max_size=24))
@settings(max_examples=60, deadline=None, derandomize=True)
def test_query_sequences_preserve_budget_menu_and_rejected_state(indices):
    episode = v.Episode(build_state(), lambda inputs: "0")
    accepted = set()
    for index in indices:
        state = episode.state()
        query_id = f"q{index}"
        should_accept = state["remaining_query_budget"] > 0 and query_id in {q["id"] for q in state["query_menu"]}
        result = episode.apply({"action": "query", "query_id": query_id})
        assert result["accepted"] is should_accept
        if should_accept:
            accepted.add(query_id)
        else:
            assert episode.state() == state
        assert episode.state()["remaining_query_budget"] == 3 - len(accepted)
        assert not accepted.intersection(q["id"] for q in episode.state()["query_menu"])


@given(st.permutations(["a", "b", "c", "d"]))
@settings(max_examples=24, deadline=None, derandomize=True)
def test_semantic_result_is_order_invariant(order):
    state = build_state()
    rows = [
        {"id": "a", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"},
        {"id": "b", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t1"}, "output": "1"},
        {"id": "c", "input": {"glyph": "g1", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"},
        {"id": "d", "input": {"glyph": "g1", "setting": "s0", "partner": "p0", "phase": "t1"}, "output": "1"},
    ]
    state["observations"] = rows
    action = {"action": "report", "verdict": "rejected", "diagnosis": "identified", "sufficiency": "identity_resolved",
              "candidate_model_codes": ["C"], "evidence_ids": ["a", "b", "c", "d"], "location": {"feature": "none", "values": []}}
    expected = v.evaluate_report(state, action)
    state["observations"] = [next(r for r in rows if r["id"] == rid) for rid in order]
    assert v.evaluate_report(state, action) == expected


def test_raw_record_is_durable_before_apply_failure(tmp_path, state_factory):
    episode = v.Episode(state_factory(), lambda inputs: "0")
    journal_path = tmp_path / "events.jsonl"
    journal = v.Journal(journal_path)
    def fail(_action):
        raise SystemExit("injected apply failure")
    with pytest.raises(SystemExit):
        journal.run_raw_action(episode, '{"action":"query","query_id":"q0"}', apply_hook=fail)
    records = [json.loads(line) for line in journal_path.read_text().splitlines()]
    assert len(records) == 1 and records[0]["kind"] == "raw_action"
    assert records[0]["raw"].endswith('"q0"}')


def test_journal_sequence_continues_after_restart(tmp_path):
    path = tmp_path / "events.jsonl"
    first = v.Journal(path)
    first.append({"kind": "fixture", "n": 1})
    second = v.Journal(path)
    assert second.append({"kind": "fixture", "n": 2})["sequence"] == 2


def test_frozen_gate_blocks_generation_if_source_changes(tmp_path, state_factory):
    frozen = tmp_path / "frozen.py"
    frozen.write_text("stable")
    manifest = tmp_path / "freeze.json"
    manifest.write_text(json.dumps({"files": [{"path": "frozen.py", "sha256": hashlib.sha256(b"stable").hexdigest()}]}))
    called = []
    episode = v.Episode(state_factory(), lambda inputs: "0")
    executor = v.FrozenExecutor(lambda prompt: called.append(prompt) or '{"action":"query","query_id":"q0"}',
                                v.FrozenRunGuard(manifest), v.Journal(tmp_path / "events.jsonl"), episode)
    assert executor.step("fixture prompt")["accepted"]
    frozen.write_text("modified")
    with pytest.raises(RuntimeError):
        executor.step("must not generate")
    assert called == ["fixture prompt"]


def test_all_reports_have_no_confidence_until_event_is_defined(state_factory, report_factory):
    action = report_factory()
    assert "confidence" not in action
    action["confidence"] = .9
    assert v.structural_errors(action)


def test_terminated_episode_blocks_generation_before_guard_or_generator(tmp_path, state_factory, report_factory):
    episode = v.Episode(state_factory(), lambda inputs: "0")
    episode.apply(report_factory())
    called = []
    class Guard:
        def verify(self):
            called.append("guard")
    executor = v.FrozenExecutor(lambda prompt: called.append("generate") or "{}", Guard(),
                                v.Journal(tmp_path / "events.jsonl"), episode)
    with pytest.raises(RuntimeError, match="already terminated"):
        executor.step("after terminal")
    assert called == []


def test_preflight_import_failure_replaces_prior_pass(tmp_path):
    import subprocess
    import sys
    folder = tmp_path / "preflight"
    (folder / "results").mkdir(parents=True)
    (folder / "results/preflight_gate_v2_3.json").write_text(
        json.dumps({"gate": "PASS_FOR_PREMODEL_REVIEW", "run_id": "old"}), encoding="utf-8")
    (folder / "instrument.py").write_text("raise RuntimeError('injected import failure')\n", encoding="utf-8")
    source = Path(__file__).resolve().parents[1] / "preflight.py"
    shutil.copyfile(source, folder / "preflight.py")
    failed = subprocess.run([sys.executable, str(folder / "preflight.py")], capture_output=True, text=True)
    current = json.loads((folder / "results/preflight_gate_v2_3.json").read_text(encoding="utf-8"))
    assert failed.returncode == 1
    assert current["gate"] == "FAIL"
    assert current["run_id"] != "old"
