"""Targeted mutations of v2.1 to check that contract probes can kill them."""
from copy import deepcopy
import json
from pathlib import Path
import types

HERE = Path(__file__).resolve().parent
SOURCE = (HERE / "instrument.py").read_text(encoding="utf-8")

def state():
    cards = [
        {"id": "A", "statement": "Output depends only on glyph.", "table": {"g0": "0", "g1": "0"}},
        {"id": "B", "statement": "Output depends only on setting.", "table": {"s0": "1", "s1": "1"}},
        {"id": "C", "statement": "Output depends on glyph and phase.", "table": {"g0|t0": "0", "g0|t1": "1", "g1|t0": "0", "g1|t1": "1"}},
    ]
    return {"candidate_models": cards, "working_model": cards[0],
            "observations": [
                {"id": "a", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"},
                {"id": "b", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t1"}, "output": "1"}],
            "query_menu": [], "remaining_query_budget": 0}

def report(verdict="rejected", evidence=("b",), candidates=("C",), location=None):
    return {"action": "report", "verdict": verdict,
            "diagnosis": "identified", "sufficiency": "identity_resolved",
            "candidate_model_codes": list(candidates), "evidence_ids": list(evidence),
            "location": location if location is not None else {"feature": "none", "values": []}}

def load_mutant(name, needle, replacement):
    if needle not in SOURCE:
        raise RuntimeError(f"mutation anchor missing: {name}")
    module = types.ModuleType(f"mutant_{name}")
    exec(compile(SOURCE.replace(needle, replacement, 1), f"<mutant:{name}>", "exec"), module.__dict__)
    return module

def probes(module, name):
    s = state()
    if name == "ignore_unobserved_ids":
        result = module.evaluate_report(s, report(evidence=("b", "invented")))
        assert not result["joint_success"] and not result["legal"]
    elif name == "accept_partial_support_certificate":
        s["observations"] = [
            {"id": "a", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"},
            {"id": "c", "input": {"glyph": "g1", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"}]
        action = report("supported", ("a",), ("A", "C"))
        action["diagnosis"] = "ambiguous"
        action["sufficiency"] = "identity_ambiguous"
        result = module.evaluate_report(s, action)
        assert not result["joint_success"]
    elif name == "depend_on_first_observation":
        reverse = deepcopy(s)
        reverse["observations"].reverse()
        assert module.expected_verdict(s) == module.expected_verdict(reverse)
    elif name == "score_duplicate_by_id":
        s["observations"] = [
            {"id": "a", "input": {"glyph": "g0", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"},
            {"id": "c", "input": {"glyph": "g1", "setting": "s0", "partner": "p0", "phase": "t0"}, "output": "0"}]
        duplicate = deepcopy(s)
        duplicate["observations"].append({**deepcopy(duplicate["observations"][0]), "id": "a_copy"})
        action = report("supported", ("a", "c"), ("A", "C"))
        action["diagnosis"] = "ambiguous"
        action["sufficiency"] = "identity_ambiguous"
        assert module.evaluate_report(s, action)["joint_success"] == module.evaluate_report(duplicate, action)["joint_success"]
    elif name == "accept_fabricated_location_values":
        assert not module.location_supported(s, report(evidence=("a", "b"), location={"feature": "phase", "values": ["t1", "invented"]}))

MUTATIONS = [
    ("ignore_unobserved_ids", 'if not set(action["evidence_ids"]).issubset(known_obs):\n            errors.append("report cites an unobserved evidence ID")',
     'if False:\n            errors.append("report cites an unobserved evidence ID")'),
    ("accept_partial_support_certificate", 'return {_content(r) for r in cited_rows} == {_content(r) for r in rows} and bool(rows)',
     'return bool(cited_rows) and bool(rows)'),
    ("depend_on_first_observation", 'for row in rows):\n        return "rejected"',
     'for row in rows[:1]):\n        return "rejected"'),
    ("score_duplicate_by_id", 'return (tuple(x[field] for field in FIELDS), row["output"])',
     'return (row["id"],)'),
    ("accept_fabricated_location_values", 'and {a[feature], b[feature]} == values):',
     'and a[feature] != b[feature]):'),
]

def main():
    results = []
    for name, needle, replacement in MUTATIONS:
        mutant = load_mutant(name, needle, replacement)
        try:
            probes(mutant, name)
            results.append({"mutation": name, "outcome": "survived", "killed": False})
        except AssertionError as exc:
            results.append({"mutation": name, "outcome": "killed_by_contract_assertion", "killed": True, "detail": str(exc)})
    if not all(item["killed"] for item in results):
        raise AssertionError(json.dumps(results, indent=2))
    result = {"targeted_mutations": len(results), "killed": sum(item["killed"] for item in results),
              "results": results, "scope": "five selected regressions; not a full mutation campaign"}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results/mutation_audit_v2_3.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))

if __name__ == "__main__":
    main()
