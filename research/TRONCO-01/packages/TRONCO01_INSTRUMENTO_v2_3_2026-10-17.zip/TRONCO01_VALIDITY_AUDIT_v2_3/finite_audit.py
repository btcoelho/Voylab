"""Finite truth-table audit against direct bit-vector expectations."""
from __future__ import annotations

from itertools import product
import json
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from instrument import compatible_cards, expected_verdict


def main():
    inputs = [
        {"glyph": glyph, "setting": "s0", "partner": "p0", "phase": phase}
        for glyph, phase in product(("g0", "g1"), ("t0", "t1"))
    ]
    checked_states = checked_compatibility_sets = checked_verdicts = 0
    for glyph_bits in product("01", repeat=2):
        for setting_bit in "01":
            for phase_bits in product("01", repeat=4):
                cards = [
                    {"id": "A", "statement": "Output depends only on glyph.", "table": dict(zip(("g0", "g1"), glyph_bits))},
                    {"id": "B", "statement": "Output depends only on setting.", "table": {"s0": setting_bit, "s1": setting_bit}},
                    {"id": "C", "statement": "Output depends on glyph and phase.",
                     "table": {f"{x['glyph']}|{x['phase']}": y for x, y in zip(inputs, phase_bits)}},
                ]
                vectors = {"A": (glyph_bits[0], glyph_bits[0], glyph_bits[1], glyph_bits[1]),
                           "B": (setting_bit,) * 4, "C": phase_bits}
                for symbols in product((None, "0", "1"), repeat=4):
                    observations = [{"id": f"r{i}", "input": x, "output": output}
                                   for i, (x, output) in enumerate(zip(inputs, symbols)) if output is not None]
                    expected = {model for model, values in vectors.items()
                                if all(symbols[i] is None or values[i] == symbols[i] for i in range(4))}
                    state = {"candidate_models": cards, "working_model": cards[0], "observations": observations}
                    actual = compatible_cards(state)
                    if actual != expected:
                        raise AssertionError({"vectors": vectors, "observations": observations, "expected": expected, "actual": actual})
                    checked_compatibility_sets += 1
                    expected_fit = "undetermined" if not observations else ("supported" if all(
                        vectors["A"][i] == symbols[i] for i in range(4) if symbols[i] is not None) else "rejected")
                    actual_fit = expected_verdict(state)
                    if actual_fit != expected_fit:
                        raise AssertionError({"observations": observations, "expected_fit": expected_fit, "actual_fit": actual_fit})
                    checked_verdicts += 1
                    checked_states += 1
    result = {"table_triples": 128, "partial_consistent_histories_per_triple": 81,
              "public_states": checked_states, "compatibility_set_checks": checked_compatibility_sets,
              "working_fit_checks": checked_verdicts, "expected_independently_indexed": True}
    (HERE / "results").mkdir(exist_ok=True)
    (HERE / "results/finite_audit_v2_3.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
