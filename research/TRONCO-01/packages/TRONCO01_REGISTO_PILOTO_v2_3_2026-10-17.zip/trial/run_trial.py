"""Run the frozen ten-episode development panel with the local base checkpoint."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "work/TRONCO01_VALIDITY_AUDIT_v2_3"
TRIAL = ROOT / "work/TRONCO01_TRIAL_v2_3"
sys.path.insert(0, str(AUDIT))
from instrument import Episode, FrozenRunGuard, Journal, FrozenExecutor

MODEL_PATH = Path("/home/bcoelho/.cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c")
MODEL_SHA = "fa6ed98084afb0497d9075a82ab17fdfc0b5d99fb6b37d8f761463e67c100f45"
OUTPUT = TRIAL / "run_20261017"
SYSTEM = (TRIAL / "system_prompt.txt").read_text(encoding="utf-8").strip()

def lines(path): return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines()]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def oracle(rule, x):
    kind = rule["kind"]
    if kind in {"empty", "supported_ambiguous", "supported_identified"}: return "0" if x["glyph"] == "g0" else "1"
    if kind == "rejected_identified": return "0" if x["setting"] == "s0" else "1"
    return str(int((x["glyph"] == "g1") ^ (x["setting"] == "s1")))

def main():
    prereg = json.loads((TRIAL / "preregistration.json").read_text())
    assert prereg["status"] in {"frozen_before_inference", "amended_after_sentinel_output_failure"}
    assert sha(MODEL_PATH / "model.safetensors") == MODEL_SHA == prereg["model"]["weights_sha256"]
    assert sha(TRIAL / "public_schedule.jsonl") == prereg["sha256"]["public_schedule.jsonl"]
    assert sha(TRIAL / "private_oracle.jsonl") == prereg["sha256"]["private_oracle.jsonl"]
    assert sha(TRIAL / "system_prompt.txt") == prereg["sha256"]["system_prompt.txt"]
    assert sha(TRIAL / "inference_environment.json") == prereg["sha256"]["inference_environment.json"]
    assert sha(Path(__file__)) == prereg["sha256"]["run_trial.py"]
    assert sha(ROOT / "work/prepare_trial_v23.py") == prereg["sha256"]["prepare_trial_v23.py"]
    assert sha(ROOT / "work/audit_trial_v23.py") == prereg["sha256"]["audit_trial_v23.py"]
    assert sha(AUDIT / "instrument.py") == prereg["sha256"]["instrument.py"]

    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    import unsloth
    from unsloth import FastLanguageModel
    import transformers
    import transformers.tokenization_utils as tokenization_utils
    from transformers.tokenization_utils_base import PreTrainedTokenizerBase
    tokenization_utils.PreTrainedTokenizerBase = PreTrainedTokenizerBase
    from lmformatenforcer import JsonSchemaParser
    from lmformatenforcer.characterlevelparser import UnionParser
    from lmformatenforcer.integrations.transformers import build_transformers_prefix_allowed_tokens_fn
    from instrument import ACTION_SCHEMA

    model, tokenizer = FastLanguageModel.from_pretrained(model_name=str(MODEL_PATH), max_seq_length=2048, dtype=None, load_in_4bit=True)
    FastLanguageModel.for_inference(model)
    parser = UnionParser([JsonSchemaParser(branch) for branch in ACTION_SCHEMA["oneOf"]])
    grammar = build_transformers_prefix_allowed_tokens_fn(tokenizer, parser)
    tokenizer_sha = sha(MODEL_PATH / "tokenizer.json")
    public = lines(TRIAL / "public_schedule.jsonl")
    private = {x["episode_id"]: x["oracle"] for x in lines(TRIAL / "private_oracle.jsonl")}
    OUTPUT.mkdir(parents=True, exist_ok=True)
    journal = Journal(OUTPUT / "events.jsonl")
    outcomes_path = OUTPUT / "outcomes.json"
    outcomes = json.loads(outcomes_path.read_text(encoding="utf-8")) if outcomes_path.exists() else []
    completed_ids = {item["episode_id"] for item in outcomes}
    if completed_ids:
        journal.append({"kind": "trial_resume", "protocol": prereg["protocol"],
            "amended_prereg_sha256": sha(TRIAL / "preregistration.json"), "completed_episode_ids": sorted(completed_ids),
            "model_sha256": MODEL_SHA, "tokenizer_json_sha256": tokenizer_sha, "model_inference": True})
    else:
        journal.append({"kind": "trial_start", "protocol": prereg["protocol"], "prereg_sha256": sha(TRIAL / "preregistration.json"),
                        "model_sha256": MODEL_SHA, "tokenizer_json_sha256": tokenizer_sha, "model_inference": True})

    sentinel_technical_failure = False
    for episode_index, item in enumerate(public):
        episode_id = item["episode_id"]
        if episode_id in completed_ids: continue
        episode = Episode(item["public_state"], lambda x, rule=private[episode_id]: oracle(rule, x))
        journal.append({"kind": "episode_start", "episode_id": episode_id, "public_state": episode.state()})
        result = {"episode_id": episode_id, "initial_stratum": item["design_stratum"], "calls": 0, "queries": 0, "status": "in_progress"}
        def generate(prompt):
            journal.append({"kind": "prompt", "episode_id": episode_id, "prompt": prompt,
                "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest()})
            encoded = tokenizer(prompt, return_tensors="pt", truncation=False).to(model.device)
            if encoded["input_ids"].shape[1] > 2048: raise ValueError("prompt exceeds frozen context limit")
            started = time.time()
            output = model.generate(**encoded, max_new_tokens=256, max_length=None, do_sample=False,
                pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id, prefix_allowed_tokens_fn=grammar)
            generated = output[0, encoded["input_ids"].shape[1]:]
            raw = tokenizer.decode(generated, skip_special_tokens=True)
            result["calls"] += 1
            journal.append({"kind": "generation", "episode_id": episode_id,
                "prompt_token_count": int(encoded["input_ids"].shape[1]), "generated_token_ids": generated.tolist(),
                "generated_token_count": int(generated.numel()), "eos_terminated": bool(generated.numel() and int(generated[-1]) == tokenizer.eos_token_id),
                "elapsed_seconds": round(time.time() - started, 4), "settings": {"do_sample": False, "max_new_tokens": 256, "max_length": None}})
            return raw
        try:
            for _ in range(4):
                user = json.dumps(episode.state(), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                prompt = tokenizer.apply_chat_template([{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}],
                    tokenize=False, add_generation_prompt=True)
                applied = FrozenExecutor(generate, FrozenRunGuard(AUDIT / "frozen_manifest.json"), journal, episode).step(prompt)
                if "observation" in applied: result["queries"] += 1
                if applied.get("terminal"):
                    result["status"] = "reported"
                    result["evaluation"] = applied["evaluation"]
                    result["final_state"] = episode.state()
                    break
            if result["status"] == "in_progress": result["status"] = "call_limit_no_report"
        except json.JSONDecodeError as error:
            result["status"] = "model_output_failure"
            result["error"] = repr(error)
            journal.append({"kind": "model_output_failure", "episode_id": episode_id,
                "raw_action_sequence": journal.sequence, "calls_recorded": result["calls"], "error": repr(error)})
        except Exception as error:
            result["status"] = "technical_failure"
            result["error"] = repr(error)
            journal.append({"kind": "episode_error", "episode_id": episode_id, "calls_recorded": result["calls"], "error": repr(error)})
        outcomes.append(result)
        journal.append({"kind": "episode_outcome", "outcome": result})
        (OUTPUT / "outcomes.json").write_text(json.dumps(outcomes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"episode_id": episode_id, "status": result["status"], "calls": result["calls"], "queries": result["queries"]}, ensure_ascii=False))
        if episode_index == 0 and result["status"] == "technical_failure":
            sentinel_technical_failure = True
            journal.append({"kind": "sentinel_stop", "reason": result.get("error")})
            break

    scored = [x for x in outcomes if x["status"] == "reported"]
    summary = {"protocol": prereg["protocol"], "episodes_attempted": len(outcomes), "episodes_planned": len(public), "reported": len(scored),
        "technical_failures": sum(x["status"] == "technical_failure" for x in outcomes),
        "model_output_failures": sum(x["status"] == "model_output_failure" for x in outcomes),
        "no_report": sum(x["status"] == "call_limit_no_report" for x in outcomes),
        "joint_successes": sum(x.get("evaluation", {}).get("joint_success", False) for x in scored),
        "primary_rate_all_episodes": sum(x.get("evaluation", {}).get("joint_success", False) for x in scored) / len(outcomes),
        "mean_queries": sum(x["queries"] for x in outcomes) / len(outcomes), "model_inference": True,
        "model_sha256": MODEL_SHA, "tokenizer_json_sha256": tokenizer_sha, "prereg_sha256": sha(TRIAL / "preregistration.json"),
        "sentinel_technical_failure": sentinel_technical_failure}
    (OUTPUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    journal.append({"kind": "trial_end", "summary": summary})
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if sentinel_technical_failure: raise SystemExit(2)

if __name__ == "__main__": main()
