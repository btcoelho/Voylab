# TRONCO-01 v2.3 synthetic pilot — reproducibility bundle

Contains the amended preregistration, public episode schedule, exact prompt and environment record, frozen run source/instrument, append-only inference journal, outcomes and summary. It excludes `private_oracle.jsonl`. The post-hoc score can be reproduced with the independent analyzer; it deliberately does not import `instrument.py`.

The public schedule contains `expected_initial` labels for independent analysis; the runner passes only each record's `public_state` to the model. The system prompt and event journal preserve what was actually passed/generated. The initial preregistration was retained only by SHA-256, not as a file; the amendment and amended preregistration are included.

`summary.json` and `outcomes.json` are preserved as written by the runner. The independent report reconciles pilot_01 from its raw generation and JSONDecodeError and flags the resumed sentinel indicator inconsistency without editing historic raw files.
