"""Independent, post-hoc replay for the TRONCO-01 v2.3 ten-case pilot.

This deliberately does not import the instrument/evaluator under audit.
It implements the finite table rules directly from the written task and
replays only public initial states plus durable action-result events.
"""
from __future__ import annotations
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TRIAL = ROOT / "work/TRONCO01_TRIAL_v2_3"
RUN = TRIAL / "run_20261017"
OUT = ROOT / "outputs"


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def predicts(card, row):
    text = card["statement"].lower()
    if "glyph and phase" in text:
        fields = ("glyph", "phase")
    elif "only on glyph" in text:
        fields = ("glyph",)
    elif "only on setting" in text:
        fields = ("setting",)
    else:
        raise ValueError(f"Unspecified public model statement: {card['statement']!r}")
    key = "|".join(row["input"][f] for f in fields)
    return card["table"].get(key, object()) == row["output"]


def same_content(a, b):
    # Compare the full observed input assignment and output, ignoring record ID.
    return a["input"] == b["input"] and a["output"] == b["output"]


def reference_labels(state):
    obs = state["observations"]
    cards = {c["id"]: c for c in state["candidate_models"]}
    viable = {cid for cid, card in cards.items() if all(predicts(card, row) for row in obs)}
    working = cards[state["working_model"]["id"]]
    verdict = ("undetermined" if not obs else "supported" if all(predicts(working, r) for r in obs)
               else "rejected")
    diagnosis = "none_fit" if not viable else "identified" if len(viable) == 1 else "ambiguous"
    sufficiency = ("no_observations" if not obs else "no_candidate_fits" if not viable
                   else "identity_resolved" if len(viable) == 1 else "identity_ambiguous")
    return {"candidates": sorted(viable), "diagnosis": diagnosis,
            "sufficiency": sufficiency, "verdict": verdict}


def independent_score(state, action):
    obs = state["observations"]
    cards = {c["id"]: c for c in state["candidate_models"]}
    known_obs = {o["id"] for o in obs}
    errors = []
    if action.get("action") != "report":
        errors.append("not a report")
    if not set(action.get("evidence_ids", [])) <= known_obs:
        errors.append("unknown evidence ID")
    if not set(action.get("candidate_model_codes", [])) <= set(cards):
        errors.append("unknown candidate ID")
    legal = not errors
    labels = reference_labels(state)
    viable = set(labels["candidates"])
    working = cards[state["working_model"]["id"]]
    verdict, diagnosis, sufficiency = labels["verdict"], labels["diagnosis"], labels["sufficiency"]
    cited = [o for o in obs if o["id"] in set(action.get("evidence_ids", []))]
    if action.get("verdict") == "supported":
        cert = bool(obs) and all(any(same_content(r, c) for c in cited) for r in obs)
    elif action.get("verdict") == "rejected":
        cert = any(not predicts(working, r) for r in cited)
    else:
        cert = not obs and not action.get("evidence_ids", [])
    loc = action.get("location", {"feature": "none", "values": []})
    loc_ok = loc == {"feature": "none", "values": []}
    parts = {
        "legal": legal,
        "legal_errors": errors,
        "expected_verdict": verdict,
        "expected_candidate_model_codes": sorted(viable),
        "expected_diagnosis": diagnosis,
        "expected_sufficiency": sufficiency,
        "verdict_correct": action.get("verdict") == verdict,
        "candidates_correct": set(action.get("candidate_model_codes", [])) == viable,
        "diagnosis_correct": action.get("diagnosis") == diagnosis,
        "sufficiency_correct": action.get("sufficiency") == sufficiency,
        "evidence_certificate_sufficient": cert,
        "location_supported": None if loc_ok else False,
        "joint_success": legal and all((action.get("verdict") == verdict,
            set(action.get("candidate_model_codes", [])) == viable,
            action.get("diagnosis") == diagnosis,
            action.get("sufficiency") == sufficiency, cert, loc_ok)),
    }
    return parts


def main():
    schedule = read_jsonl(TRIAL / "public_schedule.jsonl")
    events = read_jsonl(RUN / "events.jsonl")
    recorded = json.loads((RUN / "outcomes.json").read_text(encoding="utf-8"))
    summary = json.loads((RUN / "summary.json").read_text(encoding="utf-8"))
    states = {x["episode_id"]: json.loads(json.dumps(x["public_state"])) for x in schedule}
    strata = {x["episode_id"]: x["design_stratum"] for x in schedule}
    event_episode = {}
    current = None
    for e in events:
        if e["kind"] == "episode_start":
            current = e["episode_id"]
        event_episode[e["sequence"]] = current

    actions_by_ep = defaultdict(list)
    raw_by_seq = {}
    generations = Counter()
    for e in events:
        ep = event_episode.get(e["sequence"])
        if e["kind"] == "generation":
            generations[ep] += 1
        elif e["kind"] == "raw_action":
            raw_by_seq[e["sequence"]] = (ep, e.get("raw", ""))
        elif e["kind"] == "action_result":
            raw = raw_by_seq.get(e.get("raw_sequence"), (ep, ""))
            ep = raw[0]
            a = e["action"]
            actions_by_ep[ep].append({"action": a, "accepted": e["result"].get("accepted"),
                                      "errors": e["result"].get("legal_errors", [])})
            if a.get("action") == "query" and e["result"].get("accepted"):
                state = states[ep]
                query = next(q for q in state["query_menu"] if q["id"] == a["query_id"])
                observation = e["result"]["observation"]
                state["observations"].append(observation)
                state["query_menu"].remove(query)
                state["remaining_query_budget"] -= 1

    output = []
    for original in schedule:
        ep = original["episode_id"]
        initial_labels = reference_labels(original["public_state"])
        old = next(x for x in recorded if x["episode_id"] == ep)
        reports = [x for x in actions_by_ep[ep] if x["action"].get("action") == "report"]
        valid_reports = [x for x in reports if x["accepted"]]
        scored = independent_score(states[ep], valid_reports[-1]["action"]) if valid_reports else None
        output.append({
            "episode_id": ep,
            "stratum": strata[ep],
            "calls": generations[ep],
            "attempted_reports": len(reports),
            "rejected_reports": sum(not x["accepted"] for x in reports),
            "accepted_report": bool(valid_reports),
            "report_fields": ({k: valid_reports[-1]["action"].get(k) for k in
                               ("verdict", "candidate_model_codes", "diagnosis", "sufficiency",
                                "evidence_ids", "location")}
                              if valid_reports else None),
            "independent_score": scored,
            "recorded_status": old["status"],
            "retrospective_status": ("model_output_failure" if ep == "pilot_01" and
                                      "JSONDecodeError" in old.get("error", "")
                                      else old["status"]),
            "independent_truth_matches_schedule": initial_labels == original["expected_initial"],
            "independent_expected_initial": initial_labels,
            "action_acceptance_matches_reference": all(
                independent_score(states[ep], a["action"])["legal"] == a["accepted"]
                for a in actions_by_ep[ep] if a["action"].get("action") == "report"),
            "runner_score_agrees": (None if not scored else all(
                old.get("evaluation", {}).get(k) == v for k, v in scored.items()
                if k in old.get("evaluation", {}))),
        })

    statuses = Counter(x["retrospective_status"] for x in output)
    valid = [x for x in output if x["accepted_report"]]
    mismatch = [x["episode_id"] for x in valid if x["runner_score_agrees"] is False]
    total_actions = sum(len(actions_by_ep[x["episode_id"]]) for x in schedule)
    total_attempted_reports = sum(len([a for a in actions_by_ep[x["episode_id"]]
                                       if a["action"].get("action") == "report"]) for x in schedule)
    independent = {
        "protocol": "TRONCO-01-v2.3-pilot-v0.1",
        "analysis": "post-hoc independent replay; no model inference; no import of instrument.py",
        "episodes": output,
        "counts": {
            "episodes": len(output),
            "episodes_by_retrospective_status": dict(statuses),
            "generated_calls": sum(generations.values()),
            "action_results": total_actions,
            "attempted_reports": total_attempted_reports,
            "rejected_report_actions": sum(x["rejected_reports"] for x in output),
            "accepted_reports": len(valid),
            "queries": sum(1 for ep in actions_by_ep.values() for a in ep
                           if a["action"].get("action") == "query" and a["accepted"]),
            "joint_successes": sum(bool(x["independent_score"]["joint_success"])
                                    for x in valid),
            "joint_success_rate_all_episodes": 0.0,
            "score_disagreements_with_runner": mismatch,
            "initial_label_disagreements": [x["episode_id"] for x in output
                                            if not x["independent_truth_matches_schedule"]],
            "action_acceptance_disagreements": [x["episode_id"] for x in output
                                                if not x["action_acceptance_matches_reference"]],
        },
        "runner_summary_as_written": summary,
        "integrity": {
            "events_sha256": sha(RUN / "events.jsonl"),
            "outcomes_sha256": sha(RUN / "outcomes.json"),
            "summary_sha256": sha(RUN / "summary.json"),
            "preregistration_sha256": sha(TRIAL / "preregistration.json"),
            "public_schedule_sha256": sha(TRIAL / "public_schedule.jsonl"),
            "private_oracle_included": False,
        },
        "notes": [
            "pilot_01 is stored as technical_failure, but its durable journal contains a model generation and a JSONDecodeError; retrospective classification is model_output_failure. The original outcome is preserved.",
            "The resumed-run summary says sentinel_technical_failure=false despite an earlier sentinel_stop event for pilot_01; this is a reporting-state defect, not a model score.",
            "call_limit_no_report means no legal terminal report; those episodes each attempted four report actions and made zero queries.",
            "This is a ten-case synthetic development panel and gives no general model-performance estimate or evidence about the Voynich manuscript."
        ],
    }
    OUT.mkdir(exist_ok=True)
    (OUT / "TRONCO01_RESULTADO_PILOTO_v2_3_2026-10-17.json").write_text(
        json.dumps(independent, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    md = [
        "# Resultado do piloto sintético TRONCO-01 v2.3",
        "",
        "## Decisão",
        "",
        "O instrumento **não está apto para um pequeno ensaio de modelo** com esta interface e configuração. O piloto de desenvolvimento não confirmou a capacidade-alvo: houve 0/10 sucessos conjuntos, nenhuma consulta aceite e apenas 3 relatórios legais. Isto é evidência de falha da configuração testada, não uma estimativa geral da capacidade do modelo nem uma validação sobre o manuscrito Voynich.",
        "",
        "## Resultados",
        "",
        f"- Episódios: {len(output)}; chamadas geradas: {sum(generations.values())}.",
        f"- Classificação retrospectiva: {dict(statuses)}.",
        f"- Ações de relatório: {total_attempted_reports}; relatórios legais: {len(valid)}; relatórios rejeitados: {sum(x['rejected_reports'] for x in output)}.",
        "- Consultas legais: 0; sucessos conjuntos: 0/10.",
        "- Nos três relatórios legais, `verdict=undetermined`, `candidate_model_codes=[A]`, `diagnosis=none_fit` e `sufficiency=no_candidate_fits`. Em dois episódios a referência era `supported / [A] / identified / identity_resolved`; no terceiro era `rejected / [] / none_fit / no_candidate_fits`. Nenhum relatório acertou o veredicto ou o certificado de evidência.",
        "",
        "## Problemas verificados",
        "",
        "1. **Saída truncada/malformada:** quatro episódios terminaram em `JSONDecodeError` após geração. `pilot_01` ficou guardado como falha técnica, embora o diário contenha geração e erro de descodificação; reclassifico-o apenas nesta análise como falha de saída do modelo. Não houve retry.",
        "2. **Ação de consulta não usada:** nos três episódios sem relatório terminal, o modelo repetiu quatro relatórios que citavam IDs de evidência não observados. O ambiente rejeitou-os; não houve consulta aceite.",
        "3. **Decisão inconsistente nos relatórios legais:** os três relatórios legais deram a mesma combinação de resposta apesar de estados que exigiam suporte, rejeição e conjuntos de candidatos diferentes.",
        "4. **Resumo de retoma enganador:** o resumo final marca `sentinel_technical_failure=false`, apesar do evento `sentinel_stop` anterior. O primeiro episódio foi tecnicamente reclassificado pelo runner na retoma, mas o estado de sentinela não foi recuperado. O diário preserva a sequência completa.",
        "5. **Verificação independente:** recalculou os rótulos dos dez estados iniciais e a legalidade das ações, sem importar o avaliador em auditoria. Divergências com rótulos do calendário = " + (", ".join(independent["counts"]["initial_label_disagreements"]) if independent["counts"]["initial_label_disagreements"] else "nenhuma") + "; divergências de legalidade = " + (", ".join(independent["counts"]["action_acceptance_disagreements"]) if independent["counts"]["action_acceptance_disagreements"] else "nenhuma") + "; divergências com o score guardado = " + (", ".join(mismatch) if mismatch else "nenhuma") + ".",
        "",
        "## Efeito das alterações e limites",
        "",
        "O harness conseguiu retomar sem repetir episódios concluídos, preservar saídas brutas e acabar os dez casos após a emenda. A emenda classificou corretamente as falhas de descodificação a partir de `pilot_02`, mas `pilot_01` permaneceu com o rótulo antigo; a retoma também tornou incorreto o indicador de falha da sentinela. Assim, o registo bruto é utilizável, mas os campos agregados do runner exigem reconciliação pós-execução.",
        "A restrição de 256 tokens foi insuficiente para alguns relatórios em JSON com texto explicativo longo. A gramática permitiu sequências estruturalmente admissíveis, mas não evitou referências a IDs inexistentes nem decisões semanticamente erradas. Não alterei prompt, modelo, gramática ou limite durante o lote.",
        "",
        "## Próximos passos",
        "",
        "1. Congelar este resultado como histórico; manter G1/G2 e reservas intactos.",
        "2. Corrigir o harness antes de qualquer novo modelo: estado de sentinela persistente em retoma, classificação de erro pelo tipo real, resumo sempre reconstruído a partir do diário e distinção entre relatório tentado, ação ilegal e relatório terminal válido.",
        "3. Reduzir a resposta estruturada a campos curtos, eliminar explicação livre, limitar IDs às opções do estado atual e testar a terminação JSON sob o orçamento fixo; congelar nova versão e repetir primeiro testes sem modelo e testes de mutação.",
        "4. Fazer nova avaliação apenas após um novo ponto de análise, com protocolo e orçamento preregistados. Não fazer fine-tuning com este painel.",
        "",
        "## Reprodutibilidade",
        "",
        "O JSON anexo contém score independente, estados por episódio e SHA-256 dos registos. O verificador independente está incluído no pacote. O pacote exclui a chave privada do oráculo; as mensagens e ações completas continuam no diário bruto.",
    ]
    (OUT / "TRONCO01_RESULTADO_PILOTO_v2_3_2026-10-17.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps(independent["counts"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
