"""One-shot held-out engineering validation of constrained transport repair."""
from __future__ import annotations
import hashlib,json,time,torch
from pathlib import Path
from transformers import AutoTokenizer
from run_g0c import ROOT,BASE,ADAPTER,BALANCED,MAX_NEW,TrieConstraint,action_candidates,canon,sha,validate,generate

OUT=ROOT/'work/TRONCO01_G0C/validation_20261017'

def fixtures():
  common={'device':'unknown_system','working_model':{'id':'G7','statement':'Fixture hypothesis.','table':{'glyphM':'outA'}},
    'candidate_models':[{'id':'G7','statement':'Fixture hypothesis.','table':{'glyphM':'outA'}},{'id':'Z4','statement':'Alternative fixture.','table':{'glyphM':'outB'}}],
    'observations':[{'id':'rK','input':{'glyph':'glyphM','setting':'setQ','partner':'partC','phase':'phaseD'},'output':'outA'},
      {'id':'rM','input':{'glyph':'glyphM','setting':'setQ','partner':'partC','phase':'phaseE'},'output':'outB'}],
    'query_menu':[{'id':'qX','input':{'glyph':'glyphN','setting':'setR','partner':'partD','phase':'phaseF'}},
      {'id':'qY','input':{'glyph':'glyphP','setting':'setS','partner':'partE','phase':'phaseG'}}],
    'remaining_query_budget':2,'response_schema':{'query':{'action':'query','query_id':'one ID from query_menu'},
      'report':{'action':'report','verdict':'supported | rejected | undetermined','candidate_model_codes':[],
      'evidence_ids':[],'location':{'feature':'input field or null','value':'value or null'},'confidence':'number 0 to 1','explanation':'short statement'}}}
  specs=[('heldout_query','query',{'action':'query','query_id':'qY'}),
    ('heldout_supported','report',{'action':'report','verdict':'supported','candidate_model_codes':['G7'],'evidence_ids':['rK'],'location':{'feature':None,'value':None},'confidence':0.8,'explanation':'Held-out fixture.'}),
    ('heldout_rejected','report',{'action':'report','verdict':'rejected','candidate_model_codes':['G7'],'evidence_ids':['rK','rM'],'location':{'feature':'glyph','value':'glyphM'},'confidence':0.9,'explanation':'Held-out fixture.'}),
    ('heldout_undetermined','report',{'action':'report','verdict':'undetermined','candidate_model_codes':['G7','Z4'],'evidence_ids':['rK'],'location':{'feature':None,'value':None},'confidence':0.5,'explanation':'Held-out fixture.'})]
  out=[]
  for name,kind,expected in specs:
    state=dict(common); state['task']=f'Held-out transport validation for {kind}: follow requested_action exactly; no scientific inference.'; state['requested_action']=expected
    out.append({'task_id':name,'state':state,'expected':expected,'split':'G0d_heldout_engineering'})
  return out

def main():
  OUT.mkdir(parents=True,exist_ok=True)
  if any(OUT.iterdir()): raise RuntimeError(f'Nonempty validation output: {OUT}')
  fs=fixtures(); tok=AutoTokenizer.from_pretrained(str(BASE),local_files_only=True,use_fast=True); plan=[]
  for model in ('base','m16'):
    for f in fs:
      prompt=tok.apply_chat_template([{'role':'system','content':BALANCED},{'role':'user','content':canon(f['state'])}],tokenize=False,add_generation_prompt=True)
      n=len(tok(prompt,truncation=False)['input_ids'])
      if n>2048: raise RuntimeError('Held-out prompt exceeds context')
      plan.append({'model':model,'task_id':f['task_id'],'split':f['split'],'state':f['state'],'expected':f['expected'],'mode':'constrained','prompt':prompt,'prompt_sha256':sha(prompt.encode()),'input_tokens':n})
  prereg={'protocol_id':'TRONCO01-G0d-v0.1','frozen_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'planned_generations':8,'max_generations':8,'no_retries':True,'model_revision':BASE.name,'balanced_prompt_sha256':sha(BALANCED.encode()),'fixtures':fs,'schedule':plan,'repair':'finite trie constrained decoding to schema-valid action objects; exact target match still scored independently'}
  prereg['sha256']=sha(json.dumps(prereg,ensure_ascii=False,sort_keys=True).encode())
  (OUT/'preregistration.json').write_text(json.dumps(prereg,ensure_ascii=False,indent=2),encoding='utf8')
  (OUT/'schedule.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in plan),encoding='utf8')
  rows=[]
  import unsloth
  for mid in ('base','m16'):
    model,mtok=unsloth.FastLanguageModel.from_pretrained(model_name=str(BASE if mid=='base' else ADAPTER),max_seq_length=2048,dtype=None,load_in_4bit=True)
    unsloth.FastLanguageModel.for_inference(model); model.eval()
    tests=[x for x in plan if x['model']==mid]
    for t in tests:
      cand=action_candidates(t['state']); seqs=[mtok.encode(canon(a),add_special_tokens=False) for a in cand]
      constraint=TrieConstraint(t['input_tokens'],seqs,mtok.eos_token_id)
      result=generate(model,mtok,t,constraint); rows.append(result)
      print(json.dumps({'model':mid,'task':t['task_id'],'strict':result.get('strict_json'),'valid':result.get('valid'),'match':result.get('match'),'eos':result.get('eos')},ensure_ascii=False),flush=True)
    del model,mtok; torch.cuda.empty_cache()
  (OUT/'generations.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf8')
  summary={'protocol_id':prereg['protocol_id'],'planned':8,'completed':len(rows),'models':{m:{'n':sum(x['model']==m for x in rows),'json':sum(x.get('strict_json',False) for x in rows if x['model']==m),'valid':sum(x.get('valid',False) for x in rows if x['model']==m),'exact':sum(x.get('match',False) for x in rows if x['model']==m),'pass_4_of_4':sum(x['model']==m and x.get('match',False) and x.get('eos',False) for x in rows)==4} for m in ('base','m16')},'details':rows}
  (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')

if __name__=='__main__': main()
