from __future__ import annotations
import hashlib, itertools, json, time
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, LogitsProcessor
from peft import PeftModel

ROOT=Path('/mnt/c/Users/Bruno/Documents/Codex/2026-10-17/files-pasted-by-the-user-projeto')
OUT=ROOT/'work/TRONCO01_G0C/run_20261017'
BASE=Path.home()/'.cache/huggingface/hub/models--unsloth--Qwen2.5-0.5B-Instruct-bnb-4bit/snapshots/216d96b52c97a3c8294776df8477592f6828981c'
ADAPTER=Path.home()/'voynich-lab/experiencias/M16_CURRICULO/runs/m16-l4l5-r1/adapter'
G0B=ROOT/'work/TRONCO01_G0B/run_20261017'
MAX_NEW=192

def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(b): return hashlib.sha256(b).hexdigest()
def fixture_set():
    old=json.loads((G0B/'preregistration.json').read_text(encoding='utf8'))
    # Preserve the frozen G0b transport states; only the prompt treatment changes.
    return old['fixtures']
BALANCED='''You are performing a bounded interface transport task. Follow requested_action exactly. Return one JSON object only, without prose or markdown. Use only public IDs and the required fields in response_schema. Do not infer additional values.\nExamples:\nInput requests a query; output: {"action":"query","query_id":"q-demo"}\nInput requests a report; output: {"action":"report","verdict":"supported","candidate_model_codes":["H-demo"],"evidence_ids":["r-demo"],"location":{"feature":null,"value":null},"confidence":0.8,"explanation":"short statement"}'''

class TrieConstraint(LogitsProcessor):
    def __init__(self, prompt_len, sequences, eos):
        self.prompt_len=prompt_len; self.eos=eos; self.next={}; self.term=set()
        for seq in sequences:
            node=self.next
            for tok in seq: node=node.setdefault(tok,{})
            self.term.add(tuple(seq))
    def __call__(self,input_ids,scores):
        prefix=tuple(input_ids[0,self.prompt_len:].tolist()); node=self.next
        for tok in prefix:
            if tok not in node: return scores
            node=node[tok]
        allowed=list(node)
        if prefix in self.term: allowed.append(self.eos)
        masked=torch.full_like(scores,float('-inf')); masked[:,allowed]=scores[:,allowed]
        return masked

def action_candidates(state):
    req=state['requested_action']
    if req['action']=='query':
        return [{'action':'query','query_id':q['id']} for q in state['query_menu']]
    mids=sorted({m['id'] for m in state['candidate_models']}); eids=sorted({e['id'] for e in state['observations']})
    subsets=lambda xs:[list(c) for n in range(len(xs)+1) for c in itertools.combinations(xs,n)]
    locations=[{'feature':None,'value':None}]
    for k in sorted(state['observations'][0]['input']):
        locations.append({'feature':k,'value':None})
        locations.append({'feature':k,'value':state['observations'][0]['input'][k]})
    out=[]
    for v,ms,es,loc,c,e in itertools.product(['supported','rejected','undetermined'],subsets(mids),subsets(eids),locations,[0.0,0.5,0.8,1.0],['short statement','fixture statement']):
        out.append({'action':'report','verdict':v,'candidate_model_codes':ms,'evidence_ids':es,'location':loc,'confidence':c,'explanation':e})
    return out

def validate(state,a):
    if not isinstance(a,dict): return False,False
    r=state['requested_action']; obs={x['id'] for x in state['observations']}; mods={x['id'] for x in state['candidate_models']}
    if r['action']=='query':
        valid=a.get('action')=='query' and a.get('query_id') in {x['id'] for x in state['query_menu']}
    else:
        valid=(a.get('action')=='report' and a.get('verdict') in {'supported','rejected','undetermined'} and
          isinstance(a.get('candidate_model_codes'),list) and all(x in mods for x in a['candidate_model_codes']) and
          isinstance(a.get('evidence_ids'),list) and all(x in obs for x in a['evidence_ids']) and
          isinstance(a.get('confidence'),(int,float)) and not isinstance(a.get('confidence'),bool) and 0<=a['confidence']<=1 and
          isinstance(a.get('location'),dict) and isinstance(a.get('explanation'),str))
    return valid, valid and a==r

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    if any(OUT.iterdir()): raise RuntimeError(f'Nonempty output: {OUT}')
    tok=AutoTokenizer.from_pretrained(str(BASE),local_files_only=True,use_fast=True)
    fs=fixture_set(); plan=[]
    for model in ('base','m16'):
      for f in fs:
       for mode in ('free','constrained'):
        msgs=[{'role':'system','content':BALANCED},{'role':'user','content':canon(f['state'])}]
        prompt=tok.apply_chat_template(msgs,tokenize=False,add_generation_prompt=True)
        ids=tok(prompt,return_tensors='pt',truncation=False)['input_ids']
        plan.append({'model':model,'task_id':f['task_id'],'mode':mode,'state':f['state'],'expected':f['expected'],'prompt':prompt,'prompt_sha256':sha(prompt.encode()),'input_tokens':ids.shape[1]})
    controls=[]
    for loader in ('transformers_base','unsloth_base'):
      state={'task':'Return exactly this JSON object and no other text: {"status":"ok","n":7}'}
      prompt=tok.apply_chat_template([{'role':'user','content':canon(state)}],tokenize=False,add_generation_prompt=True)
      controls.append({'model':loader,'task_id':'canonical_control','mode':'free','state':state,'expected':{'status':'ok','n':7},'prompt':prompt,'prompt_sha256':sha(prompt.encode()),'input_tokens':len(tok(prompt)['input_ids'])})
    schedule=plan+controls
    prereg={'protocol_id':'TRONCO01-G0c-v0.1','frozen_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'budget':len(schedule),'max_new_tokens':MAX_NEW,'generation':'greedy; do_sample=false; no retries','base_revision':BASE.name,'adapter_path':str(ADAPTER),'balanced_system_sha256':sha(BALANCED.encode()),'fixtures_sha256':sha(canon(fs).encode()),'schedule':schedule,'loader_compare':'independent transformers AutoModelForCausalLM vs Unsloth loader on exact canonical control'}
    prereg['sha256']=sha(json.dumps(prereg,sort_keys=True,ensure_ascii=False).encode())
    (OUT/'preregistration.json').write_text(json.dumps(prereg,ensure_ascii=False,indent=2),encoding='utf8')
    (OUT/'schedule.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in schedule),encoding='utf8')
    results=[]
    # Independent Transformers base loader control; failures are recorded, then Unsloth path is assessed.
    try:
      model=AutoModelForCausalLM.from_pretrained(str(BASE),local_files_only=True,device_map='auto',torch_dtype='auto')
      model.eval()
      for t in [x for x in controls if x['model']=='transformers_base']:
       results.append(generate(model,tok,t,None))
      del model; torch.cuda.empty_cache()
    except Exception as e:
      results.append({'model':'transformers_base','task_id':'canonical_control','mode':'free','loader_error':f'{type(e).__name__}: {e}'})
    for model_id in ('base','m16'):
      model,mtok=__import__('unsloth').FastLanguageModel.from_pretrained(model_name=str(BASE if model_id=='base' else ADAPTER),max_seq_length=2048,dtype=None,load_in_4bit=True)
      __import__('unsloth').FastLanguageModel.for_inference(model); model.eval()
      if mtok.get_vocab()!=tok.get_vocab(): raise RuntimeError('Tokenizer vocabulary mismatch')
      tests=[x for x in plan if x['model']==model_id]+([x for x in controls if x['model']=='unsloth_base'] if model_id=='base' else [])
      for t in tests:
       constraint=None
       if t['mode']=='constrained':
        cand=action_candidates(t['state'])
        seqs=[mtok.encode(canon(a),add_special_tokens=False) for a in cand]
        constraint=TrieConstraint(t['input_tokens'],seqs,mtok.eos_token_id)
       results.append(generate(model,mtok,t,constraint))
       print(json.dumps({'model':model_id,'task':t['task_id'],'mode':t['mode'],'strict':results[-1].get('strict_json'),'valid':results[-1].get('valid'),'match':results[-1].get('match')},ensure_ascii=False),flush=True)
      del model,mtok; torch.cuda.empty_cache()
    (OUT/'generations.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in results),encoding='utf8')
    summary={'protocol_id':prereg['protocol_id'],'planned':len(schedule),'completed':len(results),'results':[{k:v for k,v in x.items() if k not in ('raw','prompt')} for x in results]}
    (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')

def generate(model,tok,t,constraint):
    ids=tok(t['prompt'],return_tensors='pt',truncation=False)['input_ids']; n=int(ids.shape[1]); inputs={'input_ids':ids.to(model.device)}
    try:
      kwargs={'max_new_tokens':MAX_NEW,'do_sample':False,'pad_token_id':tok.pad_token_id or tok.eos_token_id,'return_dict_in_generate':True}
      if constraint: kwargs['logits_processor']=[constraint]
      with torch.inference_mode(): out=model.generate(**inputs,**kwargs)
      seq=out.sequences[0,n:]; raw=tok.decode(seq,skip_special_tokens=True)
      try: parsed=json.loads(raw.strip()); parse_error=None
      except Exception as e: parsed=None; parse_error=f'{type(e).__name__}: {e}'
      if t['task_id']=='canonical_control': valid=parsed==t['expected']; match=valid
      else: valid,match=validate(t['state'],parsed)
      return {'model':t['model'],'task_id':t['task_id'],'mode':t['mode'],'prompt_sha256':t['prompt_sha256'],'raw':raw,'strict_json':isinstance(parsed,dict),'parsed':parsed,'valid':valid,'match':match,'parse_error':parse_error,'output_tokens':len(seq),'eos':bool(len(seq) and seq[-1].item()==tok.eos_token_id),'hit_limit':len(seq)>=MAX_NEW}
    except Exception as e:
      return {'model':t['model'],'task_id':t['task_id'],'mode':t['mode'],'prompt_sha256':t['prompt_sha256'],'error':f'{type(e).__name__}: {e}'}

if __name__=='__main__': main()
