"""Review v2.7 offline without modifying its source, results, or historical archive."""
from pathlib import Path
from itertools import combinations, product
from collections import defaultdict
import copy
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "work/TRONCO01_TRIAL_v2_7"
OUTPUT = ROOT / "outputs/TRONCO01_V2_7_VERIFICACAO_INDEPENDENTE_2026-10-17.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def assert_equal(actual, expected, context):
    if actual != expected:
        raise AssertionError({"context": context, "actual": actual, "expected": expected})


def reference_labels(state):
    """Literal interpretation of the three declared cards, independent of replay."""
    fields = {
        "Output depends only on glyph.": ["glyph"],
        "Output depends only on setting.": ["setting"],
        "Output depends on glyph and phase.": ["glyph", "phase"],
    }
    fits = []
    for card in state["candidate_models"]:
        ok = True
        for observation in state["observations"]:
            coordinates = [observation["input"][field] for field in fields[card["statement"]]]
            key = "|".join(coordinates)
            if key not in card["table"] or card["table"][key] != observation["output"]:
                ok = False
                break
        if ok:
            fits.append(card["id"])
    has_evidence = len(state["observations"]) > 0
    working_fits = state["working_model"]["id"] in fits
    return {
        "verdict": ("supported" if working_fits else "rejected") if has_evidence else "undetermined",
        "candidates": sorted(fits),
        "diagnosis": {0: "none_fit", 1: "identified"}.get(len(fits), "ambiguous"),
        "sufficiency": ({0: "no_candidate_fits", 1: "identity_resolved"}.get(len(fits), "identity_ambiguous")
                        if has_evidence else "no_observations"),
    }


def report_from_reference(state):
    labels = reference_labels(state)
    return {"action": "report", "verdict": labels["verdict"],
            "candidate_model_codes": labels["candidates"], "diagnosis": labels["diagnosis"],
            "sufficiency": labels["sufficiency"], "evidence_ids": [r["id"] for r in state["observations"]],
            "location": {"feature": "none", "values": []}}


def finite_semantic_check(replay, base_state):
    # Exhaust every history of zero, one, or two distinct binary observations.
    # Includes contradictory outputs for the same full input; all three working cards.
    observations = []
    for glyph, setting, partner, phase, output in product(range(2), repeat=5):
        observations.append({"id": f"r{len(observations)}",
            "input": {"glyph": f"g{glyph}", "setting": f"s{setting}",
                      "partner": f"p{partner}", "phase": f"t{phase}"}, "output": str(output)})
    count = altered = 0
    for length in range(3):
        for history in combinations(observations, length):
            for card in base_state["candidate_models"]:
                state = dict(base_state, observations=list(history), working_model=card)
                expected = reference_labels(state)
                assert_equal(replay.labels(state), expected, "independent finite labels")
                action = report_from_reference(state)
                assert_equal(replay.score(state, action)["joint_success"], True, "reference report")
                for verdict in ("supported", "rejected", "undetermined"):
                    if verdict != expected["verdict"]:
                        assert_equal(replay.score(state, dict(action, verdict=verdict))["joint_success"],
                                     False, "altered verdict")
                        altered += 1
                wrong_candidates = [c["id"] for c in state["candidate_models"]
                                    if c["id"] not in expected["candidates"]]
                assert_equal(replay.score(state, dict(action, candidate_model_codes=wrong_candidates))["joint_success"],
                             False, "altered candidate set")
                altered += 1
                if length:
                    assert_equal(replay.score(state, dict(action, evidence_ids=[]))["joint_success"],
                                 False, "missing nonempty evidence certificate")
                    altered += 1
                # Order cannot change a scientific conclusion or its score.
                reversed_state = dict(state, observations=list(reversed(history)))
                assert_equal(replay.labels(reversed_state), expected, "observation order")
                assert_equal(replay.score(reversed_state, action)["joint_success"], True, "report order")
                count += 1
    return {"states": count, "altered_reports_rejected": altered,
            "domain": "all histories of up to two distinct observations among 32 binary input/output rows; three working cards",
            "scope": "literal deterministic public tables; labels, verdict, candidate set, missing certificate, observation order",
            "not_covered": ["learned generation", "noise", "generalization", "information acquisition", "all possible location claims"]}


def main():
    result = {"protocol": "TRONCO-01-v2.7-result-review", "new_model_calls": 0, "weights_loaded": False}
    archive = ROOT / "outputs/TRONCO01_V2_7_PONTO_ANALISE_REPRODUCIBLE_2026-10-17.zip"
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        checksums = json.loads(z.read("PACKAGE_SHA256.json"))["files"]
        for name, digest in checksums.items():
            assert_equal(sha(z.read(name)), digest, f"archive hash: {name}")
            if name.startswith("TRONCO01_TRIAL_v2_7/"):
                path = PACKAGE / name.removeprefix("TRONCO01_TRIAL_v2_7/")
            elif name.startswith("delivery/"):
                path = ROOT / "outputs" / Path(name).name
            else:
                path = ROOT / "outputs" / Path(name).name
            assert_equal(sha(path.read_bytes()), digest, f"local bytes: {path.name}")
        result["archive_integrity"] = {"crc_pass": True, "members_hashed_and_matching_disk": len(checksums),
                                       "sha256": sha(archive.read_bytes())}
    manifest = read_json(PACKAGE / "analysis_manifest_draft.json")
    for entry in manifest["files"]:
        assert_equal(sha((PACKAGE / entry["path"]).read_bytes()), entry["sha256"], "internal manifest")
    result["manifest_internal_check"] = {"files_verified": len(manifest["files"]), "status": manifest["status"]}
    result["scorer_unchanged_from_v26"] = ((PACKAGE / "replay.py").read_bytes() ==
        (ROOT / "work/TRONCO01_TRIAL_v2_6/replay.py").read_bytes())

    with tempfile.TemporaryDirectory() as temp:
        scratch = Path(temp) / "package"
        shutil.copytree(PACKAGE, scratch, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        runner = '''import unittest,io,json
stream=io.StringIO()
r=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.discover("tests"))
print(json.dumps({"tests":r.testsRun,"failures":len(r.failures),"errors":len(r.errors),"log":stream.getvalue()}))
'''
        proc = subprocess.run([sys.executable, "-c", runner], cwd=scratch, text=True, capture_output=True)
        if proc.returncode:
            raise RuntimeError(proc.stdout + proc.stderr)
        suite = json.loads(proc.stdout)
        assert_equal((suite["tests"], suite["failures"], suite["errors"]), (37, 0, 0), "suite")
        result["unit_suite"] = suite
        proc = subprocess.run([sys.executable, "mutation_check.py"], cwd=scratch, text=True, capture_output=True)
        if proc.returncode:
            raise RuntimeError(proc.stdout + proc.stderr)
        mutants = json.loads(proc.stdout)
        assert_equal(mutants["total_valid_kills"], 4, "mutation kills")
        result["mutation_check"] = mutants

    spec = importlib.util.spec_from_file_location("v27_independent_replay", PACKAGE / "replay.py")
    replay = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(replay)
    result["historical_v23_replay"] = replay.replay(PACKAGE / "fixtures/v23")["summary"]
    schedule = [json.loads(line) for line in (PACKAGE / "development_schedule.jsonl").read_text().splitlines()]
    groups = defaultdict(list)
    for item in schedule:
        groups[json.dumps(item["public_state"], sort_keys=True)].append(item["episode_id"])
        assert_equal(replay.labels(item["public_state"]), reference_labels(item["public_state"]), "scheduled labels")
    result["schedule"] = {"episodes": len(schedule), "distinct_public_states": len(groups),
                          "duplicates": [ids for ids in groups.values() if len(ids) > 1],
                          "previously_exposed": True, "query_budget": 0}
    result["finite_semantic_check"] = finite_semantic_check(replay, schedule[0]["public_state"])
    result["decision"] = "Suitable for one small development model trial under this observational contract; no generalization, information-seeking, or M17 validity claim."
    OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in {"unit_suite", "mutation_check"}}, indent=2))
    print("RESULT: " + str(OUTPUT))


if __name__ == "__main__":
    main()
