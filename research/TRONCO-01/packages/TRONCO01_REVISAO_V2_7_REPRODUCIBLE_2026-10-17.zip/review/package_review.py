"""Package the v2.7 review and its original evidence without model weights."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs"
archive = OUT / "TRONCO01_REVISAO_V2_7_REPRODUCIBLE_2026-10-17.zip"
inputs = {}
for path in Path(__file__).resolve().parent.glob("*.py"):
    inputs["review/" + path.name] = path
for name in ["TRONCO01_REVISAO_RESULTADOS_V2_7_2026-10-17.md",
             "TRONCO01_V2_7_VERIFICACAO_INDEPENDENTE_2026-10-17.json",
             "TRONCO01_V2_7_RUNTIME_VERIFICADO_2026-10-17.json"]:
    inputs["delivery/" + name] = OUT / name
original = "TRONCO01_V2_7_PONTO_ANALISE_REPRODUCIBLE_2026-10-17.zip"
inputs["historical/" + original] = OUT / original
checksums = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in inputs.items()}
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
    for name, path in inputs.items():
        z.write(path, name)
    z.writestr("PACKAGE_SHA256.json", json.dumps(checksums, indent=2) + "\n")
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, digest in checksums.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == digest
print(json.dumps({"archive": str(archive), "hashed_members": len(checksums), "crc_valid": True,
                  "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))
