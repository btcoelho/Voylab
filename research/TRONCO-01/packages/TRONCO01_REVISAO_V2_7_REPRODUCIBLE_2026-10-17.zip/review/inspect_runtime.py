"""Verify external bytes/runtime and replay a fake-model adapter smoke in WSL."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = ROOT / "work/TRONCO01_TRIAL_v2_7"
prereg = json.loads((PACKAGE / "preregistration_draft.json").read_text())
manifest = json.loads((PACKAGE / "analysis_manifest_draft.json").read_text())
expected = prereg["experimental_condition"]["checkpoint_artifacts"]
artifacts = {}
for item in manifest["external_files"]:
    path = Path(item["path"])
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    actual = digest.hexdigest()
    assert actual == item["sha256"] == expected[path.name], path.name
    artifacts[path.name] = actual
assert set(artifacts) == set(expected)
snapshot = Path(manifest["external_files"][0]["path"]).parent
assert {p.name for p in snapshot.iterdir() if p.is_file()} == set(expected)
runtime = {"python": platform.python_version()}
for key, distribution in {"transformers": "transformers", "lm_format_enforcer": "lm-format-enforcer",
                          "unsloth": "unsloth", "torch": "torch", "bitsandbytes": "bitsandbytes"}.items():
    runtime[key] = importlib.metadata.version(distribution)
assert runtime == prereg["software_environment"]
sys.path.insert(0, str(PACKAGE))
import harness
verified = harness.FrozenManifestGuard(PACKAGE / "analysis_manifest_draft.json").verify(allow_draft=True)
assert verified["__manifest_status__"] == "draft_not_frozen"
try:
    harness.FrozenManifestGuard(PACKAGE / "analysis_manifest_draft.json").verify()
except harness.ResumeIntegrityError:
    blocked = True
else:
    raise AssertionError("draft entered production guard")
with tempfile.TemporaryDirectory() as temporary:
    scratch = Path(temporary) / "package"
    shutil.copytree(PACKAGE, scratch, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    proc = subprocess.run([sys.executable, str(scratch / "adapter_fake_model_smoke.py")],
                          text=True, capture_output=True)
    if proc.returncode:
        raise RuntimeError(proc.stdout + proc.stderr)
    smoke = json.loads(proc.stdout)
    assert smoke["adapter_call_exercised"] and smoke["real_tokenizer_and_lmfe_callback"]
    assert not smoke["checkpoint_loaded"] and not smoke["learned_model_inference"]
result = {"protocol": "TRONCO-01-v2.7-result-review-runtime", "external_artifacts": artifacts,
          "runtime": runtime, "draft_blocks_production": blocked, "adapter_fake_model_smoke": smoke,
          "parent_process_imported_ml_frameworks": any(n in sys.modules for n in ("torch", "unsloth", "transformers")),
          "learned_model_calls": 0, "weights_loaded": False}
output = ROOT / "outputs/TRONCO01_V2_7_RUNTIME_VERIFICADO_2026-10-17.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
