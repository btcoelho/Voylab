"""Read-only audit of whether each preregistered target was reachable by the decoder."""
import json
from pathlib import Path
from run_g0c import action_candidates

root = Path('/mnt/c/Users/Bruno/Documents/Codex/2026-10-17/files-pasted-by-the-user-projeto')
for name, folder in [('G0c', 'run_20261017'), ('G0d', 'validation_20261017')]:
    prereg = json.loads((root / 'work/TRONCO01_G0C' / folder / 'preregistration.json').read_text(encoding='utf8'))
    fixtures = (json.loads((root / 'work/TRONCO01_G0B/run_20261017/preregistration.json').read_text(encoding='utf8'))['fixtures']
                if name == 'G0c' else prereg['fixtures'])
    for fixture in fixtures:
        candidates = action_candidates(fixture['state'])
        print(json.dumps({'run': name, 'fixture': fixture['task_id'],
                          'candidate_count': len(candidates),
                          'target_reachable': fixture['expected'] in candidates}))
