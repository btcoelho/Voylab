# M15 synthetic query agent — Unsloth pilot

This package prepares an SFT run for a narrow agent: choosing the next query in the M14 synthetic 4-context × 16-position experiment. It is not a Voynich decoder and it has not been trained on Voynich/Egerton folios. The existing `voynich-primeiro-lora` adapter is left untouched; this run starts from the declared Qwen 0.5B 4-bit base and writes a new adapter.

See `REPORT_SFT_PILOT.md` for the data split, training details, validation results, and limits. The policy-level scientific comparison remains a draft in `PROTOCOL_DRAFT.md`.

## What is included

- `adaptive_policy.py`: deterministic query-selection teacher using only public parameters, prior observations, and remaining budget.
- `generate_sft.py`: creates fresh adaptive trajectories by querying M14 development worlds. Development answers enter a prompt only after that point has been queried.
- `data/sft/train.jsonl`, `validation.jsonl`: conversational prompt-completion examples split by whole world, stratified by condition.
- `audit_sft.py`: checks world separation, schemas, answer validity, query uniqueness, hashes, and absence of hidden world labels in prompts.
- `train_unsloth.py`: reproducible Unsloth + TRL LoRA training entry point; `--smoke` runs one optimizer step into `/tmp`.
- `evaluate_adapter.py`: greedy exact-action check over the world-held-out validation examples.
- `infer_agent.py`: inference wrapper that validates model output against the supplied, unseen query queue.

## Run in WSL

From `~/voynich-lab` with the existing `.venv`:

```bash
cd ~/voynich-lab/experiencias/M15
../../.venv/bin/python generate_sft.py
../../.venv/bin/python audit_sft.py data/sft
../../.venv/bin/python train_unsloth.py --smoke
```

After the smoke run succeeds, a full three-epoch run writes a new adapter under `experiencias/M15/runs/unsloth-m15-r2-explicit-agenda/adapter`:

```bash
../../.venv/bin/python train_unsloth.py
../../.venv/bin/python evaluate_adapter.py
```

To run one decision state saved as JSON (using only public observations and the query options your caller has already computed):

```bash
../../.venv/bin/python infer_agent.py --input /path/to/decision-state.json
```

The wrapper fails closed if the model returns malformed JSON, an out-of-domain coordinate, a repeated query, or anything other than the first point in the supplied priority queue.

The smoke command trains one step in `/tmp` only. The full command writes the new M15 adapter to its own run folder and does not overwrite the existing `voynich-primeiro-lora` adapter.

## Limits

The labels imitate a deterministic, preregisterable query rule. A fine-tuned model is therefore an approximate controller for this synthetic task, not evidence of historical decoding ability or autonomous scientific reasoning. M14 confirmation and transfer records, all private truth files, external evaluation points, and Voynich/Egerton folio data are excluded. Before scientific claims, evaluate the saved adapter on newly generated, sealed worlds and compare it with the deterministic teacher and M14 policies.
