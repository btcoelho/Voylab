"""Run the M15 adapter on one public synthetic decision state."""
import argparse
import json
import re
import sys
from pathlib import Path

from unsloth import FastLanguageModel


def parse_action(text):
    match = re.search(r"\{[^{}]*\}", text)
    if not match:
        raise ValueError("model output did not contain a JSON object")
    action = json.loads(match.group(0))
    if set(action) != {"action", "t", "x"} or action["action"] != "query":
        raise ValueError("model output has the wrong action schema")
    if not isinstance(action["t"], int) or not isinstance(action["x"], int):
        raise ValueError("query coordinates must be integers")
    return action


def validate_state(state):
    if state.get("task") != "choose_next_query":
        raise ValueError("expected task=choose_next_query")
    if state.get("priority") not in {"diagnostic", "coverage"}:
        raise ValueError("priority must be diagnostic or coverage")
    field = "diagnostic_queries_pending" if state["priority"] == "diagnostic" else "coverage_agenda_remaining"
    options = state.get(field)
    if not isinstance(options, list) or not options:
        raise ValueError(f"{field} must contain at least one available point")
    seen = {(r["t"], r["x"]) for r in state["initial_observations"] + state["observations"]}
    for point in options:
        if not (isinstance(point, list) and len(point) == 2 and
                all(isinstance(v, int) for v in point) and 0 <= point[0] < 4 and 0 <= point[1] < 16):
            raise ValueError("available query contains an invalid point")
        if tuple(point) in seen:
            raise ValueError("available query has already been observed")
    return field, options


def main():
    p = argparse.ArgumentParser(description="M15 synthetic query-policy adapter")
    p.add_argument("--input", type=Path, help="JSON decision state; reads stdin when omitted")
    p.add_argument("--adapter", type=Path, default=Path(__file__).resolve().parent / "runs/unsloth-m15-r2-explicit-agenda/adapter")
    args = p.parse_args()
    raw = args.input.read_text(encoding="utf-8") if args.input else sys.stdin.read()
    state = json.loads(raw)
    field, options = validate_state(state)
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=str(args.adapter), max_seq_length=1024, dtype=None, load_in_4bit=True
    )
    FastLanguageModel.for_inference(model)
    messages = [{"role": "user", "content": json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))}]
    prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=1024).to(model.device)
    output = model.generate(**inputs, max_new_tokens=48, do_sample=False,
                            pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id)
    text = tokenizer.decode(output[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    action = parse_action(text)
    if not (0 <= action["t"] < 4 and 0 <= action["x"] < 16):
        raise ValueError("model query is outside the synthetic domain")
    if [action["t"], action["x"]] != options[0]:
        raise ValueError(f"model did not select the first allowed {field} point")
    print(json.dumps({"validated": True, "priority": state["priority"], "query": action}, ensure_ascii=False))


if __name__ == "__main__":
    main()
