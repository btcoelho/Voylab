# M15 — Diagnóstico de inadequação da representação

**Estado:** rascunho do estudo científico comparativo; confirmação M15 ainda não foi executada. O ensaio técnico Unsloth separado está documentado em `REPORT_SFT_PILOT.md`.  
**Motivação:** continuação proposta no relatório M14-R e falhas de transferência da M13/M14.  
**Âmbito deste protocolo:** avaliação sintética de políticas determinísticas. Não cobre a avaliação do adaptador SFT nem dados de fólios Voynich/Egerton.

## Pergunta

Quando os candidatos e as reparações disponíveis concordam, mas uma observação contradiz todos, uma política pode detetar que a linguagem atual é insuficiente e escolher consultas que distingam uma exceção pontual de uma mudança estrutural? A política deve preservar a incerteza quando os dados não permitem essa distinção.

## Hipóteses

1. Um sinal de inadequação baseado apenas em previsões incompatíveis com todas as reparações atuais reduz a confiança indevida em modelos concordantes.
2. Consultas de seguimento emparelhadas, escolhidas pela história observada, podem aumentar a exatidão efetiva em mudanças estruturadas fora da região ajustada, sem aumentar erros emitidos em exceções pontuais.
3. Se a exceção for observacionalmente indistinguível de uma mudança estrutural dentro do orçamento, nenhuma política recebe crédito por adivinhar a localização ou o mecanismo oculto; mede-se a calibração e a abstenção.

## Domínio, orçamento e divisões

- Reutilizar o domínio discreto M14 (quatro contextos, dezasseis posições por contexto; 64 pontos) para permitir comparação. Geradores, mecanismos, sementes e conjuntos reservados de M15 são novos.
- Cada mundo começa com as mesmas oito observações iniciais. Cada política recebe doze consultas adicionais idênticas em quantidade, mais 44 pontos externos reservados para avaliação.
- Quatro políticas: suspensão de contexto, memorização de observações, consenso M14 e diagnóstico adaptativo M15. Cada braço recebe o mesmo orçamento de consultas e os mesmos pontos externos.
- Separar desenvolvimento, confirmação e transferência com geradores independentes de implementação e semente. A transferência usa uma família que não aparece no desenvolvimento.
- A verdade privada, os mecanismos e os pontos externos ficam no avaliador; nunca são fornecidos às políticas.

## Regra adaptativa candidata

1. Antes de existir contradição comum, o braço M15 segue a mesma agenda pública de consultas de cobertura usada pelo comparador M14.
2. Uma contradição comum ocorre quando a resposta observada difere da previsão de todos os candidatos e de todas as reparações ainda admissíveis. O braço M15 regista um alarme de representação possivelmente inadequada; não cria uma nova reparação com base apenas nesse ponto.
3. Se ainda houver orçamento, as quatro consultas seguintes formam um pacote de diagnóstico: consultar as posições adjacentes disponíveis no mesmo contexto (x−1 e x+1) e os pontos correspondentes em dois outros contextos, escolhidos por ordem fixa e pública. Se uma posição já foi observada ou estiver fora do domínio, usar o vizinho disponível mais próximo.
4. As respostas ao pacote determinam apenas se a evidência é pontual, estruturada ou inconclusiva segundo uma regra congelada antes do piloto. Não se declara descoberto o mecanismo causal. O resto das consultas mantém a agenda M14, com qualquer nova hipótese rotulada como exploratória e sem acesso aos pontos externos.
5. O pacote só usa a história pública e a lista de pontos por consultar. Os comparadores mantêm as respetivas políticas de seleção; recebem a mesma quantidade total de consultas.

A implementação desta regra é candidata, não congelada. O piloto deve testar colisões, consultas repetidas, orçamento insuficiente após um alarme e regras que possam consultar inadvertidamente a região externa.

## Condições sintéticas

- **CLEAN:** regra base sem mudança.
- **POINT:** uma exceção isolada, em posição uniforme e sem pista pública.
- **LOCAL:** mudança estruturada numa região de um contexto.
- **CROSS:** mudança estruturada em mais de um contexto.
- **OUT_OF_CLASS:** padrão periódico condicionado pelo contexto, não expressável pela DSL congelada M14 e nunca usado no desenvolvimento.

Os mecanismos devem ter versões de desenvolvimento e confirmação independentes. Os parâmetros de confirmação e transferência são gerados depois de congelar o protocolo. Nenhuma família deve oferecer ao agente uma pista explícita da localização da exceção.

## Métricas e gates a pré-registar

Reportar por mundo, com intervalos emparelhados: exatidão efetiva (abstenções contam como não acertos), cobertura, erro entre previsões emitidas, alarmes de inadequação verdadeiros/falsos, classificação pontual/estruturada/inconclusiva, custo de consultas e ganho contra cada comparador.

Após o piloto, fazer uma análise de potência e congelar gates numéricos antes de abrir confirmação. Os gates têm de incluir:

- **Segurança POINT:** limite superior pré-definido para erros emitidos adicionais face a consenso e suspensão; penalizar alarmes falsos que levem a generalizações incorretas.
- **Benefício OUT_OF_CLASS:** ganho mínimo pré-definido de exatidão efetiva ou redução de erro, com intervalo emparelhado a excluir zero.
- **Utilidade LOCAL/CROSS:** ganho com cobertura mínima, para evitar que abstenção total pareça sucesso.
- **CLEAN:** preservar previsões corretas e evitar alarmes persistentes sem contradição.
- Não promover se qualquer gate de segurança falhar; publicar também resultados nulos e todas as condições.

## Controlos contra fuga e sobreajuste

- Guardar parâmetros verdadeiros, mecanismos, alvos externos e sementes de confirmação em private/; a política nunca os recebe.
- Confirmar que os quatro braços recebem exatamente as mesmas observações iniciais, orçamento, respostas e pontos de avaliação.
- Comprometer hashes das previsões externas antes de calcular as métricas.
- Guardar replays fora dos resultados oficiais e manter auditorias originais, incluindo emendas audit-only.
- Não usar private_truth.jsonl para treino, seleção de modelo, escolha de consultas ou ajuste da DSL.
- O piloto serve para depurar e estimar variância; não conta como confirmação nem escolhe resultados a reportar.

## Critério para iniciar o piloto

Antes do piloto, especificar a função de pontuação da regra do passo 4, o gerador periódico OUT_OF_CLASS, as sementes de cada divisão e a unidade de análise. Rever a agenda para demonstrar que nenhum braço vê pontos externos. Depois, executar apenas desenvolvimento/piloto em diretórios temporários. Gates numéricos e hashes de confirmação só são congelados após o piloto e antes de gerar qualquer confirmação.
