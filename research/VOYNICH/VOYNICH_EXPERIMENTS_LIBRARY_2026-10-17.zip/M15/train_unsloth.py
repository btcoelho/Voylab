"""Unsloth SFT entry point for the M15 synthetic query-policy pilot."""
import argparse
import hashlib
import json
from pathlib import Path

from unsloth import FastLanguageModel
from datasets import load_dataset
from trl import SFTConfig, SFTTrainer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).resolve().parent / "data/sft")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "runs/unsloth-m15-r2-explicit-agenda")
    parser.add_argument("--smoke", action="store_true", help="Run one optimizer step and save only to /tmp")
    args = parser.parse_args()
    if args.smoke:
        args.output = Path("/tmp/voynich-m15-unsloth-smoke")
    if not (args.data / "train.jsonl").exists() or not (args.data / "validation.jsonl").exists():
        raise SystemExit("Run generate_sft.py and audit_sft.py before training.")

    model_name = "unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit"
    max_length = 1024
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=model_name,
        max_seq_length=max_length,
        dtype=None,
        load_in_4bit=True,
    )
    model = FastLanguageModel.get_peft_model(
        model,
        r=8,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        lora_alpha=16,
        lora_dropout=0,
        bias="none",
        use_gradient_checkpointing="unsloth",
        random_state=3407,
        use_rslora=False,
        loftq_config=None,
    )
    data = load_dataset("json", data_files={
        "train": str(args.data / "train.jsonl"),
        "validation": str(args.data / "validation.jsonl"),
    })
    config = SFTConfig(
        output_dir=str(args.output),
        max_length=max_length,
        per_device_train_batch_size=2,
        per_device_eval_batch_size=2,
        gradient_accumulation_steps=4,
        learning_rate=2e-4,
        num_train_epochs=3,
        warmup_steps=8,
        weight_decay=0.01,
        lr_scheduler_type="cosine",
        logging_steps=1 if args.smoke else 10,
        eval_strategy="steps" if args.smoke else "epoch",
        eval_steps=1 if args.smoke else None,
        save_strategy="no" if args.smoke else "epoch",
        load_best_model_at_end=False,
        completion_only_loss=True,
        assistant_only_loss=False,
        dataset_num_proc=1,
        packing=False,
        report_to="none",
        seed=3407,
        data_seed=3407,
        max_steps=1 if args.smoke else -1,
        bf16=True,
        gradient_checkpointing=True,
        optim="adamw_8bit",
    )
    trainer = SFTTrainer(
        model=model,
        args=config,
        train_dataset=data["train"],
        eval_dataset=data["validation"],
        processing_class=tokenizer,
    )
    trainer.train()
    if not args.smoke:
        trainer.save_model(str(args.output / "adapter"))
        tokenizer.save_pretrained(str(args.output / "adapter"))
        data_manifest = (args.data / "manifest.json").read_bytes()
        run_manifest = {
            "purpose": "synthetic M15 query-policy imitation pilot",
            "base_model": model_name,
            "dataset_manifest_sha256": hashlib.sha256(data_manifest).hexdigest(),
            "train_examples": len(data["train"]),
            "validation_examples": len(data["validation"]),
            "epochs": 3,
            "max_length": max_length,
            "effective_batch_size": 8,
            "learning_rate": 2e-4,
            "warmup_steps": 8,
            "lora_rank": 8,
            "lora_alpha": 16,
            "seed": 3407,
            "training_log_history": trainer.state.log_history,
            "claim_limit": "Imitation of a synthetic next-query policy; not a Voynich decoder or evidence of historical interpretation.",
        }
        (args.output / "run_manifest.json").write_text(json.dumps(run_manifest, indent=2) + "\n")
        (args.output / "adapter/README.md").write_text(
            "# M15 synthetic query-policy adapter\n\n"
            f"Base model: `{model_name}`.\n\n"
            "This LoRA adapter imitates a deterministic query-selection teacher on synthetic M14 development worlds. "
            "It is not trained on Voynich/Egerton folios and is not a manuscript decoder. Its 100% exact match is on "
            "a held-out split from the same development generator, with the available query queue supplied in the prompt. "
            "It is a technical pilot, not a sealed scientific confirmation. See the parent M15 report and run manifest.\n"
        )
    print(f"Training complete. smoke={args.smoke}; output={args.output}")


if __name__ == "__main__":
    main()
