# M15 — Unsloth SFT pilot

**Status:** the first Unsloth adapter and an improved second adapter were trained. The second adapter passes the held-out action-format and imitation check. This is an engineering pilot; it does not count as the preregistered scientific confirmation described in `PROTOCOL_DRAFT.md`.

## Agent scope

The adapter selects the next query for the synthetic 4-context × 16-position task used by M14. It receives public parameters, already-observed values, a priority flag, and the available diagnostic or coverage query queue. It returns one JSON query. It does not interpret Voynich glyphs, decode the manuscript, or make historical claims. No Voynich/Egerton folio data were used.

## Data and leakage controls

- Source: M14's development-world generator only (`private/dev_worlds.py`); four synthetic conditions, 80 worlds total.
- Split: 64 whole worlds for training and 16 whole worlds for validation, stratified across CLEAN, CROSS, LOCAL, and POINT. No world appears in both splits.
- Size: 768 training actions and 192 validation actions (12 sequential decisions per world).
- Each answer is inserted into the observed history only after the policy has selected that query. World IDs, condition labels, generator truth tables, anomaly positions, confirmation/transfer runs, external evaluation points, and Voynich/Egerton data are not placed in prompts.
- The exact JSONL files and split are recorded in `data/sft/manifest.json`; `audit_sft.py` verifies hashes, split disjointness, schema, and that each target is the first available query under the stated priority.

## Training and evaluation

- Base: `unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit`; LoRA rank 8, alpha 16; three epochs; 288 optimizer steps; batch size 8 after accumulation; maximum sequence length 1024.
- Hardware/runtime: RTX 4070 (12 GB), CUDA; Unsloth 2026.10.6, TRL 1.15.0, Transformers 5.17.0. A one-step smoke run also completed before the full run.
- Adapter: `runs/unsloth-m15-r2-explicit-agenda/adapter`.
- Validation generation: 192/192 JSON outputs parsed, 192/192 were in-domain and not previously queried, and 192/192 exactly matched the teacher's next action. Exact match was 48/48 in each of the four conditions.
- The initial prompt format omitted the pseudo-random coverage queue derived from an M14 hash. Its first adapter had 59.4% exact match and repeated five queries. That adapter was not selected. Version 2 exposes the available query queue, and its 100% match demonstrates reliable imitation/copying of this explicit queue on held-out development worlds.

## Limits and next scientific step

The 100% figure is not evidence that the model independently inferred the policy, discovered hidden mechanisms, or generalizes to new generator families: the prompt provides the candidate query queue and the target is its first item. Validation worlds share the M14 development generator, so this is not confirmation. The adapted model is ready for controlled Unsloth use on this narrow synthetic task; it must not be presented as a Voynich decoder. Any claim about policy benefits requires the separately frozen M15 protocol, an independent generator, sealed confirmation worlds, and comparison against deterministic baselines.
