"""Deterministic, public-history-only M15 query policy for the synthetic pilot."""
from __future__ import annotations

from core import DOMAIN, INITIAL, fit_baselines, fit_repairs, select_queries, baseline


def _compatible_predictors(params, observed):
    ks = fit_baselines(params, observed)
    if not ks:
        return []
    has_baseline_contradiction = any(
        row["t"] >= 2 and all(baseline(params, row["t"], row["x"], k) != row["y"] for k in ks)
        for row in observed
    )
    if not has_baseline_contradiction:
        return [(lambda t, x, k=k: baseline(params, t, x, k)) for k in ks]
    repairs = fit_repairs(params, observed, ks)
    if not repairs:
        return [(lambda t, x, k=k: baseline(params, t, x, k)) for k in ks]
    from core import repair_predict
    return [(lambda t, x, h=h: repair_predict(params, h, t, x)) for h in repairs]


def _new_common_contradiction(params, initial, observations):
    """Return an observed point incompatible with every prior compatible repair."""
    for index, row in enumerate(observations):
        if row["t"] < 2:
            continue
        predictors = _compatible_predictors(params, initial + observations[:index])
        if not predictors:
            continue
        if all(p(row["t"], row["x"]) != row["y"] for p in predictors):
            return (row["t"], row["x"])
    return None


def _nearest_unseen(t, x, seen):
    candidates = [(t, z) for z in range(16) if (t, z) not in seen]
    return min(candidates, key=lambda p: (abs(p[1] - x), p[1])) if candidates else None


def diagnostic_packet(origin, seen):
    """Two adjacent points in the implicated context and same-x controls elsewhere."""
    t, x = origin
    packet = []
    for z in (x - 1, x + 1):
        if 0 <= z < 16:
            point = _nearest_unseen(t, z, seen | set(packet))
            if point is not None:
                packet.append(point)
    other_contexts = [q for q in range(4) if q != t]
    for q in other_contexts[:2]:
        point = _nearest_unseen(q, x, seen | set(packet))
        if point is not None:
            packet.append(point)
    return packet


def choose_query(params, initial, observations, agenda, alarm_origin, diagnostic_queue):
    """Select one next query; only params and already-observed values are inputs."""
    seen = {(r["t"], r["x"]) for r in initial + observations}
    if diagnostic_queue:
        while diagnostic_queue and diagnostic_queue[0] in seen:
            diagnostic_queue.pop(0)
        if diagnostic_queue:
            return diagnostic_queue.pop(0), alarm_origin, diagnostic_queue, "diagnostic"

    origin = _new_common_contradiction(params, initial, observations)
    if origin is not None and origin != alarm_origin:
        diagnostic_queue = diagnostic_packet(origin, seen)
        if diagnostic_queue:
            return diagnostic_queue.pop(0), origin, diagnostic_queue, "diagnostic"

    for point in agenda:
        if point not in seen:
            return point, alarm_origin, diagnostic_queue, "coverage"
    # This is only a safety fallback; normal episodes have twelve agenda points.
    for point in DOMAIN:
        if point not in seen:
            return point, alarm_origin, diagnostic_queue, "fallback"
    raise RuntimeError("no unobserved query remains")


def trace_episode(world, budget=12):
    """Build public observations by querying a development world as the policy acts."""
    params = world["params"]
    table = world["table"]
    initial = [{"t": t, "x": x, "y": table[16*t+x]} for t, x in INITIAL]
    agenda = select_queries(params, initial)
    observations = []
    decisions = []
    alarm_origin = None
    diagnostic_queue = []
    for step in range(budget):
        point, alarm_origin, diagnostic_queue, priority = choose_query(
            params, initial, observations, agenda, alarm_origin, diagnostic_queue
        )
        t, x = point
        prompt = {
            "task": "choose_next_query",
            "domain": {"contexts": 4, "positions_per_context": 16},
            "parameters": params,
            "initial_observations": list(initial),
            "observations": list(observations),
            "remaining_budget": budget - step,
            "known_alarm": list(alarm_origin) if alarm_origin else None,
            "priority": priority,
            "diagnostic_queries_pending": ([list(point)] + [list(p) for p in diagnostic_queue]
                                           if priority == "diagnostic" else []),
            "coverage_agenda_remaining": [list(p) for p in agenda
                                          if p not in {(r["t"], r["x"]) for r in initial + observations}],
            "rule": "If priority is diagnostic, choose the first diagnostic query still pending. Otherwise choose the first remaining coverage query. Never query a seen point or infer hidden truth.",
        }
        decisions.append((prompt, {"action": "query", "t": t, "x": x}))
        observations.append({"t": t, "x": x, "y": table[16*t+x]})
    return decisions
