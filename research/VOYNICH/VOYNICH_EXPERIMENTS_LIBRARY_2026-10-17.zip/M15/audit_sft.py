"""Structural, split, and serialization checks for the generated pilot corpus."""
import argparse
import hashlib
import json
import pathlib


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("data", type=pathlib.Path)
    args = p.parse_args()
    manifest = json.loads((args.data / "manifest.json").read_text(encoding="utf-8"))
    train, valid = rows(args.data / "train.jsonl"), rows(args.data / "validation.jsonl")
    assert manifest["confirmation_or_transfer_used"] is False
    assert manifest["private_truth_exported"] is False
    train_ids = {x["world_id"] for x in manifest["world_split"]["train"]}
    valid_ids = {x["world_id"] for x in manifest["world_split"]["validation"]}
    assert train_ids and valid_ids and train_ids.isdisjoint(valid_ids)
    assert len(train_ids) == 64 and len(valid_ids) == 16
    assert len(train) == 64 * 12 and len(valid) == 16 * 12
    for name, records in (("train", train), ("validation", valid)):
        digest = hashlib.sha256((args.data / f"{name}.jsonl").read_bytes()).hexdigest()
        assert digest == manifest["sha256"][name]
        for row in records:
            assert set(row) == {"prompt", "completion"}
            assert len(row["prompt"]) == len(row["completion"]) == 1
            assert row["prompt"][0]["role"] == "user"
            assert row["completion"][0]["role"] == "assistant"
            prompt = json.loads(row["prompt"][0]["content"])
            answer = json.loads(row["completion"][0]["content"])
            assert set(answer) == {"action", "t", "x"} and answer["action"] == "query"
            assert 0 <= answer["t"] < 4 and 0 <= answer["x"] < 16
            options = (prompt["diagnostic_queries_pending"] if prompt["priority"] == "diagnostic"
                       else prompt["coverage_agenda_remaining"])
            assert options and options[0] == [answer["t"], answer["x"]]
            assert prompt["remaining_budget"] in range(1, 13)
            seen = {(r["t"], r["x"]) for r in prompt["initial_observations"] + prompt["observations"]}
            assert (answer["t"], answer["x"]) not in seen
            assert not ({"world_id", "condition", "truth", "table", "anomaly_positions", "private"}
                        & set(prompt))
    print(json.dumps({"status": "PASS", "worlds_train": len(train_ids),
                      "worlds_validation": len(valid_ids), "examples_train": len(train),
                      "examples_validation": len(valid)}, indent=2))


if __name__ == "__main__":
    main()
