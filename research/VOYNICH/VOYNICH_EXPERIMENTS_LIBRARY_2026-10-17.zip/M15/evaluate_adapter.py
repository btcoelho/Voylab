"""Greedy exact-action evaluation on world-held-out M15 validation examples."""
import argparse
import hashlib
import json
import re
from pathlib import Path

from unsloth import FastLanguageModel
import torch


def extract_action(text):
    match = re.search(r"\{[^{}]*\}", text)
    if not match:
        return None
    try:
        value = json.loads(match.group(0))
    except json.JSONDecodeError:
        return None
    if set(value) != {"action", "t", "x"} or value.get("action") != "query":
        return None
    if not isinstance(value["t"], int) or not isinstance(value["x"], int):
        return None
    return value


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", type=Path, default=Path(__file__).resolve().parent / "data/sft")
    p.add_argument("--adapter", type=Path, default=Path(__file__).resolve().parent / "runs/unsloth-m15-r2-explicit-agenda/adapter")
    args = p.parse_args()
    rows = [json.loads(line) for line in (args.data / "validation.jsonl").read_text().splitlines() if line]
    manifest = json.loads((args.data / "manifest.json").read_text(encoding="utf-8"))
    validation_worlds = manifest["world_split"]["validation"]
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=str(args.adapter), max_seq_length=1024, dtype=None, load_in_4bit=True
    )
    FastLanguageModel.for_inference(model)
    model.generation_config.max_length = 1024
    tokenizer.padding_side = "left"
    tokenizer.pad_token = tokenizer.pad_token or tokenizer.eos_token
    exact = valid_json = in_domain = actionable = 0
    grouped = {}
    predictions = []
    for start in range(0, len(rows), 8):
        batch_rows = rows[start:start + 8]
        prompts = [tokenizer.apply_chat_template(
            row["prompt"], tokenize=False, add_generation_prompt=True
        ) for row in batch_rows]
        inputs = tokenizer(prompts, return_tensors="pt", padding=True, truncation=True,
                           max_length=1024).to(model.device)
        with torch.inference_mode():
            output = model.generate(**inputs, max_new_tokens=48, do_sample=False,
                                    pad_token_id=tokenizer.pad_token_id)
        decoded = tokenizer.batch_decode(output[:, inputs["input_ids"].shape[1]:], skip_special_tokens=True)
        for offset, (row, text) in enumerate(zip(batch_rows, decoded)):
            row_index = start + offset
            expected = json.loads(row["completion"][0]["content"])
            actual = extract_action(text)
            is_json = actual is not None
            is_in_domain = is_json and 0 <= actual["t"] < 4 and 0 <= actual["x"] < 16
            prompt = json.loads(row["prompt"][0]["content"])
            seen = {(r["t"], r["x"]) for r in prompt["initial_observations"] + prompt["observations"]}
            is_actionable = is_in_domain and (actual["t"], actual["x"]) not in seen
            is_exact = is_actionable and actual == expected
            valid_json += int(is_json)
            in_domain += int(is_in_domain)
            actionable += int(is_actionable)
            exact += int(is_exact)
            condition = validation_worlds[row_index // 12]["condition"]
            group = grouped.setdefault(condition, {"exact": 0, "examples": 0})
            group["exact"] += int(is_exact)
            group["examples"] += 1
            predictions.append({"expected": expected, "generated": text.strip(),
                                "parsed": actual, "valid_json": bool(is_json),
                                "in_domain": bool(is_in_domain), "actionable": bool(is_actionable),
                                "exact": bool(is_exact), "condition": condition})
    for value in grouped.values():
        value["exact_match_rate"] = value["exact"] / value["examples"]
    result = {"examples": len(rows), "valid_json_actions": valid_json,
              "valid_json_rate": valid_json / len(rows), "in_domain_actions": in_domain,
              "actionable_unseen_actions": actionable, "actionable_rate": actionable / len(rows),
              "exact_actions": exact,
              "exact_match_rate": exact / len(rows),
              "by_condition": grouped,
              "adapter": str(args.adapter),
              "dataset_manifest_sha256": hashlib.sha256((args.data / "manifest.json").read_bytes()).hexdigest()}
    out = args.adapter.parent / "validation_generation.jsonl"
    out.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in predictions), encoding="utf-8")
    (args.adapter.parent / "validation_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
