"""Generate leakage-controlled SFT examples from M14 development worlds only."""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
M14 = ROOT / "dados/m14/VOYNICH_M14_REPARACOES_CONCORRENTES_2026-10-17"
sys.path.insert(0, str(M14 / "src"))
sys.path.insert(0, str(M14 / "private"))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

from dev_worlds import worlds  # noqa: E402
from adaptive_policy import trace_episode  # noqa: E402


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        for row in rows:
            f.write(canonical(row) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=pathlib.Path, default=ROOT / "experiencias/M15/data/sft")
    args = parser.parse_args()

    worlds_by_condition = {}
    for world in worlds(20):
        worlds_by_condition.setdefault(world["condition"], []).append(world)
    train_rows, validation_rows, split = [], [], {}
    for condition, condition_worlds in sorted(worlds_by_condition.items()):
        for index, world in enumerate(sorted(condition_worlds, key=lambda w: w["id"])):
            # Every fifth world is held out; selection is within condition.
            destination = "validation" if index % 5 == 0 else "train"
            split.setdefault(destination, []).append({"condition": condition, "world_id": world["id"]})
            destination_rows = validation_rows if destination == "validation" else train_rows
            for prompt, answer in trace_episode(world):
                destination_rows.append({
                    "prompt": [{"role": "user", "content": canonical(prompt)}],
                    "completion": [{"role": "assistant", "content": canonical(answer)}],
                })

    write_jsonl(args.out / "train.jsonl", train_rows)
    write_jsonl(args.out / "validation.jsonl", validation_rows)
    manifest = {
        "dataset": "M15 synthetic query-policy imitation",
        "source": "M14 development generator only; queried values appear only after the policy asks for them",
        "confirmation_or_transfer_used": False,
        "private_truth_exported": False,
        "world_split": split,
        "examples": {"train": len(train_rows), "validation": len(validation_rows)},
        "sha256": {
            name: hashlib.sha256((args.out / f"{name}.jsonl").read_bytes()).hexdigest()
            for name in ("train", "validation")
        },
    }
    (args.out / "manifest.json").write_text(canonical(manifest) + "\n", encoding="utf-8")
    print(json.dumps({"train": len(train_rows), "validation": len(validation_rows),
                      "worlds": {k: len(v) for k, v in split.items()},
                      "out": str(args.out)}, indent=2))


if __name__ == "__main__":
    main()
