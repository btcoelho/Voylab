"""M12 competing hypotheses: deterministic and NOT a trained AI model.
Only receives public programs, allowed actions and observations, never oracle truth.
"""
import hashlib,json
ACTIONS=tuple((t,x) for t in range(4) for x in range(16))
INITIAL=tuple((0,x) for x in range(0,16,2))
POLICIES=('auto_fixed','eliminate_fixed','validate_fixed','eliminate_active','validate_active')

def digest(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def features(q):
    t,x=q
    return ((t==1 and (x&1)!=0 and (x&2)!=0),(t==2 and (x&1)!=0 and (x&4)!=0))

def predict(p,q):
    t,x=q
    base=p['constant']
    for i,c in enumerate(p['x_coef']):
        if x>>i & 1:base^=c
    base ^=p['t_coef'][t]
    f=features(q)[p['operator']]
    return base^(p['mask'] if f else 0)

def compatible(candidates,obs):
    return [i for i,p in enumerate(candidates) if all(predict(p,q)==v for q,v in obs.items())]

def choose_discovery(initial,candidates,allowed,mode):
    pool=[q for q in allowed if q not in initial]
    public_seed=digest(sorted([(list(k),v) for k,v in initial.items()]))
    if mode=='fixed':
        # Static truth-blind random-like ordering, fixed across all worlds, independent of oracle state.
        return sorted(pool,key=lambda q:digest(['fixed',public_seed,q]))[:4]
    # Static active disagreement order; all candidate choices made without oracle feedback.
    pool=sorted(pool,key=lambda q:(-int(predict(candidates[0],q)!=predict(candidates[1],q)),digest(['active',public_seed,q])))
    return pool[:4]

def choose_validation(initial,candidates,allowed,discovery):
    # Independent, protocol-fixed deterministic observation sampler. No access to answer.
    pool=[q for q in allowed if q not in initial and q not in discovery]
    public_seed=digest(sorted([(list(k),v) for k,v in initial.items()]))
    return sorted(pool,key=lambda q:digest(['independent-validation',public_seed,q]))[:4]

def consensus(candidates,indices,q):
    pred=[predict(candidates[i],q) for i in indices]
    return pred[0] if pred and len(set(pred))==1 else None

def investigate(api,policy):
    if policy not in POLICIES:raise ValueError(policy)
    candidates=api.candidates()
    initial=api.initial()
    allowed=api.available()
    if len(candidates)!=2 or len(initial)!=8:raise ValueError('invalid protocol')
    mode='active' if policy.endswith('active') else 'fixed'
    discovery=choose_discovery(initial,candidates,allowed,mode)
    validation=choose_validation(initial,candidates,allowed,discovery)
    obs=dict(initial)
    ledger=[]
    for q in discovery:
        prior=compatible(candidates,obs)
        row={'phase':'discovery','action':list(q),'predictions':[predict(p,q) for p in candidates],
             'surviving_prior':prior,'evidence_hash':digest(sorted([(list(k),v) for k,v in obs.items()])),
             'rule':'Reject a model only after an observable disagreement'}
        row['precommit']=digest(row)
        v=api.probe(q);row['observed']=v;obs[q]=v;ledger.append(row)
    pre_valid=compatible(candidates,obs)
    proposals=[]
    for i in pre_valid:
        proposal={'candidate_index':i,'defining_observations':len(obs),'defining_hash':digest(sorted([(list(k),v) for k,v in obs.items()])),
                  'contradiction_aim':'A newly observed output that differs from the candidate would falsify it',
                  'validation_actions':[list(q) for q in validation],
                  'validation_forecast':[predict(candidates[i],q) for q in validation],
                  'rejection_rule':'Reject if any precommitted validation prediction is false',
                  'acceptance':'Only provisional; not a global or historical identity assertion'}
        proposal['precommit']=digest(proposal)
        proposals.append(proposal)
    for q in validation:
        row={'phase':'independent_validation','action':list(q),'predictions':[predict(p,q) for p in candidates],
             'surviving_prior':compatible(candidates,obs),'evidence_hash':digest(sorted([(list(k),v) for k,v in obs.items()])),
             'rule':'Do not fit/rewrite a proposal after the validation answer'}
        row['precommit']=digest(row)
        v=api.probe(q);row['observed']=v;obs[q]=v;ledger.append(row)
    survived=compatible(candidates,obs)
    if policy=='auto_fixed':
        # Select candidate index 0 without falsification audit; still withdraw if direct contradiction observed.
        accepted=[0] if 0 in survived else []
    elif policy.startswith('eliminate'):
        accepted=survived
    else:
        # Distinct from simple elimination: require a provisional proposal based on discovery,
        # AND >=1 validation that separated the two candidates (otherwise no exclusive verdict).
        forecaster_indices=[p['candidate_index'] for p in proposals]
        discriminants=sum(predict(candidates[0],q)!=predict(candidates[1],q) for q in validation)
        if len(survived)==1 and survived[0] in forecaster_indices and discriminants>=1:
            accepted=survived
        elif len(survived)==2:accepted=survived   # equivalence class; no exclusive origin
        else:accepted=[]
    status=('INADEQUATE' if not survived else ('UNDERDETERMINED' if len(survived)==2 else 'ONE_COMPATIBLE'))
    claimed_exclusive=bool(len(accepted)==1)
    queried=set(initial)|set(discovery)|set(validation)
    outputs={f'{t},{x}':consensus(candidates,accepted,(t,x)) for (t,x) in ACTIONS if (t,x) not in queried}
    return {'policy':policy,'initial_count':len(initial),'query_count':len(ledger),'queried':[[t,x] for t,x in discovery+validation],
            'discovery_count':4,'validation_count':4,'candidate_count_start':2,'prevalid_survivors':pre_valid,
            'final_survivors':survived,'accepted_indices':accepted,'status':status,
            'exclusive_functional_claim':claimed_exclusive,'certified_origin':False,
            'proposals':proposals,'ledger':ledger,'predictions':outputs,
            'agent_type':'deterministic_program_not_LLM'}
