"""Reproducible paired experiment. Run dev first, then freeze protocol, then confirmation."""
import argparse,collections,json,sys
from pathlib import Path
from investigator import ACTIONS,INITIAL,POLICIES,investigate,predict,digest

class PublicAPI:
    def __init__(self,world):
        self._cand=world['programs'];self._init=world['initial'];self._allowed=world['allowed'];self._answer=world['answers']
        self._seen=set(self._init);self.probed=[]
    def candidates(self):return json.loads(json.dumps(self._cand))
    def initial(self):return dict(self._init)
    def available(self):return tuple(self._allowed)
    def probe(self,q):
        if q not in self._allowed or q in self._seen or len(self.probed)>=8:raise ValueError('invalid oracle query')
        self._seen.add(q);self.probed.append(q);return self._answer[q]

def one_world(world,policy):
    api=PublicAPI(world);run=investigate(api,policy)
    excluded=set(world['initial'])|set(api.probed)
    truth={f'{t},{x}':v for (t,x),v in world['answers'].items() if (t,x) not in excluded}
    assert len(truth)==48 and len(run['predictions'])==48 and set(truth)==set(run['predictions'])
    right=sum(p is not None and p==truth[k] for k,p in run['predictions'].items())
    issued=sum(p is not None for p in run['predictions'].values());wrong=issued-right
    exclusive_bad=bool(run['exclusive_functional_claim'] and world['kind'] in ('NONE','AMBIGUOUS'))
    return run,dict(kind=world['kind'],world_id=world['id'],policy=policy,seed_index=world['index'],right=right,wrong=wrong,issued=issued,
                    total=48,coverage=issued/48,effective=right/48,error=wrong/issued if issued else None,
                    exclusive_bad=exclusive_bad,true_origin=world['true_origin'],status=run['status'],accepted=run['accepted_indices'])

def aggregate(rows):
    out={}
    groups=collections.defaultdict(list)
    for r in rows:groups[r['kind'],r['policy']].append(r)
    for (kind,policy),group in sorted(groups.items()):
        n=len(group);right=sum(r['right'] for r in group);wrong=sum(r['wrong'] for r in group);issued=sum(r['issued'] for r in group)
        out[f'{kind}/{policy}']=dict(worlds=n,coverage=issued/(48*n),effective_accuracy=right/(48*n),
              selective_error=wrong/issued if issued else None,issued=issued,right=right,wrong=wrong,
              wrong_exclusive_worlds=sum(r['exclusive_bad'] for r in group),accepted_worlds=sum(len(r['accepted'])==1 for r in group),
              ambiguous_worlds=sum(len(r['accepted'])==2 for r in group))
    return out

def run(stage,out):
    if stage=='development':from development_oracle import build; count=20; offset=0
    else:from confirmation_oracle import build;count=100;offset=20000
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    runs=[];score=[];truth=[]
    for kind in ('ONE','NONE','AMBIGUOUS'):
        for j in range(offset,offset+count):
            world=build(kind,j)
            truth.append({'id':world['id'],'kind':kind,'index':j,'answers':[world['answers'][q] for q in ACTIONS],
                          'true_origin':world['true_origin'],'allowed':[list(q) for q in world['allowed']]})
            for policy in POLICIES:
                agent_row,sc=one_world(world,policy)
                agent_row['world_id']=world['id'];agent_row['kind_hidden_from_agent']=None
                runs.append(agent_row);score.append(sc)
    assert len(runs)==count*3*len(POLICIES)
    for file,data in [('public_runs.jsonl',runs),('scores.jsonl',score),('private_truth.jsonl',truth)]:
        with open(out/file,'w') as f:
            for row in data:f.write(json.dumps(row,sort_keys=True)+'\n')
    summary=dict(stage=stage,worlds=len(truth),arms=len(POLICIES),executions=len(runs),
         oracle='separate private confirm implementation' if stage=='confirmation' else 'development oracle',groups=aggregate(score))
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['development','confirmation'],required=True);ap.add_argument('--out',required=True)
    args=ap.parse_args();run(args.stage,args.out)
