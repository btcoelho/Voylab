# M12 — Extensões concorrentes (17-10-2026)

**Decisão: NÃO promover a regra de validação**. Desenvolvimento: 60 mundos; confirmação: 300 mundos; 5 braços, mesmo orçamento; 10 testes; auditoria 23.129 verificações sem falhas e 495 reexecuções iguais. Gates científicos: 2/5.

- `RELATORIO_CIENTIFICO_M12_CONCORRENTES.md`: relatório completo.
- `RESULTADOS_RESUMO_M12_CONCORRENTES.txt`: sumário curto.
- `src/`: investigador determinístico e runner; `private/`: geradores e verdade, apenas para reprodução.
- `results/development` e `results/confirmation`: registos, previsões e pontuações individuais.
- `protocol/`: especificações e hashes congelados antes da confirmação.
- `audit/`: verificador, inferência por mundo, e alteração exclusiva da auditoria.
- `reference/`: ZIP M12 piloto anterior não alterado.

A confirmação foi efetuada após o congelamento, num gerador Python separado mas com famílias de mecanismos especificadas pelo mesmo protocolo. Não foi usado qualquer manuscrito histórico. Não implica LLM multiagente nem descoberta aberta de mecanismos.
