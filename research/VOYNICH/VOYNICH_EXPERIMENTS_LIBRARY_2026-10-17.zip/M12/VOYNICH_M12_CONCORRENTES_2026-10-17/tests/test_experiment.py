import unittest
from investigator import ACTIONS,INITIAL,predict,compatible,choose_discovery,choose_validation,digest,investigate
from development_oracle import build
from experiment import PublicAPI,one_world

class Tests(unittest.TestCase):
    def test_initial_ambiguity(self):
        for kind in ('ONE','NONE','AMBIGUOUS'):
            for j in range(12):
                w=build(kind,j)
                self.assertEqual(compatible(w['programs'],w['initial']),[0,1])
    def test_candidate_correct_on_one(self):
        for j in range(12):
            w=build('ONE',j)
            self.assertTrue(all(predict(w['programs'][w['true_origin']],q)==v for q,v in w['answers'].items()))
    def test_neither_correct_none(self):
        for j in range(12):
            w=build('NONE',j)
            for p in w['programs']:
                self.assertTrue(any(predict(p,q)!=v for q,v in w['answers'].items()))
    def test_unidentifiable_available_ambiguous(self):
        for j in range(12):
            w=build('AMBIGUOUS',j)
            self.assertTrue(all(predict(w['programs'][0],q)==predict(w['programs'][1],q) for q in w['allowed']))
            self.assertTrue(any(predict(w['programs'][0],q)!=predict(w['programs'][1],q) for q in ACTIONS))
    def test_identifiability_one(self):
        w=build('ONE',0);self.assertTrue(any(predict(w['programs'][0],q)!=predict(w['programs'][1],q) for q in w['allowed']))
    def test_query_limits(self):
        w=build('ONE',9);api=PublicAPI(w)
        for q in choose_discovery(w['initial'],w['programs'],w['allowed'],'fixed'):api.probe(q)
        with self.assertRaises(ValueError):api.probe(next(iter(w['initial'])))
    def test_determinism(self):
        w=build('NONE',10);a=one_world(w,'validate_active')[0];b=one_world(w,'validate_active')[0]
        self.assertEqual(digest(a),digest(b))
    def test_matched_queries(self):
        w=build('NONE',9)
        a=one_world(w,'eliminate_active')[0];b=one_world(w,'validate_active')[0]
        self.assertEqual(a['queried'],b['queried'])
    def test_precommit_hash(self):
        w=build('ONE',7);r=one_world(w,'validate_fixed')[0]
        for row in r['ledger']:
            tmp={k:v for k,v in row.items() if k not in ('observed','precommit')}
            self.assertEqual(digest(tmp),row['precommit'])
        for prop in r['proposals']:
            self.assertEqual(digest({k:v for k,v in prop.items() if k!='precommit'}),prop['precommit'])
    def test_no_revert_after_refutation(self):
        # When no candidates remain, no predictions are emitted.
        w=build('NONE',3);r=one_world(w,'validate_active')[0]
        if r['final_survivors']==[]:self.assertEqual(sum(x is not None for x in r['predictions'].values()),0)

if __name__=='__main__':unittest.main()
