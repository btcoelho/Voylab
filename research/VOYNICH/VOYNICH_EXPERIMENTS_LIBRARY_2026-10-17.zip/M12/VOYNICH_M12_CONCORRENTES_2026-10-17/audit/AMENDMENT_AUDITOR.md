# Auditoria pós-confirmação: alterações exclusivas ao verificador
A primeira execução do novo auditor falhou por dois erros do próprio verificador, **sem qualquer alteração aos ficheiros científicos congelados**:
1. Uma variável indefinida em uma expressão de índice diagnosticou NameError antes de completar a auditoria.
2. O verificador inicialmente usou o gerador de **confirmação** para revalidar os mundos de **desenvolvimento**, provocando falsos avisos `NON_SINGLE_ANOMALY` nos 20 mundos de desenvolvimento `NONE`.
Corrigiu-se apenas `audit/audit_and_stats.py`, que **não faz parte dos 7 ficheiros científicos congelados**. Os dados, simulações, regras, sementes, código do investigador, geradores, métricas e critérios de promoção mantiveram-se inalterados. A execução após a correção registou `PASS`: 23.129 verificações sem falhas, 495 replays coincidentes. A auditoria é interna.
