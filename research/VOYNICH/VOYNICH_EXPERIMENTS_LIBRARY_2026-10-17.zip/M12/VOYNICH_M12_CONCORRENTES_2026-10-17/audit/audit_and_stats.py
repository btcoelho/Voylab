"""Post-confirmation independent verifier; does not modify frozen scientist or oracle files."""
import collections,hashlib,json,random,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'private')]
from investigator import ACTIONS,INITIAL,POLICIES,digest
from experiment import one_world
from confirmation_oracle import build as build_confirm
from development_oracle import build as build_dev

def load_jsonl(p):return [json.loads(line) for line in open(p,encoding='utf8')]
def boot_differences(a,b,field,n=5000,seed=20261017):
    rng=random.Random(seed);ids=sorted(set(a)&set(b));pairs=[a[z][field]-b[z][field] for z in ids]
    vals=[]
    for _ in range(n):
        vals.append(sum(pairs[rng.randrange(len(pairs))] for z in range(len(pairs)))/len(pairs))
    vals.sort();return {'paired_diff_mean':sum(pairs)/len(pairs),'CI95':[vals[int(.025*n)],vals[int(.975*n)]], 'worlds':len(ids)}

def main():
    checks=0;problems=[]
    freeze=json.loads((ROOT/'protocol/FREEZE_SHA256.json').read_text())
    for name,h in freeze['files'].items():
        checks+=1
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=h:problems.append('FROZEN_HASH_CHANGE '+name)
    if hashlib.sha256((ROOT/'results/development/summary.json').read_bytes()).hexdigest()!=freeze['dev_summary_sha256']:problems.append('DEV_SUMMARY_CHANGED')
    results={};same_obs=0;replays=0;anomaly_flags=collections.Counter()
    for stage in ('development','confirmation'):
        p=ROOT/'results'/stage
        rows=load_jsonl(p/'public_runs.jsonl');scores=load_jsonl(p/'scores.jsonl');truth=load_jsonl(p/'private_truth.jsonl')
        lookup={(s['world_id'],s['policy']):s for s in scores}
        case=dict()
        byworld=collections.defaultdict(dict)
        for row in rows:
            byworld[row['world_id']][row['policy']]=row
            for led in row['ledger']:
                checks+=1
                pre={k:v for k,v in led.items() if k not in ('observed','precommit')}
                if digest(pre)!=led['precommit']:problems.append('PRECOMMIT '+row['world_id'])
            for proposal in row['proposals']:
                checks+=1
                if digest({k:v for k,v in proposal.items() if k!='precommit'})!=proposal['precommit']:problems.append('PROPOSAL_PRECOMMIT '+row['world_id'])
            checks+=1
            if len(row['queried'])!=8 or len(set(map(tuple,row['queried'])))!=8:problems.append('QUERY_BUDGET '+row['world_id'])
            checks+=1
            if len(row['predictions'])!=48:problems.append('HOLDOUT_SIZE '+row['world_id'])
        for w in truth:
            wid=w['id'];case[w['id']]=w['kind']
            choices=byworld[wid]
            checks+=1
            if set(choices)!=set(POLICIES):problems.append('POLICY_SET '+wid)
            for a,b in [('eliminate_fixed','validate_fixed'),('eliminate_active','validate_active')]:
                checks+=1
                if choices[a]['queried']!=choices[b]['queried']:problems.append('PAIR_QUERY_MISMATCH '+wid)
                checks+=1
                if [(x['observed'],x['action']) for x in choices[a]['ledger']]!=[(x['observed'],x['action']) for x in choices[b]['ledger']]:problems.append('PAIR_RESPONSE_MISMATCH '+wid)
                else:same_obs+=1
            checkset=[q for q in ACTIONS if q not in INITIAL]
            if w['kind']=='NONE':
                # anomaly is point where the candidate closest to true generator differs
                actual={q:v for q,v in zip(ACTIONS,w['answers'])}
                generator=build_confirm if stage=='confirmation' else build_dev
                witness={q for q in checkset if actual[q]!=__import__('investigator').predict(generator(w['kind'],w['index'])['programs'][0],q)}
                checks+=1
                if len(witness)!=1:problems.append('NON_SINGLE_ANOMALY '+wid)
                for arm in POLICIES:
                    anomaly_flags[(stage,arm, 'seen' if witness&set(map(tuple,choices[arm]['queried'])) else 'unseen')]+=1
            if stage=='confirmation' and w['index']%3==0:
                # Replay 1/3 of worlds, every policy; evaluation recomputed from original oracle.
                world=build_confirm(w['kind'],w['index'])
                for arm in POLICIES:
                    rec,sc=one_world(world,arm)
                    rec['world_id']=world['id'];rec['kind_hidden_from_agent']=None
                    checks+=1;replays+=1
                    if digest(rec)!=digest(choices[arm]):problems.append('REPLAY '+wid+'/'+arm)
                    if digest(sc)!=digest(lookup[wid,arm]):problems.append('SCORE_REPLAY '+wid+'/'+arm)
        results[stage]=dict(worlds=len(truth),runs=len(rows),paired_equal_observation_pairs=len(truth)*2)
    confirm=load_jsonl(ROOT/'results/confirmation/scores.jsonl')
    ix={(k,p):{r['world_id']:r for r in confirm if r['kind']==k and r['policy']==p} for k in ('ONE','NONE','AMBIGUOUS') for p in POLICIES}
    contrasts={
       'ONE_validated_fixed_minus_elimination_fixed_effective':boot_differences(ix['ONE','validate_fixed'],ix['ONE','eliminate_fixed'],'effective'),
       'ONE_active_elimination_minus_fixed_elimination_effective':boot_differences(ix['ONE','eliminate_active'],ix['ONE','eliminate_fixed'],'effective'),
       'NONE_elimination_fixed_minus_validation_fixed_bad_exclusive':boot_differences({w:{**r,'bad':int(r['exclusive_bad'])} for w,r in ix['NONE','eliminate_fixed'].items()}, {w:{**r,'bad':int(r['exclusive_bad'])} for w,r in ix['NONE','validate_fixed'].items()},'bad'),
       'NONE_elimination_fixed_minus_validation_fixed_wrong_points':boot_differences(ix['NONE','eliminate_fixed'],ix['NONE','validate_fixed'],'wrong'),
       'ONE_validate_active_minus_eliminate_active_effective':boot_differences(ix['ONE','validate_active'],ix['ONE','eliminate_active'],'effective'),
    }
    # Truth-blind block-thinning comparator at V fixed coverage on NONE.
    # For each world, V_fixed outcomes must form a subset of E_fixed issued forecasts, hence matching coverage
    # can be obtained by randomly dropping the same number of full-world exclusive blocks.
    rng=random.Random(120126)
    all_rows=load_jsonl(ROOT/'results/confirmation/public_runs.jsonl');ridx={(r['world_id'],r['policy']):r for r in all_rows}
    E=ix['NONE','eliminate_fixed'];V=ix['NONE','validate_fixed']
    dropped=[w for w in E if E[w]['issued']>V[w]['issued']]
    num_drop=len(dropped);candidates=[w for w in E if E[w]['issued']==48 and V[w]['issued'] in (0,48)]
    # Calculate risk over 5k truth-blind random sets of comparable full-world blocks.
    rand_errors=[];rand_right=[];rand_coverage=[]
    for z in range(5000):
        drop=set(rng.sample(candidates,num_drop));wrong=sum(r['wrong'] for w,r in E.items() if w not in drop)
        right=sum(r['right'] for w,r in E.items() if w not in drop)
        issued=sum(r['issued'] for w,r in E.items() if w not in drop)
        rand_errors.append(wrong);rand_right.append(right);rand_coverage.append(issued/4800)
    matched={
       'eligibility':'only candidate-exclusive full-world blocks, dropping a fixed number based on public issued counts',
       'candidate_blocks':len(candidates),'dropped_blocks':num_drop,
       'observed_validate_fixed':{'wrong':sum(r['wrong'] for r in V.values()),'right':sum(r['right'] for r in V.values()),'coverage':sum(r['issued'] for r in V.values())/4800},
       'random_drop_5000':{'wrong_min':min(rand_errors),'wrong_max':max(rand_errors),'wrong_mean':sum(rand_errors)/len(rand_errors),
          'coverage_min':min(rand_coverage),'coverage_max':max(rand_coverage),
          'fraction_equal_or_lower_wrong_than_validation':sum(w<=sum(r['wrong'] for r in V.values()) for w in rand_errors)/len(rand_errors)}
    }
    # Value of validation compared to simple elimination must not be credited if same at risk-matched issuance.
    final={'result':'PASS' if not problems else 'FAIL','checks':checks,'problems':problems[:20],
      'replay_runs':replays,'pairwise_identical_observation_checks':same_obs,
      'stages':results,'paired_world_bootstrap':contrasts,'risk_coverage_random_world_block':matched,
      'anomaly_observability':{f'{stage}/{p}/{z}':v for (stage,p,z),v in anomaly_flags.items()},
      'note':'Independent implementation and seeds but same designed mechanism families; internal audit, NOT external scientific verification.'}
    (ROOT/'audit/AUDIT_AND_INFERENCE.json').write_text(json.dumps(final,indent=2))
    print(json.dumps(final,indent=2))
    if problems:sys.exit(1)
if __name__=='__main__':main()
