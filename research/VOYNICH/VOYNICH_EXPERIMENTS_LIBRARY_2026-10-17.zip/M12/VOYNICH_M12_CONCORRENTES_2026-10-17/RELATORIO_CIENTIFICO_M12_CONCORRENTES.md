# VOYNICH — M12, hipóteses concorrentes: desenvolvimento, confirmação e auditoria

**Data de referência:** 17 outubro 2026.  
**Estado científico:** `NO_PROMOTION`; **2/5 critérios científicos passaram**.  
**Experiência:** avaliação sintética e determinística de aceitação de hipóteses e seleção de consultas, **não** aprendizagem por RL, invenção aberta de operadores, modelos de linguagem especializados nem teste histórico Voynich.

## 1. Pergunta respondida

> Com o mesmo conjunto inicial de duas hipóteses e o mesmo orçamento, testar previsões antes de aceitar uma extensão melhora a escolha e a rejeição de modelos, relativamente à eliminação simples de candidatos incompatíveis?

**Resposta neste benchmark: não demonstrado.** Houve redução de aceitações globais erradas com a validação fixa, mas à custa de uma perda significativa de utilidade quando havia um modelo correto. A comparação com recusas aleatórias à mesma cobertura revelou o mesmo número de erros e nenhum ganho seletivo. Consultas ativas para separar modelos foram úteis isoladamente; associá-las à regra de validação definida tornou o sistema excessivamente conservador.

## 2. Genealogia e limites

A M11 encontrou extensões úteis e reparações prejudiciais; a M12 original, com uma única extensão, produziu um sinal de seleção de risco que não excedeu a referência conservadora. Esta experiência nasce da crítica de que **validar** uma extensão e **eliminar candidatos incompatíveis** podem ser a mesma operação se os dados forem idênticos. Para resolver a ambiguidade causal, testámos cinco políticas separadas em pares que veem rigorosamente as mesmas observações. Os dois programas candidatos são fornecidos pelo benchmark: **o investigador não os sintetiza a partir do zero**.

Unidade de análise: mundo artificial, com 64 combinações `(t,x)` e saída de quatro bits (16 símbolos de grelha 2×2). Observações: 8 iniciais comuns + 4 consultas de descoberta + 4 validações de procedimento independente, **total 16 observações e 48 testes externos**. Orçamentos iguais. Os quatro locais de validação são escolhidos por hash determinístico que depende apenas das observações iniciais públicas, sem consultar a verdade. Ambas as políticas do mesmo modo (fixo ou ativo) recebem respostas e locais idênticos.

### Condições

- `ONE`: uma das duas extensões está correta e existem consultas permitidas que distinguem os dois programas; as regras adicionais são interações raras de contexto e bits.
- `NONE`: nenhum candidato é globalmente correto. O gerador altera **um único ponto**, acessível mas possivelmente não consultado, relativamente ao candidato A. Isto constitui um teste deliberadamente difícil de identificabilidade com orçamento limitado.
- `AMBIGUOUS`: duas origens diferentes são indistinguíveis em **todas as consultas permitidas**; diferem apenas em alguns locais fora do conjunto acessível. A resposta legítima não deve identificar exclusivamente uma origem.

As três condições são sintéticas e desenhadas em torno de duas formas de operador já conhecidas dos programas. Na `NONE` uma exceção inobservada não pode ser inferida; uma hipótese compatible **não é uma identificação causal global**, nem deveria ser tratada como tal. O relatório mede, por transparência, quantas propostas aceites são globalmente falsas, sem atribuir obrigação de adivinhar a exceção.

### Políticas

1. `auto_fixed`: aceita previamente candidato 0 se não observar contradição direta; referência ingênua.
2. `eliminate_fixed`: elimina candidatos incompatíveis com todas as 8 consultas fixas.
3. `validate_fixed`: declara proposta no final de 4 consultas de descoberta, regista previsões antecipadas para mais 4 consultas independentes e exige uma observação discriminante na validação antes de aceitar exclusivamente um dos candidatos. Se não passar, abstém-se onde a conclusão excede os dados. Não reabilita hipóteses refutadas.
4. `eliminate_active`: eliminação simples, mas primeiro consulta contextos em que as duas hipóteses divergem.
5. `validate_active`: igual seleção ativa, com regra de validação adicional.

A utilização de 5 braços permite medir separadamente o efeito da aceitação (`validate_fixed` vs `eliminate_fixed`, `validate_active` vs `eliminate_active`) e da escolha de consultas (`eliminate_active` vs `eliminate_fixed`). **Não compara três agentes LLM contra um agente único**.

## 3. Desenvolvimento e congelamento

Piloto de **60 mundos × 5 políticas = 300 execuções**. A primeira versão era demasiado fácil. Foram alterados exclusivamente o desenho de desenvolvimento e a geração de consultas **antes do congelamento**, para criar sinais raros e exceções. A versão corrigida passou 10/10 testes e só então fixámos `protocol/CONFIRMATION_PREREGISTERED.md` e os hashes em `protocol/FREEZE_SHA256.json`.

A confirmação teve um **gerador Python escrito separadamente** e sementes diferentes, mas com as **mesmas famílias predefinidas**. Isto proporciona alguma independência de implementação, não independência conceptual nem revisão científica externa. Nenhuma alteração foi feita ao investigador, aos geradores ou aos critérios depois de ver os dados confirmatórios.

## 4. Resultados da confirmação

**300 mundos × 5 políticas = 1.500 execuções**; 100 mundos por condição, 48 entradas externas por mundo/política. Juntando o desenvolvimento: **360 mundos e 1.800 execuções**, sem misturar as medidas inferenciais.

| Condição | Política | Previsões corretas / 48 (média) | Cobertura | Erros em 4.800 pontos | Aceitação exclusiva indevida (mundos) |
|---|---|---:|---:|---:|---:|
| ONE | `auto_fixed` | 60.00% | 62.00% | 96 | 0 |
| ONE | `eliminate_fixed` | 96.00% | 96.00% | 0 | 0 |
| ONE | `validate_fixed` | 66.00% | 66.00% | 0 | 0 |
| ONE | `eliminate_active` | 100.00% | 100.00% | 0 | 0 |
| ONE | `validate_active` | 27.00% | 27.00% | 0 | 0 |
| NONE | `auto_fixed` | 76.38% | 78.00% | 78 | 78 |
| NONE | `eliminate_fixed` | 73.12% | 74.67% | 74 | 58 |
| NONE | `validate_fixed` | 58.44% | 59.67% | 59 | 43 |
| NONE | `eliminate_active` | 82.25% | 84.00% | 84 | 84 |
| NONE | `validate_active` | 21.54% | 22.00% | 22 | 22 |
| AMBIGUOUS | `auto_fixed` | 91.67% | 100.00% | 400 | 100 |
| AMBIGUOUS | `eliminate_fixed` | 83.33% | 83.33% | 0 | 0 |
| AMBIGUOUS | `validate_fixed` | 83.33% | 83.33% | 0 | 0 |
| AMBIGUOUS | `eliminate_active` | 83.33% | 83.33% | 0 | 0 |
| AMBIGUOUS | `validate_active` | 83.33% | 83.33% | 0 | 0 |

*Uma aceitação exclusiva indevida significa que o agente escolheu apenas uma das duas propostas quando a origem era inidentificável ou quando ambas eram globalmente incorretas; o agente não afirma certificação histórica. Em `NONE`, a exceção pode ser invisível, pelo que essa métrica não mede apenas erros epistémicos evitáveis.*

### Contrastes emparelhados por mundo

- `ONE`: validação fixa contra eliminação fixa: **−30,0 pp** de exatidão efetiva, IC bootstrap 95% **[-39; -21] pp**. Razão de utilidade: **66/96 = 68,75%**.
- `NONE`: eliminação fixa com **58/100** propostas únicas globalmente erradas, contra **43/100** da validação fixa; queda de **15 pp**, IC bootstrap por mundo **[8; 22] pp**. Ganho relativo de **25,86%**, mas sem prova de discriminação além de recusar mais propostas.
- `ONE`: consultas ativas + eliminação: **100% de exatidão**, contra **96%** com consultas fixas. Diferença +4,0 pp, IC **[+2,67; +5,33] pp**. Este efeito pertence à **seleção das consultas**, não à regra de aceitação.
- `ONE`: validação ativa apenas **27% de exatidão**, contra **100%** da eliminação ativa (−73 pp, IC **[−81; −64]**). A regra demasiado exigente recusou descobertas corretas.
- `AMBIGUOUS`: os comparadores por eliminação e validação não fizeram nenhuma atribuição exclusiva e deram cobertura **83,33%** de previsões por consenso. A referência automática selecionou uma única hipótese sem justificação, emitindo 400 previsões erradas nos 4.800 pontos externos.

### Comparação a cobertura equivalente (condição `NONE`)

A validação fixa recusou 15 blocos de previsões (mundos inteiros) que a eliminação fixa teria emitido, passando de 58 para 43 propostas únicas aceites. Havia 58 blocos integrais elegíveis para recusa aleatória sem usar verdade. Fizemos **5.000** amostragens independentes, retirando **15 desses blocos inteiros**, sempre com a mesma cobertura final de **59,67%**.

- Validação fixa: **59 erros** em 2.864 previsões emitidas; 2,06% de erro condicional.
- Recusa aleatória por blocos, com cobertura exatamente igual: **59 erros em todas as 5.000 simulações**.
- A política de validação **não mostrou discriminação superior ao acaso à mesma cobertura** neste benchmark. O resultado é especialmente diagnóstico porque cada proposta falsa emitida na população testada produzia uma única previsão errada no exterior.

### Distinguibilidade real

Nos **100 mundos `NONE` de confirmação**, a exceção foi efetivamente observada em apenas **22 mundos** pelas consultas fixas e em **16** pelas consultas ativas. Nos restantes **78 e 84 mundos**, respetivamente, a localização da exceção ficou oculta. Nesses mundos, nenhuma política poderia concluir a partir da evidência observada que a exceção específica existia. A avaliação penaliza cobertura e contabiliza propostas falsas à luz da verdade privada, mas não deve converter essas falsidades em culpa por não descobrir informação inacessível.

## 5. Gates previamente congelados e decisão

| Gate | Critério | Observado | Veredito |
|---|---|---|---|
| G1 Utilidade | Validação fixa mantém ≥80% da referência em `ONE` e ≥70% de exatidão efetiva | 68,75% / 66% | **FAIL** |
| G2 Risco | Reduz em ≥20% falsas exclusividades em `NONE`, IC emparelhado inferior >0 | −25,86% e IC [+8; +22] pp | **PASS descritivo** |
| G3 Ambiguidade | 0 atribuições exclusivas; ≥75% de cobertura por consenso | 0; 83,33% | **PASS instrumental** |
| G4 Valor incremental | Vantagem de risco à mesma cobertura face a recusa aleatória/eliminações simples | Mesmos 59 erros | **FAIL** |
| G5 Escolha ativa + gate | `validate_active` ≥70% em `ONE` e sem mais erros exclusivos em `NONE` que validação fixa | 27% / 22 vs 43 | **FAIL** |

**Decisão pré-registada:** `NO_PROMOTION` (2/5 gates). A M12 concorrentes não estabeleceu que validar independentemente uma hipótese torna a escolha melhor do que eliminar candidatos incompatíveis; mostrou que um gate rígido pode atrasar identificações corretas enquanto melhora aparente segurança por abstinência.

## 6. Auditoria e fiabilidade técnica

- **10/10 testes técnicos** antes do congelamento.
- **7 ficheiros científicos pré-registados** com SHA256 antes da confirmação; hashes preservados.
- **23.129 verificações de auditoria** sem anomalias, incluindo pré-compromissos antes da resposta, orçamento, entradas externas, comparação de consultas e de observações em todos os pares.
- **495 reexecuções determinísticas** em confirmação (1/3 dos mundos × 5 braços), todas idênticas.
- **720 verificações emparelhadas** de identidade das sequências de observação entre eliminação e validação, em desenvolvimento e confirmação.
- A auditoria precisou de uma correção posterior **exclusivamente no verificador**, documentada em `audit/AMENDMENT_AUDITOR.md`. O agente, os dados e os critérios congelados não foram alterados.
- O verificador e o gerador de confirmação são **internos** ao projeto; não constituem auditoria externa ou validação institucional independente.
- Sem uso de imagens reais, fólios Voynich, reserva Egerton ou informação pessoal.

## 7. O que fazer depois, sem enviesar a confirmação

Não redesenhar o mesmo gate após olhar para estes resultados e chamá-lo confirmação M12. Há duas direções cientificamente legítimas para um **novo protocolo**:

1. **Confiança seletiva bem calibrada**: avaliar estimativas de risco de previsão por ponto, não apenas aceitação ou rejeição do modelo inteiro, impondo curvas erro-cobertura e penalização de abstenção. A comparação precisa ser contra uma política de eliminação com as mesmas consultas e a mesma cobertura.
2. **Descoberta de teste independente**: pedir a um agente que gere consultas que possam revelar erros partilhados por todos os candidatos, em vez de procurar apenas diferenças entre os dois. Avaliar em mundos com várias exceções e mudanças de regime, usando geradores verdadeiramente distintos e metadados de observabilidade.

Nenhuma dessas capacidades foi demonstrada aqui. A experiência atual ensina que validar um modelo não é equivalente a melhorar a informação disponível; **escolher o teste falsificador pode importar mais do que exigir um ritual adicional de aceitação**.

## 8. Reprodução

```bash
ROOT=VOYNICH_M12_CONCORRENTES_2026-10-17
PYTHONPATH="$ROOT/src:$ROOT/private" python -m unittest discover -s "$ROOT/tests" -v
PYTHONPATH="$ROOT/src:$ROOT/private" python "$ROOT/src/experiment.py" --stage development --out /tmp/m12_dev_replay
PYTHONPATH="$ROOT/src:$ROOT/private" python "$ROOT/src/experiment.py" --stage confirmation --out /tmp/m12_confirm_replay
PYTHONPATH="$ROOT/src:$ROOT/private" python "$ROOT/audit/audit_and_stats.py"
```

Usar destinos `/tmp/` alternativos para não substituir os registos originais. Código e dados incluem um modelo de verdade privado; para um ensaio cego futuro, será necessário separar permissões de execução ao nível do processo/SO e controlar os ficheiros privados.
