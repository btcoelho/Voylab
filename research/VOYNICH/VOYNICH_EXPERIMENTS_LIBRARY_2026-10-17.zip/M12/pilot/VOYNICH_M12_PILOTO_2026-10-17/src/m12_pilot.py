"""M12: deterministic three-arm development pilot of provisional extension acceptance.

Agent-side logic consumes observations only; ground truth belongs to the external runner.
The base grammar and one-conjunction DSL are unchanged copies of M11.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path

from m11_agent import ACTIONS, INITIAL, PREDICATES, fit, models, predict, stable_hash

DISCOVERY = ((0,1),(0,3),(0,5),(0,9),(1,0),(2,0),(3,0),(2,1))
VALIDATION = ((0,7),(1,3),(2,11),(3,1))
ARMS = ('auto','validated','conservative')
MAX_PROPOSALS = 1
assert not set(INITIAL) & set(DISCOVERY + VALIDATION)
assert len(set(INITIAL + DISCOVERY + VALIDATION)) == 20


def obs_hash(obs):
    return stable_hash([[t,x,v] for (t,x),v in sorted(obs.items())])


def consensus(candidates, q):
    vals=[predict(b,q,e) for _,e,b in candidates]
    return vals[0] if vals and vals[0] is not None and all(v == vals[0] for v in vals) else None


def first_refutation(obs):
    """Return witness for inconsistency under linear grammar, or None."""
    acc={}
    for q,v in sorted(obs.items()):
        acc[q]=v
        if fit(acc) is None:
            return {'action':list(q),'value':v,'observation_sha256':obs_hash(acc)}
    return None


def agent_on_discovery(discovery_obs, arm):
    """Make a proposal without knowing validation or test values."""
    if arm not in ARMS:raise ValueError(arm)
    linear=fit(discovery_obs)
    if arm!='validated':
        return {'type':'DEFER_TO_FINAL_FIT', 'proposal':None}
    if linear is not None:
        cands=[('base',None,linear)]
        typ='BASE_PROVISIONAL'
    else:
        cands=sorted(models(discovery_obs, True),key=lambda z:(str(z[1]),z[0]))
        typ='EXTENSION_PROVISIONAL' if cands else 'NO_EXPRESSIBLE_MODEL'
    # One proposal only, chosen using discovery data. No test-until-it-passes loop.
    chosen=cands[0] if cands else None
    predicted=[consensus([chosen],q) if chosen else None for q in VALIDATION]
    proposal={
        'type':typ,'witness':first_refutation(discovery_obs),
        'defines':[[t,x,v] for (t,x),v in sorted(discovery_obs.items())],
        'defines_sha256':obs_hash(discovery_obs),
        'expression':{'family':chosen[0],'conjunction':list(chosen[1]) if chosen and chosen[1] else None} if chosen else None,
        'candidate_count':len(cands),
        'test_actions':[list(q) for q in VALIDATION],
        'test_predictions':predicted,
        'rejection_rule':'Reject if any defined test prediction disagrees, or fewer than 2 defined predictions. Never revert refuted base.',
        'maximum_proposals':MAX_PROPOSALS,
    }
    proposal['precommit_sha256']=stable_hash(proposal)
    return {'type':typ,'proposal':proposal,'chosen':chosen}


def agent_finalize(discovery_obs, validation_obs, arm, planned):
    """Return executable model(s) and status; no truth access beyond observed probes."""
    obs={**discovery_obs,**validation_obs}
    witness=first_refutation(obs)
    if arm in ('auto','conservative'):
        can=models(obs, arm=='auto')
        status=('AUTOMATIC_COMPATIBLE' if can else 'NO_VALID_MODEL') if arm=='auto' else ('BASE_COMPATIBLE' if can else 'BASE_REFUTED_ABSTAIN')
        return can, {'status':status,'linear_contradiction':witness,'accepted_provisionally':bool(can),'proposal':None}
    proposal=planned['proposal']
    can=planned.get('chosen')
    if can is None:
        return [],{'status':'NO_PROPOSAL_ABSTAIN','linear_contradiction':witness,'accepted_provisionally':False,'proposal':proposal}
    actual=[validation_obs[q] for q in VALIDATION]
    ps=proposal['test_predictions']
    defined=sum(p is not None for p in ps)
    errors=sum(p is not None and p!=a for p,a in zip(ps,actual))
    passed=(errors==0 and defined>=2)
    status=('EXTENSION_PROVISIONALLY_ACCEPTED' if can[0]=='extended' else 'BASE_PROVISIONALLY_ACCEPTED') if passed else ('EXTENSION_REJECTED_ABSTAIN' if can[0]=='extended' else 'BASE_REFUTED_ABSTAIN')
    # Never reset to linear after detecting a contradiction; no fitting to validation responses.
    return ([can] if passed else []),{'status':status,'linear_contradiction':witness,'accepted_provisionally':passed,'validation_defined':defined,'validation_errors':errors,'proposal':proposal,'validation_actuals':actual,'precommit_verified':stable_hash({k:v for k,v in proposal.items() if k!='precommit_sha256'})==proposal['precommit_sha256']}


def make_private_world(kind, seed, variant=0):
    """Private pilot generator wrapper with a genuinely outside-DSL two-term family."""
    from m11_worlds import make_world, base, family_coeff
    if kind != 'C6': return make_world(kind, seed, variant)
    c,r=family_coeff(seed)
    mask1=r.randrange(1,16)
    mask2=r.randrange(1,16)
    table=[]
    for t,x in ACTIONS:
        v=base(t,x,c)
        if (x&1) and (x&2):v^=mask1
        if (x&1) and (x&8):v^=mask2
        table.append(v)
    return {'id':'W'+hashlib.sha256(bytes(table)+seed.to_bytes(8,'big')).hexdigest()[:20],
       'kind':'C6','origin':'two_hidden_conjunctions','table':table,'seed':seed}


def public_observations(table,queries):
    return {q:table[q[0]*16+q[1]] for q in queries}


def run_arm(kind,seed,variant,arm):
    world=make_private_world(kind,seed,variant)
    # The agent receives only decoded synthetic glyph measurements; no world kind or origin.
    init=public_observations(world['table'], INITIAL)
    discovery=public_observations(world['table'], DISCOVERY)
    validations=public_observations(world['table'],VALIDATION)
    first={**init,**discovery}
    planned=agent_on_discovery(first,arm)
    cands,diag=agent_finalize(first, validations,arm,planned)
    excluded=set(INITIAL+DISCOVERY+VALIDATION)
    predictions={f'{t},{x}':consensus(cands,(t,x)) for t,x in ACTIONS if (t,x) not in excluded}
    return {
        'opaque_world_id':world['id'],'arm':arm,'status':diag['status'],
        'observations_sha256':obs_hash({**first,**validations}),
        'query_locations':[[t,x] for t,x in DISCOVERY+VALIDATION],
        'observation_count':20,'external_count':44,
        'diagnostics':diag,'predictions':predictions,
        'agent_type':'deterministic_python_not_LLM','historical_origin_claim':None,
    },world


def score(row,world):
    queried={(t,x) for t,x in INITIAL+DISCOVERY+VALIDATION}
    test={f'{t},{x}':world['table'][t*16+x] for t,x in ACTIONS if (t,x) not in queried}
    pred=row['predictions']
    assert len(pred)==44 and set(pred)==set(test)
    issued=sum(x is not None for x in pred.values())
    right=sum(x is not None and x==test[q] for q,x in pred.items())
    wrong=issued-right
    return {'opaque_world_id':row['opaque_world_id'],'kind':world['kind'],'seed':world['seed'],'arm':row['arm'],
        'right':right,'wrong':wrong,'issued':issued,'abstained':44-issued,'external':44,
        'coverage':issued/44,'selective_error':wrong/issued if issued else None,
        'effective_accuracy':right/44,'status':row['status']}


def paired_worlds():
    # Distinct synthetic development seeds; not confirmation nor a blind holdout.
    for kind in ('C1','C2','C4','C5','C6'):
        for j in range(20):yield kind,12000+101*j+(j%7),0
    for j in range(10):
        for v in (0,1):yield 'C3',24000+101*j,v


def aggregate(score_rows):
    out={}
    by=defaultdict(list)
    for x in score_rows:by[(x['kind'],x['arm'])].append(x)
    for (kind,arm),rows in sorted(by.items()):
        got=sum(r['right'] for r in rows);wrong=sum(r['wrong'] for r in rows);issued=sum(r['issued'] for r in rows);n=44*len(rows)
        out[f'{kind}/{arm}']={'worlds':len(rows),'issued':issued,'right':got,'wrong':wrong,'coverage':issued/n,
          'selective_error':wrong/issued if issued else None,'effective_accuracy':got/n,
          'statuses':dict(sorted(__import__('collections').Counter(r['status'] for r in rows).items()))}
    return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args()
    dest=Path(a.out);dest.mkdir(parents=True,exist_ok=True)
    public=[];scores=[];private=[]
    for kind,seed,v in paired_worlds():
        worlds=[]
        for arm in ARMS:
            row,w=run_arm(kind,seed,v,arm)
            public.append(row);scores.append(score(row,w));worlds.append(w)
        assert all(z['table']==worlds[0]['table'] for z in worlds)
        private.append({'opaque_world_id':worlds[0]['id'],'kind':kind,'seed':seed,'variant':v,'table':worlds[0]['table']})
    for filename,values in [('public_agents.jsonl',public),('scores.jsonl',scores),('private_truth.jsonl',private)]:
        with (dest/filename).open('w',encoding='utf8') as f:
            for rec in values:f.write(json.dumps(rec,sort_keys=True,ensure_ascii=False)+'\n')
    summary={'experimental_status':'DEVELOPMENT_PILOT_ONLY','worlds':len(private),'arms':len(ARMS),'executions':len(public),
      'external_predictions':len(scores)*44,'groups':aggregate(scores),'protocol':'protocol/DEV_PROTOCOL.md'}
    (dest/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf8')
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=='__main__':main()
