# Voynich M12 — piloto de aceitação provisória de extensões

**PILOTO DE DESENVOLVIMENTO APENAS.** Não houve confirmação externa nem promoção.

Arquivos: `protocol/DEV_PROTOCOL.md` (antes do piloto), `src/m12_pilot.py` (3 braços), `private/m11_worlds.py` (gerador sintético derivado da M11), `reference/m11_agent.py` (base anterior inalterada), `results/*.jsonl`, `audit/audit_m12.py`, `audit/AUDIT_M12.json`, `tests/test_pilot.py`, `RELATORIO_CIENTIFICO_M12_PILOTO.md`.

## Reproduzir sem alterar resultados fornecidos

```bash
PYTHONPATH=src:reference:private python -m unittest discover -s tests -v
PYTHONPATH=src:reference:private python src/m12_pilot.py --out /tmp/m12_pilot_replay
PYTHONPATH=src:reference:private python audit/audit_m12.py --root .
```

A segunda linha gera outro conjunto de ficheiros no caminho de saída indicado; o auditor por defeito verifica os resultados oficiais incluídos no pacote. O arquivo contém também tabelas completas do gerador privado APENAS para verificação offline; nunca disponibilizar `private/` ou `results/private_truth.jsonl` aos agentes num futuro teste.
