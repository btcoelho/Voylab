# VOYNICH — M12 | Piloto de validação provisória de extensões

**Data:** 17 de outubro de 2026  
**Estado:** PILOTO DE DESENVOLVIMENTO EXECUTADO; CONFIRMAÇÃO NÃO INICIADA; protocolo confirmatório NÃO congelado.  
**Veredito científico:** NÃO DEMONSTRADA vantagem da validação independente sobre extensão automática com cobertura equiparada. Nenhuma promoção.

## 1. Objetivo e antecedentes

M11 mostrou uma capacidade limitada de introduzir uma conjunção entre flags, mas uma reparação local pode criar previsões falsas no resto do domínio. Este piloto M12 testa a intervenção sugerida: conservar cada extensão como provisória até fazer novas previsões pré-registadas e confrontá-las com um bloco de validação não usado para ajustar a proposta.

Os quatro ajustes da revisão estão implementados: **só três braços** (`auto`, `validated`, `conservative`); **não recuperar o modelo refutado**; **quatro validações não são garantia de risco <5%**; **medição conjunta de erro e cobertura, com comparação sobre as mesmas previsões**. O controlador aprendido foi adiado.

## 2. Desenho e natureza do ensaio

- **120 mundos artificiais**, **360 execuções** (três braços por mundo), **15.840 oportunidades de previsão externa**, mas muitas foram recusadas; 20 mundos de cada C1, C2, C4, C5, C6 e dez pares C3 de proveniências indistinguíveis.
- Entradas `(t,x)` num domínio de 64 valores; 8 observações iniciais, 8 consultas de descoberta e 4 observações de validação. **Os três braços recebem os mesmos 20 valores observados** e são avaliados nos outros 44.
- `auto`: ajusta automaticamente um modelo linear ou uma extensão de conjunção após todos os 20 valores; evita prever quando não consegue representar os dados.
- `validated`: congela **uma única** proposta após as 16 primeiras observações, regista um SHA256 com as previsões do bloco seguinte e aceita provisoriamente apenas se pelo menos duas previsões forem definidas e nenhuma falhar. O modelo não é reajustado às quatro validações. Em caso de refutação, suspende previsões; não restaura a regra original refutada.
- `conservative`: procura apenas função XOR linear sobre os 20 valores; se houver contradição, suspende previsões.
- C1: extensão genuína; C2: linear; C3: mesmos comportamentos com duas histórias causais; C4: alteração pontual/esparsa; C5: dependência de contexto e posição; C6: duas conjunções (não cabem na linguagem de uma conjunção).
- **Pilotagem em modelos Python determinísticos; NÃO há LLMs autónomos, nem avaliação histórica ou visão real.** O gerador deriva da infraestrutura sintética da M11 e partilha pressupostos com os agentes. Separação entre agentes e verdade é lógica, não isolamento de sistema operativo.

## 3. Resultados, erro e cobertura

| Condição | Automático: cobertura / erros emitidos | Validado: cobertura / erros emitidos | Conservador: cobertura / erros emitidos | Interpretação |
|---|---:|---:|---:|---|
| C1 (20 mundos, extensão válida) | 100% / 0% | **100% / 0%** | 0% / — | Controlo positivo saturado |
| C2 (20 mundos, linear) | 100% / 0% | **100% / 0%** | 100% / 0% | Não há necessidade de extensão |
| C3 (20 mundos, 10 pares) | 100% / 0% | **100% / 0%** | 100% / 0% | Não reivindica origem; isso é imposto pelo programa |
| C4 (20 mundos, exceção rara) | **89,09% / 3,32%** | **80,00% / 2,27%** | **80,00% / 2,27%** | Validação perde cobertura e empata com conservador |
| C5 (20 mundos, posição) | 0% / — | 0% / — | 0% / — | Todos se abstêm: nenhuma capacidade útil demonstrada |
| C6 (20 mundos, duas interações) | 0% / — | 0% / — | 0% / — | Família fora do vocabulário de extensão |

**C4, contagens brutas:** `auto` emite 784 previsões, sendo **26 erradas**; `validated` emite 704, sendo **16 erradas**. Reduzem-se 10 erros ao recusar 80 previsões adicionais, mas há perda simultânea de 70 previsões corretas (758 → 688). O ganho em precisão aparente é acompanhado por menor cobertura.

**Verificação na mesma cobertura e nos mesmos pontos:** nas **704 posições previstas** pelo validado, `auto` também emitiu 704 previsões, das quais **16 erradas**, todas com o **mesmo valor previsto** que a política validada. Portanto, **não existe melhoria demonstrada ao comparar exatamente os mesmos casos**. O intervalo bootstrap exploratório de 95% da diferença *validated − auto* em erros por posição externa é [-3,07; 0,00] pontos percentuais, incluindo zero. Não constitui evidência confirmatória.

**Abstenção não é sucesso:** C5 e C6 revelam o problema de uma política que evita todos os erros recusando todas as previsões. A condição C1 mantém 100% de cobertura, mas já era resolvida perfeitamente pelo comparador automático.

## 4. Sobre os quatro casos de validação

O facto de uma proposta acertar quatro previsões não permite certificar erro inferior a 5%. Mesmo na hipótese simplificadora de quatro ensaios Bernoulli independentes com zero erros, o limite superior unilateral exato de 95% para a taxa de erro é aproximadamente **52,7%**. No nosso ambiente, as previsões podem ser dependentes, tornando essa extrapolação ainda mais inadequada. As aceitações M12 são expressamente **provisórias**, nunca uma declaração de identidade causal ou correção global.

## 5. Auditoria

- **8/8 testes unitários** passaram; cobrem isolamento das propostas face à validação, compromisso SHA256, estados após refutação, proteção C3, orçamento e projeção externa.
- **4.718 verificações internas**, zero inconformidades; **18 reexecuções determinísticas**, cobrindo os três braços de cada uma das seis condições.
- Relatórios públicos por braço, resultados privados por mundo e observações completas foram preservados em `results/` para auditoria e reprodução.
- O auditor sofreu **uma correção de nomenclatura (`common[k]` para `common[kind]`) antes de produzir a auditoria final**; foi erro na agregação de auditoria, não na política experimental nem nos resultados. A primeira execução do auditor falhou com `KeyError: C4`; o teste unitário já tinha passado. A alteração está registada no histórico deste trabalho.
- Nenhum fólio histórico Voynich ou Egerton foi consultado.

## 6. Diagnóstico e decisão

**O mecanismo de validação existe e respeita a disciplina de evidência**, mas este piloto não identifica uma vantagem científica específica: o validador exclui previsões, sem corrigir as que emite. Mais ainda, o controlador `auto` recebe as quatro observações e reajusta o modelo, sendo um comparador mais forte e justo do que proibir essa informação.

Para a próxima iteração de desenvolvimento, antes de congelar a confirmação:

1. Introduzir casos novos em que duas extensões diferentes sobrevivam aos dados de descoberta e proponham previsões discordantes na validação; sem favorecer à partida a regra certa.
2. Estender o conjunto de controles com um braço que faça **validação independente e revisão local sem usar as observações de validação para ajustar a mesma proposta**; conservar igualdade de orçamento e limite de propostas.
3. Pré-especificar patamares mínimos de cobertura C1/C2 e medir erro a cobertura fixa, além de risco seletivo; estimar tamanho de amostra por mundo e taxa esperada de falsos diagnósticos.
4. Incluir geradores de confirmação estruturalmente independentes e casos irredutivelmente indistinguíveis. Não usar o resultado deste piloto como confirmação científica.

**Decisão SCI-GOV:** `PILOT_COMPLETED; VALIDATION_MECHANISM_IMPLEMENTED; SCIENTIFIC_BENEFIT_NOT_DEMONSTRATED; CONFIRMATION_NOT_FROZEN.`
