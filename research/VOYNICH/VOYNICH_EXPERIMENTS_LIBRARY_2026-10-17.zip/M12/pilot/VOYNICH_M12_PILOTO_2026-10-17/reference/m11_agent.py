"""M11: deterministic program investigators, no access to oracle internals.
Evidence-scoped claims, executable one-operator extensions and explicit non-identifiability.
Inspired by M10's GF(2) elimination and SHA256 precommit; NOT an LLM.
"""
from __future__ import annotations
import hashlib,json,random
from collections import Counter

ACTIONS=tuple((t,x) for t in range(4) for x in range(16))
INITIAL=tuple((0,x) for x in range(0,16,2))
BUDGET=8
ARMS=('base_only','extend_active','extend_random','extend_fixed','triad_modular')
# Generic predicate-building DSL: pairwise conjunction of observed input flags.
# A new predicate is selected after an empirical contradiction, not a pre-named mechanism family.
PREDICATES=tuple((i,j) for i in range(7) for j in range(i+1,7))

def stable_hash(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def read_glyph(g):
    if len(g)!=2 or any(len(r)!=2 for r in g):raise ValueError('bad shape')
    bits=sum(g,[])
    if any(type(z) is not int or z not in (0,1) for z in bits):raise ValueError('bad bits')
    return sum(z<<i for i,z in enumerate(bits))

def flags(t,x):
    return [((x>>i)&1) for i in range(4)]+[int(t==u) for u in (1,2,3)]

def feat(t,x,extension=None):
    f=flags(t,x)
    f=[1]+f
    if extension is not None:
        a,b=extension; f.append(flags(t,x)[a]&flags(t,x)[b])
    return sum(v<<i for i,v in enumerate(f))

def fit(obs,extension=None):
    basis={}
    for (t,x),y in sorted(obs.items()):
        m=feat(t,x,extension)
        while m:
            p=m.bit_length()-1
            if p not in basis:
                basis[p]=(m,y);break
            q,z=basis[p];m^=q;y^=z
        if not m and y:return None
    return basis

def predict(basis,q,extension=None):
    if basis is None:return None
    m=feat(*q,extension);y=0
    while m:
        p=m.bit_length()-1
        if p not in basis:return None
        q0,z=basis[p];m^=q0;y^=z
    return y

def models(obs,may_extend=True):
    base=fit(obs)
    # Crucial control: extensions can be considered ONLY after base contradiction.
    if base is not None or not may_extend:
        return [('base',None,base)] if base is not None else []
    return [('extended',p,b) for p in PREDICATES if (b:=fit(obs,p)) is not None]

def query_score(obs,candidates,q):
    vals=[predict(b,q,e) for _,e,b in candidates]
    determined=[v for v in vals if v is not None]
    counts=Counter(determined)
    conflicting=max(0,len(counts)-1)
    novel=sum(v is None for v in vals)
    tt,x=q
    seen_t={t for t,_ in obs}
    # Encourage tests on new x-bit configurations and contexts.
    # A model challenge is a test in which the current model makes a falsifiable prediction.
    coverage=(3 if tt not in seen_t else 0)+(0.7 if (x&1) else 0)
    if candidates and candidates[0][0]=='base':
        coverage+=2 if (x&1 and (x&4)) else 0
        coverage+=1 if (x&1 and (x&2)) else 0
    rank_gain=(novel / max(1,len(vals))) * 1.8
    contradiction_bonus=(2.5 if len(counts)>1 else 0)+min(conflicting,4)
    return (contradiction_bonus+rank_gain+coverage+len(determined)/max(1,len(vals))*0.4)

def choose(obs,candidates,seed,step,arm):
    remaining=[q for q in ACTIONS if q not in obs]
    if arm=='extend_random':return random.Random(seed*113+step*1013).choice(remaining)
    if arm=='extend_fixed':
        schedule=[(0,1),(0,3),(0,5),(0,7),(1,1),(2,3),(3,5),(1,7)]
        return schedule[step] if schedule[step] in remaining else remaining[0]
    # Programmed falsification contrasts for each x-bit interaction.
    # This is a targeted *heuristic*, not a learned experiment planner.
    contrasts=[(0,1),(0,3),(0,5),(0,9)]
    for q in contrasts:
        if q in remaining:return q
    # Build coverage for the previously unobserved contexts; use a later probe
    # to challenge the assumption that x effects generalize across contexts.
    witnesses=[(1,0),(2,0),(3,0),(2,1)]
    for q in witnesses:
        if q in remaining:return q
    rng=random.Random(seed*241+step*307)
    return max(remaining,key=lambda q:(query_score(obs,candidates,q),rng.random()))

def investigate(api,opaque_id,seed,arm):
    if arm not in ARMS:raise ValueError(arm)
    obs={(t,x):read_glyph(g) for t,x,g in api.initial()}
    if set(obs)!=set(INITIAL):raise ValueError('invalid initial')
    allow_extension=arm!='base_only'
    ledger=[];trigger=None;specialist=[]
    for step in range(BUDGET):
        candidates=models(obs,allow_extension)
        q=choose(obs,candidates,seed,step,arm)
        predictions=[predict(b,q,e) for _,e,b in candidates]
        known=set(p for p in predictions if p is not None)
        prediction=next(iter(known)) if len(known)==1 and len(predictions)==len(known) else None
        row={'world':opaque_id,'arm':arm,'step':step,'action':list(q),
             'observed_hash':stable_hash([[t,x,y] for (t,x),y in sorted(obs.items())]),
             'predicted':prediction,'model_status':'BASE' if fit(obs) is not None else ('EXTENDED' if candidates else 'NONE'),
             'candidate_count':len(candidates)}
        row['precommit_sha256']=stable_hash(row)
        if arm=='triad_modular':
            specialist.append({'round':step,'V':{'evidence_hash':row['observed_hash'],'raster_decoded':len(obs)},
                'C':{'candidate_count':len(candidates),'base_fit':fit(obs) is not None}})
        y=read_glyph(api.probe(*q));obs[q]=y
        row['actual']=y;ledger.append(row)
        if trigger is None and fit(obs) is None: trigger=step
    base=fit(obs)
    candidates=models(obs,allow_extension)
    # Predictions only where EVERY current model gives same exact value;
    # candidate sets may be underdetermined: abstention counts as noncoverage.
    preds={}
    for q in ACTIONS:
        if q in obs:continue
        values=[predict(b,q,e) for _,e,b in candidates]
        preds[f'{q[0]},{q[1]}']=values[0] if values and all(v is not None and v==values[0] for v in values) else None
    extensions=sorted(set(e for _,e,b in candidates if e is not None))
    state='MODEL_INADEQUATE' if not candidates else ('UNDERDETERMINED' if len(candidates)>1 else 'COMPATIBLE_NOT_CERTIFIED')
    return {'world':opaque_id,'arm':arm,'seed':seed,'state':state,'global_certified':False,
       'origin_claim':None,'trigger_step':trigger,'query_count':len(ledger),'ledger':ledger,
       'observed':[[t,x,y] for (t,x),y in sorted(obs.items())],
       'prediction':preds,'compatible_count':len(candidates),'base_compatible':base is not None,
       'extension_candidates':extensions,'specialist_messages':specialist,
       'ledger_sha256':stable_hash(ledger),'agent_type':'deterministic_python_not_LLM'}
