"""Technical audit and exploratory paired metrics. NOT an external scientific review."""
import argparse,hashlib,json,math,random,sys
from collections import defaultdict
from pathlib import Path
from m12_pilot import (ARMS,INITIAL,DISCOVERY,VALIDATION,make_private_world,run_arm,score,
                       stable_hash,agent_on_discovery,obs_hash,public_observations)


def readjsonl(p):return [json.loads(x) for x in open(p,encoding='utf8') if x.strip()]


def boot_ci(pairs,seed=12017,reps=4000):
    if not pairs:return None
    rng=random.Random(seed);n=len(pairs)
    vals=[]
    for j in range(reps): vals.append(sum(pairs[rng.randrange(n)] for k in range(n))/n)
    vals.sort()
    return [vals[int(0.025*reps)],vals[int(0.975*reps)-1]]


def do_audit(root):
    root=Path(root);res=root/'results'
    public=readjsonl(res/'public_agents.jsonl');scores=readjsonl(res/'scores.jsonl');private=readjsonl(res/'private_truth.jsonl')
    truth={x['opaque_world_id']:x for x in private}
    issues=[];checks=0
    by=defaultdict(dict)
    for row in public:
        worldid=row['opaque_world_id'];arm=row['arm'];key=(worldid,arm)
        checks+=1
        if worldid not in truth or arm not in ARMS or key in by:issues.append(['bad_world_arm',key])
        by[key]=row
        checks+=4
        if row['observation_count']!=20 or row['external_count']!=44:issues.append(['budgets',key])
        if row['query_locations']!=[list(q) for q in DISCOVERY+VALIDATION]:issues.append(['actions',key])
        if set(row['predictions'])!={f'{t},{x}' for t,x in __import__('m11_agent').ACTIONS if (t,x) not in INITIAL+DISCOVERY+VALIDATION}:issues.append(['holdouts',key])
        if row['historical_origin_claim'] is not None:issues.append(['provenance',key])
        if arm=='validated':
            prop=row['diagnostics']['proposal']
            if prop:
                checks+=4
                if stable_hash({k:v for k,v in prop.items() if k!='precommit_sha256'})!=prop['precommit_sha256']:issues.append(['precommit',key])
                if len(prop['defines'])!=16 or len(prop['test_actions'])!=4:issues.append(['partitions',key])
                w=truth[worldid]
                if prop['defines_sha256']!=obs_hash(public_observations(w['table'],INITIAL+DISCOVERY)):issues.append(['basis_sha',key])
                if prop['maximum_proposals']!=1:issues.append(['proposal_limit',key])
    for item in scores:
        key=item['opaque_world_id'],item['arm'];w=truth[item['opaque_world_id']]
        expected=score(by[key],w)
        checks+=6
        for metric in ('right','wrong','issued','abstained','external','status'):
            if item[metric]!=expected[metric]:issues.append(['bad_score',key,metric])
    for worldid,w in truth.items():
        checks+=2
        if any((worldid,a) not in by for a in ARMS):issues.append(['missing_arms',worldid])
        if len(w['table'])!=64:issues.append(['truth_size',worldid])
        if w['kind']=='C3':
            pair=[z for z in private if z['kind']=='C3' and z['seed']==w['seed']]
            checks+=1
            if len(pair)!=2 or pair[0]['table']!=pair[1]['table']:issues.append(['c3_pair',worldid])
    # Deterministic replay subset including every condition and every arm.
    replay=[]
    for kind in ('C1','C2','C3','C4','C5','C6'):
        w=next(x for x in private if x['kind']==kind)
        for a in ARMS:
            observed, rec=run_arm(kind,w['seed'],w['variant'],a)
            replay.append({'kind':kind,'arm':a,'world':w['opaque_world_id'],'pass':stable_hash(observed)==stable_hash(by[(w['opaque_world_id'],a)])})
            checks+=1
            if not replay[-1]['pass']:issues.append(['replay',kind,a])
    # Paired per-world all external-point rates. C3 provenance pairs grouped by seed.
    measured={k:[] for k in ('C1','C2','C3','C4','C5','C6')}
    for w in private:
        id=w['opaque_world_id'];a=next(z for z in scores if z['opaque_world_id']==id and z['arm']=='auto')
        v=next(z for z in scores if z['opaque_world_id']==id and z['arm']=='validated')
        measured[w['kind']].append({'world':id,'seed':w['seed'],'auto':a,'validated':v})
    contrasts={}
    for k,rows in measured.items():
        if k=='C3': rows=rows[::2]
        right=[(r['validated']['right']-r['auto']['right'])/44 for r in rows]
        wrong=[(r['validated']['wrong']-r['auto']['wrong'])/44 for r in rows]
        cov=[(r['validated']['issued']-r['auto']['issued'])/44 for r in rows]
        contrasts[k]={'world_units':len(rows),'delta_effective_accuracy':sum(right)/len(rows),
            'delta_wrong_per_external':sum(wrong)/len(rows),'delta_coverage':sum(cov)/len(rows),
            'exploratory_bootstrap_CI_delta_wrong':boot_ci(wrong)}
    # Compare on the exact subset of actions for which validated issued predictions.
    common={}
    for kind in ('C1','C2','C3','C4','C5','C6'):
        p_issued=p_wrong=auto_issued=auto_wrong=disagree=0
        for w in private:
            if w['kind']!=kind:continue
            va=by[w['opaque_world_id'],'validated']['predictions'];aa=by[w['opaque_world_id'],'auto']['predictions']
            for q,p in va.items():
                if p is not None:
                    p_issued+=1;p_wrong+=(p!=w['table'][int(q.split(',')[0])*16+int(q.split(',')[1])])
                    if aa[q] is not None:
                        auto_issued+=1;auto_wrong+=(aa[q]!=w['table'][int(q.split(',')[0])*16+int(q.split(',')[1])]);disagree+=(aa[q]!=p)
        common[kind]={'validated_issued':p_issued,'validated_wrong':p_wrong,'auto_issued_on_same_points':auto_issued,'auto_wrong_on_same_points':auto_wrong,'different_predictions_on_same_points':disagree}
    out={'audit_type':'INTERNAL_TECHNICAL_PILOT','status':'PASS' if not issues else 'FAIL','worlds':len(private),'executions':len(public),'checks':checks,
         'issues':issues[:50],'replays':replay,'contrasts':contrasts,'matched_prediction_subset':common,
         'scientific_promotion':False,'confirmation_run':False}
    (root/'audit'/'AUDIT_M12.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf8')
    print(json.dumps({'status':out['status'],'checks':checks,'issues':len(issues),'replays_passed':sum(x['pass'] for x in replay),'matched_C4':common['C4'],'delta_C4':contrasts['C4']},indent=2));return bool(issues)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='.');args=p.parse_args();sys.exit(do_audit(args.root))
