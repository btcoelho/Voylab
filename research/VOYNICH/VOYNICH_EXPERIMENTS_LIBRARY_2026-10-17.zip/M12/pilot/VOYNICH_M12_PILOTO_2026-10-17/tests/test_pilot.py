import unittest
from m12_pilot import (INITIAL,DISCOVERY,VALIDATION,ARMS,public_observations,make_private_world,
    agent_on_discovery,agent_finalize,run_arm,first_refutation)
from m11_agent import fit

class M12PilotTests(unittest.TestCase):
    def test_identical_observation_locations(self):
        self.assertEqual(len(set(INITIAL+DISCOVERY+VALIDATION)),20)
        for a in ARMS:
            r,_=run_arm('C1',1234,0,a)
            self.assertEqual(r['query_locations'],[list(q) for q in DISCOVERY+VALIDATION])
            self.assertEqual(r['observation_count'],20)
            self.assertEqual(len(r['predictions']),44)

    def test_extension_c1_provisional_correct_on_new_points(self):
        row,w=run_arm('C1',1234,0,'validated')
        self.assertEqual(row['status'],'EXTENSION_PROVISIONALLY_ACCEPTED')
        self.assertTrue(row['diagnostics']['precommit_verified'])
        self.assertTrue(all(p==w['table'][int(k.split(',')[0])*16+int(k.split(',')[1])] for k,p in row['predictions'].items()))

    def test_validation_rejects_c5(self):
        row,_=run_arm('C5',1234,0,'validated')
        self.assertEqual(row['status'],'EXTENSION_REJECTED_ABSTAIN')
        self.assertEqual(sum(z is not None for z in row['predictions'].values()),0)
        self.assertFalse(row['diagnostics']['accepted_provisionally'])

    def test_validation_proposal_independent_of_validation_values(self):
        w=make_private_world('C1',1234)
        first=public_observations(w['table'],INITIAL+DISCOVERY)
        pp=agent_on_discovery(first,'validated')
        observed=public_observations(w['table'],VALIDATION)
        changed={q:(v^3) for q,v in observed.items()}
        self.assertEqual(pp['proposal']['precommit_sha256'],agent_on_discovery(first,'validated')['proposal']['precommit_sha256'])
        c1,d1=agent_finalize(first,observed,'validated',pp)
        c2,d2=agent_finalize(first,changed,'validated',pp)
        self.assertEqual(d1['proposal']['precommit_sha256'],d2['proposal']['precommit_sha256'])
        self.assertTrue(c1)
        self.assertEqual(c2,[])

    def test_refuted_base_not_restored(self):
        w=make_private_world('C5',1432)
        init=public_observations(w['table'],INITIAL+DISCOVERY)
        self.assertIsNone(fit(init))
        planned=agent_on_discovery(init,'validated')
        can,diag=agent_finalize(init,public_observations(w['table'],VALIDATION),'validated',planned)
        self.assertEqual(can,[])
        self.assertEqual(diag['status'],'EXTENSION_REJECTED_ABSTAIN')
        self.assertIsNotNone(first_refutation(init))

    def test_c3_same_outputs_different_provenance(self):
        a=make_private_world('C3',1204,0);b=make_private_world('C3',1204,1)
        self.assertEqual(a['table'],b['table'])
        self.assertNotEqual(a['origin'],b['origin'])
        row,_=run_arm('C3',1204,0,'validated')
        self.assertIsNone(row['historical_origin_claim'])

    def test_no_certification_in_output(self):
        for k in ('C1','C2','C3','C4','C5','C6'):
            for a in ARMS:
                row,_=run_arm(k,1256,0,a)
                self.assertNotIn('CERTIFIED',row['status'])
                self.assertIsNone(row['historical_origin_claim'])

    def test_precommit_has_explicit_rejection_and_witness(self):
        w=make_private_world('C1',1234)
        first=public_observations(w['table'],INITIAL+DISCOVERY)
        pp=agent_on_discovery(first,'validated')['proposal']
        self.assertIn('Reject',pp['rejection_rule'])
        self.assertEqual(len(pp['test_predictions']),4)
        self.assertEqual(len(pp['defines']),16)
        self.assertIsNotNone(pp['witness'])
        self.assertEqual(pp['maximum_proposals'],1)

if __name__=='__main__':unittest.main()
