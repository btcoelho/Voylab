# M12 — Pilot protocol (development only; no confirmation claims)
Date: 2026-10-17. Protocol defined before the first M12 pilot run.

## Scientific question
Does withholding acceptance of an executable extension until independent observations test precommitted predictions reduce damaging repairs, with useful coverage, relative to automatic extension and a conservative base-only model?

## Arms
1. `auto`: M11-compatible base or one-conjunction extension, refit to all 20 observations; acceptance based on consistency, no validation gate.
2. `validated`: fit a proposal on the first 16 observations only; precommit its predictions on four further fixed probes; provisionally accept if at least 2 non-null validations and zero errors. If base or candidate is contradicted, mark it `REFUTED`, and abstain where justified; never restore the refuted base. One candidate maximum, no retries.
3. `conservative`: base linear model only, fit on all 20 observations; if refuted, abstain rather than revert.

Exactly 8 common initial observations, 8 common discovery queries, 4 common validation queries. No arm chooses query locations; causal effect is acceptance / updating, not query planning. 44 external, completely unqueried entries per world. Both pilot generator and interpreter source included; no manuscripts touched.

## Conditions
C1 genuine one-term conjunction; C2 linear; C3 two provenance labels with exactly identical observable table; C4 single sparse exception; C5 position-dependent t>=2 AND odd x; C6 two-term conjunction outside single-extension DSL. 20 independent seeds each for C1/C2/C4/C5/C6, plus 10 matched C3 pairs = 120 worlds (360 arms). Unit for causal contrasts = world, C3 paired provenance clustered.

## Hypothesis trace
Every provisional extension logs contradiction witness, proposed executable predicate, defining observations and data hash, validation forecasts and their hash BEFORE responses, rejection condition, validation actuals and outcome, and external predictions. No retraining the validated proposal on its validation inputs.

## Metrics and diagnostics
Compute correct/external points, wrong/external points, coverage = issued/external, selective error = wrong/issued, effective accuracy = correct/external. Include correct at common-issued points and policy-matched-coverage comparator via deterministic, truth-blind fixed priority sampling. Compare per-world paired differences; exploratory CIs may be computed but no scientific promotion from development.

Pilot viability checkpoints (not confirmatory gates): C1 coverage >= 70%, C2 >= 90%; reduction of harmful predictions in C4/C5/C6 compared with auto while not only abstaining; state retention when base contradicted; zero exclusive historical provenance claims. A future 5% error threshold is a confirmation-set target, NOT a rule inferred from four validation successes.

## Controls
Scripts are deterministic, no LLM calls, no hidden truth in agent input, no historical Voynich or Egerton reserve access. `private/` oracle evaluated externally by scoring script, public functions accept only observation tuples. Reports must separate mechanical assumptions from learned competence. Pilot may inform the next protocol, but confirmatory seeds/data must be new and frozen separately.
