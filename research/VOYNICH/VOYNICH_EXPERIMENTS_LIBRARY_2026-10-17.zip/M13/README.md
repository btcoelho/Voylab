# M13 — Cobertura de contextos versus desacordo entre candidatos

Estado: CONFIRMAÇÃO CONCLUÍDA, 2 PASS / 2 FAIL, 1 controlo negativo descritivo. **Sem promoção geral**.

- `RELATORIO_CIENTIFICO_M13_2026-10-17.md`: relatório com medidas, limitações, riscos e critérios.
- `RESULTADOS_RESUMO_M13.txt`: resumo para revisão externa.
- `src/`: investigador programado e corredor experimental.
- `private/`: geradores de desenvolvimento/confirmatório, usados exclusivamente pelo oracle avaliador.
- `protocol/`: protocolo de desenvolvimento, confirmação pré-registada e hashes SHA256 fixados antes dos dados da confirmação.
- `results/`: logs públicos, verdade privada e métricas por execução. A partilha da verdade é permitida apenas depois da experiência; não deve ser dada a investigadores de futuras experiências.
- `audit/`: auditor original preservado, correção de comparação JSON documentada, placar e verificações.
- `reference/`: ZIP original da experiência M12 precedente.

Reprodução (Python 3.11+):
```
PYTHONPATH=src:private python -m unittest discover -s tests -v
PYTHONPATH=src:private python src/experiment.py --stage development --output /tmp/m13_dev
PYTHONPATH=src:private python src/experiment.py --stage confirmation --per-condition 120 --output /tmp/m13_conf
python audit/score_and_audit_jsonfix.py
```

Não usar `results/` como destino de reexecuções se pretender preservar os resultados oficiais do pacote.
