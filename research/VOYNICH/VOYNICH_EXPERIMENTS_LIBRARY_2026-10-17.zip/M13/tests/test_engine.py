import unittest,sys,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'private')]
from core import *
from development_worlds import worlds
class M13Tests(unittest.TestCase):
    def test_initial_no_disagreements(self):
        for w in worlds(2):
            for t,x in INITIAL:self.assertEqual(model(w['params'],t,x,0),model(w['params'],t,x,1))
    def test_budget_and_uniqueness(self):
        for w in worlds(2):
            for p in POLICIES:
                r=run(w,p);self.assertEqual(len(r['queries']),8)
                self.assertEqual(len({(z['t'],z['x']) for z in r['queries']}),8)
                self.assertFalse(r['global_certified'])
    def test_holdout(self):
        for w in worlds(2):
            r=run(w,'hybrid'); self.assertEqual(len(r['external_predictions']),48)
            used={(v['t'],v['x']) for v in r['queries']+r['initial']}
            self.assertTrue(all((v['t'],v['x']) not in used for v in r['external_predictions']))
    def test_repair_full_regime(self):
        for w in worlds(8):
            if w['condition']=='REGIME':
                r=run(w,'hybrid');self.assertEqual(len(r['inference']['repairs']),1)
                self.assertEqual(score(w,r)['wrong'],0)
    def test_no_repair_point(self):
        for w in worlds(8):
            if w['condition']=='POINT':
                for p in POLICIES:self.assertEqual(len(run(w,p)['inference']['repairs']),0)
    def test_probes_no_truth(self):
        w=next(iter(worlds(1)))
        r=run(w,'random');self.assertNotIn('table',str(r))
    def test_deterministic(self):
        w=next(iter(worlds(1)));self.assertEqual(run(w,'hybrid'),run(w,'hybrid'))
    def test_score_identity(self):
        for w in worlds(2):
            for p in POLICIES:
                s=score(w,run(w,p));self.assertEqual(s['right']+s['wrong'],s['emitted'])
                self.assertLessEqual(s['emitted'],48)
if __name__=='__main__':unittest.main()
