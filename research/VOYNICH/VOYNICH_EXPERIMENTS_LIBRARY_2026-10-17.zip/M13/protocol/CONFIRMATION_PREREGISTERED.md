# M13 - protocol for confirmation (frozen before opening confirmation worlds)
2026-10-17. This is a NEW protocol, not retroactively changing M12. Exploratory development is separate.

## Causal question
With the same two executable candidate functions, same eight initial observations and same eight-query budget, does spending some probes on **coverage of initially unseen contexts** uncover failures shared by both candidates and improve external prediction, versus disagreement-only querying and random probing?

## Policies (same inference + repair rule)
- `disagreement`: eight probes where the two proposed functions disagree.
- `random`: eight unique uniformly sampled probes among 56 not initially observed, based on public seed only.
- `hybrid`: four disagreements plus one low-x and one high-x observation from each of two initially unseen contexts, locations sampled using only public candidate descriptions and initial values. Query schedule does not see the oracle.
Each method has equal budget. Mechanism inference: eliminate on disagreements, detect shared refutations, propose a provisional whole-context XOR residual after at least two independent contradictions with identical residual; with just one unexplained contradiction, abstain in affected context, never revalidate a refuted global model. Globally historical/casual origin not certified. This is a *hand-coded procedure*, not learned autonomous science.

## Worlds and split
Development: 25 worlds per condition, 100 worlds, 300 executions. Confirmation: 120 worlds per condition, 480 worlds, 1440 executions. Four families: `ONE` (one correct); `REGIME` (entire initially unseen context shifted via XOR, both candidates wrong); `POINT` (single random anomaly without observable clue, negative control); `HALF` (half of an unseen context shifted, adversarial stress). Initial eight cells fixed to t=0,1 x={0,4,8,12}. Candidate disagreement occurs on a subset of these seen contexts not included in the initial set. These family definitions create a deliberate advantage for context coverage; confirm only claims on these specified populations. 64 total cells per world, 48 held out per policy.

## Primary metrics
World-clustered independent units. Common-refutation detection (truth from oracle evaluator only), effective exact prediction accuracy = correct / 48 including abstention as noncorrect, coverage = emitted / 48, emitted error rate = wrong / emitted. World-level paired bootstrap, 4000 replicates seed 13017, compare hybrid-minus-disagreement and hybrid-minus-random. Report point-anomaly *hit* frequency (even when not evidence of shared contradiction), and HALF effective accuracy and emitted error to expose conservative over-abstention. No prediction is a certification of program origin.

## Confirmatory gates (fixed before confirmation generation)
- G1 REGIME: hybrid common contradiction detection >=75%, at least +15 pp above each other policy with paired bootstrap CI95 lower > 0.
- G2 REGIME: hybrid effective exact prediction >=85%, at least +10 pp above each other policy with CI95 lower > 0.
- G3 ONE: hybrid effective accuracy >=95%, coverage >=95%; no global certifications.
- G4 POINT: no unsupported claim of systematic superiority over random at spotting uniformly uncued exceptions; report effect + CI, interpret only if CI excludes zero; never make universal anomaly-detection claim.
- G5 HALF robust transfer: hybrid effective accuracy no more than 10 pp *below* disagreement-only. This gate can fail even when G1-3 pass; failure prevents declaring broad improvement beyond full-context REGIME.

## Known limitations
Half-context changes are not representable by the provisional whole-context repair; this branch can find a contradiction and abstain over-broadly. One-in-56 changes without clues cannot systematically be located by any non-oracular policy beyond chance. Same research group defines both candidate family and structured anomaly, so even independent generator code is not independence of task design. No genuine visual processing or agent LLM. Calibration, model-selection, and alternative downstream repairs are later experiments.
