M13 DEVELOPMENT protocol 2026-10-17
The M12 fixed acceptance gate is retired. Compare exactly 3 methods with identical initial examples, same two executable candidate hypotheses, equal budget of eight queries: disagreement-only, random, hybrid(4 disagreements+4 domain coverage).
Worlds ONE true candidate; REGIME both candidates wrong on whole previously unobserved context; POINT one uncued exception uniform outside the initial set; HALF previously unobserved context high-x half altered, a hard stress case. No visual Voynich/Egerton data.
A possible provisional context XOR repair is permitted after >=2 independent common contradictions with identical residual. One contradiction is logged, not enough to patch. Global origin never certified. Direct private truth is only provided to evaluator, not investigator API. Evaluate 48 holdout cells.
Exploratory development can change code before confirmation lock; confirmation generator code is separate but families defined by same researchers.
