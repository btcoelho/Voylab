# Projeto Voynich — M13: Desacordo versus cobertura de contextos

**Data:** 17 outubro 2026.  
**Estado:** desenvolvimento + confirmação sintética + auditoria concluídos.  
**Decisão SCI-GOV:** `NO_GENERAL_PROMOTION`; apenas ganho localizado em mudanças de regime que abrangem um contexto inteiro. Dois dos quatro gates quantitativos decisivos passaram; um controlo negativo é descritivo. Esta não é evidência de capacidade geral de descobrir novos mecanismos.

## 1. Motivação

A M12 anterior mostrou que exigir validação fixa após a eliminação simples de candidatos pode sacrificar descobertas corretas; a recusa aleatória naquela versão tinha blocos de risco idêntico, tornando inevitável o empate. A hipótese testada na M13 foi:

> Dedicar parte de um orçamento fixo à cobertura de contextos ainda pouco observados encontra mais contradições partilhadas pelos modelos e permite melhorar previsões externas, sem destruir a capacidade de distinguir candidatos?

A M12 original e o seu relatório estão preservados no ZIP de referência; **nenhum gate ou resultado M12 foi reinterpretado como confirmação M13**.

## 2. Desenho e limitações dos geradores

- Domínio sintético: 64 entradas `(t,x)`, com `t` de 0 a 3 e `x` de 0 a 15; cada saída é um inteiro 0–15, representável como glifo artificial 2×2. Não se processaram manuscritos reais.
- Agente recebe dois programas executáveis, produzidos pelo gerador, mas não o índice verdadeiro nem a tabela privada; ambos partilham as oito observações iniciais `(t=0,1; x=0,4,8,12)`. Os candidatos discordam apenas em certos valores dos contextos iniciais não observados.
- Cada política tem **oito consultas adicionais** e prevê as 48 entradas remanescentes. Não há informação do oracle na escolha das consultas.
- Três braços, com o **mesmo algoritmo de inferência e reparação**: `disagreement` (8 consultas de desacordo), `random` (8 consultas uniformes entre 56 pontos não observados), `hybrid` (4 desacordos e 4 observações de cobertura, duas por contexto inicial não representado, uma na metade inferior e outra na superior de x).
- Quando dois candidatos predizem o mesmo símbolo e o oracle devolve outro, regista-se uma **contradição comum**. Duas observações diferentes no mesmo contexto com residual XOR igual permitem uma **reparação provisória** para esse contexto inteiro. Uma observação contraditória apenas mantém o contexto inconclusivo e faz o agente abster-se nele. Esta regra é fornecida por programação, não aprendida.
- Quatro condições: **ONE** (um candidato integralmente correto), **REGIME** (ambos errados num contexto inteiro inicialmente não observado), **POINT** (anomalia pontual uniforme sem pistas; controlo negativo), **HALF** (mudança limitada à metade superior de um contexto não observado; stress de transferência).
- **100 mundos de desenvolvimento** (25/família; 300 execuções) e **480 mundos de confirmação** (120/família; 1.440 execuções), gerados por rotinas Python distintas e derivações determinísticas diferentes. Total **580 mundos / 1.740 execuções**.
- Os dois geradores pertencem ao mesmo laboratório e usam famílias escolhidas em comum. A própria definição REGIME favorece uma política que explora contextos ausentes no início. A independência é de *implementação e sementes*, não de desenho conceptual.

## 3. Congelamento e integridade

O piloto foi executado antes de escrever `protocol/CONFIRMATION_PREREGISTERED.md` e `protocol/FREEZE.json`, com SHA256 de oito ficheiros científicos/auditoria. O manifesto foi fixado antes da geração da confirmação. O auditor inicialmente comparou `inference.failures`/`repairs` em objetos Python contendo chaves inteiras e tuplos contra JSON com chaves texto/listas; isto produziu uma discrepância falsa de replay. A versão original do auditor permanece congelada e foi acrescentada `audit/score_and_audit_jsonfix.py`, que compara os formatos JSON canónicos sem mudar geradores, dados, políticas ou critérios. `audit/AMENDMENT_AUDIT_ONLY.md` regista a mudança. O SHA256 dos oito ficheiros congelados foi revalidado.

**Oito testes passaram**. O auditor corrigido contabilizou **153.708 verificações individuais**, sem inconformidades, incluindo reconstrução da execução, exclusão dos holdouts e compromisso SHA256 das previsões dos candidatos anterior a cada resposta. Este número **não representa 153.708 experiências independentes**; a unidade inferencial é o mundo.

## 4. Confirmação: números observados

Todos os números seguintes são exclusivamente de **480 mundos novos**, 120 por condição. `Exatidão efetiva` = previsões pontuais corretas / 48 por mundo (abstenções contam como não acertos). `Cobertura` = previsões emitidas / 48. `Erro emitido` = incorretas entre emitidas. `Contradição comum` = foi observada ao menos uma resposta incompatível com ambos os candidatos.

| Condição | Política | Exatidão efetiva | Cobertura | Erros emitidos | Contradição comum |
|---|---|---:|---:|---:|---:|
| ONE | Desacordo | 100,00% | 100,00% | 0 | 0,0% |
| ONE | Aleatória | 93,89% | 93,89% | 0 | 0,0% |
| ONE | Mista | **100,00%** | 100,00% | 0 | 0,0% |
| REGIME | Desacordo | 66,67% | 100,00% | 1.920 | 0,0% |
| REGIME | Aleatória | 85,50% | 88,00% | 144 | 92,5% |
| REGIME | Mista | **100,00%** | **100,00%** | **0** | **100,0%** |
| POINT | Desacordo | 97,19% | 99,03% | 106 | 5,8% |
| POINT | Aleatória | 90,40% | 92,10% | 98 | 11,7% |
| POINT | Mista | 96,16% | 98,07% | 110 | 6,7% |
| HALF | Desacordo | **83,33%** | 100,00% | 960 | 0,0% |
| HALF | Aleatória | 73,72% | 82,31% | 495 | 76,7% |
| HALF | Mista | 70,83% | 70,83% | **0** | 100,0% |

### Inferência por mundo (bootstrap emparelhado, 4.000 reamostragens)

| Contraste | Efeito | IC95% |
|---|---:|---|
| REGIME: mista − desacordo, exatidão efetiva | **+33,33 pp** | [+33,33; +33,33] pp |
| REGIME: mista − aleatória, exatidão efetiva | **+14,50 pp** | [+11,70; +17,53] pp |
| REGIME: mista − aleatória, deteção de contradição comum | +7,50 pp | [+3,33; +12,50] pp |
| HALF: mista − desacordo, exatidão efetiva | **−12,50 pp** | [−12,50; −12,50] pp |
| HALF: mista − aleatória, exatidão efetiva | −2,88 pp | [−4,74; −1,08] pp |
| POINT: mista − aleatória, deteção comum | −5,00 pp | [−12,50; +1,67] pp |

**Interpretação crucial:** a política aleatória já identifica a anomalia estrutural REGIME em 92,5% dos mundos. A política mista chega a 100% mas o ganho de **7,5 pp em deteção** não atinge o limiar de **15 pp** pré-registado. O ganho de **14,5 pp em exatidão externa** resulta também de reunir observações suficientes para ativar a reparação contextual, não simplesmente de detetar ao menos uma contradição.

### Controlo de exceções sem pistas

Em POINT, a política mista consultou a localização anómala em **8,33%** dos mundos e a aleatória em **11,67%**. Ambos os números são compatíveis com a dificuldade de localizar uma exceção uniforme não sinalizada. O operador não tem acesso ao ponto oculto. Não alegamos superioridade sistemática em deteção de exceções invisíveis.

### Stress de meia-regra

Na condição HALF, a mista reconhece um erro comum em todos os mundos, mas vê uma contradição na metade superior e uma correspondência na metade inferior. O seu contrato requer duas contradições consistentes para reparar o contexto; como só existe uma, abstém-se em todo esse contexto. Assim, emite **zero erros** mas perde **12,5 pp de exatidão efetiva** face à estratégia baseada no desacordo. Este comportamento é mais prudente, mas menos útil à métrica pré-registada. Detetar que um mecanismo é insuficiente não equivale a reconstruí-lo.

## 5. Decisão de gates congelados

| Gate | Critério | Observado | Decisão |
|---|---|---|---|
| G1 | REGIME: deteção mista ≥75% e vantagem ≥15 pp versus cada comparador, IC95 inferior positivo | 100% vs 92,5% aleatória; +7,5 pp | **FAIL** |
| G2 | REGIME: exatidão ≥85%, vantagem ≥10 pp vs cada comparador, CI positivo | 100%; +14,5 pp vs aleatória, +33,33 pp vs desacordo | **PASS** |
| G3 | ONE: preservar ≥95% exatidão e cobertura | 100% / 100% | **PASS** |
| G4 | POINT: controlo negativo descritivo, não alegar deteção além da evidência | Hit 8,33% mista vs 11,67% aleatória | **DESCRITIVO** |
| G5 | HALF: não perder mais de 10 pp de exatidão versus desacordo | −12,5 pp | **FAIL** |

**Resultado:** 2 PASS / 2 FAIL, mais um controlo descritivo. A hipótese de cobertura teve sucesso **localizado** em REGIME, mas o gate de detetar melhor do que a aleatória falhou e a extensão para meia-regra falhou. **NÃO PROMOVER** como política geral de investigação, síntese aberta ou autonomia científica. Preservar o método como instrumento exploratório de cobertura de domínio.

## 6. O que ficou sem demonstrar

- A melhoria de REGIME foi obtida em mundos construídos com a diferença precisamente num dos contextos antes não observados; a política mista foi concebida para explorar esses contextos. Testar outra topologia de falhas e outros geradores será fundamental.
- A reparação contextual é programada, com XOR constante por contexto; não representa mecanismo descoberto autonomamente.
- O agente não aprende a política de consultas: três algoritmos determinísticos são comparados, não três investigadores neurais independentes.
- Em HALF há melhoria da deteção mas menor exatidão efetiva, demonstrando que melhores observações podem resultar em menos respostas sem aumentar poder explicativo.
- Nada testa escrita histórica, semântica do Voynich, novas gramáticas desconhecidas ou especialistas TRIAD reais.
- Truth isolada logicamente por API e logs separados, não por processos/OS com permissões isoladas.

## 7. Continuação justificada

A próxima pergunta não é se um gate de validação é mais rígido. É se uma política de cobertura **adaptativa ao tipo de contradição**, mas ainda cega para a verdade, consegue aprender uma regra condicional provisória em HALF sem abster-se em todo o contexto nem inventar uma exceção em POINT. Requer mecanismos e geradores distintos, reanálise do risco a cobertura equiparada e uma nova confirmação pré-registada. Não retocar os gates M13 após conhecer estes resultados.

## 8. Reprodução

```bash
ROOT=VOYNICH_M13_COBERTURA_2026-10-17
cd "$ROOT"
PYTHONPATH=src:private python -m unittest discover -s tests -v
PYTHONPATH=src:private python src/experiment.py --stage development --output /tmp/m13_dev_replay
PYTHONPATH=src:private python src/experiment.py --stage confirmation --per-condition 120 --output /tmp/m13_confirmation_replay
python audit/score_and_audit_jsonfix.py
```

O auditor reporta sobre os resultados oficiais incluídos em `results/`; para não os substituir, executar os replay com outro destino. O protocolo e o SHA256 congelados ficam em `protocol/`. As reservas Voynich e Egerton não foram usadas.
