"""Run M13 without ever passing world metadata to the agent."""
import argparse,json,sys,pathlib
from core import POLICIES,run,score,canon

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['development','confirmation'],required=True)
    ap.add_argument('--per-condition',type=int);ap.add_argument('--output',required=True)
    args=ap.parse_args()
    root=pathlib.Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(root/'private'))
    if args.stage=='development':from development_worlds import worlds; n=args.per_condition or 25
    else:from confirmation_worlds import worlds;n=args.per_condition or 100
    out=pathlib.Path(args.output);out.mkdir(parents=True,exist_ok=True)
    pubs=[];secrets=[];rows=[]
    for w in worlds(n):
        secrets.append(w)
        for pol in POLICIES:
            r=run(w,pol);pubs.append(r);rows.append(score(w,r))
    for name,data in [('private_truth.jsonl',secrets),('public_runs.jsonl',pubs),('scores.jsonl',rows)]:
        with (out/name).open('w') as f:
            for z in data:f.write(canon(z)+'\n')
    print(canon({'stage':args.stage,'n_worlds':len(secrets),'n_executions':len(pubs),'output':str(out)}))
if __name__=='__main__':main()
