"""M13: small deterministic synthetic investigator. No Voynich or historical data."""
import hashlib
import json
import random
from dataclasses import dataclass

DOMAIN = [(t,x) for t in range(4) for x in range(16)]
INITIAL = [(t,x) for t in (0,1) for x in (0,4,8,12)]
BUDGET = 8
POLICIES = ('disagreement', 'random', 'hybrid')

def canon(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',',':'))

def sha(x):
    return hashlib.sha256(canon(x).encode()).hexdigest()

def model(params, t, x, k):
    a,b,c,r,mask = params
    z = (a*x+b*t+c) & 15
    return z ^ (mask if k == 1 and t in (0,1) and x % 4 == r else 0)

def public_seed(params, initials, policy):
    return int(sha({'p':params,'initials':initials,'policy':policy})[:16],16)

class API:
    """Only candidate descriptions, public initial and one-point probe; no oracle table property exposed."""
    def __init__(self, answer_function, params):
        self._answer_function=answer_function
        self.params=tuple(params)
        self.initial=[{'t':t,'x':x,'y':answer_function(t,x)} for t,x in INITIAL]
        self._observed=set(INITIAL)
        self.history=[]
    def probe(self,t,x,commit):
        assert (t,x) in DOMAIN and (t,x) not in self._observed
        assert len(self.history)<BUDGET
        assert isinstance(commit,str) and len(commit)==64
        self._observed.add((t,x))
        y=self._answer_function(t,x)
        self.history.append({'t':t,'x':x,'prediction_sha256':commit,'y':y})
        return y

def choose_probes(params, initials, policy):
    rng=random.Random(public_seed(params,initials,policy))
    unseen=[z for z in DOMAIN if z not in INITIAL]
    disag=[z for z in unseen if model(params,*z,0)!=model(params,*z,1)]
    if policy=='disagreement':
        rng.shuffle(disag)
        return disag[:BUDGET]
    if policy=='random':
        return rng.sample(unseen,BUDGET)
    if policy=='hybrid':
        # Four disagreements (candidate selection); then balanced coverage of currently
        # unrepresented contexts, two probes each and both halves of the x-domain.
        a=disag[:]
        rng.shuffle(a)
        selected=a[:4]
        seen_contexts={r['t'] for r in initials}
        unseen_contexts=[t for t in range(4) if t not in seen_contexts]
        for t in unseen_contexts:
            for half in (0,1):
                candidates=[(t,x) for x in range(half*8,(half+1)*8) if (t,x) not in selected]
                selected.append(rng.choice(candidates))
        assert len(selected)==BUDGET
        return selected
    raise ValueError(policy)

def infer(params, initials, history):
    # Candidates are distinguished only by actual discriminating observations.
    votes=[]; failures={}
    for v in initials+history:
        t,x,y=v['t'],v['x'],v['y']
        p=[model(params,t,x,k) for k in (0,1)]
        if p[0]!=p[1]:
            if y in p:
                votes.append(p.index(y))
            else:
                failures.setdefault(t,[]).append((x,y^p[0]))
        elif y!=p[0]:
            failures.setdefault(t,[]).append((x,y^p[0]))
    selected = votes[0] if votes and len(set(votes))==1 else None
    repairs={}
    for t,events in failures.items():
        # No acceptance from one anomaly. Require two independently queried distinct
        # locations with precisely the same residual, then provisional context patch.
        if len(events)>=2 and len({x for x,_ in events})>=2 and len({d for _,d in events})==1:
            repairs[t]=events[0][1]
    return {'selected':selected,'votes':votes,'failures':failures,'repairs':repairs}

def decide_predict(params, derived, t, x):
    # An unvalidated context with a shared contradiction remains unresolved.
    if t in derived['failures'] and t not in derived['repairs']:
        return None
    preds=[model(params,t,x,k) for k in (0,1)]
    if derived['selected'] is None:
        if preds[0]!=preds[1]: return None
        pred=preds[0]
    else: pred=preds[derived['selected']]
    return pred ^ derived['repairs'].get(t,0)

def run(world, policy):
    params=tuple(world['params'])
    # Exactly one permitted query function; investigator never receives hidden metadata.
    truth=world['table']; oracle=lambda t,x:truth[t*16+x]
    api=API(oracle,params)
    chosen=choose_probes(params,api.initial,policy)
    for t,x in chosen:
        commitment=sha({'t':t,'x':x,'candidate_predictions':[model(params,t,x,k) for k in (0,1)],
                        'prior_observations':api.initial+api.history})
        api.probe(t,x,commitment)
    inferred=infer(params,api.initial,api.history)
    heldout=[(t,x) for t,x in DOMAIN if (t,x) not in set(INITIAL+chosen)]
    preds=[]
    for t,x in heldout:
        y=decide_predict(params,inferred,t,x)
        preds.append({'t':t,'x':x,'prediction':y})
    return {'world_id':world['id'],'policy':policy,'params':list(params),'initial':api.initial,
            'queries':api.history,'inference':inferred,'external_predictions':preds,
            'global_certified':False}

def score(world,run):
    truth=world['table']; predictions=run['external_predictions']
    assert len(predictions)==48
    shown=[p for p in predictions if p['prediction'] is not None]
    right=sum(p['prediction']==truth[p['t']*16+p['x']] for p in shown)
    wrong=len(shown)-right
    common=sum(1 for p in run['queries'] if p['y'] not in [model(world['params'],p['t'],p['x'],k) for k in (0,1)])
    anomaly_hit=any((p['t'],p['x']) in [tuple(v) for v in world['anomaly_positions']] for p in run['queries'])
    return {'world_id':world['id'],'condition':world['condition'],'policy':run['policy'],
            'right':right,'wrong':wrong,'emitted':len(shown),'total':48,
            'accuracy_effective':right/48,'coverage':len(shown)/48,'error_conditional':wrong/len(shown) if shown else None,
            'common_contradiction':common>0,'n_common':common,'anomaly_hit':anomaly_hit,
            'n_repairs':len(run['inference']['repairs']), 'n_queries':len(run['queries'])}
