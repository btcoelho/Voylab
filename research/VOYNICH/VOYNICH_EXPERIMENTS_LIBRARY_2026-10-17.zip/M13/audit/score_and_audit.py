"""Independent-ish replayer and clustered summaries for M13. Not external scientific audit."""
import collections,hashlib,json,pathlib,random,sys,statistics
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from core import run,score,canon,sha,model,INITIAL,DOMAIN,POLICIES


def load(path):
    return [json.loads(x) for x in path.open() if x.strip()]

def verify_freeze():
    fr=json.loads((ROOT/'protocol/FREEZE.json').read_text())
    invalid=[]
    for f,expected in fr['sha256'].items():
        actual=hashlib.sha256((ROOT/f).read_bytes()).hexdigest()
        if actual!=expected:invalid.append(f)
    assert not invalid,invalid
    return len(fr['sha256'])

def paired_bootstrap(a,b,metric='accuracy_effective',rngseed=13017,n=4000):
    assert len(a)==len(b)
    diffs=[x[metric]-y[metric] for x,y in zip(a,b)]
    rng=random.Random(rngseed)
    nworlds=len(diffs)
    samples=[sum(diffs[rng.randrange(nworlds)] for _ in range(nworlds))/nworlds for _ in range(n)]
    samples.sort()
    return {'difference':sum(diffs)/nworlds, 'ci95':[samples[int(.025*n)],samples[int(.975*n)-1]]}

def main():
    frozen=verify_freeze();check_count=frozen;parts={}
    for stage in ('development','confirmation'):
        folder=ROOT/'results'/stage
        priv=load(folder/'private_truth.jsonl')
        pubs=load(folder/'public_runs.jsonl')
        scores=load(folder/'scores.jsonl')
        assert len(pubs)==len(scores)==3*len(priv)
        truth={w['id']:w for w in priv}
        i=0
        for w in priv:
            assert len(w['table'])==64;check_count+=64
            for policy in POLICIES:
                got=pubs[i];sc=scores[i];i+=1
                assert got['policy']==policy and got['world_id']==w['id']
                assert sc==score(w,got)
                assert run(w,policy)==got
                assert not got['global_certified']
                assert len(got['queries'])==8 and len(got['external_predictions'])==48
                assert len({(q['t'],q['x']) for q in got['queries']})==8
                assert all((q['t'],q['x']) not in INITIAL for q in got['queries'])
                assert all((q['t'],q['x']) not in INITIAL for q in got['external_predictions'])
                assert not any(z in got for z in ('table','condition','anomaly_positions','private'))
                previous=list(got['initial'])
                for q in got['queries']:
                    commitment=sha({'t':q['t'],'x':q['x'],
                                    'candidate_predictions':[model(w['params'],q['t'],q['x'],k) for k in (0,1)],
                                    'prior_observations':previous})
                    assert q['prediction_sha256']==commitment
                    previous.append(q)
                    check_count+=1
                check_count+=11+48
        parts[stage]={'worlds':len(priv),'runs':len(pubs)}
    arr=load(ROOT/'results/confirmation/scores.jsonl')
    summaries={};comparisons={}
    for cond in ('ONE','REGIME','POINT','HALF'):
        v=[z for z in arr if z['condition']==cond]
        bypol={p:sorted([z for z in v if z['policy']==p],key=lambda x:x['world_id']) for p in POLICIES}
        summary={}
        for p,rows in bypol.items():
            total=len(rows)*48
            summary[p]={'worlds':len(rows),'effective_accuracy':sum(x['right'] for x in rows)/total,
                        'coverage':sum(x['emitted'] for x in rows)/total,
                        'wrong':sum(x['wrong'] for x in rows),
                        'emitted':sum(x['emitted'] for x in rows),
                        'error_given_emitted':sum(x['wrong'] for x in rows)/max(1,sum(x['emitted'] for x in rows)),
                        'common_detection':sum(x['common_contradiction'] for x in rows)/len(rows),
                        'anomaly_hit':sum(x['anomaly_hit'] for x in rows)/len(rows),
                        'provisional_repairs':sum(x['n_repairs'] for x in rows)}
        summaries[cond]=summary
        comparisons[cond]={}
        for p in ('disagreement','random'):
            m='common_contradiction'
            comparisons[cond][f'hybrid_minus_{p}']={
                'effective_accuracy':paired_bootstrap(bypol['hybrid'],bypol[p],'accuracy_effective'),
                'common_detection':paired_bootstrap(bypol['hybrid'],bypol[p],'common_contradiction')}
    s=summaries; c=comparisons
    G={}
    G['G1_regime_common']=s['REGIME']['hybrid']['common_detection']>=.75 and all(c['REGIME'][f'hybrid_minus_{p}']['common_detection']['difference']>=.15 and c['REGIME'][f'hybrid_minus_{p}']['common_detection']['ci95'][0]>0 for p in ('disagreement','random'))
    G['G2_regime_predictions']=s['REGIME']['hybrid']['effective_accuracy']>=.85 and all(c['REGIME'][f'hybrid_minus_{p}']['effective_accuracy']['difference']>=.10 and c['REGIME'][f'hybrid_minus_{p}']['effective_accuracy']['ci95'][0]>0 for p in ('disagreement','random'))
    G['G3_one_preservation']=s['ONE']['hybrid']['effective_accuracy']>=.95 and s['ONE']['hybrid']['coverage']>=.95
    G['G4_point_descriptive_only']=None
    G['G5_half_resilience']=c['HALF']['hybrid_minus_disagreement']['effective_accuracy']['difference']>=-.10
    output={'freeze_verified_files':frozen,'checks':check_count,'stages':parts,'summary':summaries,'paired_bootstrap':comparisons,'gates':G,
            'scientific_decision':'RESTRICTED_REGIME_CAPABILITY_ONLY' if G['G1_regime_common'] and G['G2_regime_predictions'] and G['G3_one_preservation'] and not G['G5_half_resilience'] else 'SEE_GATES',
            'review':'Internal audit, not independent review; single synthetic task specification; no Voynich/Egerton data.'}
    (ROOT/'audit/AUDIT_SCORE.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'checks':check_count,'gates':G,'decision':output['scientific_decision']},ensure_ascii=False))
if __name__=='__main__':main()
