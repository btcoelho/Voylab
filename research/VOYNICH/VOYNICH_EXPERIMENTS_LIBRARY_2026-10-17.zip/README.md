# Biblioteca de experiências Voynich (M12–M17)

Recolha curada dos registos locais disponíveis em 2026-10-17 para reutilização e auditoria.

## Âmbito científico

M12–M14 são experiências com mundos sintéticos e políticas determinísticas; M15–M16 são pilotos SFT/avaliações de políticas em tarefas sintéticas; M17 é um benchmark textual sintético para descoberta e diagnóstico. **Estes pacotes não contêm experiências com fólios históricos do manuscrito Voynich ou Egerton e não demonstram descodificação do manuscrito.**

## Conteúdo

- Relatórios, protocolos, código-fonte, testes, dados públicos de desenvolvimento/validação, logs públicos de execução e resultados/placares arquivados.
- Os resultados confirmatórios e de transferência incluídos são resultados históricos concluídos; não devem ser reutilizados como amostras inéditas, treino ou nova confirmação.
- M15/M16 incluem conjuntos SFT e métricas/saídas de validação; os pesos dos adaptadores não estão incluídos.
- M17 inclui mundos e controlos de desenvolvimento e o estado de interrupção do modelo base; não inclui resultados de diagnóstico individuais.

## Exclusões deliberadas

- Diretórios `private/`, ficheiros `private_truth.jsonl` e gabaritos ocultos.
- Resultados de diagnóstico/validação M17 que possam expor uma partição reservada.
- Pesos de modelos, checkpoints, caches compiladas e ficheiros temporários.
- ZIPs de referência redundantes; a referência M12 foi incluída em forma curada, sem verdades privadas.

O manifesto `SHA256SUMS.txt` lista o hash SHA-256 de cada ficheiro incluído. O repositório de destino é privado. Não foi atribuída uma licença global; os materiais mantêm as licenças e titularidade aplicáveis.
