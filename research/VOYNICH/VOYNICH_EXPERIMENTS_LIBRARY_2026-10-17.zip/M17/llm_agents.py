"""M17 text-only wrappers for the base Qwen model and preserved M16 adapter."""
import json
import warnings

from action_utils import first_json_object
from unsloth import FastLanguageModel


BASE_MODEL = "unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit"


class UnslothJSONAgent:
    def __init__(self, model_path=BASE_MODEL, adapter=False, max_length=1024):
        self.model, self.tokenizer = FastLanguageModel.from_pretrained(
            model_name=str(model_path), max_seq_length=max_length, dtype=None, load_in_4bit=True
        )
        FastLanguageModel.for_inference(self.model)
        self.max_length = max_length
        self.last_feedback = None

    def feedback(self, value):
        self.last_feedback = value

    def act(self, state):
        prompt_state = dict(state)
        if self.last_feedback is not None:
            prompt_state["previous_action_feedback"] = self.last_feedback
            self.last_feedback = None
        content = json.dumps(prompt_state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        prompt = self.tokenizer.apply_chat_template(
            [{"role": "user", "content": content}], tokenize=False, add_generation_prompt=True
        )
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True,
                                max_length=self.max_length).to(self.model.device)
        # The adapter stores a very large default max_length. The action is short,
        # so suppress only Transformers' repeated max-length precedence warning.
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message="Both `max_new_tokens`.*")
        output = self.model.generate(**inputs, max_new_tokens=192, do_sample=False,
                                         pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id)
        text = self.tokenizer.decode(output[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)
        return first_json_object(text) or {"action": "invalid_model_output"}


class BaseQwenAgent(UnslothJSONAgent):
    def __init__(self, max_length=1024):
        super().__init__(BASE_MODEL, max_length=max_length)


class M16AdapterAgent(UnslothJSONAgent):
    def __init__(self, adapter_path, max_length=1024):
        super().__init__(adapter_path, max_length=max_length)

