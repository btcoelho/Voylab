"""Non-trained reference and control policies for M17."""
import random

from generator import _compatible, _input_key, _predict


def _conflict(rows):
    groups = {}
    for row in rows:
        groups.setdefault(_input_key(row["input"]), []).append(row)
    for key, group in groups.items():
        if len({r["output"] for r in group}) > 1:
            return key, group
    return None, None


def _pair_effect(rows):
    for i, a in enumerate(rows):
        for b in rows[i + 1:]:
            x, y = a["input"], b["input"]
            if ((x["glyph"], x["setting"], x["phase"])
                    == (y["glyph"], y["setting"], y["phase"])
                    and x["partner"] != y["partner"] and a["output"] != b["output"]):
                return a, b
    return None, None


def _phase_effect(rows):
    for i, a in enumerate(rows):
        for b in rows[i + 1:]:
            x, y = a["input"], b["input"]
            if x["glyph"] == y["glyph"] and x["phase"] != y["phase"] and a["output"] != b["output"]:
                return a, b
    return None, None


class StatisticalAnomalyDetector:
    """Simple residual detector: checks duplicate conflicts and the working account."""

    def feedback(self, value):
        pass

    def report(self, state):
        rows = state["observations"]
        key, group = _conflict(rows)
        if key:
            key_dict = dict(zip(("glyph", "setting", "partner", "phase"), key))
            return {"action": "report", "verdict": "rejected", "candidate_model_codes": [],
                    "evidence_ids": [r["id"] for r in group],
                    "location": {"feature": "input", "value": key_dict},
                    "confidence": 0.95, "explanation": "Repeated input has conflicting outputs."}
        working = state["working_model"]
        # The three published model forms are fixed by the environment contract.
        if "only on glyph" in working["statement"]:
            kind = "glyph"
        elif "only on setting" in working["statement"]:
            kind = "setting"
        else:
            kind = "glyph_phase"
        card = {"kind": kind, "table": working["table"]}
        residuals = [r for r in rows if _predict(card, r["input"]) != r["output"]]
        if not residuals:
            return {"action": "report", "verdict": "supported",
                    "candidate_model_codes": [working["id"]],
                    "evidence_ids": [r["id"] for r in rows[:3]], "location": {"feature": None, "value": None},
                    "confidence": 0.65, "explanation": "No residual against the working account."}
        phase_pair = _phase_effect(rows)
        pair_pair = _pair_effect(rows)
        if phase_pair[0]:
            evidence = list(phase_pair)
            location = {"feature": "phase", "value": [r["input"]["phase"] for r in evidence]}
        elif pair_pair[0]:
            evidence = list(pair_pair)
            location = {"feature": "partner", "value": [r["input"]["partner"] for r in evidence]}
        else:
            evidence = residuals[:3]
            location = {"feature": None, "value": None}
        return {"action": "report", "verdict": "rejected",
                "candidate_model_codes": [], "evidence_ids": [r["id"] for r in evidence],
                "location": location, "confidence": 0.7,
                "explanation": "The working account has residuals."}

    def act(self, state):
        return self.report(state)


class RandomQueryControl:
    def __init__(self, seed=0):
        self.rng = random.Random(seed)
        self.detector = StatisticalAnomalyDetector()

    def feedback(self, value):
        pass

    def act(self, state):
        if state["remaining_query_budget"] > 0 and state["query_menu"]:
            return {"action": "query", "query_id": self.rng.choice(state["query_menu"])["id"]}
        return self.detector.report(state)


class FixedQueryControl:
    def __init__(self, seed=0):
        self.detector = StatisticalAnomalyDetector()

    def feedback(self, value):
        pass

    def act(self, state):
        if state["remaining_query_budget"] > 0 and state["query_menu"]:
            return {"action": "query", "query_id": state["query_menu"][0]["id"]}
        return self.detector.report(state)

