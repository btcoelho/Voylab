# M14-R — desenvolvimento exploratório (não confirmatório)

Data: 17-10-2026. Consultas: oito iniciais, 12 adicionais iguais para todos os braços; saídas 0–15 em 64 entradas; 44 holdouts por mundo.

CLEAN: sem alteração. LOCAL: alteração XOR condicional na metade alta de um contexto. CROSS: alteração XOR na metade alta dos dois contextos finais. POINT: uma exceção pontual sem pista (controlo negativo). Novidade programática: extensão entre operadores já fornecidos, não descoberta aberta de mecanismos.

O desenvolvimento (20 mundos/família × três políticas) encontrou ganhos de consenso em LOCAL/CROSS; não ultrapassou o comportamento conservador em POINT. Os mundos devem ser separados por semente/família na confirmação; as condições CLEAN/LOCAL/CROSS/POINT representam estruturas conhecidas em desenvolvimento, não transferência fora da linguagem.

Todos os braços recebem as mesmas 12 observações adicionais de um plano estratificado dependente só dos parâmetros públicos e iniciais: quatro para identificar o candidato base, oito para cobrir quadrantes de x nos contextos 2 e 3. Isto **não testa aprendizagem de escolher consultas**.

Reparação por consenso só prevê quando todas as expressões executáveis ainda compatíveis concordam. Os operadores admitidos (máscaras XOR de um bit, predicados de contexto, metade e paridade) são congelados no código. A hipótese estrutural de mudança XOR condicional pode falhar fora da DSL; testá-la-emos num mecanismo de janela móvel em transferência.
