# M14-R — protocolo de confirmação PRE-REGISTADO (antes de abrir os dados)

Data de congelamento: 2026-10-17. Estado: pronto para confirmação e transferência. **Nenhum dado de confirmação/transferência foi analisado na definição destes gates.**

## Pergunta
Depois de uma contradição, manter reparações condicionais concorrentes e emitir previsões só onde concordam permite recuperar previsões corretas sem excesso de erro, face a suspender todo o contexto e a memorizar anomalias?

## Braços (mesmo total de observações e consultas idênticas)
- `suspend_context`: abster-se nos contextos contraditos, preservando outros contextos.
- `memorize_observed`: guardar exceções pontuais observadas, mas usar a hipótese base noutros pontos; controlo contra generalização ausente.
- `repair_consensus`: enumerar reparações executáveis compatíveis com todas as observações, sem escolher uma causa única, emitindo previsão apenas onde todas concordam. Se nenhuma reparação encaixar, suspender apenas contextos observadamente contraditos.

O conjunto inicial de candidatos k=0/1 e os parâmetros públicos são idênticos. Os 8 iniciais + 12 probes são partilhados. Nenhuma política usa o gerador, localização de anomalias, ou holdout na escolha de consulta. O registo de cada previsão fica congelado antes da avaliação externa. Não são feitas afirmações causais únicas.

## Mundos e isolamento
- Desenvolvimento (já observado): 20×4=80 mundos, 240 execuções.
- Confirmação: 80×4=320 mundos, 960 execuções, gerador de streams BLAKE2 separado do desenvolvimento.
- Transferência: 80 mundos, 240 execuções, janela deslocada entre dois contextos que **não é expressável** pela DSL de reparações. Gerador SHAKE256+Random próprio.
- Total previsto: 480 mundos, 1440 execuções.

Observações iniciais: `(t in 0,1; x in 0,4,8,12)`. Cada braço faz mais 12 probes, 44 pontos reservados por mundo. Unidade estatística mundo; intervalos bootstrap emparelhados por mundo (4000 reamostragens, sementes fixas). Métricas: exatidão efetiva (corretas/44), cobertura (emitidas/44), erro condicional (erradas/emitidas), erro absoluto por mundo, total de reparações, contradições observadas. Relatar recusas e acertos; abstenções não contam como acertos.

## Gates principais previamente congelados
G1 — LOCAL: `repair_consensus` supera `suspend_context` em exatidão efetiva por >=10 pontos percentuais; IC95 de diferença estritamente positivo.
G2 — CROSS: o mesmo ganho >=10 pontos percentuais, IC95 positivo.
G3 — LOCAL + CROSS: cobertura de consenso >=80% **em cada condição**, erro condicional <=5% em cada e exatidão efetiva >=80% em cada.
G4 — CLEAN: consenso preserva exatidão efetiva >=95%, cobertura >=95%, zero reparações espúrias em 80 mundos.
G5 — POINT: erros absolutos do consenso <= erros do controlo de memorização, sem falsa alegação de certeza causal; observar o que é e não é detetável.
G6 — TRANSFER: consenso melhora exatidão efetiva em >=10 pontos sobre suspensão mantendo erro condicional <=5% e cobertura >=70%. Trata-se da ambição de generalização para família não expressável; uma falha significa não promover transferência.

Promover apenas o componente de previsão limitada se G1-G5 aprovados; promoção da generalização exige adicionalmente G6. **Não usar sucesso nos mundos representáveis para afirmar descoberta aberta**. Se critério limitado falha: não promover. Se transferência falha, não promover capacidade geral. Não ajustar código ou gates após abrir confirmação.

## Observabilidade e teto
Nesta versão o objetivo principal não é a taxa de deteção contra aleatório; a seleção dos 12 probes é fixa para todos os braços. Evita-se um limiar inatingível em condições com taxa de controlo elevada. Exceção invisível recebe descrição de limitação observacional, não diagnóstico de falha de raciocínio.

## Limitações pré-identificadas
- Predicados disponibilizados de antemão privilegiam LOCAL e CROSS; ganhos nestes mundos são validação delimitada de consenso, não aprendizagem de operador inesperado.
- A hipótese de conservar contextos não refutados é um pressuposto não demonstrado globalmente; o controlo de transferência procura expor a sua falha.
- A inspeção do avaliador é interna, sem isolamento de SO.
- Sem folios Voynich e sem usar os 22 fólios Egerton reservados.
