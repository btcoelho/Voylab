import sys,json,pathlib,argparse
from core import ObservationAPI,run,score,POLICIES,canonical

def generate(stage,n=None):
    root=pathlib.Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(root/'private'))
    if stage=='development':from dev_worlds import worlds;return worlds(n or 20)
    if stage=='confirmation':from confirm_worlds import worlds;return worlds(n or 80)
    from transfer_worlds import worlds
    return worlds(n or 80)

def evaluate(stage,out,n=None):
    out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True)
    with (out/'private_truth.jsonl').open('w') as truth, (out/'public_runs.jsonl').open('w') as public, (out/'scores.jsonl').open('w') as scoref:
        nworld=0
        for w in generate(stage,n):
            nworld+=1
            truth.write(canonical({**w,'anomaly_positions':sorted(w['anomaly_positions'])})+'\n')
            rows=[]
            for policy in POLICIES:
                api=ObservationAPI(lambda t,x:w['table'][16*t+x],w['params'])
                result=run(w['params'],api,policy)
                result['world_id']=w['id'];result['params']=w['params']
                rows.append(result)
                public.write(canonical(result)+'\n')
                scoref.write(canonical(score(w,result))+'\n')
            # Queries are identical for all policies, by design.
            assert all([(z['t'],z['x'],z['y']) for z in rows[0]['queries']]==[(z['t'],z['x'],z['y']) for z in z2['queries']] for z2 in rows[1:])
    return {'stage':stage,'worlds':nworld,'executions':nworld*len(POLICIES),'output':str(out)}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['development','confirmation','transfer'],required=True)
    p.add_argument('--out',required=True);p.add_argument('--n',type=int)
    a=p.parse_args();print(json.dumps(evaluate(a.stage,a.out,a.n)))
