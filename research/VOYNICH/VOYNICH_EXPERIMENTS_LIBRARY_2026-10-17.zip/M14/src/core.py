"""M14-R: synthetic program repair. No access to oracles, protected holdouts or source metadata.
The three policies share identical discovery probes; only uncertainty propagation differs.
"""
import hashlib
import json
import random
from itertools import product

DOMAIN = tuple((t,x) for t in range(4) for x in range(16))
INITIAL = tuple((t,x) for t in (0,1) for x in (0,4,8,12))
BUDGET = 12
POLICIES = ('suspend_context','memorize_observed','repair_consensus')

def canonical(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def sha(x):return hashlib.sha256(canonical(x).encode()).hexdigest()

def baseline(params,t,x,k):
    a,b,c,r,mask=params
    return ((a*x+b*t+c)&15) ^ (mask if k and t<2 and x%4==r else 0)

def predicates():
    p={
        'context_2':lambda t,x:t==2,
        'context_3':lambda t,x:t==3,
        'context_23':lambda t,x:t>=2,
        'high_x':lambda t,x:x>=8,
        'low_x':lambda t,x:x<8,
        'odd_x':lambda t,x:x%2==1,
        'even_x':lambda t,x:x%2==0,
        'x_mod4_0':lambda t,x:x%4==0,
        'x_mod4_1':lambda t,x:x%4==1,
        'x_mod4_2':lambda t,x:x%4==2,
        'x_mod4_3':lambda t,x:x%4==3,
    }
    for label,tf in [('context_2',lambda t:t==2),('context_3',lambda t:t==3),('context_23',lambda t:t>=2)]:
        for name,xf in [('high_x',lambda x:x>=8),('low_x',lambda x:x<8),
                         ('odd_x',lambda x:x%2==1),('even_x',lambda x:x%2==0)]:
            p[label+'__'+name]=(lambda tf,xf:(lambda t,x:tf(t) and xf(x)))(tf,xf)
    return p
PREDICATES=predicates()

class ObservationAPI:
    def __init__(self,oracle,params):
        self._oracle=oracle;self.params=tuple(params)
        self.initial=[{'t':t,'x':x,'y':oracle(t,x)} for t,x in INITIAL]
        self.history=[];self.seen=set(INITIAL)
    def query(self,t,x,commit):
        assert (t,x) in DOMAIN and (t,x) not in self.seen
        assert len(self.history)<BUDGET and isinstance(commit,str) and len(commit)==64
        y=self._oracle(t,x)
        self.seen.add((t,x))
        item={'t':t,'x':x,'y':y,'precommit_sha256':commit}
        self.history.append(item)
        return y

def select_queries(params,initial):
    """Predefined stratified exploration; independent of policy, seed depends on public inputs.
    Four baseline-identification probes and eight 2x4 domain-coverage probes.
    """
    r=params[3]
    probes=[(0,r),(1,r+4),(0,r+8),(1,r+12)]
    seed=int(sha({'params':params,'initial':initial,'schedule':'m14-v1'})[:16],16)
    rng=random.Random(seed)
    for t in (2,3):
        for quarter in range(4):
            candidates=[(t,x) for x in range(4*quarter,4*quarter+4)]
            probes.append(rng.choice(candidates))
    assert len(set(probes))==BUDGET and not (set(probes)&set(INITIAL))
    return probes

def fit_baselines(params,observed):
    """Infer k using clean-context observations. No truth or generator labels."""
    clean=[v for v in observed if v['t']<2]
    return [k for k in (0,1) if all(baseline(params,v['t'],v['x'],k)==v['y'] for v in clean)]

def fit_repairs(params,observed,ks):
    """Compatible minimal one-predicate repairs. Always include zero only when compatible.
    These predicates are specified before confirmation and cannot express arbitrary mechanisms.
    """
    candidates=[]
    for k in ks:
        for name,p in [('no_change',lambda t,x:False)]+list(PREDICATES.items()):
            for mask in ([0] if name=='no_change' else [1,2,4,8]):
                if all((baseline(params,v['t'],v['x'],k) ^ (mask if p(v['t'],v['x']) else 0))==v['y'] for v in observed):
                    candidates.append({'k':k,'name':name,'mask':mask})
    return candidates

def repair_predict(params,h,t,x):
    return baseline(params,t,x,h['k'])^(h['mask'] if h['name']!='no_change' and PREDICATES[h['name']](t,x) else 0)

def infer(params,observed):
    ks=fit_baselines(params,observed)
    issues=[]
    for v in observed:
        if v['t']>=2 and ks and all(baseline(params,v['t'],v['x'],k)!=v['y'] for k in ks):
            issues.append({'t':v['t'],'x':v['x'],'observed':v['y']})
    repairs=fit_repairs(params,observed,ks) if issues else []
    return ks,issues,repairs

def predict(params,policy,ks,issues,repairs,seen,t,x):
    if not ks:return None
    vals={baseline(params,t,x,k) for k in ks}
    base=next(iter(vals)) if len(vals)==1 else None
    if policy=='memorize_observed':
        # Remembering discovered exceptions has no ability to generalize to holdouts.
        if (t,x) in seen:return seen[(t,x)]
        return base
    if policy=='suspend_context':
        if t in {z['t'] for z in issues}:return None
        return base
    if policy=='repair_consensus':
        if not issues:return base
        if not repairs:
            # Do not revive a refuted base in an implicated context.
            return None if t in {z['t'] for z in issues} else base
        possible={repair_predict(params,h,t,x) for h in repairs}
        return next(iter(possible)) if len(possible)==1 else None
    raise ValueError(policy)

def run(params,api,policy):
    assert policy in POLICIES
    queries=select_queries(params,api.initial)
    for t,x in queries:
        observed=api.initial+api.history
        ks,issues,repairs=infer(params,observed)
        possible=[baseline(params,t,x,k) for k in ks]
        pre=sha({'query':[t,x],'history':observed,'possible_predictions':possible,'policy':policy})
        api.query(t,x,pre)
    observed=api.initial+api.history
    ks,issues,repairs=infer(params,observed)
    seen={(v['t'],v['x']):v['y'] for v in observed}
    unobserved=[z for z in DOMAIN if z not in seen]
    predictions=[{'t':t,'x':x,'prediction':predict(params,policy,ks,issues,repairs,seen,t,x)} for t,x in unobserved]
    # Precommit the entire external forecast before it can be scored.
    forecast_hash=sha(predictions)
    return {'policy':policy,'initial':api.initial,'queries':api.history,
            'baseline_compatible':ks,'contradictions':issues,'repair_candidates':repairs,
            'external_predictions':predictions,'external_prediction_hash':forecast_hash,
            'unique_global_provenance_claim':False}

def score(w,run):
    preds=run['external_predictions'];truth=w['table'];emitted=[p for p in preds if p['prediction'] is not None]
    correct=sum(p['prediction']==truth[16*p['t']+p['x']] for p in emitted)
    wrong=len(emitted)-correct
    return {'world_id':w['id'],'condition':w['condition'],'policy':run['policy'],
            'emitted':len(emitted),'correct':correct,'wrong':wrong,'total':len(preds),
            'coverage':len(emitted)/len(preds),'effective_accuracy':correct/len(preds),
            'conditional_error':wrong/len(emitted) if emitted else None,
            'contradictions':len(run['contradictions']),
            'repair_candidates':len(run['repair_candidates']),
            'anomalies_seen':sum((v['t'],v['x']) in w['anomaly_positions'] for v in run['queries']),
            'query_count':len(run['queries'])}
