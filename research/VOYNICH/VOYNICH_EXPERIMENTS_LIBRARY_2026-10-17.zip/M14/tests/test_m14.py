import unittest
from core import *
class Repairs(unittest.TestCase):
    def setUp(self):self.p=[3,7,2,1,4]
    def test_baseline(self):self.assertEqual(baseline(self.p,2,7,0),((3*7+7*2+2)&15))
    def test_scheduling(self):
        api=ObservationAPI(lambda t,x:baseline(self.p,t,x,1),self.p)
        q=select_queries(self.p,api.initial)
        self.assertEqual(len(q),12);self.assertEqual(len(set(q)),12);self.assertFalse(set(q)&set(INITIAL))
    def test_no_anomaly(self):
        obs=[{'t':t,'x':x,'y':baseline(self.p,t,x,1)} for t,x in INITIAL+tuple(select_queries(self.p,[]))]
        ks,issues,repairs=infer(self.p,obs)
        self.assertEqual(ks,[1]);self.assertFalse(issues)
    def test_local_repair_true(self):
        observations=[{'t':t,'x':x,'y':baseline(self.p,t,x,0)^(4 if t==2 and x>=8 else 0)} for t,x in DOMAIN]
        ks,issues,repairs=infer(self.p,observations)
        self.assertTrue(any(z['name']=='context_2__high_x' and z['mask']==4 for z in repairs))
        self.assertTrue(issues)
    def test_memorization_does_not_generalize(self):
        self.assertEqual(predict(self.p,'memorize_observed',[0],[{'t':2,'x':8}],[],{},2,9),baseline(self.p,2,9,0))
    def test_suspend_never_revives_contradicted(self):
        self.assertIsNone(predict(self.p,'suspend_context',[0],[{'t':2,'x':8}],[],{},2,9))
    def test_consensus_rejects_empty(self):
        self.assertIsNone(predict(self.p,'repair_consensus',[0],[{'t':2,'x':8}],[],{},2,9))
    def test_oracle_no_double_observe(self):
        api=ObservationAPI(lambda t,x:0,self.p)
        with self.assertRaises(AssertionError):api.query(0,0,'x'*64)
    def test_consensus_agreement(self):
        repairs=[{'name':'context_2__high_x','mask':4,'k':0},{'name':'context_23__high_x','mask':4,'k':0}]
        out=predict(self.p,'repair_consensus',[0],[{'t':2,'x':8}],repairs,{},2,9)
        self.assertEqual(out,baseline(self.p,2,9,0)^4)
        self.assertIsNone(predict(self.p,'repair_consensus',[0],[{'t':2,'x':8}],repairs,{},3,9))

if __name__=='__main__':unittest.main()
