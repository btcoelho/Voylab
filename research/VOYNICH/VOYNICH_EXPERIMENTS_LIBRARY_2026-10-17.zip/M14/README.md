# Projeto Voynich — M14-R, Reparações Concorrentes

Experiência reprodutível, com código-fonte, ficheiros públicos e verdades privadas para auditoria. A política não recebe a verdade privada durante as consultas.

- `src/core.py`: contrato observacional, três políticas, biblioteca de reparações, compromisso de previsão.
- `src/experiment.py`: execução de desenvolvimento/confirmatório/transferência.
- `private/`: geradores independentes de implementação e famílias de teste. **Não disponibilizar ao investigador.**
- `protocol/`: desenvolvimento exploratório, critérios congelados e SHA256 das fontes.
- `results/*/`: `public_runs.jsonl`, `scores.jsonl`, `private_truth.jsonl` (verdade **privada**, só para avaliação).
- `audit/`: estatística por mundo e auditoria com emenda pós-confirmação explicitada. A auditoria original reprovada está guardada.
- `tests/`: nove testes de regressão.
- `reference/`: ZIP completo M13, de onde se recuperou a estrutura do problema.

Ler `RELATORIO_CIENTIFICO_M14_2026-10-17.md` para métricas, limites e decisão. A conclusão é **4/6 critérios científicos**, com reprovação nos controlos fora da classe de mecanismos representáveis. Não houve investigação sobre fólios históricos nem treino de LLM.

Para repetir sem alterar dados oficiais:
```
PYTHONPATH=src:private python -m unittest discover -s tests -v
PYTHONPATH=src:private python src/experiment.py --stage development --out /tmp/m14_dev_replay
PYTHONPATH=src:private python src/experiment.py --stage confirmation --out /tmp/m14_confirm_replay
PYTHONPATH=src:private python src/experiment.py --stage transfer --out /tmp/m14_transfer_replay
python audit/stats.py
python audit/audit_jsonfix.py
```
