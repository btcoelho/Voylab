# Projeto Voynich — M14-R: consenso de reparações condicionais e limites da explicação

**Data:** 17 de outubro de 2026. **Estado:** desenvolvimento, pré-registo, confirmação, transferência e auditoria concluídos. **Decisão SCI-GOV:** `4/6_PASS; NO_GENERAL_PROMOTION; NO_LIMITED_PROMOTION_UNDER_PREREGISTERED_RULE`.

## Questão científica
Depois de encontrar uma contradição, manter várias reparações executáveis compatíveis e prever **apenas onde todas concordam** permite preservar previsões corretas sem aumentar excessivamente os erros? A reparação local exige uma hipótese estrutural, não autorizada pela contradição isoladamente.

### Origem
A M13 identificou o custo de suspender todo um contexto quando apenas parte da regra muda. O presente estudo avalia a **decisão de preservar previsões**, não a descoberta de onde consultar. Não recupera diretamente texto Voynich e não usa modelos de linguagem, visão computacional ou agentes independentes. É Python determinístico com operadores de reparação escritos por nós.

## Desenho e orçamento igual
- Espaço de entrada: `(t,x)` com t=0,1,2,3 e x=0..15, saídas de quatro bits representadas por símbolos 0–15. Cada mundo tem **64 pontos**.
- Todas as políticas conhecem a mesma família base pública: `((a*x+b*t+c) mod 16) XOR mask_if(k && t<2 && x%4==r)`, mas não conhecem k nem os mecanismos verdadeiros adicionais.
- **8 observações iniciais +12 consultas iguais** entre os três braços; **44 observações externas reservadas** por mundo. Quatro consultas ajudam a distinguir as duas bases; oito cobrem os quadrantes de x em t=2,3, sem receber a localização de anomalias.
- Políticas: `suspend_context` (abstém-se num contexto contradito), `memorize_observed` (decora as exceções observadas, mas fora delas mantém a regra base) e `repair_consensus` (todas as reparações de um vocabulário pré-definido compatíveis com a história; previsão pontual só se todas concordarem).
- Linguagem de reparações: uma única máscara XOR de um bit, condicionada a t, metade/paridade/resto de x, ou conjunções simples t–x. **Inclui os mecanismos locais e multi-contexto de desenvolvimento** e não inclui a janela móvel da transferência.
- Gerador de desenvolvimento `random.Random`+SHA256; confirmação independente na implementação com stream BLAKE2; transferência com SHAKE256 e classe de janela deslizante não disponível na DSL. Esta é independência **de implementação/semente**, não conceptual.

**Divisão:** 80 mundos de desenvolvimento (20 por condição), 320 mundos de confirmação (80 por condição), 80 de transferência. **480 mundos, 1.440 execuções**. O desenvolvimento informou um protocolo de confirmação, congelado em `protocol/CONFIRMATION_PREREGISTERED.md` com 10 hashes SHA256 antes de abrir confirmação e transferência. Os mecanismos e gates científicos não foram alterados posteriormente.

### Condições de confirmação
- `CLEAN`: sem mudança.
- `LOCAL`: mudança estruturada na metade alta de um contexto.
- `CROSS`: mudança estruturada na metade alta de dois contextos.
- `POINT`: exceção pontual, sem qualquer pista da posição — controlo negativo de observabilidade.
- `WINDOW_TRANSFER`: janela contígua deslocada sobre contextos 2 e 3, estrutura **fora da linguagem** das reparações disponíveis.

## Resultados da confirmação (80 mundos por condição)

Os valores abaixo são **acertos/44 pontos externos**, incluindo abstenções no denominador (*exatidão efetiva*), cobertura de previsões emitidas e total de erros emitidos. Não são probabilidades de recuperar a origem histórica única do mecanismo.

| Condição | Política | Exatidão efetiva | Cobertura | Erros emitidos (n/3520) |
|---|---|---:|---:|---:|
| CLEAN | Suspensão | 100,00% | 100,00% | 0 |
| CLEAN | Memorização | 100,00% | 100,00% | 0 |
| CLEAN | Consenso | **100,00%** | 100,00% | 0 |
| LOCAL | Suspensão | 72,73% | 72,73% | 0 |
| LOCAL | Memorização | 86,36% | 100,00% | 480 |
| LOCAL | Consenso | **96,70%** | 96,70% | 0 |
| CROSS | Suspensão | 45,45% | 45,45% | 0 |
| CROSS | Memorização | 72,73% | 100,00% | 960 |
| CROSS | Consenso | **100,00%** | 100,00% | 0 |
| POINT | Suspensão | 91,16% | 92,84% | 59 |
| POINT | Memorização | **98,32%** | 100,00% | 59 |
| POINT | Consenso | 91,22% | 93,52% | **81** |

Em `LOCAL`: consenso menos suspensão **+23,98 pp**, IC bootstrap emparelhado por mundo 95% **[+22,05; +25,68] pp**. Em `CROSS`: **+54,55 pp**, IC [54,55;54,55] pp — intervalo degenerado devido a um desenho que impõe resultados iguais a todos os mundos, **não garantia universal**. Em `POINT`: +0,06 pp, IC aproximado **[-0,26; +0,43] pp**, ao mesmo tempo que introduz **22 erros adicionais**. Nos 80 mundos POINT, a exceção foi observada durante as consultas em 21 mundos; em dois casos, a enumeração deixou uma reparação plausível que generalizou mal.

### Transferência (80 mundos, 3520 pontos externos por braço)

| Política | Exatidão efetiva | Cobertura | Erradas | Erro entre previsões emitidas |
|---|---:|---:|---:|---:|
| Suspensão | 54,32% | 58,75% | 156 | 7,54% |
| Memorização | 86,36% | 100,00% | 480 | 13,64% |
| Consenso | 54,32% | 59,32% | **176** | **8,43%** |

Em transferência, consenso − suspensão = **0,00 pp** de exatidão efetiva, IC95 por mundo **[-0,57; +0,45] pp**. A reparação não ganhou cobertura útil significativa e produziu mais erros; o mecanismo verdadeiro não pertence à linguagem das extensões permitidas. A regra de suspensão também já cometia erros, demonstrando que presumir intactos os contextos não contraditos é uma hipótese de estrutura, não uma verdade provada.

### Gating congelado

| Gate | Critério pré-registado | Resultado |
|---|---|---|
| G1 | Ganho do consenso vs suspensão ≥10 pp em LOCAL e IC95 inferior positivo | **PASS** (+23,98 pp) |
| G2 | Mesmo em CROSS | **PASS** (+54,55 pp) |
| G3 | LOCAL e CROSS: cobertura ≥80%, erro condicional ≤5%, exatidão ≥80% | **PASS** |
| G4 | CLEAN: ≥95% acertos, ≥95% cobertura, zero reparações espúrias | **PASS** |
| G5 | POINT: erros do consenso não superam memorização | **FAIL** (81 > 59) |
| G6 | Transferência: ganho ≥10 pp, erro condicional ≤5%, cobertura ≥70% | **FAIL** (0 pp, 8,43%, 59,32%) |

**Veredito: 4/6 PASS; não promover a capacidade geral nem promover formalmente a componente de previsão limitada sob a regra pré-registada que exigia G1–G5.** A melhoria estruturada é uma validação limitada de consenso dentro de uma DSL que já contém os mecanismos verdadeiros, não uma prova de descoberta aberta de mecanismos.

## Auditoria, controlo de fuga e limitações

- **9/9 testes unitários passaram.** O auditor corrigido verificou **194.254 unidades de integridade**, zero inconformidades, e **324 reexecuções determinísticas coincidentes** em todas as divisões. Estas são verificações individuais, não 194.254 ensaios independentes.
- As políticas recebem apenas parâmetros públicos, observações iniciais e respostas a consultas precomprometidas. O mecanismo privado, a localização de falhas e os valores externos são usados somente pelo executor e verificador. Separação lógica no mesmo processo Python, **não sandbox de SO**.
- Os pares partilham as mesmas observações, o mesmo orçamento e o mesmo conjunto inicial de hipóteses. Os hashes SHA256 das previsões externas são calculados **antes** da verificação nos 44 holdouts por mundo.
- **Emenda exclusivamente de auditoria, pós-confirmação:** o auditor original comparava coordenadas de anomalia como tuplos do Python com listas vindas de JSON, fazendo falhar a comparação da métrica `anomalies_seen`. Mantiveram-se o auditor inicial, os resultados, o protocolo e os hashes congelados; `audit/audit_jsonfix.py` normaliza somente o tipo desses campos. Conserva-se o registo original das falhas em `audit/AUDIT_M14_ORIGINAL_FAIL.json` e a descrição em `audit/AMENDMENT_AUDITOR_ONLY.md`.
- A ausência de erro observável em LOCAL/CROSS resulta de mecanismos criados na linguagem que o agente já enumera; não prova robustez na identificação de origem causal. A proveniência exclusiva é proibida por contrato e **não uma capacidade aprendida**.
- Em exceções invisíveis, o agente não pode saber a localização da falha sem dados; não lhe atribuímos capacidade sobrenatural de adivinhar. Na transferência, a fronteira de generalização encontra-se reprovada.
- **Nenhuma reserva Voynich/Egerton foi utilizada** neste trabalho.

## Próximo ensaio, não executado aqui

Focar diagnóstico explícito de *representação inadequada*: quando duas ou mais alternativas concordam, mas ambas podem falhar, procurar testes estruturais fora das regiões usadas para as ajustar, **sem fingir que uma anomalia não observável é previsível**. Separar a proteção de contextos supostamente estáveis da criação de uma DSL alternativa. Sem ampliar a linguagem após observar o conjunto reservado desta M14-R; isso exigiria novo protocolo e novas reservas. Só posteriormente ensinar um controlador neural a escolher consultas/reparações.

## Reprodução

A partir do diretório descompactado, com Python 3.11+:

```bash
PYTHONPATH=src:private python -m unittest discover -s tests -v
PYTHONPATH=src:private python src/experiment.py --stage development --out /tmp/m14_dev_replay
PYTHONPATH=src:private python src/experiment.py --stage confirmation --out /tmp/m14_confirm_replay
PYTHONPATH=src:private python src/experiment.py --stage transfer --out /tmp/m14_transfer_replay
python audit/stats.py
python audit/audit_jsonfix.py
```

Os scripts `audit/stats.py` e `audit/audit_jsonfix.py` auditam os resultados originais em `results/`. Não sobrescrever esses resultados ao repetir os ensaios, usar diretórios `/tmp/` como mostrado.
