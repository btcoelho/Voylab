"""Audits release artefacts, precommits, holdouts, paired budgets; deterministic replays."""
import sys,json,pathlib,collections,hashlib,random
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'private'))
from core import DOMAIN,INITIAL,BUDGET,POLICIES,ObservationAPI,run,score,sha,baseline,infer,canonical

def validate():
    c=0; problems=[]; bystage={};replays=0
    frozen=json.loads((ROOT/'protocol'/'SOURCE_FREEZE_SHA256.json').read_text())
    for rel,expected in frozen.items():
        p=ROOT/rel
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:problems.append('frozen source modified '+rel)
        c+=1
    for stage in ['development','confirmation','transfer']:
        p=ROOT/'results'/stage
        def read(fn):return [json.loads(s) for s in (p/fn).read_text().splitlines() if s]
        worlds=read('private_truth.jsonl');runs=read('public_runs.jsonl');scores=read('scores.jsonl')
        for w in worlds: w['anomaly_positions']=set(map(tuple,w['anomaly_positions']))  # auditor-only repair: JSON lists -> coordinate tuples
        assert len(runs)==len(scores)==len(worlds)*len(POLICIES)
        bystage[stage]={'worlds':len(worlds),'executions':len(runs)}
        worldmap={w['id']:w for w in worlds}
        runs_byid=collections.defaultdict(list)
        for r in runs:runs_byid[r['world_id']].append(r)
        rng=random.Random(99114)
        replay_ids=set(rng.sample(sorted(worldmap),min(36,len(worldmap))))
        for r,stored_score in zip(runs,scores):
            wid=r['world_id'];w=worldmap[wid]; params=w['params']
            rows=r['queries'];seen=set(INITIAL);history=[]
            assert len(rows)==BUDGET and r['policy'] in POLICIES
            assert len(r['initial'])==len(INITIAL)
            assert all(z['y']==w['table'][z['t']*16+z['x']] for z in r['initial']);c+=len(INITIAL)
            for z in rows:
                t,x=z['t'],z['x'];assert (t,x) not in seen and (t,x) in DOMAIN
                before=r['initial']+history
                ks,issues,repairs=infer(params,before)
                expected=sha({'query':[t,x],'history':before,'possible_predictions':[baseline(params,t,x,k) for k in ks],'policy':r['policy']})
                assert z['precommit_sha256']==expected
                assert z['y']==w['table'][16*t+x]
                history.append(z);seen.add((t,x));c+=3
            predictions=r['external_predictions']
            assert len(predictions)==len(DOMAIN)-len(seen)
            assert sha(predictions)==r['external_prediction_hash'];c+=1
            assert { (d['t'],d['x']) for d in predictions }==set(DOMAIN)-seen;c+=len(predictions)
            recompute=score(w,r)
            if canonical(recompute)!=canonical(stored_score):problems.append('score mismatch '+wid+r['policy'])
            c+=len(predictions)
            assert not r['unique_global_provenance_claim'];c+=1
            if wid in replay_ids:
                api=ObservationAPI(lambda t,x:w['table'][16*t+x],params)
                rr=run(params,api,r['policy'])
                # Drop labels/params, identical to investigator record.
                original={k:v for k,v in r.items() if k not in ['world_id','params']}
                assert canonical(rr)==canonical(original)
                replays+=1;c+=1
        for wid,rr in runs_byid.items():
            assert len(rr)==3
            trace=[(z['t'],z['x'],z['y']) for z in rr[0]['queries']]
            assert all(trace==[(z['t'],z['x'],z['y']) for z in run['queries']] for run in rr[1:])
            c+=2
    return {'verification_units':c,'problems':problems,'replays_identical':replays,'by_stage':bystage,
            'status':'PASS' if not problems else 'FAIL'}
if __name__=='__main__':
    result=validate();(ROOT/'audit'/'AUDIT_M14_JSONFIX.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
