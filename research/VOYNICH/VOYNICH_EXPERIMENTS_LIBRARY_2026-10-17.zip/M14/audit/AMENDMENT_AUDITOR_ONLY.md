# Auditor amendment — after confirmation / transfer

The initial frozen auditor loaded `private_truth.jsonl` as JSON. JSON converts each anomaly coordinate tuple `(t,x)` into list `[t,x]`. The source scorer uses membership `(t,x) in w['anomaly_positions']`, which then incorrectly returns false for observed anomalies if the auditor passes lists unchanged. The frozen evaluator previously operated directly on sets of tuples and recorded the correct counts. As a result, the initial auditor produced many `score mismatch` warnings on anomalies_seen **only**.

`audit/audit_jsonfix.py` is a post-confirmation amendment which converts private anomaly position arrays back to `set(map(tuple,...))` before re-scoring. Original frozen auditor, immutable scientific source code, results, performance gates, and source manifest remain untouched. Initial failed audit is retained in `audit/AUDIT_M14_ORIGINAL_FAIL.json`. Do not treat this as a clean no-amendment frozen pipeline.
