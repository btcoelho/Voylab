"""Descriptive world-level inference. Does not tune algorithms."""
import json,collections,random,statistics,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
ORDER=('suspend_context','memorize_observed','repair_consensus')

def read(stage):
    return [json.loads(l) for l in open(ROOT/'results'/stage/'scores.jsonl')]

def group(rows):
    d=collections.defaultdict(lambda:collections.defaultdict(list))
    for r in rows:d[r['condition']][r['policy']].append(r)
    return d

def summarise(rows):
    n=len(rows); emitted=sum(q['emitted'] for q in rows);right=sum(q['correct'] for q in rows)
    wrong=sum(q['wrong'] for q in rows);tot=sum(q['total'] for q in rows)
    return {'n_worlds':n,'right':right,'wrong':wrong,'emitted':emitted,'total':tot,
        'coverage':emitted/tot,'effective_accuracy':right/tot,'conditional_error':wrong/emitted if emitted else None,
        'detectable_contradictions':sum(q['contradictions']>0 for q in rows),
        'repair_has_candidates':sum(q['repair_candidates']>0 for q in rows)}

def bootstrap_diff(left,right,seed=141017,n=4000):
    byid_l={z['world_id']:z for z in left};byid_r={z['world_id']:z for z in right}
    ids=sorted(byid_l)
    assert set(ids)==set(byid_r)
    diffs=[byid_l[i]['effective_accuracy']-byid_r[i]['effective_accuracy'] for i in ids]
    rng=random.Random(seed); out=[]
    for _ in range(n):
        samp=[diffs[rng.randrange(len(diffs))] for _ in ids]
        out.append(statistics.mean(samp))
    out.sort()
    return {'point':statistics.mean(diffs),'bootstrap95':[out[int(.025*n)],out[int(.975*n)]],'n_worlds':len(ids)}

def all_stats(stage):
    g=group(read(stage));report={}
    for cond,vals in g.items():
        report[cond]={x:summarise(vals[x]) for x in ORDER}
        report[cond]['paired_consensus_minus_suspend_effective']=bootstrap_diff(vals['repair_consensus'],vals['suspend_context'])
        report[cond]['paired_consensus_minus_memorize_effective']=bootstrap_diff(vals['repair_consensus'],vals['memorize_observed'],seed=141018)
    return report
if __name__=='__main__':
    out={x:all_stats(x) for x in ['development','confirmation','transfer']}
    (ROOT/'audit'/'FINAL_SCORES.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
    for stage,conditions in out.items():
        print('\n'+stage)
        for family,score in conditions.items():
            print(family,' '.join(f"{pol}={score[pol]['effective_accuracy']:.3f}/{score[pol]['coverage']:.3f}/{score[pol]['wrong']}wrong" for pol in ORDER))
