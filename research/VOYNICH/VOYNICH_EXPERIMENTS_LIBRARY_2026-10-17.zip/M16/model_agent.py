"""Unsloth-backed agent wrapper for the live interactive episode API."""
import json
import re

from unsloth import FastLanguageModel


class UnslothSFTAgent:
    def __init__(self, adapter_path, max_length=1024):
        self.model, self.tokenizer = FastLanguageModel.from_pretrained(
            model_name=str(adapter_path), max_seq_length=max_length, dtype=None, load_in_4bit=True
        )
        FastLanguageModel.for_inference(self.model)
        self.max_length = max_length

    def feedback(self, value):
        # The next public state reflects accepted observations and budget changes.
        self.last_feedback = value

    def act(self, state):
        content = json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        prompt = self.tokenizer.apply_chat_template(
            [{"role": "user", "content": content}], tokenize=False, add_generation_prompt=True
        )
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True,
                                max_length=self.max_length).to(self.model.device)
        output = self.model.generate(**inputs, max_new_tokens=64, do_sample=False,
                                     pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id)
        text = self.tokenizer.decode(output[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)
        match = re.search(r"\{[^{}]*\}", text)
        if not match:
            return {"action": "invalid_model_output"}
        try:
            action = json.loads(match.group(0))
        except json.JSONDecodeError:
            return {"action": "invalid_model_output"}
        return action if isinstance(action, dict) else {"action": "invalid_model_output"}
