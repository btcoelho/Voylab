"""Generate teacher trajectories on development seeds only for interactive L4/L5."""
import argparse
import hashlib
import json
from pathlib import Path

from agents import InfoGainAgent
from interactive import Episode, make_world


def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def build(seed_start, n_per_level):
    records = []
    world_ids = []
    for level in ("L4", "L5"):
        for index in range(n_per_level):
            world = make_world(level, seed_start, index)
            world_ids.append({"level": level, "world_id": world["world_id"]})
            episode = Episode(world)
            teacher = InfoGainAgent()
            for _ in range(12):
                if episode.terminal:
                    break
                state = episode.state()
                action = teacher.act(state)
                records.append({
                    "prompt": [{"role": "user", "content": canonical(state)}],
                    "completion": [{"role": "assistant", "content": canonical(action)}],
                })
                response = episode.apply(action)
                if not response.get("accepted"):
                    raise RuntimeError(response)
    return records, world_ids


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(canonical(x) + "\n" for x in rows), encoding="utf-8")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "data/sft")
    p.add_argument("--train-worlds-per-level", type=int, default=80)
    p.add_argument("--validation-worlds-per-level", type=int, default=20)
    args = p.parse_args()
    train, train_worlds = build(5101, args.train_worlds_per_level)
    validation, validation_worlds = build(8207, args.validation_worlds_per_level)
    write_jsonl(args.out / "train.jsonl", train)
    write_jsonl(args.out / "validation.jsonl", validation)
    manifest = {
        "purpose": "interactive L4/L5 teacher-imitation SFT pilot",
        "generator": "M16 synthetic systems; independent seeds for train and validation",
        "train_seed": 5101, "validation_seed": 8207,
        "train_worlds": train_worlds, "validation_worlds": validation_worlds,
        "examples": {"train": len(train), "validation": len(validation)},
        "no_evaluation_seeds_used": True,
        "hidden_rule_ids_oracle_tables_in_prompts": False,
        "sha256": {name: hashlib.sha256((args.out / f"{name}.jsonl").read_bytes()).hexdigest()
                   for name in ("train", "validation")},
    }
    (args.out / "manifest.json").write_text(canonical(manifest) + "\n", encoding="utf-8")
    print(json.dumps({"train_examples": len(train), "validation_examples": len(validation),
                      "train_worlds": len(train_worlds), "validation_worlds": len(validation_worlds),
                      "out": str(args.out)}, indent=2))


if __name__ == "__main__":
    main()
