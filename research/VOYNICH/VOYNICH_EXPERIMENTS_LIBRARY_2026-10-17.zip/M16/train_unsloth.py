"""Train a separate M16 interactive-agent LoRA with Unsloth SFT."""
import argparse
import hashlib
import json
from pathlib import Path

from unsloth import FastLanguageModel
from datasets import load_dataset
from trl import SFTConfig, SFTTrainer


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", type=Path, default=Path(__file__).resolve().parent / "data/sft")
    p.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "runs/m16-l4l5-r1")
    p.add_argument("--smoke", action="store_true")
    args = p.parse_args()
    if not (args.data / "train.jsonl").exists() or not (args.data / "validation.jsonl").exists():
        raise SystemExit("Generate and audit the interactive data before training.")
    if args.smoke:
        args.output = Path("/tmp/m16-l4l5-unsloth-smoke")

    model_name = "unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit"
    max_length = 1024
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=model_name, max_seq_length=max_length, dtype=None, load_in_4bit=True
    )
    model = FastLanguageModel.get_peft_model(
        model, r=8,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        lora_alpha=16, lora_dropout=0, bias="none",
        use_gradient_checkpointing="unsloth", random_state=3407,
    )
    data = load_dataset("json", data_files={
        "train": str(args.data / "train.jsonl"),
        "validation": str(args.data / "validation.jsonl"),
    })
    config = SFTConfig(
        output_dir=str(args.output), max_length=max_length,
        per_device_train_batch_size=2, per_device_eval_batch_size=2,
        gradient_accumulation_steps=4, learning_rate=2e-4, num_train_epochs=3,
        warmup_steps=8, weight_decay=0.01, lr_scheduler_type="cosine",
        logging_steps=10, eval_strategy="steps" if args.smoke else "epoch",
        eval_steps=1 if args.smoke else None, save_strategy="no" if args.smoke else "epoch",
        save_total_limit=1, completion_only_loss=True, assistant_only_loss=False,
        dataset_num_proc=1, packing=False, report_to="none", seed=3407, data_seed=3407,
        max_steps=1 if args.smoke else -1, bf16=True, gradient_checkpointing=True,
        optim="adamw_8bit",
    )
    trainer = SFTTrainer(
        model=model, args=config, train_dataset=data["train"],
        eval_dataset=data["validation"], processing_class=tokenizer,
    )
    trainer.train()
    if not args.smoke:
        adapter = args.output / "adapter"
        trainer.save_model(str(adapter))
        tokenizer.save_pretrained(str(adapter))
        manifest = json.loads((args.data / "manifest.json").read_text(encoding="utf-8"))
        run_manifest = {
            "purpose": "synthetic interactive query/contradiction policy imitation",
            "base_model": model_name,
            "dataset_manifest_sha256": hashlib.sha256((args.data / "manifest.json").read_bytes()).hexdigest(),
            "train_examples": len(data["train"]), "validation_examples": len(data["validation"]),
            "train_worlds": len(manifest["train_worlds"]),
            "validation_worlds": len(manifest["validation_worlds"]),
            "epochs": 3, "max_length": max_length, "effective_batch_size": 8,
            "learning_rate": 2e-4, "warmup_steps": 8, "lora_rank": 8,
            "lora_alpha": 16, "seed": 3407,
            "claim_limit": "Teacher imitation on synthetic L4/L5; no evidence of independent research skill or Voynich decoding.",
        }
        (args.output / "run_manifest.json").write_text(json.dumps(run_manifest, indent=2) + "\n")
    print(f"Training complete. smoke={args.smoke}; output={args.output}")


if __name__ == "__main__":
    main()
