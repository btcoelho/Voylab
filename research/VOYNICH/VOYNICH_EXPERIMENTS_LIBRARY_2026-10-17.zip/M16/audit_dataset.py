"""Leakage, split, and action-validity audit for M16 interactive SFT files."""
import hashlib
import json
import sys
from pathlib import Path


def read_rows(path):
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x]


def main(data_dir):
    data = Path(data_dir)
    manifest = json.loads((data / "manifest.json").read_text(encoding="utf-8"))
    train_ids = {x["world_id"] for x in manifest["train_worlds"]}
    valid_ids = {x["world_id"] for x in manifest["validation_worlds"]}
    assert train_ids.isdisjoint(valid_ids)
    assert manifest["no_evaluation_seeds_used"] is True
    assert manifest["hidden_rule_ids_oracle_tables_in_prompts"] is False
    totals = {}
    for name in ("train", "validation"):
        rows = read_rows(data / f"{name}.jsonl")
        assert len(rows) == manifest["examples"][name]
        assert hashlib.sha256((data / f"{name}.jsonl").read_bytes()).hexdigest() == manifest["sha256"][name]
        for row in rows:
            assert set(row) == {"prompt", "completion"}
            state = json.loads(row["prompt"][0]["content"])
            action = json.loads(row["completion"][0]["content"])
            assert state["task"] == "investigate_unknown_transformation"
            assert "hidden_rule_id" not in state and "oracle_table" not in state
            assert action["action"] in {"query", "commit", "abstain", "search_alternatives"}
            if action["action"] == "query":
                assert action["x"] in state["available_experiments"]
                assert state["remaining_query_budget"] > 0
            elif action["action"] == "commit":
                assert action["hypothesis_id"] in {h["id"] for h in state["hypotheses"]}
            elif action["action"] == "search_alternatives":
                assert state["can_search_alternatives"] is True
        totals[name] = len(rows)
    print(json.dumps({"status": "PASS", "train_worlds": len(train_ids),
                      "validation_worlds": len(valid_ids), "examples": totals}, indent=2))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent / "data/sft")
