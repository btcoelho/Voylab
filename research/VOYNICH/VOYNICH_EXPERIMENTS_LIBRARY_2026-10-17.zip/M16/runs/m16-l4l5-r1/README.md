---
base_model: unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit
library_name: transformers
model_name: m16-l4l5-r1
tags:
- generated_from_trainer
- unsloth
- trl
- sft
licence: license
---

# Model Card for m16-l4l5-r1

This model is a fine-tuned version of [unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit](https://huggingface.co/unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit).
It has been trained using [TRL](https://github.com/huggingface/trl).

## Quick start

```python
from transformers import pipeline

question = "If you had a time machine, but could only go to the past or the future once and never return, which would you choose and why?"
generator = pipeline("text-generation", model="None", device_map="auto")
output = generator([{"role": "user", "content": question}], max_new_tokens=128, return_full_text=False)[0]
print(output["generated_text"])
```

## Training procedure

 



This model was trained with SFT.

### Framework versions

- TRL: 1.15.0
- Transformers: 5.17.0
- Pytorch: 2.14.1+cu132
- Datasets: 4.8.5
- Tokenizers: 0.23.3

## Citations



Cite TRL as:
    
```bibtex
@software{vonwerra2020trl,
  title   = {{TRL: Transformers Reinforcement Learning}},
  author  = {von Werra, Leandro and Belkada, Younes and Tunstall, Lewis and Beeching, Edward and Thrush, Tristan and Lambert, Nathan and Huang, Shengyi and Rasul, Kashif and Gallouédec, Quentin},
  license = {Apache-2.0},
  url     = {https://github.com/huggingface/trl},
  year    = {2020}
}
```