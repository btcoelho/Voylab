"""Interactive, deterministic hidden-system environments for the M16 L4/L5 pilot."""
from __future__ import annotations

import hashlib
import json
import random

DOMAIN = tuple(range(8))
QUERY_BUDGET = 4


def _rule(rule_id, description, fn):
    return {"id": rule_id, "description": description, "fn": fn}


CORE_BASE_RULES = (
    _rule("add1", "Add one, wrapping around at eight.", lambda x: (x + 1) % 8),
    _rule("add3", "Add three, wrapping around at eight.", lambda x: (x + 3) % 8),
    _rule("double", "Multiply by two, keeping only the remainder modulo eight.", lambda x: (2 * x) % 8),
    _rule("triple", "Multiply by three, keeping only the remainder modulo eight.", lambda x: (3 * x) % 8),
    _rule("xor1", "Flip the lowest binary bit.", lambda x: x ^ 1),
    _rule("xor3", "Flip the two lowest binary bits.", lambda x: x ^ 3),
    _rule("reverse3", "Reverse the order of the three binary bits.", lambda x: int(f"{x:03b}"[::-1], 2)),
    _rule("half", "Return the integer part after dividing by two.", lambda x: x // 2),
)

CORE_VARIANTS = tuple(
    _rule(f"{r['id']}_except{x}", f"Use {r['description']} except shift the output for input {x} by one.",
          lambda value, fn=r["fn"], exception=x: (fn(value) + 1) % 8 if value == exception else fn(value))
    for r in CORE_BASE_RULES
    for x in (7,)
)
CORE_RULES = CORE_BASE_RULES + CORE_VARIANTS

ALTERNATIVE_RULES = (
    _rule("square_mod8", "Square the input and keep the remainder modulo eight.", lambda x: (x * x) % 8),
    _rule("rotate_bits", "Rotate the three binary bits left by one position.", lambda x: ((x << 1) | (x >> 2)) & 7),
    _rule("odd_increment", "Add one to odd inputs; leave even inputs unchanged.", lambda x: (x + (x % 2)) % 8),
    _rule("thirds", "Return the integer part after dividing by three.", lambda x: x // 3),
)

ALTERNATIVE_VARIANTS = tuple(
    _rule(f"{r['id']}_except{x}", f"Use {r['description']} except shift the output for input {x} by one.",
          lambda value, fn=r["fn"], exception=x: (fn(value) + 1) % 8 if value == exception else fn(value))
    for r in ALTERNATIVE_RULES
    for x in (7,)
)
ALL_RULES = CORE_RULES + ALTERNATIVE_RULES + ALTERNATIVE_VARIANTS
RULES = {r["id"]: r for r in ALL_RULES}


def _fingerprint(seed, level, index):
    return hashlib.sha256(f"m16:{seed}:{level}:{index}".encode()).hexdigest()[:16]


def make_world(level: str, seed: int, index: int):
    if level not in {"L4", "L5"}:
        raise ValueError(level)
    rng = random.Random(int(hashlib.sha256(f"{seed}:{level}:{index}".encode()).hexdigest()[:16], 16))
    # L4 is an identifiable experiment-selection task over eight mechanisms.
    rule_pool = CORE_BASE_RULES if level == "L4" else ALTERNATIVE_RULES + ALTERNATIVE_VARIANTS
    feasible_worlds = []
    for candidate_rule in rule_pool:
        pairs = []
        if level == "L4":
            for x0 in DOMAIN:
                obs = [{"x": x0, "y": candidate_rule["fn"](x0)}]
                fits = [r for r in CORE_RULES if r["fn"](x0) == obs[0]["y"]]
                if len(fits) < 3:
                    continue
                ranked = []
                for x in DOMAIN:
                    if x == x0:
                        continue
                    buckets = {}
                    for rule in fits:
                        y = rule["fn"](x)
                        buckets[y] = buckets.get(y, 0) + 1
                    score = len(fits) ** 2 - sum(n * n for n in buckets.values())
                    ranked.append((score, x, buckets))
                best_score = max((row[0] for row in ranked), default=0)
                best_rows = [row for row in ranked if row[0] == best_score]
                if best_score > 0 and all(row[2][candidate_rule["fn"](row[1])] >= 2 for row in best_rows):
                    pairs.append((obs, fits))
        else:
            for x1 in DOMAIN:
                for x2 in DOMAIN:
                    if x1 >= x2:
                        continue
                    obs = [{"x": x1, "y": candidate_rule["fn"](x1)},
                           {"x": x2, "y": candidate_rule["fn"](x2)}]
                    fits = [r for r in CORE_RULES if all(r["fn"](o["x"]) == o["y"] for o in obs)]
                    if len(fits) >= 2:
                        pairs.append((obs, fits))

        if level == "L4" and pairs:
            feasible_worlds.append((candidate_rule, pairs, None))
        elif level == "L5":
            viable = []
            for candidate_observations, core_survivors in pairs:
                observed_x = {o["x"] for o in candidate_observations}
                for x in DOMAIN:
                    if x in observed_x or any(r["fn"](x) == candidate_rule["fn"](x) for r in core_survivors):
                        continue
                    challenge = {"x": x, "y": candidate_rule["fn"](x)}
                    expanded = [r for r in ALL_RULES if all(
                        r["fn"](o["x"]) == o["y"] for o in candidate_observations + [challenge]
                    )]
                    if len(expanded) >= 2:
                        viable.append((candidate_observations, core_survivors, challenge))
            if viable:
                feasible_worlds.append((candidate_rule, None, viable))

    if not feasible_worlds:
        raise RuntimeError(f"no valid world for {level}")
    hidden_rule, pairs, viable = rng.choice(feasible_worlds)
    if level == "L4":
        observations, surviving = rng.choice(pairs)
        challenge = None
    else:
        observations, surviving, challenge = rng.choice(viable)
        observations = observations + [challenge]

    return {
        "world_id": _fingerprint(seed, level, index),
        "level": level,
        "hidden_rule_id": hidden_rule["id"],
        "observations": observations,
        "challenge_x": challenge["x"] if challenge else None,
        "seed": seed,
        "index": index,
    }


def _compatible(rule_set, observations):
    return [r for r in rule_set if all(r["fn"](o["x"]) == o["y"] for o in observations)]


def _public_catalog(rule_set, observations):
    unseen = [x for x in DOMAIN if x not in {o["x"] for o in observations}]
    return [{"id": r["id"], "description": r["description"],
             "predictions": {str(x): r["fn"](x) for x in unseen}} for r in rule_set
            if all(r["fn"](o["x"]) == o["y"] for o in observations)]


class Episode:
    """Stateful oracle. The hidden rule never appears in state/action responses."""

    def __init__(self, world):
        self.world = world
        self.level = world["level"]
        self.observations = [dict(x) for x in world["observations"]]
        self.remaining = QUERY_BUDGET
        self.expanded = False
        self.terminal = False
        self.result = None
        self.invalid_actions = 0
        self.query_history = []
        self.current_rule_set = CORE_RULES

    def state(self):
        hypotheses = _public_catalog(self.current_rule_set, self.observations)
        # Prevent the public catalog's declaration order from favoring the
        # sticky-first control; this order is reproducible and truth-independent.
        order_rng = random.Random(int(self.world["world_id"], 16))
        order_rng.shuffle(hypotheses)
        used = {o["x"] for o in self.observations}
        return {
            "task": "investigate_unknown_transformation",
            "level": self.level,
            "domain": {"inputs": list(DOMAIN), "outputs": list(DOMAIN)},
            "observations": [dict(x) for x in self.observations],
            "remaining_query_budget": self.remaining,
            "available_experiments": [x for x in DOMAIN if x not in used],
            "hypotheses": hypotheses,
            "contradiction": len(hypotheses) == 0,
            "can_search_alternatives": self.level == "L5" and not self.expanded and len(hypotheses) == 0,
            "expanded_hypothesis_search_used": self.expanded,
            "allowed_actions": ["query", "commit", "abstain"] + (
                ["search_alternatives"] if self.level == "L5" and not self.expanded and len(hypotheses) == 0 else []
            ),
        }

    def apply(self, action):
        if self.terminal:
            raise RuntimeError("episode is terminal")
        if not isinstance(action, dict) or not isinstance(action.get("action"), str):
            self.invalid_actions += 1
            return {"accepted": False, "error": "action must be a JSON object with an action field"}
        kind = action["action"]
        if kind == "query":
            x = action.get("x")
            used = {o["x"] for o in self.observations}
            if not isinstance(x, int) or x not in DOMAIN or x in used or self.remaining <= 0:
                self.invalid_actions += 1
                return {"accepted": False, "error": "query must use one available input and remaining budget"}
            y = RULES[self.world["hidden_rule_id"]]["fn"](x)
            observation = {"x": x, "y": y}
            self.observations.append(observation)
            self.query_history.append(x)
            self.remaining -= 1
            return {"accepted": True, "observation": observation,
                    "contradiction": len(_compatible(self.current_rule_set, self.observations)) == 0}
        if kind == "search_alternatives":
            if self.level != "L5" or self.expanded or len(_compatible(CORE_RULES, self.observations)) != 0:
                self.invalid_actions += 1
                return {"accepted": False, "error": "alternative search is available only after core hypotheses fail"}
            self.current_rule_set = ALL_RULES
            self.expanded = True
            found = _public_catalog(self.current_rule_set, self.observations)
            return {"accepted": True, "surviving_alternatives": len(found)}
        if kind == "commit":
            rule_id = action.get("hypothesis_id")
            fits = {r["id"] for r in _compatible(self.current_rule_set, self.observations)}
            if rule_id not in fits:
                self.invalid_actions += 1
                return {"accepted": False, "error": "cannot commit to a contradicted or unknown hypothesis"}
            self.terminal = True
            self.result = {"decision": "commit", "hypothesis_id": rule_id,
                           "correct": rule_id == self.world["hidden_rule_id"]}
            return {"accepted": True, "terminal": True}
        if kind == "abstain":
            self.terminal = True
            self.result = {"decision": "abstain", "correct": False}
            return {"accepted": True, "terminal": True}
        self.invalid_actions += 1
        return {"accepted": False, "error": "unknown action"}

    def run(self, agent, max_actions=12):
        states, actions = [], []
        contradicted_commit_attempts = 0
        for _ in range(max_actions):
            if self.terminal:
                break
            state = self.state()
            states.append(state)
            action = agent.act(state)
            actions.append(action)
            if action.get("action") == "commit" and action.get("hypothesis_id") not in {
                h["id"] for h in state["hypotheses"]
            }:
                contradicted_commit_attempts += 1
            response = self.apply(action)
            if not response.get("accepted"):
                # Expose only the public protocol error so the agent can recover.
                agent.feedback(response)
            if self.remaining == 0 and not self.terminal and action.get("action") == "query":
                continue
        if not self.terminal:
            self.terminal = True
            self.result = {"decision": "forced_abstain", "correct": False}
        observed_contradiction = any(s["contradiction"] for s in states)
        abandoned_after_contradiction = False
        for state, action in zip(states, actions):
            if state["contradiction"] and action.get("action") in {"search_alternatives", "abstain"}:
                abandoned_after_contradiction = True
                break
        return {
            "world_id": self.world["world_id"], "level": self.level,
            "result": self.result, "queries": len(self.query_history),
            "query_history": self.query_history, "invalid_actions": self.invalid_actions,
            "contradicted_commit_attempts": contradicted_commit_attempts,
            "observed_contradiction": observed_contradiction,
            "abandoned_after_contradiction": abandoned_after_contradiction,
            "expanded": self.expanded, "hidden_rule_id": self.world["hidden_rule_id"],
        }


def canonical_state(state):
    return json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
