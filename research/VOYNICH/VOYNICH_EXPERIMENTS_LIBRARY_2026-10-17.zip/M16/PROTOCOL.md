# M16 L4/L5 interactive pilot — protocol frozen before model evaluation

**Status:** training and blind evaluation complete; all frozen L4/L5 gates passed on all three replacement seeds. The original provisional generator was rejected during control calibration: L4 allowed a trivial first commitment and then an over-expanded variant catalog made the reference agent abstain. Those seeds were retired before the final model evaluation. This pilot is separate from M15 and does not test images, Voynich, or historical interpretation. See `M16_FINAL_REPORT.md` and `results/gate_audit.json` for outcomes.

## Research questions

1. In L4, can an agent select experiments that reduce uncertainty among candidate systems, then commit only to a candidate supported by observations?
2. In L5, when a new observation contradicts every current hypothesis, can it stop defending the old set, search an expanded hypothesis space, use follow-up observations, or abstain when the evidence remains insufficient?

## Environment and action loop

- Inputs and outputs are integers 0–7. The evaluator owns each world's generating rule; the agent receives only observed input/output pairs, the remaining query budget, and public hypothesis descriptions/forecasts.
- Each episode allows four oracle queries. L4 starts with one observation, leaving at least three candidate mechanisms; its generator ensures the information-gain reference needs at least two further queries. The agent repeatedly returns one JSON action: `query`, `commit`, `abstain`, or (only after a contradiction in L5) `search_alternatives`. The environment returns the observed value before asking for the next action.
- L4 hidden rules come from the core catalog. L5 hidden rules come from a disjoint alternative catalog. An L5 episode begins with examples that fit multiple core rules plus a public observation that contradicts every surviving core rule. Alternative search returns all expanded-catalog rules still consistent with the public history, never the hidden rule label.
- Hidden rule IDs, truth functions, and generator state remain in the evaluator. They are excluded from every model prompt and public metric file.

## Divisions

- Training worlds use seed 5101: 80 worlds per level.
- Validation worlds use seed 8207: 20 worlds per level, disjoint from training worlds.
- Final evaluation uses replacement seeds 17021, 29027, and 43019; each has 40 L4 and 40 L5 worlds. These seeds are not used for training, validation, or model selection. Report results separately for each seed.
- This tests independent random worlds from the same rule catalogs. It is not L6 transfer to a new generator family.

## Metrics and provisional passage gates

Compare the trained agent against the information-gain teacher, random active querying, sticky-first commitment, and always-abstain controls. Use exact hidden-rule recovery, effective accuracy (abstention is zero), coverage, queries per episode, invalid actions, L5 contradiction response, and unsupported/contradicted commitments.

For each of the three evaluation seeds, all must pass:

- **L4:** effective accuracy ≥ 0.70, coverage ≥ 0.70, zero invalid actions, and effective accuracy at least 0.15 above both random active querying and sticky-first commitment.
- **L5:** valid response to the initial contradiction (search alternatives or abstain) in at least 90% of episodes; zero contradicted-commit attempts; effective accuracy ≥ 0.60; and effective accuracy at least 0.15 above always-abstain and 0.10 above random active querying.
- No aggregate may hide a failing seed. A failed gate means no passage; do not tune against these evaluation seeds.

These thresholds are provisional engineering gates, not a scientific claim. They must be reviewed against the observed controls and measurement uncertainty before any promotion. Passing them would support only this narrow synthetic behavior. L6 requires new generators and new sealed tests.

## Controls

- The evaluator emits only aggregate metrics; per-world hidden answers are not written to the public results file. Catalog order is reproducibly shuffled from a world ID independent of its hidden rule so sticky-first cannot exploit declaration order.
- The agent receives observations only after its query. It cannot request an unobserved answer except through `query`.
- Confirmation/evaluation seeds are kept out of the SFT files. No model is evaluated until this protocol and the held-out seeds are fixed.
- Record the adapter, data hashes, package versions, seed list, control results, and all gate outcomes. Do not promote on training loss alone.
