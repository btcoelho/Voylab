"""Three-seed, world-blind evaluation for a trained M16 L4/L5 adapter."""
import argparse
import json
from collections import defaultdict
from pathlib import Path

from agents import AlwaysAbstainAgent, InfoGainAgent, RandomActiveAgent, StickyFirstAgent
from interactive import Episode, make_world
from model_agent import UnslothSFTAgent


SEEDS = (17021, 29027, 43019)
CASES_PER_LEVEL = 40


def summarize(rows):
    n = len(rows)
    commits = [r for r in rows if r["result"]["decision"] == "commit"]
    correct = sum(bool(r["result"].get("correct")) for r in rows)
    committed_correct = sum(bool(r["result"].get("correct")) for r in commits)
    contradiction_rows = [r for r in rows if r["level"] == "L5"]
    return {
        "episodes": n,
        "effective_accuracy": correct / n if n else 0,
        "coverage": len(commits) / n if n else 0,
        "accuracy_when_committed": committed_correct / len(commits) if commits else None,
        "mean_queries": sum(r["queries"] for r in rows) / n if n else 0,
        "invalid_actions": sum(r["invalid_actions"] for r in rows),
        "contradicted_commit_attempts": sum(r["contradicted_commit_attempts"] for r in rows),
        "l5_contradictions": sum(r["observed_contradiction"] for r in contradiction_rows),
        "l5_correct_abandonment": sum(r["abandoned_after_contradiction"] for r in contradiction_rows),
        "l5_alternative_searches": sum(r["expanded"] for r in contradiction_rows),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--adapter", type=Path, required=True)
    p.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "results/model_eval.json")
    args = p.parse_args()

    model = UnslothSFTAgent(args.adapter)
    factories = {
        "unsloth_model": lambda seed: model,
        "information_gain_teacher": lambda seed: InfoGainAgent(),
        "random_active_control": lambda seed: RandomActiveAgent(seed),
        "sticky_first_control": lambda seed: StickyFirstAgent(),
        "always_abstain_control": lambda seed: AlwaysAbstainAgent(),
    }
    all_rows = defaultdict(list)
    by_seed = {}
    for seed in SEEDS:
        by_seed[str(seed)] = {}
        for level in ("L4", "L5"):
            for index in range(CASES_PER_LEVEL):
                world = make_world(level, seed, index)
                for name, factory in factories.items():
                    agent = factory(seed * 10000 + index)
                    outcome = Episode(world).run(agent)
                    all_rows[(name, level)].append(outcome)
                    by_seed[str(seed)].setdefault(name, {})
                    by_seed[str(seed)][name].setdefault(level, []).append(outcome)
        # Store aggregates only; hidden rule IDs and per-world outcomes are not exported.
        for name in factories:
            by_seed[str(seed)][name] = {
                level: summarize(by_seed[str(seed)][name][level]) for level in ("L4", "L5")
            }
    result = {
        "purpose": "interactive held-out evaluation; not used for training or model selection",
        "seeds": list(SEEDS), "cases_per_level_per_seed": CASES_PER_LEVEL,
        "total_worlds": len(SEEDS) * CASES_PER_LEVEL * 2,
        "aggregates": {f"{name}/{level}": summarize(rows) for (name, level), rows in all_rows.items()},
        "by_seed": by_seed,
        "hidden_rule_ids_oracle_tables_exported": False,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"out": str(args.out), "worlds": result["total_worlds"],
                      "aggregates": result["aggregates"]}, indent=2))


if __name__ == "__main__":
    main()
