# M16 — L4/L5 interactive pilot

## Outcome

The Unsloth adapter passed the pre-registered gates on all three held-out seeds. Each seed contains 40 L4 and 40 L5 worlds. The evaluator kept only aggregate results; no per-world answer key was written to the result file.

| Seed | L4 exact accuracy | L4 random control | L4 sticky control | L5 exact accuracy | L5 random control | Contradiction response |
|---|---:|---:|---:|---:|---:|---:|
| 17021 | 100% | 55% | 15% | 100% | 77.5% | 100% |
| 29027 | 100% | 70% | 20% | 100% | 82.5% | 100% |
| 43019 | 100% | 60% | 12.5% | 100% | 82.5% | 100% |

Across all 120 worlds at each level, the model made no invalid actions and no contradicted-commit attempts. It averaged 2 oracle queries in L4 and 1.01 in L5. It matched the information-gain reference on every scored world.

## Training record

- Base: `unsloth/Qwen2.5-0.5B-Instruct-bnb-4bit`
- Separate LoRA adapter: `runs/m16-l4l5-r1/adapter`
- 480 training actions from 160 development worlds; 121 validation actions from 40 disjoint worlds
- 3 epochs, rank 8, alpha 16; final validation loss 0.00008755
- Dataset manifest SHA-256: `3cfd26ee5de6a68bb9bc804d2c425081f63a5f008dd0a2a02dbb10ac466cff5e`
- Adapter weights SHA-256: `a9dc12b57d16738ace05c1d9d27a6a36445207e8f83bd8b937543c4baab33db5`

## Scope of the result

This is evidence for a narrow synthetic behavior: asking discriminative questions among a small published catalog, responding to a deliberately introduced contradiction by expanding the catalog, then testing a surviving alternative. The adapter was trained by imitating a deterministic information-gain teacher. Matching that teacher does not establish independent scientific reasoning, robust uncertainty calibration, or transfer to a new generator family.

It does not test visual recognition, image-text grounding, L6 transfer, Copiale, herbals, Voynich, or any historical interpretation. The manuscript remains outside training and evaluation. Before using Voynich, the next scientific step is to implement L6 with a genuinely new generator family and fresh blind seeds, followed by the visual levels with a model that actually accepts images.

## Reproduction

From WSL:

```bash
cd ~/voynich-lab/experiencias/M16_CURRICULO
../../.venv/bin/python audit_dataset.py
../../.venv/bin/python audit_results.py
../../.venv/bin/python evaluate_model.py --adapter runs/m16-l4l5-r1/adapter
```

The full per-seed gate audit is in `results/gate_audit.json`; aggregate evaluation is in `results/model_eval.json`.
