"""Reference and negative-control agents for the interactive L4/L5 benchmark."""
import random


class InfoGainAgent:
    """Transparent teacher: choose the query with the best forecast partition."""

    def __init__(self):
        self.last_feedback = None

    def feedback(self, value):
        self.last_feedback = value

    def act(self, state):
        hypotheses = state["hypotheses"]
        if state["contradiction"]:
            if state["can_search_alternatives"]:
                return {"action": "search_alternatives"}
            return {"action": "abstain"}
        if len(hypotheses) == 1:
            return {"action": "commit", "hypothesis_id": hypotheses[0]["id"]}
        if not hypotheses:
            return {"action": "abstain"}
        if state["remaining_query_budget"] <= 0:
            return {"action": "abstain"}
        best_x, best_score = None, -1
        for x in state["available_experiments"]:
            counts = {}
            for hypothesis in hypotheses:
                y = hypothesis["predictions"][str(x)]
                counts[y] = counts.get(y, 0) + 1
            # Maximize expected pair separation; no hidden answer is used.
            score = len(hypotheses) ** 2 - sum(n * n for n in counts.values())
            if score > best_score:
                best_x, best_score = x, score
        if best_x is None or best_score == 0:
            return {"action": "abstain"}
        return {"action": "query", "x": best_x}


class RandomActiveAgent:
    """Control: respects contradictions but chooses experiments uniformly at random."""

    def __init__(self, seed=0):
        self.rng = random.Random(seed)

    def feedback(self, value):
        pass

    def act(self, state):
        if state["contradiction"]:
            return {"action": "search_alternatives"} if state["can_search_alternatives"] else {"action": "abstain"}
        hypotheses = state["hypotheses"]
        if len(hypotheses) == 1:
            return {"action": "commit", "hypothesis_id": hypotheses[0]["id"]}
        if state["remaining_query_budget"] > 0 and state["available_experiments"]:
            return {"action": "query", "x": self.rng.choice(state["available_experiments"])}
        return {"action": "abstain"}


class StickyFirstAgent:
    """Negative control: commits to the first surviving idea and does not revise."""

    def feedback(self, value):
        pass

    def act(self, state):
        if state["hypotheses"]:
            return {"action": "commit", "hypothesis_id": state["hypotheses"][0]["id"]}
        return {"action": "abstain"}


class AlwaysAbstainAgent:
    def feedback(self, value):
        pass

    def act(self, state):
        return {"action": "abstain"}
