# M16 — Interactive synthetic investigator (L4/L5)

This package turns the investigation loop into a stateful environment: the agent chooses a query, receives only that observation, updates its hypothesis state, and then chooses again. The hidden rule stays in the evaluator. L4 tests experiment selection among known candidate families over multiple steps; L5 starts with a contradiction, requiring alternative search or abstention before further testing.

It implements L4/L5 only. The current Qwen adapter is text-only; this work does not claim visual competence for L1/L3, and it does not cover L6 transfer to new rule families. None of these tests uses Voynich/Egerton data.

## Run in WSL

```bash
cd ~/voynich-lab/experiencias/M16_CURRICULO
../../.venv/bin/python generate_sft.py
../../.venv/bin/python audit_dataset.py
../../.venv/bin/python evaluate_model.py --help
../../.venv/bin/python train_unsloth.py --smoke
```

Train a separate adapter after the smoke check:

```bash
../../.venv/bin/python train_unsloth.py
```

When training and validation are complete, run the three frozen evaluation seeds:

```bash
../../.venv/bin/python evaluate_model.py --adapter runs/m16-l4l5-r1/adapter
```

The evaluator compares the model with an information-gain teacher and three controls. Results include aggregate performance by seed and level; it does not export hidden rule IDs or per-world labels.

## Files

- `interactive.py`: generator, oracle boundary, state transitions, and episode runner.
- `agents.py`: transparent teacher and behavioral controls.
- `generate_sft.py`, `audit_dataset.py`: development-only training/validation trajectories and leakage/schema checks.
- `train_unsloth.py`, `model_agent.py`: Unsloth SFT and live interactive model wrapper.
- `evaluate_model.py`: three-seed blind evaluation against controls.
- `PROTOCOL.md`: metrics, held-out seeds, gates, and promotion limits, frozen before model evaluation.

The model is not promoted by low loss or training completion. It must pass every per-seed gate in `PROTOCOL.md`; passing supports only this synthetic task.

The current adapter and its evaluation report are in `runs/m16-l4l5-r1/adapter` and `M16_FINAL_REPORT.md`. The run passed every L4/L5 gate on three held-out seeds. It is a teacher-imitation pilot, not evidence of independent research ability or Voynich decoding.
