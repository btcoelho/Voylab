"""Apply the pre-registered per-seed M16 passage gates to aggregate-only results."""
import json
from pathlib import Path


def audit(result):
    audited = {"protocol": "M16 PROTOCOL.md gates; every seed must pass",
               "seeds": {}, "passed_all_seeds": True}
    for seed, agents in result["by_seed"].items():
        model = agents["unsloth_model"]
        random = agents["random_active_control"]
        sticky = agents["sticky_first_control"]
        abstain = agents["always_abstain_control"]
        teacher = agents["information_gain_teacher"]
        l4 = model["L4"]
        l5 = model["L5"]
        l4_checks = {
            "effective_accuracy_ge_0_70": l4["effective_accuracy"] >= 0.70,
            "coverage_ge_0_70": l4["coverage"] >= 0.70,
            "zero_invalid_actions": l4["invalid_actions"] == 0,
            "beats_random_by_0_15": l4["effective_accuracy"] >= random["L4"]["effective_accuracy"] + 0.15,
            "beats_sticky_by_0_15": l4["effective_accuracy"] >= sticky["L4"]["effective_accuracy"] + 0.15,
        }
        contrad = l5["l5_contradictions"]
        response_rate = l5["l5_correct_abandonment"] / contrad if contrad else 0
        l5_checks = {
            "contradiction_response_ge_0_90": response_rate >= 0.90,
            "zero_contradicted_commit_attempts": l5["contradicted_commit_attempts"] == 0,
            "effective_accuracy_ge_0_60": l5["effective_accuracy"] >= 0.60,
            "beats_abstain_by_0_15": l5["effective_accuracy"] >= abstain["L5"]["effective_accuracy"] + 0.15,
            "beats_random_by_0_10": l5["effective_accuracy"] >= random["L5"]["effective_accuracy"] + 0.10,
        }
        seed_pass = all(l4_checks.values()) and all(l5_checks.values())
        audited["seeds"][seed] = {
            "L4": {"model_accuracy": l4["effective_accuracy"],
                   "teacher_accuracy": teacher["L4"]["effective_accuracy"],
                   "random_accuracy": random["L4"]["effective_accuracy"],
                   "sticky_accuracy": sticky["L4"]["effective_accuracy"],
                   "checks": l4_checks},
            "L5": {"model_accuracy": l5["effective_accuracy"],
                   "teacher_accuracy": teacher["L5"]["effective_accuracy"],
                   "random_accuracy": random["L5"]["effective_accuracy"],
                   "contradiction_response_rate": response_rate,
                   "checks": l5_checks},
            "passed": seed_pass,
        }
        audited["passed_all_seeds"] &= seed_pass
    return audited


def main():
    root = Path(__file__).resolve().parent
    source = root / "results/model_eval.json"
    out = root / "results/gate_audit.json"
    report = audit(json.loads(source.read_text(encoding="utf-8")))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
